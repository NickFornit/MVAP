# Состояние проекта BEAST — снимок для нового чата

**Дата снимка:** 2026-03-21

## Зачем этот документ

Передайте файл в начале нового чата (или приложите к задаче), чтобы быстро восстановить архитектуру, точки входа в код и договорённости по логике — без разбора всей истории переписки.

## Что это за проект

- **BEAST** — браузерное приложение («Существо Beast, пульт связи»). Точка входа: **`index.html`** в корне репозитория.
- Основной код: **`beast/`** — модули в подпапках `_1_` … `_12_` (виталы, базовые контексты, стимулы, действия, рефлексы, семантика, дерево восприятия, гиппокамп/ОР, сознание/ФО, эпизодическая память, образы действия, автоматизмы, **режим сна / сновидения**).
- **Пульс:** `beast/puls.js` — тики, `global.cpuls`, диспетчер сознания, рефлексы, ЭП.
- **Персистенция:** IndexedDB, сохранение в файл (`saving_all` / UI); часть — `localStorage`.
- Рабочая копия **может быть не в git** — ориентир по файлам на диске.

## Документы в корне

| Файл | Назначение |
|------|------------|
| **`PROJECT_STATE_FOR_NEW_CHAT.md`** | Этот снимок состояния для ИИ и разработчиков |
| **`Mad_programmer_manual.md`** | Развёрнутый мануал по принципам Beast, слоям, отладке и развитию кода |

## Порядок подключения скриптов (`index.html`)

Критичен **порядок в конце `body`**. Фрагмент цепочки сознания:

`consciousness_dispatcher.js` → `infofunctions.js` → `conscious_attention_channel.js` → … → **`mental_automatism.js`** → **`conscience_level_2.js`** → **`conscience_level_3.js`** → **`conscience_level_4.js`** → **`gestalt.js`** → … → **`abstract_images.js`** → **`episodic_memory.js`** → …

`gestalt.js` должен быть подключён **до** `episodic_memory.js` (хук `Gestalt_onEpisodeFeedbackClosed` в `closeLastFrame`).

**Сон:** `sleep_mode.js` и `dreams.js` — рядом с базовыми контекстами; **`sleep_dream_process.js`** — **после** `episodic_memory.js` и **`fantasizming.js`** (цепочка фантазма, абстракции по кадру).

На момент **вызова** ур.3 модули выше по списку уже загружены; `abstract_images.js` подключается позже файла ур.3, но к моменту исполнения кода в рантайме глобалы `AbstractImages_*` доступны.

## Карта документации

| Документ | Содержание |
|----------|------------|
| `beast/_10_Episodic_memory/about_episodic_memory_rules.md` | Правила ЭП, ОР, ожидание, второй проход, цепочки |
| `beast/_10_Episodic_memory/about_episodic_memory.md` | ЭП, связь с абстракциями, участие ур.3 |
| `beast/_9_Conscience/about_conscience.md` | ФО, диспетчер, ур.3–4, ссылки на гештальт |
| `beast/_9_Conscience/about_gestalt.md` | Гештальт, буфер резонанса, интеграция с ур.3–4 и ЭП |
| `beast/_8_Hippocampus/about_hippocampus.md` | Гиппокамп и ОР |
| `beast/_6_semantic_memory/about_semantic_memory.md` | Семантическая память |
| `beast/about_global_variables.md` | Справочник ключевых глобалов |
| `beast/docs/design_conscious_automatisms.md` | Концептуальный дизайн |
| `beast/docs/analysis_adaptivity_system.md` | Разбор адаптивности (если используется) |
| `beast/_12_Sleep/about_sleep.md` | Режим сна, стимулы, сновидения, связь с ФО и ЭП |

Расхождения **код ↔ комментарии ↔ about_*** править у источника в `beast/`.

## Ключевая логика (файлы)

| Тема | Файлы |
|------|--------|
| ОР, конкуренция стимулов | `beast/_8_Hippocampus/orientation_reflex.js` |
| Вход ФО, «тишина мыслей», `Consciousness_runOneStep` | `beast/_9_Conscience/conscious_attention_channel.js` |
| Реестр циклов, **`Consciousness_cycleAppendLog`**, `expired` / `force` в логе | `beast/_9_Conscience/consciousness_dispatcher.js` |
| ЭП, `closeLastFrame`, effect ∈ [-10,+10] | `beast/_10_Episodic_memory/episodic_memory.js` |
| Абстракции, `semanticStructure`, поиск кадра контекста | `beast/_9_Conscience/abstract_images.js` |
| `info_automatismWithEpisodeFeedbackAndExpireCycle`, `info_bestEpisodicRule` | `beast/_9_Conscience/infofunctions.js` |
| **Ур.3:** пайплайн, гейты ожидания ЭП и значимости | `beast/_9_Conscience/conscience_level_3.js` |
| **Ур.4 / гештальт:** резонанс, контекст для ур.3, фидбек из ЭП | `beast/_9_Conscience/conscience_level_4.js`, `beast/_9_Conscience/gestalt.js`, `beast/_9_Conscience/about_gestalt.md` |
| Ур.2, ответ оператора, ментальный автоматизм из semantic rule | `beast/_9_Conscience/conscience_level_2.js` |
| Ментальные автоматизмы, МАИ | `beast/_9_Conscience/mental_automatism.js` |
| Инфокартина, `mode: passive \| target` | `beast/_9_Conscience/informing.js` |
| Цели жизненного опыта, умолчательная цель «Плачь», ОД | `beast/_9_Conscience/goals.js`, `beast/_10_actions_image/actions_image.js` |
| Генетические рефлексы, `processGeneticReflexes` | `beast/_5_Genetic__reflexes/genetic_reflexes_engine.js`, `genetic_reflexes.js` |
| Стимулы, UI | `beast/_3_perception/stimuls.js`, `stimuls_ui.js` |
| Режим сна, сновидения, `SleepMode_exit(true)` → фоновые циклы | `beast/_12_Sleep/sleep_mode.js`, `dreams.js`, `sleep_dream_process.js`; `prepare.js` (контекст «Сон»); `manuals/Mad_programmer_manual.md` §14 |

## Третий уровень сознания (актуальное поведение)

Файл: **`beast/_9_Conscience/conscience_level_3.js`**. Вызов за тик: **`conscience_level_3_runFromChannel`** из `Consciousness_runOneStep`.

**Порядок попыток:** ментальный автоматизм (дефолт + согласованный кадр `semanticStructure`) → shortcut по `AbstractImages_findRuleFrameMatchingContext` → семантика стимула + лучшее правило ЭП (`info_bestEpisodicRule`, стимул, положительный effect) → учительский fallback.

**Устойчивость:** пока `awaitingAutomatismEpisodeFeedback && !automatismOperatorAnswerReceived`, полный пайплайн не выполняется (нет ложного «правило не найдено» при втором/третьем триггере в том же тике). Вложенный `runLevel3` проверяет то же до вызова `conscience_level_3`.

**Значимость перед мотором:**

- `conscience_level_3_semanticStructureFrameAllowsMotor(fr)` — для shortcut и ментального пути: teacher или episodic с **числовым effect > 0** (или маркеры учителя на кадре).
- Эпизодический путь: если у лучшего семантического кадра стимула **meanImportance < 0**, мотор не запускается.
- Учитель: если у кадра **числовой effect ≤ 0**, мотор не запускается.

**Лог цикла:** важные сообщения идут в **`Consciousness_cycleAppendLog(cycle, text, puls, opts)`**; при **`cycle.expired`** без **`opts.force`** dispatcher **не** дописывает строку — для ур.3 после автоматизма часто используется **`{ force: true }`**. Обёртка в файле: `appendCycleLog` (учёт главного цикла и `force`).

Подробнее: **`beast/_9_Conscience/about_conscience.md`**, **`beast/about_global_variables.md`**, **`beast/_10_Episodic_memory/about_episodic_memory.md`**.

## Четвёртый уровень и гештальт

- **Файлы:** `conscience_level_4.js` (тик канала), `gestalt.js` (данные и логика), `about_gestalt.md`.
- **Ур.3:** в начале `conscience_level_3_runFromChannel` вызывается **`Gestalt_prepareContextForCycle`** — в **`GestaltContextForLevel3`** попадает снимок открытого гештальта по образу цели (если есть).
- **Ур.4:** в `conscience_level_4_runFromChannel` — **`Gestalt_onConsciousnessTick`** только для **главного** цикла.
- **ЭП:** после расчёта `effect` в **`closeLastFrame`** вызывается **`Gestalt_onEpisodeFeedbackClosed`**.
- **UI:** в строке «Информационная картина» индикатор **гешт: N** (`informing.js`).

## Важные согласования поведения

- **`orientationReflexWinner`:** победитель ОР уже выбран — порог прерывания главного цикла не должен отменять старт нового ФО из‑за «недостаточной значимости».
- **`mainBlocksThoughtSilence`:** понижение значимости конкурента — только пока главный цикл существует и **не** `expired`.
- **Ожидание ЭП:** ответ оператора закрывает кадр; связка с абстракциями и **`MentalAutomatizms_tryCreateFromSemanticStructureRule`** — см. `about_episodic_memory.md`.
- **Умолчательная цель «Плачь» / ОД:** при загрузке образов действий из IndexedDB вызывается синхронизация `actionImageId` умолчательной цели с каноническим ОД (`getOrCreateActionImageId(0, [1], '')`) — см. `goals.js`, `actions_image.js`.
- **Еда / Вода (мотивация 1–2):** эффекты включают удержание «Хорошо» (`SetWellForHolding`); для ОР действует обход порога `OR_well_known` при активных стимулах 1001/1002; при активации сбрасывается `automatismRanForBranchIds`; инфокартина может подавлять индикатор критического витала при «Хорошо» + еда/вода — см. `genetic_reflexes.js`, `orientation_reflex.js`, `stimuls_ui.js`, `info_detectors.js`.
- **Режим сна:** при `SleepMode_isActive` в `getActiveBasicContexts` только контекст «Сон» (id 15), независимо от виталов; сновидения используют пассивный главный цикл и `info_fantasizming` как обычный пассив; после завершения лимита кадров `SleepMode_exit(true)` вызывает `Consciousness_deleteAllBackgroundCycles` (ручной выход — нет). См. `beast/_12_Sleep/about_sleep.md`.

## Что считается стабильно работающим

1. Пульс, виталы, контексты, UI стимулов, дерево восприятия, рефлексы — в общем цикле.
2. **ОР → ФО → ЭП** при штатных порогах; кадр ЭП и прогресс ожидания при полном ОР.
3. Главный цикл осмысления помечается **`expired`** при простое; лог цикла учитывает `force` после автоматизма.
4. Ур.3 не «дёргается» повторно вслепую во время ожидания ЭП по уже запущенному автоматизму.

## Известные ограничения

1. Ранние пульсы после загрузки: контексты могут быть не готовы — индикатор готовности к ОР может быть временно неточным.
2. Индикатор на кнопке стимула не моделирует полную многокандидатную конкуренцию.
3. Ур.2 и пассивные сценарии — зона развития; ур.4 по гештальту реализован базово; расширения — см. `about_gestalt.md` и TODO в коде.

## Шаблон сообщения для нового чата

```
Контекст: проект BEAST, обязательно прочитай PROJECT_STATE_FOR_NEW_CHAT.md в корне.

Цель: разработка модуля сна и сновидений

Ограничения: ничего нельзя ломать; модуль сна автономен по файлам `_12_Sleep`, но влияет на контексты (`prepare.js`) и пульс (`SleepDreams_onPulse` до диспетчера).
```

После правок по архитектуре имеет смысл **обновить этот файл** и соответствующие `about_*.md` в `beast/`.
