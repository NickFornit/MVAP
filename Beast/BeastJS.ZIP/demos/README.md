# Beast demos (`/demos`)

Standalone **`.htm` tutorials**: mock fragments of the control panel + scripted steps (`createDemoRunner`) + **`sys/arrows.js`** for animated arrows.

- **No** `beast/*.js`, **no** IndexedDB.
- After large changes to **`index.html`** layout or shared CSS, skim each file in `modules/` (~5 min) and adjust copied classes/markup if the real panel moved.

Entry: **`demo.html`** (list of demos).

### Controls (injected by `demo-runner.js`)

- **Далее** — ручной переход по кадрам.
- **Старт**: сначала экран-подсказка (`0 / N`); **▶** запускает автопоказ с **первого кадра** без «Далее»; «Далее» вручную тоже с первого кадра.
- **Круглая иконка** — вкл/выкл **автопоказ**; паузы по умолчанию **~в 2 раза короче** прежней базы (`autoTimeFactor: 0.5`).
- **Ползунок «Темп»** — слева дольше кадр, справа короче. База: `options.baseReadMs` (26 с); шаг: `readTimeMs`; ускорение: `options.autoTimeFactor` (0.5 = вдвое быстрее).
