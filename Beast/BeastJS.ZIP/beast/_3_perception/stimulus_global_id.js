/**
 * Глобально уникальные ID стимулов (type * MULTIPLIER + localId).
 *
 * ПРИЧИНА ВВОДА: В разных массивах стимулов (StimulMotivarion, StimulPositiv, StimulNegative, StimulNeutral)
 * используются одни и те же числовые Id (например 10 = "Неприятно" в мотивации и 10 = "Пение" в позитивных).
 * При сохранении образа восприятия (FinalImage) и расшифровке по Id возникают коллизии — показывается
 * неверное имя стимула. Глобальный Id однозначно задаёт тип и локальный Id, поэтому расшифровка
 * и сравнение образов работают корректно при любом количестве стимулов в массивах (до 999 на тип).
 */
(function (global) {
  'use strict';

  /** Типы стимулов (совпадают с порядком массивов в коде). */
  var TYPE_MOTIVATION = 1;
  var TYPE_POSITIV = 2;
  var TYPE_NEGATIVE = 3;
  var TYPE_NEUTRAL = 4;

  /**
   * Максимум локальных id на один тип (1..MULTIPLIER-1).
   * При изменении числа стимулов в массивах решение остаётся рабочим, пока в каждом типе < 1000.
   */
  var MULTIPLIER = 1000;

  /**
   * Глобальный id по типу и локальному id.
   * @param {number} type — 1=Motivation, 2=Positiv, 3=Negative, 4=Neutral
   * @param {number} localId — Id в соответствующем массиве (Stimul*)
   */
  function toGlobalStimulusId(type, localId) {
    var t = parseInt(type, 10);
    var id = parseInt(localId, 10);
    if (isNaN(t) || isNaN(id) || id <= 0) return 0;
    if (t < 1 || t > 4) return 0;
    return t * MULTIPLIER + id;
  }

  /**
   * Разбор глобального id в тип и локальный id.
   * @param {number} globalId
   * @returns {{ type: number, localId: number } | null}
   */
  function fromGlobalStimulusId(globalId) {
    var g = parseInt(globalId, 10);
    if (isNaN(g) || g < MULTIPLIER) return null;
    var type = Math.floor(g / MULTIPLIER);
    var localId = g % MULTIPLIER;
    if (type < 1 || type > 4 || localId <= 0) return null;
    return { type: type, localId: localId };
  }

  /**
   * Имя стимула по глобальному id (для алертов и отображения).
   * Поддерживает старый формат: если globalId < MULTIPLIER, считается локальным id без типа
   * (обратная совместимость со старыми сохранёнными образами).
   */
  function getStimulusNameByGlobalId(globalId) {
    var g = parseInt(globalId, 10);
    if (isNaN(g) || g <= 0) return '';
    var parsed = fromGlobalStimulusId(g);
    var arr = null;
    if (parsed) {
      if (parsed.type === TYPE_MOTIVATION) arr = global.StimulMotivarion;
      else if (parsed.type === TYPE_POSITIV) arr = global.StimulPositiv;
      else if (parsed.type === TYPE_NEGATIVE) arr = global.StimulNegative;
      else if (parsed.type === TYPE_NEUTRAL) arr = global.StimulNeutral;
      if (arr && Array.isArray(arr)) {
        for (var i = 0; i < arr.length; i++) {
          if (arr[i] && arr[i].Id === parsed.localId) return arr[i].name || ('Id ' + parsed.localId);
        }
      }
      return '';
    }
    // Старый формат: id < MULTIPLIER — ищем по всем массивам (первое совпадение).
    var groups = [global.StimulMotivarion, global.StimulPositiv, global.StimulNegative, global.StimulNeutral];
    for (var h = 0; h < groups.length; h++) {
      if (!groups[h] || !Array.isArray(groups[h])) continue;
      for (var k = 0; k < groups[h].length; k++) {
        if (groups[h][k] && groups[h][k].Id === g) return groups[h][k].name || ('Id ' + g);
      }
    }
    return '';
  }

  /**
   * Массив глобальных id по текущим активным стимулам (для getOrCreateFinalImageId).
   * Активные массивы (ActiveMotivationStimuls и т.д.) хранят локальные id — здесь переводим в глобальные.
   */
  function getActiveGlobalStimulusIds() {
    var out = [];
    function add(type, activeArr) {
      if (!Array.isArray(activeArr)) return;
      for (var i = 0; i < activeArr.length; i++) {
        var localId = activeArr[i];
        if (typeof localId !== 'number' || localId <= 0) continue;
        var g = toGlobalStimulusId(type, localId);
        if (g && out.indexOf(g) === -1) out.push(g);
      }
    }
    add(TYPE_MOTIVATION, global.ActiveMotivationStimuls);
    add(TYPE_POSITIV, global.ActivePositivStimuls);
    add(TYPE_NEGATIVE, global.ActiveNegativeStimuls);
    add(TYPE_NEUTRAL, global.ActiveNeutralStimuls);
    out.sort(function (a, b) { return a - b; });
    return out;
  }

  /**
   * Тип стимула по идентификатору строки UI (для вызова из stimuls_ui).
   * @param {string} rowId — 'stimulsRowPositiv' | 'stimulsRowNegative' | 'stimulsRowNeutral' или контекст мотивации
   */
  function getStimulusTypeFromRowId(rowId) {
    if (rowId === 'stimulsRowPositiv') return TYPE_POSITIV;
    if (rowId === 'stimulsRowNegative') return TYPE_NEGATIVE;
    if (rowId === 'stimulsRowNeutral') return TYPE_NEUTRAL;
    return TYPE_MOTIVATION;
  }

  /** Тип по строке sourceType: 'motivation' | 'positive' | 'negative' | 'neutral'. */
  function getStimulusTypeFromSourceType(sourceType) {
    if (sourceType === 'motivation') return TYPE_MOTIVATION;
    if (sourceType === 'positive') return TYPE_POSITIV;
    if (sourceType === 'negative') return TYPE_NEGATIVE;
    if (sourceType === 'neutral') return TYPE_NEUTRAL;
    return TYPE_MOTIVATION;
  }

  global.StimulusGlobalId_toGlobal = toGlobalStimulusId;
  global.StimulusGlobalId_fromGlobal = fromGlobalStimulusId;
  global.StimulusGlobalId_getName = getStimulusNameByGlobalId;
  global.StimulusGlobalId_getActiveGlobalIds = getActiveGlobalStimulusIds;
  global.StimulusGlobalId_getTypeFromRowId = getStimulusTypeFromRowId;
  global.StimulusGlobalId_getTypeFromSourceType = getStimulusTypeFromSourceType;
  global.StimulusGlobalId_MULTIPLIER = MULTIPLIER;
})(typeof window !== 'undefined' ? window : this);
