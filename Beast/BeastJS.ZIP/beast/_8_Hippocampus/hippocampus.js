/**
 * Гиппокамп: оперативная память стимулов, вызвавших ориентировочный рефлекс.
 *
 * - active_stimulsArr_ID — массив ID удерживаемых стимулов (FinalImageId),
 *   которые вызывали ОР.
 * - actual_stimul_ID — глобальная ссылка на наиболее актуальный стимул (ID образа/комбинации).
 */
(function (global) {
  'use strict';

  /** Оперативная память: массив ID стимулов (FinalImageId), вызвавших ОР. */
  if (!Array.isArray(global.active_stimulsArr_ID)) {
    global.active_stimulsArr_ID = [];
  }

  /** Наиболее актуальный стимул (ID образа — FinalImageId). Заполняется при ОР. */
  if (typeof global.actual_stimul_ID !== 'number') {
    global.actual_stimul_ID = 0;
  }

  /**
   * Удержать в памяти стимул, вызвавший ОР (добавить в active_stimulsArr_ID и установить actual_stimul_ID).
   * @param {number} finalImageId — ID образа (FinalImageId) наиболее актуального стимула.
   */
  function holdStimulusFromOR(finalImageId) {
    if (typeof finalImageId !== 'number' || finalImageId <= 0) return;
    if (global.active_stimulsArr_ID.indexOf(finalImageId) === -1) {
      global.active_stimulsArr_ID.push(finalImageId);
    }
    global.actual_stimul_ID = finalImageId;
  }

  global.Hippocampus_holdStimulusFromOR = holdStimulusFromOR;
})(window);
