# Генетические рефлексы (_5_Genetic__reflexes)

## Назначение

Модуль реализует **генетически заданные моторные рефлексы**: по активации стимулов (мотивирующих, позитивных, негативных) по картам *_GeneticReflexes выбираются базовые действия (BasicActions), выполняются с учётом ориентировочного рефлекса и блокировок, с регистрацией в семантике, образах действия и эпизодической памяти.

## Логика

- На каждый пульс вызывается **processGeneticReflexes()** (из puls.js).
- Сначала обрабатываются **отложенные рефлексы** (delayedReflexes). Заблокированный ОР генетический рефлекс ставится в очередь из ОР (addBlockedReflexToQueue) с branchId активной ветки дерева. **Если в stimuls_consciousness автоматизм запущен**, из очереди удаляются все рефлексы по этой ветке (removeDelayedReflexesForBranch) — без сравнения действий, только по branchId. Если автоматизм отклонён, удаление не вызывается, отложенный рефлекс выполнится по истечении задержки.
- Затем проверяются **условные рефлексы** (synonyms_tryRunReflexes); если сработал условный — выполняется его действие через runGeneticActionFromSynonymReflex.
- Иначе по **новым** активированным стимулам (мотивация, позитив, негатив) собираются события из StimulMotivarion_GeneticReflexes, StimulPositiv_GeneticReflexes, StimulNegative_GeneticReflexes. Если рефлекс заблокирован ОР (OrientationReflex_isReflexBlockedByOR), событие помещается в delayedReflexes с noConditionalReflex: true; иначе вызывается startAction.

**startAction** регистрирует опыт в семантической памяти, обновляет блок «Активность Beast», пролонгированные действия (еда, питьё и т.д.), образы действия (ActionsImage_registerReaction) и последний кадр ЭП (EpisodicMemory_setLastFrameActionFromActionId). Вызов synonyms_onGeneticActionFired (формирование условного рефлекса) не выполняется при sourceType === 'synonym' или при noConditionalReflex.

## Файлы

- **genetic_reflexes.js** — карты стимул → действие (StimulMotivarion_GeneticReflexes, StimulPositiv_GeneticReflexes, StimulNegative_GeneticReflexes), плюс вербальный рефлекс (Id 100) и пролонгаторы действий.
- **genetic_reflexes_engine.js** — процесс рефлексов, очередь отложенных рефлексов, startAction, runGeneticActionFromSynonymReflex, отображение активности.
