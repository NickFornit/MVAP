# Пассивный режим и фантазирование (`info_fantasizming`)

## Роли режимов

- Режим мышления (**`target`** | **`passive`**) хранится на **цикле ФО** (`cycle.thinkingMode`), **не** в `InfoPicture`. У главного и фонового цикла он может различаться; инфокартина — общий «экран» и ячейки данных без поля «режим».
- Целевой и пассивный режимы **антагонистичны на уровне шага цикла**: при **`thinkingMode === 'passive'`** не вызываются ур. 3–4; выполняется **`info_fantasizming(cycle)`** (если не сработал антистагнационный гейт).
- **Главный цикл** в пассиве дописывает сюжет в **`InfoPicture.fantasmPlotRules`** («Сюжет фантазма») и использует **`fantazmingPlot` / `lastGeneratedActionId`** на цикле как контекст продолжения.
- **Фоновый цикл** в пассиве **не** пишет в `fantasmPlotRules`; накапливает контекст в **`cycle.fantasizmArr`** и **`cycle.fantazmingPlot`** (цепочка и якорь для следующего шага).

## Опорный кадр и «EpisodicTreeNode»

В коде кадры хранятся в массиве **`Episodes`**. Для шага фантазирования точка входа — **идентификатор стимула** `currentStimulusId` (см. `info_fantasizming`); для главного при отсутствии якоря допускается **`InfoPicture.currentGoalId`**, для фонового — нет.

## Антистагнация

После шага в **`cycle.passiveFantasyLastSig`** пишется сигнатура прогресса. **Главный** цикл: **`Consciousness_getInfoPictureSignature()`** (изменения глобальной инфокартины). **Фоновый**: локальная строка по **`fantazmingPlot` + `fantasizmArr`** (без записи в инфокартину). При **streak ≥ 3** и совпадении с последним снимком вызов **`info_fantasizming`** пропускается.

## Алгоритм одного шага `info_fantasizming(cycle)`

1. **`cycle.thinkingMode === 'passive'`**; иначе выход.
2. **Текущий стимул** — приоритет: `lastGeneratedActionId` → `context.actual_stimul_ID` → (только главный) `InfoPicture.currentGoalId`.
3. Кадры ЭП с **`responseStimulusImageId === currentStimulusId`**, лучший по **|effect|**.
4. В **`fantazmingPlot`** и **`fantasizmArr`** — всегда; в **`fantasmPlotRules`** — **только если цикл главный**.
5. Инсайт по порогу → **`info_insight`** (ставит **`thinkingMode = 'target'`** у цикла).
6. Иначе: **главный** — `runActionImage`, `Info_updateFromStimulus`, шаг инфокартины; **фоновый** — без изменения глобальной инфокартины и без моторной имитации.

## Связь с гештальтами и резонансом

Дальнейшее развитие — приоритеты объектов, `curConditions`, гештальты / **`GestaltResonanceBuffer`**.

## Режим сна

Сновидения используют **тот же** `info_fantasizming` для главного цикла: оркестратор в `beast/_12_Sleep/sleep_dream_process.js` создаёт главный цикл с `thinkingMode === 'passive'` и после серии пульсов дополняет «пустой» кадр ЭП по цепочке `fantazmingPlot.chain`. Подробности — **`beast/_12_Sleep/about_sleep.md`**.
