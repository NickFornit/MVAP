# Адаптивность ФО: уровни 2 и 4 (констатация реализованного)

Документ фиксирует **фактическое состояние кода** по взаимосвязи второго и четвёртого уровней осознания, семантики, эпизодической памяти и смежных контуров. Не является спецификацией будущих задач; отдельные «зазоры» указаны как **текущие границы реализации**.

---

## 1. Уровень 2 (`conscience_level_2.js`)

Реализован как слой **постановки и пересмотра целей** и **переработки последствий действия**, когда сработал мотор и есть обратная связь по эпизодической памяти (ЭП).

### 1.1. Ветки (как в коде)

| Ветка | Реализованное поведение |
|--------|-------------------------|
| Ответ оператора / кадр ЭП | `AbstractImages_applyEpisodeEffectToSemanticContextAbstractions`; при числовом `effect > 0` — `MentalAutomatizms_tryCreateFromSemanticStructureRule`; корректировка полезности цели (`Goals_applyWaitingPeriodEffectToGoalUsefulness`, `Goals_mergeUsefulnessSampleForGoalId`) с учётом детекторов (`negativeMotorEffect`, `positiveActionEffect`, `lowAutomatismUsefulness`). Защита от повторного входа: `operatorAnswerPipelineConsumed`. |
| Выживание | Условия: `conscience_level_2_isSurvivalContext`, критичность виталов; цели из жизненного опыта (`Goals_addOrUpdateLifeGoalFromFrame` и связанная логика); цепочки по `Target_rule_stack` / `EpisodicMemory_findChainForGoalStack` при `usedRule`; запуск автоматизма с ожиданием ЭП (`info_automatismWithEpisodeFeedbackAndExpireCycle`, `conscience_level_2_startSurvivalAutomatism`). |
| Цель «значение» | `conscience_level_2_tryMeaningGoalForecast`: выборка кадров ЭП по стимулу/ветке, прогноз; `Gestalt_bumpFromMeaningForecast`; `AbstractImages_boostSemanticRulesForAction`. |
| Завершение фазы ожидания | `conscience_level_2_finalizeAutomatismAnswerCycle` — снятие флагов ожидания, `expired` цикла. |

### 1.2. Связи с другими модулями

- **ЭП**: кадры, effect, закрытие кадра → вход в пайплайн ответа оператора.
- **`abstract_images.js`**: усреднение по контексту семантики при feedback; усиление правил по ОД для цели «значение».
- **`mental_automatism.js`**: создание ментального автоматизма при положительном effect и совпадении с `semanticStructure`.
- **`goals.js`**: образы целей жизненного опыта, полезность, цель «значение».
- **`gestalt.js`**: вызовы из ветки «значение» (`Gestalt_bumpFromMeaningForecast`).

---

## 2. Уровень 4 (`conscience_level_4.js`)

Реализован как **тонкая обёртка** над гештальт-модулем: основной рабочий вызов в тике канала — `Gestalt_onConsciousnessTick(cycle)` (см. `gestalt.js`). Дополнительно объявлен `conscience_level_4(context)` с логом и **TODO** на расширения (мета-рефлексия и т.д.) — полноценная логика там **не разведена**.

### 2.1. Зафиксированное в коде назначение ур. 4

- Обработка **главного** running-цикла в `Gestalt_onConsciousnessTick` (фоновые циклы отсекаются внутри гештальта).
- Привязка ведущего гештальта к цели (`cycle.goalImageId` / `InfoPicture.currentGoalId` в целевом режиме мышления главного цикла).
- Разбор **`GestaltResonanceBuffer`** (FIFO сигнатур закрытых кадров ЭП), эвристика score → инсайт аналогии, обновление `analogyPool` и статуса гештальта.
- Повторный вызов `Gestalt_prepareContextForLevel3` после возможных инсайтов.
- Пополнение буфера резонанса **не** в этом тике: при закрытии кадра ЭП (`EpisodicMemory_closeLastFrame` → `Gestalt_onEpisodeFeedbackClosed`).

### 2.2. Связь с уровнем 3

- В начале ур. 3 вызывается `Gestalt_prepareContextForLevel3` — в `GestaltContextForLevel3` попадает снимок открытого гештальта для использования как контекст; ур. 3 не заменяет собственный поиск правил этим контекстом полностью — см. комментарии в `conscience_level_3.js` и `conscience_level_4.js`.

---

## 3. Согласованность ур. 2 ↔ ур. 3 ↔ ур. 4 (факты)

**Реализовано:**

1. Замкнутый контур: мотор / автоматизм → ЭП → обработка ответа в ур. 2 → при необходимости дальнейшие тики `runOneStep` с ур. 3 и 4.
2. Гейт ожидания ЭП: пока `awaitingAutomatismEpisodeFeedback` без ответа оператора, повторный полный проход ур. 3 не выполняется (`conscience_level_3_shouldSkipBecauseAwaitingEpisodeFeedback` и смежная логика).
3. Проверка кадра `semanticStructure` перед мотором: `conscience_level_3_semanticStructureFrameAllowsMotor` (учительский кадр и положительный episodic effect).
4. Ур. 4 не дублирует поиск правил ур. 3; добавляет слой гештальта и резонанса по уже произошедшим закрытиям кадров.

**Текущие границы (констатация, не багрепорт):**

1. Основная адаптивная логика ур. 4 сосредоточена в **`gestalt.js`**, а не в теле `conscience_level_4.js`.
2. Правила с `ruleKind === 'fantasy'` (после `info_new_abstract_semantic` / `AbstractImages_upsertSemanticRuleFromFantasyFrame`) в явном виде в `conscience_level_3_semanticStructureFrameAllowsMotor` **не перечислены** — политика мотора по fantasy отделена от episodic/teacher на уровне явных условий в этом гейте.
3. Пассивный режим мышления цикла (`cycle.thinkingMode === 'passive'`) и `info_fantasizming` в **`Consciousness_runOneStep`** обходят ур. 3–4 в том же тике; консолидация сюжета — `info_new_abstract_semantic` в `infofunctions.js` — **отдельный** вызов, не встроенный в тик гештальта по умолчанию.
4. Два источника пополнения `semanticStructure`: реальные кадры ЭП и fantasy-слоты; учительский слот при конфликте **не перезаписывается** fantasy-апдейтом (реализовано в `AbstractImages_upsertSemanticRuleFromFantasyFrame`).

---

## 4. Оценка адаптивных качеств (по текущей реализации)

| Аспект | Что зафиксировано в системе |
|--------|-----------------------------|
| Обучение на последствиях | Ур. 2: feedback по ЭП, обновление семантического контекста и целей. |
| Приоритет угроз | Отдельная ветка выживания в ур. 2. |
| Долгая память о нерешённом | Гештальты, цель «значение», прогноз по ЭП в ур. 2. |
| Аналогии и перенос | Резонансный буфер, эвристика score, `analogyPool` в `gestalt.js`. |
| Внутренняя симуляция | Пассивное фантазирование, перенос в семантику fantasy через `info_new_abstract_semantic` — отдельный контур от тика ур. 3–4. |

---

## 5. Связанные файлы

| Файл | Роль |
|------|------|
| `conscience_level_2.js` | Ур. 2 |
| `conscience_level_3.js` | Ур. 3 (канал, гейты семантики/ЭП) |
| `conscience_level_4.js` | Ур. 4 (вызов гештальта) |
| `gestalt.js` | Гештальты, резонанс, инсайты аналогии |
| `abstract_images.js` | Клоны, `semanticStructure`, fantasy-upsert |
| `infofunctions.js` | `info_new_abstract_semantic`, прочие info_* |
| `conscious_attention_channel.js` | `runOneStep`, пассивная ветка |
| `consciousness_dispatcher.js` | Диспетчер циклов, стагнация, сигнатуры |

---

*Текст согласован с обзором архитектуры адаптивности ур. 2 и 4 и приведён к форме документации «что сделано в коде».*
