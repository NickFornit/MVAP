# Канал осознанного внимания (_9_Conscience)

## Назначение

Модуль реализует **осознание стимула** после ориентировочного рефлекса: **stimuls_consciousness(context)** вызывается из ОР. На вход передаётся контекст с полной детализацией новизны условий (**actual_stimul_ID**, **branchId**, **novelty**, **significance**, **samplesCount**, **pathArr**, **well**, **emotionId**, **activityID**, **isResponseStimulus**, **orientationReflexWinner**) для анализа ситуации. Если **orientationReflexWinner** истинен, порог «тишины мыслей» (сравнение с текущей значимостью главного цикла) **не блокирует** запуск нового цикла ФО — победитель уже выбран конкуренцией ОР.

**Тишина мыслей** (понижение эффективной значимости конкурирующего стимула: несовпадение темы/ситуации с главным циклом, штраф при `ImportantProblem`, порог `INTERRUPT_THRESHOLD_ATTENTION_RATIO`) применяется **только пока существует главный цикл осмысления и он ещё не помечен `expired`**. Для стимулов **приоритета цепочки** ЭП отдельные правила см. `about_episodic_memory_rules.md`, §7. Проверяется наличие штатного автоматизма у активного узла дерева (branchId); при наличии — запускается образ действия (runActionImage). При запуске автоматизма вызывается removeDelayedReflexesForBranch(branchId): из очереди отложенных рефлексов удаляются все записи по этой ветке (без сравнения действий). Здесь предусмотрено место для блока оценки приемлемости запуска ActionsImageID при данной новизне условий.

**Независимость автоматизма от рефлекса:** первоначальный автоматизм в функции осознания может быть произвольно модифицирован с изменением его действия (ОД). Никакой связи между первичным рефлексом и вторичным автоматизмом не предполагается: автоматизм — самостоятельное правило по ветке, его образ действия может отличаться от изначально зафиксированного рефлексом.

## Диспетчер циклов мышления

Циклы осознания выполняются **итеративно по пульсу**, без рекурсивных вызовов ФО (по образцу OLD_CODE/GO: understanding.go, understanding_cycle.go).

- **consciousness_dispatcher.js** — реестр циклов (ConsciousnessCycles), создание/отмена/удаление, назначение главного (Consciousness_setMainCycle). По каждому пульсу вызывается **dispetchConsciousnessThinking(pulsCount)**: главному циклу даётся один шаг (Consciousness_runOneStep), фоновым — раз в **5** пульсов (см. `consciousness_dispatcher.js`); при отсутствии главного поднимается следующий контекст из ConsciousnessBackgroundStack (**promoteFromBackgroundCycle** / стек прерываний). Без диспетчера невозможна надёжная реализация мышления. **Стагнация:** если после шага главный помечается **expired** (три итерации без изменений инфокартины) и на этом же пульсе уже отработал тик ур.4/гештальта (`lastGestaltConsciencePuls`), инфокартина переводится в **пассивный** режим, на цикле — флаг `passiveWorkAfterGestaltExpire` (детализация цикла в `informing.js`, `formatCycleOrStackInfo`).
- **conscious_attention_channel.js** — точка входа **stimuls_consciousness(context)**. При более значимом вызове текущий главный цикл пушится в стек и отменяется; создаётся новый цикл и выполняется элементарный проход (Consciousness_runElementary). Рекурсии нет: продолжение и «возврат» к прерванному контексту выполняет диспетчер.

## Текущая реализация

- **conscious_attention_channel.js** — stimuls_consciousness создаёт цикл, запускает уровень 1 и 2 (поиск по ЭП, штатный автоматизм, при неудаче — conscience_level_2). Consciousness_runElementary и Consciousness_runOneStep экспортируются для диспетчера; шаг ур. 3–4 в runOneStep делегируется в **conscience_level_3_runFromChannel** / **conscience_level_4_runFromChannel**.
- Вызов из `orientation_reflex.js` при **полном** срабатывании ОР (в т.ч. на **втором** проходе после ответного стимула в периоде ожидания); на 3-м пульсе — начальный цикл без стимула (`actualId: 0`, контекст без `orientationReflexWinner`).
- **puls.js** — каждый пульс вызывает dispetchConsciousnessThinking(global.cpuls).

## Файлы

- **consciousness_dispatcher.js** — реестр циклов, диспетчер, promoteFromBackgroundStack.
- **infofunctions.js** — `info_automatismWithEpisodeFeedbackAndExpireCycle`; `info_bestEpisodicRule` (поиск лучшего правила ЭП с опциями: фильтр по стимулу как для ур.3, fallback по стимулу как для ур.2 выживание); `info_bestEpisodicRuleForStimulus` — обёртка.
- **conscious_attention_channel.js** — stimuls_consciousness, Consciousness_runElementary, Consciousness_runOneStep.
- **conscience_level_3.js** — третий уровень осознания (вызов из `conscience_level_3_runFromChannel` за тик канала). **Порядок:** готовый ментальный автоматизм по умолчанию (если кадр `semanticStructure` согласован с МАИ) → shortcut по `AbstractImages_findRuleFrameMatchingContext` → семантика стимула + `info_bestEpisodicRule` (тот же стимул, положительный effect) → учительский fallback (`info_teacherEpisodicRuleForAction`, зеркала 88/89). Во всех успешных ветках мотор — через `conscience_level_3_startAutomatismFromEpisodicRule` → `info_automatismWithEpisodeFeedbackAndExpireCycle`. **Устойчивость:** пока цикл ждёт кадр ЭП после запуска автоматизма (`awaitingAutomatismEpisodeFeedback` без ответа оператора), полный пайплайн не выполняется; при нескольких триггерах за тик второй/третий вызовы пропускаются с записью в лог (`Consciousness_cycleAppendLog`, часто с `{ force: true }` из‑за `expired`). **Значимость перед мотором:** shortcut и ментальный путь — только если кадр `semanticStructure` «положителен» (`conscience_level_3_semanticStructureFrameAllowsMotor`: teacher или episodic с числовым `effect > 0`); путь ЭП дополнительно блокируется при `meanImportance < 0` у лучшего семантического кадра стимула; учительский путь — если у выбранного кадра числовой `effect ≤ 0`.
- **conscience_level_4.js** — четвёртый уровень: тик канала вызывает **`Gestalt_onConsciousnessTick`** (`gestalt.js`) — привязка ведущего гештальта к цели главного цикла, разбор **буфера резонанса** (сигнатуры закрытых кадров ЭП), повторное обновление контекста. Подробно: **`about_gestalt.md`**.
- **gestalt.js** — записи **гештальтов** (доминанты по `goalImageId`), **GestaltResonanceBuffer**, вызовы из ур.3 (**`Gestalt_prepareContextForCycle`** → `GestaltContextForLevel3`) и из **`closeLastFrame`** (**`Gestalt_onEpisodeFeedbackClosed`**). Персистенция IndexedDB `BEAST_Gestalt_DB`. На главной странице в строке «Информационная картина» — индикатор **«гешт: N»** и `Info_showGestaltsList` / `Info_showGestaltDetail` (`informing.js`).

## См. также

- **`about_adaptivity_levels_2_4.md`** — констатация реализованной взаимосвязи ур. 2 и ур. 4 с семантикой, ЭП, пассивным фантазированием и границами реализации.
- **`../_12_Sleep/about_sleep.md`** — режим сна и сновидения (главный пассивный цикл, `Consciousness_deleteAllBackgroundCycles` после `SleepMode_exit(true)`).
