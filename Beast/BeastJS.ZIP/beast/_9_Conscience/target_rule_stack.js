(function (global) {
  'use strict';

  /**
   * Стек целей для правил (LIFO), не глубже 3 ячеек.
   * Хранит FinalImageId образов цели; индексы массива: [0] — дно, [length-1] — вершина.
   */
  var MAX_DEPTH = 3;

  if (!Array.isArray(global.Target_rule_stack)) {
    global.Target_rule_stack = [];
  }

  function normalize() {
    while (global.Target_rule_stack.length > MAX_DEPTH) {
      global.Target_rule_stack.shift();
    }
  }

  /**
   * Положить ID образа цели на вершину стека (0 игнорируется).
   */
  function TargetRuleStack_push(finalImageId) {
    var id = parseInt(finalImageId, 10) || 0;
    if (!id) return;
    global.Target_rule_stack.push(id);
    normalize();
  }

  /** Снять вершину стека, вернуть ID или 0. */
  function TargetRuleStack_pop() {
    if (!global.Target_rule_stack.length) return 0;
    return global.Target_rule_stack.pop() || 0;
  }

  /** Верх стека без изъятия. */
  function TargetRuleStack_peek() {
    var a = global.Target_rule_stack;
    return a.length ? (a[a.length - 1] || 0) : 0;
  }

  function TargetRuleStack_clear() {
    global.Target_rule_stack.length = 0;
  }

  function TargetRuleStack_depth() {
    return global.Target_rule_stack.length;
  }

  global.TargetRuleStack_push = TargetRuleStack_push;
  global.TargetRuleStack_pop = TargetRuleStack_pop;
  global.TargetRuleStack_peek = TargetRuleStack_peek;
  global.TargetRuleStack_clear = TargetRuleStack_clear;
  global.TargetRuleStack_depth = TargetRuleStack_depth;
})(typeof window !== 'undefined' ? window : globalThis);
