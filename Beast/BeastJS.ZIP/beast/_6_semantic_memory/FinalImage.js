(function (global) {
  'use strict';

  // Массив известных FinalImage: сочетаний активных стимулов.
  // Формат элемента: { id: number, stimulIds: number[] }.
  // stimulIds с версии с глобальными id хранят значения type*1000+localId (см. stimulus_global_id.js).
  if (!Array.isArray(global.FinalImages)) {
    global.FinalImages = [];
  }

  function normalizeIds(ids) {
    if (!Array.isArray(ids)) return [];
    var arr = [];
    for (var i = 0; i < ids.length; i++) {
      var v = parseInt(ids[i], 10);
      if (!isNaN(v) && v > 0) {
        if (arr.indexOf(v) === -1) {
          arr.push(v);
        }
      }
    }
    arr.sort(function (a, b) { return a - b; });
    return arr;
  }

  function arraysEqual(a, b) {
    if (a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] !== b[i]) return false;
    }
    return true;
  }

  function findFinalImageIdByStimuls(stimulIds) {
    var norm = normalizeIds(stimulIds);
    if (!norm.length) return 0;
    for (var i = 0; i < global.FinalImages.length; i++) {
      if (arraysEqual(global.FinalImages[i].stimulIds, norm)) {
        return global.FinalImages[i].id;
      }
    }
    return 0;
  }

  function getNextFinalImageId() {
    var maxId = 0;
    for (var i = 0; i < global.FinalImages.length; i++) {
      if (global.FinalImages[i].id > maxId) {
        maxId = global.FinalImages[i].id;
      }
    }
    return maxId + 1;
  }

  function getOrCreateFinalImageId(stimulIds) {
    var norm = normalizeIds(stimulIds);
    if (!norm.length) return 0;
    var existingId = findFinalImageIdByStimuls(norm);
    if (existingId) return existingId;
    var newId = getNextFinalImageId();
    global.FinalImages.push({ id: newId, stimulIds: norm });
    if (Array.isArray(global.KnownFinalImageIds) && global.KnownFinalImageIds.indexOf(newId) === -1) {
      global.KnownFinalImageIds.push(newId);
    }
    return newId;
  }

  global.FinalImages_findFinalImageId = findFinalImageIdByStimuls;
  global.FinalImages_getOrCreateFinalImageId = getOrCreateFinalImageId;

})(window);

