/**
 * Подготовка виталов: загрузка/сохранение value и пересчёт по shift.
 *
 * Назначение:
 * - Восстановление значений value виталов из localStorage при старте.
 * - Сохранение value в localStorage (периодически и по кнопке «Сохранить память»).
 * - performSensorOperations() — пересчёт value по коэффициенту shift, вызывается из пульса.
 *
 * Зависимость: перед этим скриптом должен быть подключён vitals.js (window.VitalsArr).
 */

(function (global) {
  'use strict';

  var STORAGE_KEY = 'VitalsValues';

  /**
   * Восстановить значения value виталов из localStorage (если есть сохранение).
   * Сохраняются только значения value, остальные поля берутся из исходного массива.
   */
  function loadVitalsFromStorage() {
    var data;
    try {
      var raw = global.localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        return;
      }
      data = JSON.parse(raw);
    } catch (e) {
      return;
    }

    if (!Array.isArray(data) || !global.VitalsArr) {
      return;
    }

    for (var i = 0; i < global.VitalsArr.length && i < data.length; i++) {
      var v = parseFloat(data[i]);
      if (isNaN(v)) {
        continue;
      }
      if (v < 0) v = 0;
      if (v > 100) v = 100;
      global.VitalsArr[i].value = v;
    }
  }

  /**
   * Сохранить текущие значения value виталов в localStorage.
   * Хранится только массив чисел.
   */
  function saveVitalsToStorage() {
    if (!global.VitalsArr) {
      return;
    }
    var values = [];
    for (var i = 0; i < global.VitalsArr.length; i++) {
      values.push(global.VitalsArr[i].value);
    }
    try {
      global.localStorage.setItem(STORAGE_KEY, JSON.stringify(values));
    } catch (e) {}
  }

  /**
   * Пересчёт жизненных параметров по коэффициенту shift.
   * Вызывается из центрального пульса раз в пульс.
   */
  function performSensorOperations() {
    if (!global.VitalsArr) {
      return;
    }

    for (var i = 0; i < global.VitalsArr.length; i++) {
      var vital = global.VitalsArr[i];
      var newVal = vital.value + vital.shift;
      if (newVal < 0) newVal = 0;
      if (newVal > 100) newVal = 100;
      vital.value = newVal;
    }

    // Дополнительное правило: при высоких значениях виталов 1–6 растёт витал 1.
    // Если виталы с Id 1,2,3,4,5,6 достигают 90% и выше, витал 1 увеличивается
    // на сумму (importance / 1000) этих виталов. Например: при Id 2 и 5 >= 90
    // добавка = 0.09 (90/1000) + 0.06 (60/1000).
    var vital1 = null;
    var extraGrowth = 0;
    for (var j = 0; j < global.VitalsArr.length; j++) {
      var v = global.VitalsArr[j];
      if (v.Id === 1) {
        vital1 = v;
      }
      if (v.Id >= 1 && v.Id <= 6 && v.value >= 90) {
        extraGrowth += (v.importance || 0) / 1000;
      }
    }
    if (vital1) {
      if (extraGrowth > 0) {
        var v1 = vital1.value + extraGrowth;
        if (v1 > 100) v1 = 100;
        if (v1 < 0) v1 = 0;
        vital1.value = v1;
      }
      // Шоковое состояние и смерть по виталу 1
      if (vital1.value >= 90) {
        global.isShockState = true;
      } else {
        global.isShockState = false;
      }
      if (vital1.value >= 100 && !global.DeathSequenceStarted && typeof global.startDeathSequence === 'function') {
        global.DeathSequenceStarted = true;
        global.startDeathSequence();
      }
    }

    // Применяем сдвиг от активных стимулов (shift на каждом пульсе)
    if (global.StimulMotivarion && global.ActiveMotivationStimuls && global.ActiveMotivationStimuls.length) {
      for (var si = 0; si < global.ActiveMotivationStimuls.length; si++) {
        var stimId = global.ActiveMotivationStimuls[si];
        for (var sj = 0; sj < global.StimulMotivarion.length; sj++) {
          var stim = global.StimulMotivarion[sj];
          if (stim.Id === stimId && stim.vitalID > 0 && stim.vitalID <= 10 && stim.shift) {
            for (var vk = 0; vk < global.VitalsArr.length; vk++) {
              var vv = global.VitalsArr[vk];
              if (vv.Id === stim.vitalID) {
                var nv = vv.value + stim.shift;
                if (nv < 0) nv = 0;
                if (nv > 100) nv = 100;
                vv.value = nv;
                break;
              }
            }
            break;
          }
        }
      }
    }

    saveVitalsToStorage();

    if (typeof global.update_vitals_view === 'function') {
      global.update_vitals_view();
    }
  }

  loadVitalsFromStorage();

  global.saveVitalsToStorage = saveVitalsToStorage;
  global.performSensorOperations = performSensorOperations;
})(window);
