/* жизненные параметры (виталы) — только задатчик массива.
 *
 * Глобальное объявление (в браузере — становится свойством window)
 * value      - текущее значение параметра (0..100), ИМЕННО value нужно сохранять
 * importance - вес значимости
 * shift      - на сколько % ухудшаются или улучшаются параметры с каждым пульсом
 *
 * Вся логика загрузки/сохранения и пересчёта — в vitals_prepare.js
 */
window.VitalsArr = [
  { Id: 1, value: 0, importance: 100, shift: -0.05, name: "Раны",      title: "Повреждения" },
  { Id: 2, value: 0, importance: 90,  shift: -0.05, name: "Удушье",    title: "Гипоксия / кислородный дефицит" },
  { Id: 3, value: 0, importance: 80,  shift: 0.003, name: "Жажда",     title: "Обезвоживание / водный дефицит" },
  { Id: 4, value: 0, importance: 70,  shift: 0,     name: "Жара",      title: "Перегрев" },
  { Id: 5, value: 0, importance: 60,  shift: 0,     name: "Холод",     title: "Переохлаждение" },
  { Id: 6, value: 0, importance: 50,  shift: 0.002, name: "Голод",     title: "Голод (дефицит энергии)" },
  { Id: 7, value: 0, importance: 40,  shift: -0.1,  name: "Стресс",    title: "Стресс" },
  { Id: 8, value: 0, importance: 30,  shift: 0.002, name: "Гон",       title: "Гон (половая активность)" },
  { Id: 9, value: 0, importance: 20,  shift: 0.004, name: "Общение",   title: "Потребность в общении" },
  { Id: 10, value: 0, importance: 10,  shift: 0.004, name: "Интерес",   title: "Потребность в изучении" }
];

// массив степени выхода виталов из нормы
window.BadVitalsValue = {
  1: 0,
  2: 0,
  3: 0,
  4: 0,
  5: 0,
  6: 0,
  7: 0,
  8: 0,
  9: 0,
  10: 0
};
  
// индикатор интергальной значимости состояния организма 
window.IntergalConditionImportance = 0;
// индикатор старого значения интергальной значимости состояния организма 
window.IntergalConditionImportanceOld = 0;
  
// Индикатор базового состояния организма Плохо (1) Норма (2) Хорошо (3)
window.BadNormWell = 0;  

// Индикатор изменения базового состояния организма в сравнении с предыдущим значением
window.DiffZnacher = 0; // дифференциатор значимости

// Шоковое состояние (true при витале 1 >= 90%)
window.isShockState = false;

// Игровой режим Beast
window.isGameMode = false;

// Режим авторитарного обучения
window.isAuthoritarianEducation = false;

// Умолчательные value и shift для кнопки «Сбросить» (снимок на момент загрузки)
window.VitalsArrDefaults = window.VitalsArr.map(function (v) {
  return { value: v.value, shift: v.shift };
});

// состояние сна
window.IsSpeeping = false;
