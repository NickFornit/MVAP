# Режим сна и сновидения (`_12_Sleep`)

Модуль **не подменяет** диспетчер ФО и `info_fantasizming`: он задаёт **режим работы UI и базовых контекстов**, оркестрирует **перебор пустых кадров эпизодической памяти** и **реализацию** кадра после пассивного фантазма.

Подробности в коде: комментарии в `sleep_mode.js`, `sleep_dream_process.js`, `dreams.js`.

---

## Файлы

| Файл | Роль |
|------|------|
| `sleep_mode.js` | Флаг активного сна, кнопка «Сон», авто-сон по счётчику финовых циклов, ограничение стимулов, `SleepMode_exit(normalDreamCompletion)`. |
| `dreams.js` | Мост: хуки входа/выхода/пульса, глобальный флаг `SleepDreams_paleActivityBeast`. |
| `sleep_dream_process.js` | Очередь пустых кадров ЭП, фазы `idle` / `fantasy`, создание сонового главного цикла (`thinkingMode: passive`), лимиты пульсов и кадров, вызов `SleepMode_exit(true)`. |

Интеграция:

- `prepare.js` — при активном сне в `getActiveBasicContexts` принудительно только контекст **`SleepMode_CONTEXT_ID`** (15), независимо от виталов.
- `stimuls_ui.js` — разрешённые стимулы сначала вызывают `SleepMode_exit()` (без флага), затем обрабатываются как обычно.
- `puls.js` — **`SleepDreams_onPulse`** вызывается **до** `dispetchConsciousnessThinking`, чтобы в том же пульсе соновой главный цикл получил шаг (`info_fantasizming`).
- `episodic_memory.js` — `EpisodicMemory_isEmptyFrameForSleep`, `EpisodicMemory_collectEmptyFrameIndicesNewestFirst`.
- `consciousness_dispatcher.js` — `Consciousness_deleteAllBackgroundCycles` только после **`SleepMode_exit(true)`** (нормальное завершение сновидений).

---

## Вход в сон

1. **Вручную** — кнопка «Сон» в строке базовых контекстов (`basic_contexts_ui.js`, перед круглой B), `SleepMode_toggle` → `enter(false)`.
2. **Авто** — при **`ConsciousnessFinCyclesTotal > 100`** (`sleep_mode.js`: `SleepMode_tryAutoAfterFinCycles` из `notifyFinCycleCompleted` в диспетчере). Сон возможен и при критических виталах, т.к. контексты переопределяются.

---

## Выход из сна

| Способ | `SleepMode_exit` | Фоновые циклы ФО |
|--------|------------------|------------------|
| Кнопка «Сон», разрешённый стимул | без аргумента | не удаляются |
| Лимит реконструированных кадров сновидений (20) | `exit(true)` | **`Consciousness_deleteAllBackgroundCycles`** |

---

## Стимулы в режиме сна

Заблокированы все кнопки стимулов, кроме согласованных пар **строка + локальный id** (Наказание, Вопль, Сирена, Рычание, Огонь — см. `allowedKeys` в `sleep_mode.js`). Разрешённые кнопки помечаются лёгким outline; остальные — полупрозрачны и без клика. Кнопки очистки строк стимулов заблокированы.

---

## Сновидения (алгоритм)

1. **Пустой кадр ЭП** — есть `stimulusImageId` и `actionImageId`, нет ответного стимула и нет числового `effect` (`EpisodicMemory_isEmptyFrameForSleep`).
2. Очередь индексов **от новых к старым**; уже обработанные индексы в сессии исключаются (`processedSet`).
3. На кадр: прежний главный цикл кладётся в стек прерываний; создаётся новый **главный** цикл с `thinkingMode === 'passive'`, контекст помечен `sleepDream`. Шаги фантазма — тот же **`info_fantasizming`**, что и в обычном пассиве (см. `about_passive_fantasizming.md`).
4. После **N пульсов** (`MAX_PULSES_PER_FANTASY`) — **реализация**: из цепочки `fantazmingPlot.chain` выбирается продолжение с максимальным **|effect|**; при отсутствии источника в `Episodes` — fallback через `getFramesByResponseStimulus` + `pickBestFrameByAbsEffect`; затем `AbstractImages_cloneFromEpisodeFrame`, `EpisodicMemory_markDirty`.
5. Счётчик реконструкций; при достижении лимита — **`SleepMode_exit(true)`**.

**Пассивная семантика** (`PassiveMode_processUnderstandingModels`) в пульсе выполняется для главного пассивного цикла и во сне — как в обычном пассиве.

---

## Визуал

- Класс **`sleep-mode`** на `html`/`body`, фон страницы согласован с `vitals_ui` и `SleepMode_PAGE_BACKGROUND`.
- Во время фазы фантазма сна флаг **`SleepDreams_paleActivityBeast`** включает бледно-серый вывод блока «Активность Beast» (`genetic_reflexes_engine.js`, `mental_automatism.js`).

---

## Порядок скриптов

`sleep_mode.js` и `dreams.js` — рядом с базовыми контекстами; **`sleep_dream_process.js`** — **после** `episodic_memory.js` и **`fantasizming.js`** (см. комментарий в `index.html`).

---

## См. также

- `beast/_9_Conscience/about_passive_fantasizming.md` — пассивный режим и `info_fantasizming`.
- `beast/about_global_variables.md` — раздел «Режим сна».
- `manuals/Mad_programmer_manual.md` — обзор для разработчика.
