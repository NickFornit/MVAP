/**
 * Мост sleep_mode ↔ sleep_dream_process: хуки жизненного цикла сна и глобальный флаг бледной «Активности Beast».
 * Подключение: sleep_mode enter/exit/onPulse; index.html грузит sleep_dream_process.js до вызовов из puls.
 */
(function (global) {
  'use strict';

  /** true на фазе fantasy сна — genetic_reflexes_engine / mental_automatism осветляют вывод автоматизмов. */
  if (typeof global.SleepDreams_paleActivityBeast !== 'boolean') {
    global.SleepDreams_paleActivityBeast = false;
  }

  function onSleepEntered(fromAuto) {
    if (typeof global.SleepDreamProcess_onSleepEntered === 'function') {
      global.SleepDreamProcess_onSleepEntered();
    }
    if (typeof global.console !== 'undefined' && global.console.log) {
      global.console.log('SleepDreams: сон', fromAuto ? '(авто)' : '(вручную)');
    }
  }

  function onSleepExited() {
    if (typeof global.SleepDreamProcess_onSleepExited === 'function') {
      global.SleepDreamProcess_onSleepExited();
    }
    global.SleepDreams_paleActivityBeast = false;
    if (typeof global.console !== 'undefined' && global.console.log) {
      global.console.log('SleepDreams: пробуждение');
    }
  }

  function onPulse(pulsCount) {
    if (typeof global.SleepDreamProcess_onPulse === 'function') {
      global.SleepDreamProcess_onPulse(pulsCount);
    }
  }

  global.SleepDreams_onSleepEntered = onSleepEntered;
  global.SleepDreams_onSleepExited = onSleepExited;
  global.SleepDreams_onPulse = onPulse;
})(window);
