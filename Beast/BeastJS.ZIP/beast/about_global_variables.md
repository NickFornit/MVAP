# Справочник глобальных переменных Beast

Переменные и объекты, объявляемые в коде как `window.*` или `global.*` (в браузере `window` обычно и есть `global`). Группировка по назначению и модулям.

---

## Пульс и время

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **Cur_puls_val** | number | Счётчик пульсов. Инкрементируется в sep_of_puls(); сохраняется в localStorage. | puls.js, saving_ui.js |
| **PrevDiffForEpisode** | number | Значение getDiffImportance() в начале пульса (до активации стимулов). Для расчёта effect в кадре ЭП. | puls.js |
| **update_beast_pulse_view** | function | Обновление отображения пульса в UI. | puls.js |

---

## Виталы и состояние организма (_1_Genetic_vitals, _2_Genetic_basic_styles)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **VitalsArr** | Array | Массив виталов: { Id, value, importance, shift, name, title }. value 0..100. | vitals.js |
| **VitalsArrDefaults** | Array | Копия исходных значений виталов для сброса. | vitals.js |
| **BadVitalsValue** | Object | Степень выхода виталов из нормы (id → значение). | vitals.js |
| **BadNormWell** | number | Базовое состояние: 1=Плохо, 2=Норма, 3=Хорошо. | vitals.js, BasicContexts.js, prepare.js |
| **IntergalConditionImportance** | number | Интегральная значимость состояния организма. | vitals.js, BasicContexts.js, prepare.js |
| **IntergalConditionImportanceOld** | number | Предыдущее значение интегральной значимости. | vitals.js, BasicContexts.js |
| **DiffZnacher** | number | Дифференциатор значимости. | vitals.js, BasicContexts.js, prepare.js |
| **isShockState** | boolean | Режим шока. | vitals.js, vitals_ui.js, vitals_prepare.js |
| **DeathSequenceStarted** | boolean | Запущена ли последовательность «смерти». | vitals_ui.js, vitals_prepare.js |
| **IsSpeeping** | boolean | Режим сна. | vitals.js |
| **isGameMode** | boolean | Режим «Играть» (vitalID 11). | vitals.js, stimuls_ui.js |
| **isAuthoritarianEducation** | boolean | Режим «Учить» (vitalID 12). | vitals.js, stimuls_ui.js |
| **WellHoldRemainingPulses** | number | Оставшиеся пульсы удержания «Хорошо». | prepare.js |
| **BadHoldRemainingPulses** | number | Оставшиеся пульсы удержания «Плохо». | prepare.js |
| **NormHoldRemainingPulses** | number | Оставшиеся пульсы удержания «Норма» (явное удержание, SetNormForHolding / info_setBadNormWellForHolding(2)). | prepare.js |
| **ContextHoldRemainingPulses** | number | Оставшиеся пульсы удержания контекста. | prepare.js |
| **WellBadEffectManual** | number | Ручная настройка влияния Хорошо/Плохо на diff (по умолчанию 5). | prepare.js |
| **saveVitalsToStorage** | function | Сохранение виталов (localStorage/IndexedDB). | vitals_prepare.js |
| **performSensorOperations** | function | Операции «сенсоров» по виталам. | vitals_prepare.js |
| **update_vitals_view** | function | Обновление отображения виталов. | vitals_ui.js |
| **resetVitalsToDefaults** | function | Сброс виталов к умолчаниям. | vitals_ui.js |
| **startDeathSequence** | function | Запуск последовательности смерти. | vitals_ui.js |

---

## Базовые контексты (_2_Genetic_basic_styles)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **BasicContexts** | Array | Базовые контексты (Вентиляция, Водопой, Страх, Агрессия, Покой и т.д.). | BasicContexts.js |
| **VitalsContextsActivingArr** | Object | Соответствие «выход витала из нормы» → массив ID активируемых контекстов. | BasicContexts.js |
| **BasicContextsActived** | Array | ID активных в данный момент базовых контекстов. | BasicContexts.js |
| **getActiveBasicContexts** | function | Получение/пересчёт активных контекстов. | basic_contexts_ui.js / prepare |
| **update_basic_contexts_view** | function | Обновление отображения контекстов. | basic_contexts_ui.js |
| **ActivateBasicContextsForHolding** | function | Принудительный набор базовых контекстов на период удержания (столько пульсов, сколько `state_retention_period` в prepare.js). | prepare.js |
| **SetWellForHolding** / **SetBadForHolding** / **SetNormForHolding** | function | Установка удержания Хорошо (3) / Плохо (1) / Норма (2); взаимно сбрасывают счётчики друг друга. | prepare.js |

---

## Стимулы (_3_perception)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **StimulMotivarion** | Array | Мотивирующие стимулы (Еда, Вода, Поощрение, Приятно, Играть…). | stimuls.js |
| **ActiveMotivationStimuls** | Array | ID активных мотивирующих стимулов. | stimuls.js, stimuls_ui.js |
| **StimulPositiv** | Array | Позитивные стимулы. | stimuls.js |
| **StimulNegative** | Array | Негативные стимулы. | stimuls.js |
| **StimulNeutral** | Array | Нейтральные стимулы. | stimuls.js |
| **ActivePositivStimuls** | Array | ID активных позитивных стимулов. | stimuls_ui.js (init) |
| **ActiveNegativeStimuls** | Array | ID активных негативных стимулов. | stimuls_ui.js (init) |
| **ActiveNeutralStimuls** | Array | ID активных нейтральных стимулов. | stimuls_ui.js (init) |
| **OrientationReflex_runOnStimulusActivation** | function | Запуск ОР при изменении набора стимулов (вызывается из UI после клика). | orientation_reflex.js |

---

## Действия (_4_actions)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **BasicActions** | Array | Базовые действия (Плачет, Ест, Улыбается…). | effectors.js |
| **BasicVerbal** | Array | Базовые «звуки» (а, о, слоги…). | effectors.js |
| **BasicMirrorActions** | Array | Зеркальные действия оператора для ЭП: { Id, mirrorParentId "n_m", name }. | effectors.js |

---

## Генетические рефлексы (_5_Genetic__reflexes)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **StimulMotivarion_EffectsToBContexts** | Object | Влияние мотивирующих стимулов на базовые контексты. | genetic_reflexes.js |
| **StimulPositiv_EffectsToBContexts** | Object | Влияние позитивных стимулов на контексты. | genetic_reflexes.js |
| **StimulNegative_EffectsToBContexts** | Object | Влияние негативных стимулов на контексты. | genetic_reflexes.js |
| **StimulMotivarion_GeneticReflexes** | Object | Стимул (id) → массив actionId. | genetic_reflexes.js |
| **StimulPositiv_GeneticReflexes** | Object | Аналогично для позитивных. | genetic_reflexes.js |
| **StimulNegative_GeneticReflexes** | Object | Аналогично для негативных. | genetic_reflexes.js |
| **ActionProlongator** | Array | Пролонгированные действия (еда, питьё и т.д.): vitalID, shift. | genetic_reflexes.js |
| **processGeneticReflexes** | function | Обработка рефлексов на каждом пульсе. | genetic_reflexes_engine.js |
| **runGeneticActionFromSynonymReflex** | function | Запуск действия из условного рефлекса. | genetic_reflexes_engine.js |
| **setBeastActivityText** | function | Установка текста в блоке «Активность Beast». | genetic_reflexes_engine.js |

---

## Условные рефлексы (_5_2_synonyms_reflexes)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **SynonymReflexes** | Array | Массив условных (синонимических) рефлексов. | synonyms_reflexes.js |
| **NextSynonymReflexId** | number | Счётчик ID для новых рефлексов. | synonyms_reflexes.js |
| **synonyms_onGeneticActionFired** | function | Вызов при срабатывании генетического рефлекса (формирование/усиление условного). | synonyms_reflexes.js |
| **synonyms_tryRunReflexes** | function | Попытка запуска условных рефлексов по текущим стимулам и контексту. | synonyms_reflexes.js |
| **serializeConditionalReflexesState** / **applyConditionalReflexesState** | function | Сериализация/восстановление состояния УР. | synonyms_reflexes.js |
| **clearAllConditionalReflexes** | function | Сброс всех условных рефлексов. | synonyms_reflexes.js |
| **get_cur_context_for_synonyms** | function | Текущий контекст для условных рефлексов. | synonyms_reflexes.js |

---

## Семантическая память и образы (_6_semantic_memory)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **FinalImages** | Array | Образы восприятия: { id, stimulIds }. | FinalImage.js |
| **KnownFinalImageIds** | Array | Известные ID образов (для семантики). | semantic_memory.js |
| **FinalImages_findFinalImageId** | function | Поиск id по массиву stimulIds. | FinalImage.js |
| **FinalImages_getOrCreateFinalImageId** | function | Получить или создать ID образа по stimulIds. | FinalImage.js |
| **Emotions** | Array | Эмоции (сочетания контекстов). | Emotion.js |
| **KnownEmotionIds** | Array | Известные ID эмоций. | semantic_memory.js |
| **Emotions_findEmotionId** / **Emotions_getOrCreateEmotionId** | function | Поиск/создание ID эмоции по контекстам. | Emotion.js |
| **SemanticMemory** | Array | Массив записей семантической значимости. | semantic_memory.js |
| **SemanticMemoryIndex** | Object | Индекс [well][emotionId][finalImageId] → { meanImportance, samplesCount }. | semantic_memory.js |
| **registerSemanticSample** | function | Регистрация опыта (z, условия, finalImageId). | semantic_memory.js |
| **getSemanticObjectFast** | function | Быстрый поиск по индексу (well, emotionId, finalImageId) → объект или null. | semantic_memory.js |
| **getSemanticFramesForFinalImageId** | function | Все кадры по finalImageId через индекс (без линейного скана). | semantic_memory.js |
| **getDiffImportance** | function | Интегральная значимость состояния (для семантики и ЭП). | vitals_prepare / prepare.js |
| **LastDiffImportanceRaw** | number \| null | Сырой diff до `normalizeValue` в последнем `getDiffImportance()`; для «лупы» в `registerSemanticSample`. | prepare.js |
| **serializeSemanticState** / **applySemanticState** | function | Сериализация/восстановление семантики. | semantic_memory.js |
| **ImageUnderstandingModelArr** | Object | Модели понимания образов. | Understanding_model.js |
| **getImageUnderstandingModel** / **buildImageUnderstandingModel** | function | Получение/построение модели понимания. | Understanding_model.js |

---

## Дерево восприятия (_7_perception_tree)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **PerceptionTree_getOrCreateTerminalNode** | function | Получить или создать терминальный узел по пути [baseID, emotionID, activityID, 0,0,0]. | perception_tree.js |
| **PerceptionTree_updateActiveBranchView** | function | Обновление блока «Активная ветка дерева» и кадров ЭП в UI. | perception_tree.js |
| **PerceptionTree_getStimulusNamesForFinalImageId** | function | Имена стимулов по FinalImageId. | perception_tree.js |
| **PerceptionTree_getActionNamesForActionImage** | function | Имена действий по ID образа действия. | perception_tree.js |
| **PerceptionTree_serializeState** / **PerceptionTree_applyState** | function | Сохранение/загрузка дерева. | perception_tree.js |
| **PerceptionTree_*** | (прочие) | addNode, findActiveBranch, getPathByNodeId, serializeCompact и т.д. | perception_tree.js |

---

## Гиппокамп и ОР (_8_Hippocampus)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **active_stimulsArr_ID** | Array | ID образов (FinalImageId), вызвавших ОР. | hippocampus.js |
| **actual_stimul_ID** | number | Наиболее актуальный стимул (ID образа). Заполняется при ОР. | hippocampus.js, orientation_reflex.js |
| **Hippocampus_holdStimulusFromOR** | function | Удержать стимул в памяти после ОР. | hippocampus.js |
| **OR_well_known** | number | Порог samplesCount для допуска стимула к ОР и ЭП (по умолчанию 10). | orientation_reflex.js |
| **OrientationReflex_runOnStimulusActivation** | function | Запуск конкуренции и ОР при активации стимулов. | orientation_reflex.js |
| **OrientationReflex_isReflexBlockedByOR** | function | Проверка, заблокирован ли рефлекс ОР на 2 пульса. | orientation_reflex.js |
| **OrientationReflex_setBlockedReflex** | function | Заблокировать рефлекс по ключу. | orientation_reflex.js |

---

## Осознание (_9_Conscience)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **ConsciousnessCycles** | Object | Реестр циклов осмысления: id → cycleInfo. Поля: … **createdThemeId**, **createdSituationId** — ID темы и ситуации инфокартины на момент создания цикла; **expired**, **events[]**, `noInfoChangeStreak`; **fantasizmArr** (снимки правил ЭП для фонового цикла), **fantasizmPassiveFillStarted** и др. | consciousness_dispatcher.js |
| **ConsciousnessProcessNextId** | number | Счётчик для присвоения уникального ID новому циклу. | consciousness_dispatcher.js |
| **ConsciousnessCurrentProcessId** | number | ID текущего главного (осознаваемого) цикла. Отображается в UI «Главный цикл ID: nn». | consciousness_dispatcher.js, conscious_attention_channel.js |
| **ConsciousnessBackgroundStack** | Array | Очередь прерываний (до 10): при прерывании в стек пушится только ID текущего главного цикла (LIFO). Цикл остаётся в реестре как фоновый. При завершении главного promoteFromBackgroundCycle() достаёт ID из стека и делает этот цикл снова главным; если цикл уже завершён — берётся следующий ID или выбор по weight. | conscious_attention_channel.js, consciousness_dispatcher.js |
| **Consciousness_createCycle** | function | Создать новый цикл и зарегистрировать в ConsciousnessCycles. | consciousness_dispatcher.js |
| **Consciousness_setMainCycle** | function | Установить цикл с заданным ID главным (остальные isMainCycle = false). | consciousness_dispatcher.js |
| **Consciousness_getMainCycle** | function | Получить текущий главный цикл (status === 'running'). | consciousness_dispatcher.js |
| **Consciousness_cancelProcess** | function | Отменить цикл (status = 'cancelled'). | consciousness_dispatcher.js |
| **Consciousness_runElementary** | function | Элементарный проход осознания (уровни 1 и 2) по контексту цикла. Вызывается при создании цикла и при подъёме из стека. | conscious_attention_channel.js |
| **Consciousness_runOneStep** | function | Один шаг цикла мышления (для диспетчера). При `cycle.thinkingMode === 'passive'` — `info_fantasizming` и выход (без ур. 3–4); иначе ур. 3–4 в `conscience_level_3_runFromChannel` / `conscience_level_4_runFromChannel`. | conscious_attention_channel.js |
| **Consciousness_getMainCycleThinkingMode** | function | `'target'` \| `'passive'` — режим мышления **главного** цикла (не поле инфокартины). | consciousness_dispatcher.js |
| **Consciousness_getInfoPictureSignature** | function | Строка-сигнатура инфокартины для антистагнации пассивного фантазирования **главного** цикла (диспетчер и `runOneStep`). | consciousness_dispatcher.js |
| **dispetchConsciousnessThinking** | function | Диспетчер: шаг главного и фоновых (раз в 5 пульсов); при завершении главного или expired — decay фоновых weight×0.5; promote из стека. | consciousness_dispatcher.js, puls.js |
| **Consciousness_decayBackgroundOperativeMemory** | function | Умножает weight всех фоновых running-циклов на 0.5 (оперативная память). Вызывается при решении проблемы (главный finished), исчерпании главного (expired), вручную из пассива. | consciousness_dispatcher.js |
| **PassiveMode_notifyScenariosExhausted** | function | Исчерпание сценариев пассивного режима — вызвать для decay фоновых циклов. | goals.js |
| **stimuls_consciousness** | function | Вход ФО. Порог прерывания: эффективная значимость стимула ≥ 150% от thinkingImportance главного; при несовпадении темы/ситуации главного с инфокартиной эффективная значимость ×0.5. Новый цикл получает weight = значимости стимула. | conscious_attention_channel.js |
| **automatismRanForBranchIds** | Object | Флаг по ветке: branchId → true, если по этой ветке уже выполнен автоматизм. Ставится в stimuls_consciousness при запуске автоматизма; в processGeneticReflexes генрефлекс по этой ветке не запускается (исключает появление «сначала автоматизм, потом рефлекс»). Сбрасывается при смене ветки. | conscious_attention_channel.js, genetic_reflexes_engine.js |
| **unsolved_problem** | number \| null | Маркер нерешённой проблемы первого уровня осознания: FinalImageId актуального стимула, по которому не найдено приемлемого автоматического ответа (ни по ЭП, ни по штатному автоматизму). Устанавливается в stimuls_consciousness, может очищаться при успешном запуске автоматизма по тому же стимулу. | conscious_attention_channel.js |
| **conscience_level_2** | function | Реализация второго уровня осознания. Вызывается из Consciousness_runElementary при наличии нерешённой проблемы (unsolved_problem) для актуального стимула. Принимает расширенный контекст (actualId, branchId, well, emotionId, activityID, sourceContext). | conscience_level_2.js |
| **info_automatismWithEpisodeFeedbackAndExpireCycle** | function | Запуск автоматизма и ОД, привязка к ожиданию ЭП, expired+не главный цикл. Ур.1–3. Ответ оператора: `closeLastFrame` → `conscience_level_2`. | infofunctions.js |
| **info_insight** | function | Инсайт: цель «что для меня означает это?» (`meaning`), режим target; фоновый цикл — в главный (`Consciousness_setMainCycle`). Вызывается из `registerInsight` (gestalt.js), при \|effect\| ≥ `FANTASMI_INSITE_COMPARE` из `info_fantasizming`. | infofunctions.js |
| **info_new_abstract_semantic** | function | `(cycle, opts?)` — перенос `fantasizmArr` в `semanticStructure` клонов с `ruleKind` fantasy (`AbstractImages_upsertSemanticRuleFromFantasyFrame`), очистка сюжета на цикле; для сна. Учительские слоты не трогает. | infofunctions.js, abstract_images.js |
| **info_fantasizming** | function | Один шаг пассивного фантазирования: цепочка по кадрам ЭП с `responseStimulusImageId === currentStimulusId`, лучший по \|effect\|; сюжет в `fantasmPlotRules` / `fantasizmArr`; опционально инсайт без `runActionImage`. | fantasizming.js |
| **FANTASMI_INSITE_COMPARE** | number | Порог \|effect\| для инсайта из фантазирования (по умолчанию 5). | fantasizming.js |
| **info_bestEpisodicRule** | function | `(perceptionNodeId, situationId, options)` → `{ frame, exactRule }`; опции: `filterByStimulus`, `stimulusImageId`, `allowStimulusFallback` (ур.2 выживание / ур.3). | infofunctions.js |
| **info_bestEpisodicRuleForStimulus** | function | Обёртка: `filterByStimulus: true`. | infofunctions.js |
| **info_teacherEpisodicRuleForAction** | function | Учительский кадр ЭП: `(perceptionNodeId, situationId, actionImageId)` → `{ frame, exactRule }`; закрытый кадр с тем же ОД и ненулевым `responseStimulusImageId`, без ранжирования по effect. | infofunctions.js |
| **AbstractImages_findRuleFrameMatchingContext** | function | Кадр `semanticStructure` клона восприятия при точном совпадении ветки, `situationId`, `actualStimulusImageId` (ур.3 shortcut). | abstract_images.js |
| **AbstractImages_applyEpisodeEffectToSemanticContextAbstractions** | function | Ответ оператора: усреднить `meanImportance` клонов восприятия/действия по `effect`, если есть соответствующий кадр `semanticStructure`. | abstract_images.js |
| **AbstractImages_boostSemanticRulesForAction** | function | Ур.2, цель «значение»: усреднить `meanImportance` абстракций, в `semanticStructure.frames` есть правило с данным `actionImageId`. | abstract_images.js |
| **info_activateBasicContextForHolding** | function | `(basicContextId)` — удержание одного базового контекста на период как в UI (`ActivateBasicContextsForHolding([id])`). | infofunctions.js |
| **info_setBadNormWellForHolding** | function | `(1\|2\|3)` — удержание Плохо / Норма / Хорошо (`SetBadForHolding` / `SetNormForHolding` / `SetWellForHolding`). | infofunctions.js |
| **activateStimulusForBasicMirrorActionId** | function | Включить стимул по `BasicMirrorActions[].Id` (поле `mirrorParentId` → тип строки стимулов и локальный id). | stimuls_ui.js |
| **info_activateBasicMirrorAction** | function | Обёртка над `activateStimulusForBasicMirrorActionId`. | infofunctions.js |
| **conscience_level_3** | function | Одно событие 3-го уровня: `{ sourceCycle, reason? }`. Пайплайн ментальный → semanticStructure → ЭП → учитель; гейт ожидания ЭП; гейты значимости кадра/семантики; лог через `Consciousness_cycleAppendLog`. Вызывается из `conscience_level_3_runFromChannel`. | conscience_level_3.js |
| **conscience_level_3_runFromChannel** | function | Тик ур. 3 из `Consciousness_runOneStep`: отложенное планирование ур.2, «плач», `isDissatisfaction`; вложенный `runLevel3` не вызывает повторный полный проход, если уже ожидание ЭП по автоматизму. | conscience_level_3.js |
| **conscience_level_4** | function | Одно событие 4-го уровня (расширения; гештальт — через `Gestalt_*`). | conscience_level_4.js |
| **conscience_level_4_runFromChannel** | function | Тик ур. 4 из канала: `Gestalt_onConsciousnessTick` (резонанс, контекст). | conscience_level_4.js |
| **GestaltArr** | Array | Записи гештальтов (нерешённые задачи по образу цели). | gestalt.js |
| **GestaltResonanceBuffer** | Array | FIFO сигнатур закрытых кадров ЭП для кросс-цикловой аналогии. | gestalt.js |
| **GestaltContextForLevel3** | Object \| null | Контекст открытого гештальта для ур.3 после `Gestalt_prepareContextForCycle`. | gestalt.js |
| **Gestalt_prepareContextForCycle** | function | Вызывается в начале `conscience_level_3_runFromChannel`. | gestalt.js |
| **Gestalt_onConsciousnessTick** | function | Тик ур.4: резонанс, обновление контекста. | gestalt.js |
| **Gestalt_onEpisodeFeedbackClosed** | function | Вызывается из `EpisodicMemory_closeLastFrame` после расчёта effect. | gestalt.js |
| **Gestalt_bumpFromMeaningForecast** | function | Ур.2, цель «значение»: повысить статус открытого гештальта при совпадении цели/автоматизма с прогнозируемым ОД. | gestalt.js |
| **GESTALT_STATUS** | Object | Константы статусов 0–4. | gestalt.js |
| **Info_showGestaltsList** | function | Диалог со списком ID гештальтов; щелчок по ID → `Info_showGestaltDetail`. | informing.js |
| **Info_showGestaltDetail** | function | Детализация одной записи `GestaltArr` (ссылки на цель, ветку, ситуацию, моторные автоматизмы). | informing.js |
| **InfoPicture.fantasmPlotRules** | Array | Сюжет фантазма: снимки кадров ЭП; при переходе target→passive (`Info_fillFantasmPlotOnPassiveMain`) и на каждом шаге `info_fantasizming`. | informing.js |
| **InfoPicture.thinkingSource** | string | `'external'` \| `'imagination'` \| `'fantasy'` — откуда оператору виден текущий ход мысли (стимул / воображение / пассивная фантазия). | informing.js, fantasizming.js |
| **Info_showFantasmPlotDetail** / **Info_showDetail('fantasmPlot')** | function | Детализация сюжета фантазма. | informing.js |
| **Info_fillFantasmPlotOnPassiveMain** / **Info_fillFantasmPlotOnPassiveBackground** | function | Заполнение сюжета при переходе в пассивный режим (заглушка: последние кадры `Episodes`). Развитие сюжета в фоне — через `info_fantasizming`, не через отдельный вызов background-fill. | informing.js |
| **addBlockedReflexToQueue** | function | Поставить заблокированный ОР генетический рефлекс в очередь delayedReflexes (вызов из ОР после setBlockedReflex). Рефлекс привязан к branchId. | genetic_reflexes_engine.js |
| **removeDelayedReflexesForBranch** | function | Удалить из очереди отложенных рефлексов все записи по ветке branchId. Вызывается из stimuls_consciousness при запуске автоматизма — без сравнения действий. | genetic_reflexes_engine.js |
| **runActionImage** | function | Выполнить образ действия (ОД) по ID: actionIds и/или odSequence. Вызывается при срабатывании автоматизма. | genetic_reflexes_engine.js |

---

## Образы действия (_10_actions_image)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **ActionImages** | Array | Образы действия: { id, finalImageId, actionIds, odSequence }. | actions_image.js |
| **ActionImages_registerReaction** | function | Зарегистрировать реакцию (finalImageId, actionId) → id ОД. | actions_image.js |
| **ActionImages_getOrCreateActionImageId** | function | Получить или создать ID ОД по finalImageId. | actions_image.js |
| **ActionImages_getActionImage** | function | Получить объект ОД по id. | actions_image.js |
| **ActionImages_serializeState** / **ActionImages_applyState** | function | Сериализация/восстановление. | actions_image.js |

---

## Эпизодическая память (_10_Episodic_memory)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **Episodes** | Array | Массив кадров эпизодической памяти. | episodic_memory.js |
| **EpisodicMemory_waitingStartedAt** | number \| null | Время начала периода ожидания в этой сессии (timestamp) или null. Используется для видимости прогресс-бара и для isInWaitingPeriod(); не восстанавливается из IndexedDB. | episodic_memory.js |
| **EpisodicMemory_pulsesWaiting** | number | Текущее число пульсов ожидания (обновляется в EpisodicMemory_onPulse). | episodic_memory.js |
| **EpisodicMemory_barShowCompletePulsesLeft** | number | Оставшиеся пульсы показа 100% прогресс-бара после закрытия кадра с ответом. | episodic_memory.js |
| **EpisodicMemory_testMode** | boolean | Режим тестирования (пошаговые сообщения). | episodic_memory.js |
| **EpisodicMemory_skipConditionalReflexFormation** | boolean | Ставится в true в ОР при закрытии кадра ответным стимулом; в startAction блокирует образование УР; сбрасывается в puls.js после processGeneticReflexes. | orientation_reflex.js, genetic_reflexes_engine.js, puls.js |
| **save_episodic_memory** | function | Создание/закрытие кадра (вызывается из ОР). | episodic_memory.js |
| **EpisodicMemory_setLastFrameActionFromActionId** | function | Записать ответное действие в последний кадр по actionId. | episodic_memory.js |
| **EpisodicMemory_isInWaitingPeriod** | function | Идёт ли период ожидания ответа. | episodic_memory.js |
| **EpisodicMemory_closeLastFrameWithResponse** | function | Закрыть последний кадр с ответным стимулом. | episodic_memory.js |
| **EpisodicMemory_onPulse** | function | Вызывается из puls.js каждый пульс; считает пульсы ожидания и закрывает кадр по таймауту. | episodic_memory.js |
| **EpisodicMemory_response_waiting_period** | number | Длительность периода ожидания в пульсах (не таймер). | episodic_memory.js |
| **EpisodicMemory_serializeState** / **EpisodicMemory_applyState** | function | Сериализация/восстановление ЭП. | episodic_memory.js |
| **EpisodicMemory_clearAll** | function | Очистка всей ЭП. | episodic_memory.js |
| **EpisodicMemory_pickBestPositiveFrameForStimulus** | function | Лучший кадр с effect > 0 и заданным `stimulusImageId` (ур.3 ФО). | episodic_memory.js |
| **EpisodicMemory_getFramesByResponseStimulus** | function | Все кадры, где `responseStimulusImageId` совпадает с аргументом (учительский ответ на стимул). | episodic_memory.js |
| **EpisodicMemory_pickBestFrameByAbsEffect** | function | Лучший кадр по максимуму \|effect\| среди кандидатов с ненулевым `actionImageId`. | episodic_memory.js |

---

## Автоматизмы (_11_Automatizms)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **Automatizms** | Array | Массив автоматизмов (id, branchId, usefulness, actionsImageId, count, isDefault). | automatizms.js |
| **Automatizms_getAutomatizmsByBranchId** | function | Все автоматизмы по ID ветки дерева. | automatizms.js |
| **Automatizms_getDefaultAutomatizmForBranch** | function | Штатный автоматизм для ветки (isDefault=true). | automatizms.js |
| **Automatizms_createAutomatizm** | function | Создать автоматизм (без дубля по branchId+actionsImageId); возвращает id или 0. | automatizms.js |
| **Automatizms_setDefaultAutomatizm** | function | Назначить автоматизм штатным для ветки (остальные той же ветки — isDefault=false). | automatizms.js |
| **Automatizms_addUsefulnessSample** | function | Обновить usefulness и count по эффекту. | automatizms.js |
| **Automatizms_serializeState** / **Automatizms_applyState** | function | Сериализация/восстановление для файла и IndexedDB. | automatizms.js |
| **GoalImagesLife** | Array | Образы цели жизненного опыта: { id, perceptionNodeId, stimulusImageId, actionImageId, effect, count, lastUsedAt }. Формируются на втором уровне при работе с эпизодами памяти. | goals.js |
| **Goals_determineGoalInSituation** | function | Определение цели (первый шаг ур.2): база → жизненный опыт по ветке → при значимости стимула >3 и отсутствии цели по ветке — умолчательная цель «значение» (`meaning`). Устанавливает currentGoalType/currentGoalId/currentGoalVitalId. | goals.js |
| **Goals_ensureDefaultMeaningGoal** / **Goals_isDefaultMeaningGoalId** / **Goals_getDefaultMeaningGoalId** | function | Умолчательная цель «что для меня означает это?» (perceptionNodeId=0, situationId=0, actionImageId=-1); проверка id. | goals.js |
| **Goals_getBestLifeGoalForBranch** | function | Лучший образ цели жизненного опыта для ветки (по точному совпадению и родителям), с учётом minCount. | goals.js |
| **Goals_considerNewGoalFromEpisode** | function | Рассмотрение кадра ЭП: при effect > 0 — добавление/обновление записи в GoalImagesLife. | goals.js |
| **getActiveBaseGoalVitalId** | function | Базовая гомеостатическая цель: ID витала для возврата в норму (только при BadNormWell === 1). | goals.js |
| **Goals_serializeState** / **Goals_applyState** | function | Сериализация/восстановление образов целей для файла и IndexedDB. | goals.js |
| **PerceptionTree_getActiveTerminalNodeId** | function | Текущий активный терминальный узел дерева по состоянию виталов и активных стимулов. Используется для привязки автоматизмов и передачи branchId в stimuls_consciousness. | perception_tree.js |

---

## Режим сна (_12_Sleep)

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **SleepMode_isActive** | function | Активен ли режим сна (UI + контексты + сновидения). | sleep_mode.js |
| **SleepMode_CONTEXT_ID** | number | ID базового контекста «Сон» (15). | sleep_mode.js |
| **SleepMode_exit** | function | Выход из сна; при `exit(true)` — нормальное завершение сновидений → удаление фоновых циклов ФО. | sleep_mode.js |
| **SleepMode_toggle** / **SleepMode_enterAuto** / **SleepMode_tryAutoAfterFinCycles** | function | Ручной переключатель, авто-вход, хук после финового цикла (>100). | sleep_mode.js |
| **SleepMode_shouldBlockStimulusInteraction** | function | Блокировать ли клик по стимулу в режиме сна. | sleep_mode.js |
| **SleepMode_refreshStimulusButtonVisuals** | function | Подсветка/блокировка кнопок стимулов (вызывается из пульса). | sleep_mode.js |
| **SleepMode_PAGE_BACKGROUND** | string | Ожидаемый фон страницы в сне (согласование с vitals_ui). | sleep_mode.js |
| **SleepDreams_onSleepEntered** / **SleepDreams_onSleepExited** / **SleepDreams_onPulse** | function | Мост к оркестратору сновидений. | dreams.js |
| **SleepDreams_paleActivityBeast** | boolean | Бледный текст «Активность Beast» на фазе фантазма сна. | dreams.js, sleep_dream_process.js |
| **SleepDreamProcess_onSleepEntered** и др. | function | API процесса сновидений (очередь пустых кадров, лимиты). | sleep_dream_process.js |
| **ConsciousnessFinCyclesTotal** | number | Счётчик «финовых» циклов осмысления; при >100 возможен авто-сон. | consciousness_dispatcher.js (инкремент), sleep_mode.js |
| **Consciousness_deleteAllBackgroundCycles** | function | Удалить все фоновые running-циклы; только из `SleepMode_exit(true)`. | consciousness_dispatcher.js |
| **EpisodicMemory_isEmptyFrameForSleep** / **EpisodicMemory_collectEmptyFrameIndicesNewestFirst** | function | Критерий пустого кадра и порядок перебора для сновидений. | episodic_memory.js |

Подробнее: **`beast/_12_Sleep/about_sleep.md`**.

---

## UI и сохранение

| Переменная | Тип | Описание | Где задаётся |
|------------|-----|----------|--------------|
| **show_alert** / **close_alert** | function | Показ/закрытие кастомного алерта. | sys/alerts/alerts.js |
| **show_confirm** / **show_prompt** | function | Подтверждение и ввод. | sys/alerts/alerts.js |
| **showSaveIndicator** / **hideSaveIndicator** | function | Показ/скрытие индикатора записи (синий круг). | index.html (inline) |
| **registerIndexedDBSaver** | function | Регистрация функции сохранения на пульс. Сохранение по мере изменения: каждый модуль использует dirty + подпись (lastSavedSig), чтобы писать в IndexedDB только при реальном изменении данных (ЭП — новый/удалённый кадр, дерево — новый узел, семантика/УР/ОД — изменение массивов). Список модулей — в комментарии в indexeddb.js. | sys/IndexedDB/indexeddb.js |
| **runIndexedDBSavesForPulse** | function | Запуск всех зарегистрированных сохранений раз в пульс (вызывается из sep_of_puls). | sys/IndexedDB/indexeddb.js |
| **IndexedDBModule** | Object | Обёртка openDatabase, get, put, remove. | sys/IndexedDB/indexeddb.js |
| **BEAST** | Object | Объект для общих структур проекта (например, реестр сохраняемых модулей). | date/saving_ui.js |
| **BEAST.persistentModules** | Array | Реестр сохраняемых модулей: массив { key, serialize, apply }. Добавление нового хранилища в файл = одна запись здесь. | date/saving_ui.js |
| **handle_save_memory_click** / **load_all_memory** | function | Сохранение/загрузка памяти в файл. | date/saving_ui.js |
| **was_emergency_shutdown** | boolean | Был ли аварийный выход (до закрытия страницы). | saving_before_closing.js |
| **init_saving_before_closing** / **saving_before_closing** | function | Инициализация и сохранение при закрытии. | saving_before_closing.js |
| **updateStimulusButtonsReadinessView** | function | Обновить UI-бордеры «готовности к ОР» у всех кнопок (без hover). Вызывается из `puls.js` только на 2-м пульсе после старта. | _3_perception/stimuls_ui.js |
| **updateStimulusButtonsReadinessViewForFinalImageId** | function | Точечное обновление «готовности к ОР» для кнопок, относящихся к конкретному `finalImageId`. Вызывается из `semantic_memory.js` после записи нового семантического образца. | _3_perception/stimuls_ui.js, _6_semantic_memory/semantic_memory.js |

---

При добавлении новых глобальных переменных или функций их стоит дописывать в этот файл с указанием модуля и кратким назначением.
