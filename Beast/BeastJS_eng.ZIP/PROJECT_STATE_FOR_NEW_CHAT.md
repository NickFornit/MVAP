# BEAST project state — snapshot for a new chat

**Snapshot date:** 2026-03-21

## Why this document exists

Hand this file at the start of a new chat (or attach it to a task) to quickly restore architecture, code entry points, and agreed logic — without replaying the whole conversation history.

## What this project is

- **BEAST** is a browser app (“Beast creature, comms panel”). Entry point: **`index.html`** at the repo root.
- Main code: **`beast/`** — modules in subfolders `_1_` … `_12_` (vitals, basic contexts, stimuli, actions, reflexes, semantics, perception tree, hippocampus/OR, consciousness processing, episodic memory, action images, automatisms, **sleep mode / dreams**).
- **Pulse:** `beast/puls.js` — ticks, `global.cpuls`, consciousness dispatcher, reflexes, EP.
- **Persistence:** IndexedDB, save to file (`saving_all` / UI); some uses `localStorage`.
- The working copy **may not be in git** — treat on-disk files as the source of truth.

## Root documents

| File | Purpose |
|------|---------|
| **`PROJECT_STATE_FOR_NEW_CHAT.md`** | This snapshot for AI and developers |
| **`Mad_programmer_manual.md`** | Longer manual on Beast principles, layers, debugging, and evolving the code |

## Script load order (`index.html`)

The **order at the end of `body`** matters. Fragment of the consciousness chain:

`consciousness_dispatcher.js` → `infofunctions.js` → `conscious_attention_channel.js` → … → **`mental_automatism.js`** → **`conscience_level_2.js`** → **`conscience_level_3.js`** → **`conscience_level_4.js`** → **`gestalt.js`** → … → **`abstract_images.js`** → **`episodic_memory.js`** → …

`gestalt.js` must load **before** `episodic_memory.js` (hook `Gestalt_onEpisodeFeedbackClosed` in `closeLastFrame`).

**Sleep:** `sleep_mode.js` and `dreams.js` — near basic contexts; **`sleep_dream_process.js`** — **after** `episodic_memory.js` and **`fantasizming.js`** (fantasy chain, abstractions per frame).

By the time **level 3** runs, modules above in the list are already loaded; `abstract_images.js` loads after the level-3 file, but at runtime globals `AbstractImages_*` are available when that code runs.

## Documentation map

| Document | Contents |
|----------|----------|
| `beast/_10_Episodic_memory/about_episodic_memory_rules.md` | EP rules, OR, waiting, second pass, chains |
| `beast/_10_Episodic_memory/about_episodic_memory.md` | EP, link to abstractions, level 3 |
| `beast/_9_Conscience/about_conscience.md` | Consciousness processing, dispatcher, levels 3–4, gestalt links |
| `beast/_9_Conscience/about_gestalt.md` | Gestalt, resonance buffer, integration with levels 3–4 and EP |
| `beast/_8_Hippocampus/about_hippocampus.md` | Hippocampus and OR |
| `beast/_6_semantic_memory/about_semantic_memory.md` | Semantic memory |
| `beast/about_global_variables.md` | Key globals reference |
| `beast/docs/design_conscious_automatisms.md` | Conceptual design |
| `beast/docs/analysis_adaptivity_system.md` | Adaptivity walkthrough (if used) |
| `beast/_12_Sleep/about_sleep.md` | Sleep mode, stimuli, dreams, link to consciousness and EP |

Fix mismatches **code ↔ comments ↔ about_*** at the source in `beast/`.

## Core logic (files)

| Topic | Files |
|------|--------|
| OR, stimulus competition | `beast/_8_Hippocampus/orientation_reflex.js` |
| Consciousness entry, “thought silence”, `Consciousness_runOneStep` | `beast/_9_Conscience/conscious_attention_channel.js` |
| Cycle registry, **`Consciousness_cycleAppendLog`**, `expired` / `force` in log | `beast/_9_Conscience/consciousness_dispatcher.js` |
| EP, `closeLastFrame`, effect ∈ [-10,+10] | `beast/_10_Episodic_memory/episodic_memory.js` |
| Abstractions, `semanticStructure`, context frame lookup | `beast/_9_Conscience/abstract_images.js` |
| `info_automatismWithEpisodeFeedbackAndExpireCycle`, `info_bestEpisodicRule` | `beast/_9_Conscience/infofunctions.js` |
| **Level 3:** pipeline, EP-wait and significance gates | `beast/_9_Conscience/conscience_level_3.js` |
| **Level 4 / gestalt:** resonance, context for level 3, EP feedback | `beast/_9_Conscience/conscience_level_4.js`, `beast/_9_Conscience/gestalt.js`, `beast/_9_Conscience/about_gestalt.md` |
| Level 2, operator answer, mental automatism from semantic rule | `beast/_9_Conscience/conscience_level_2.js` |
| Mental automatisms, MAI | `beast/_9_Conscience/mental_automatism.js` |
| Info picture, `mode: passive \| target` | `beast/_9_Conscience/informing.js` |
| Life-experience goals, default goal “Cry”, action images | `beast/_9_Conscience/goals.js`, `beast/_10_actions_image/actions_image.js` |
| Genetic reflexes, `processGeneticReflexes` | `beast/_5_Genetic__reflexes/genetic_reflexes_engine.js`, `genetic_reflexes.js` |
| Stimuli, UI | `beast/_3_perception/stimuls.js`, `stimuls_ui.js` |
| Sleep mode, dreams, `SleepMode_exit(true)` → background cycles | `beast/_12_Sleep/sleep_mode.js`, `dreams.js`, `sleep_dream_process.js`; `prepare.js` (Sleep context); `manuals/Mad_programmer_manual.md` §14 |

## Third level of consciousness (current behavior)

File: **`beast/_9_Conscience/conscience_level_3.js`**. Per tick: **`conscience_level_3_runFromChannel`** from `Consciousness_runOneStep`.

**Attempt order:** mental automatism (default + aligned `semanticStructure` frame) → shortcut via `AbstractImages_findRuleFrameMatchingContext` → stimulus semantics + best EP rule (`info_bestEpisodicRule`, stimulus, positive effect) → teacher fallback.

**Stability:** while `awaitingAutomatismEpisodeFeedback && !automatismOperatorAnswerReceived`, the full pipeline does not run (avoids false “rule not found” on second/third trigger in the same tick). Nested `runLevel3` checks the same before calling `conscience_level_3`.

**Significance before motor:**

- `conscience_level_3_semanticStructureFrameAllowsMotor(fr)` — for shortcut and mental path: teacher or episodic with **numeric effect > 0** (or teacher markers on frame).
- Episodic path: if the best semantic frame for the stimulus has **meanImportance < 0**, motor does not run.
- Teacher: if the frame has **numeric effect ≤ 0**, motor does not run.

**Cycle log:** important lines go to **`Consciousness_cycleAppendLog(cycle, text, puls, opts)`**; when **`cycle.expired`** without **`opts.force`**, the dispatcher **does not** append — for level 3 after automatism **`{ force: true }`** is often used. Wrapper in file: `appendCycleLog` (main cycle and `force`).

Details: **`beast/_9_Conscience/about_conscience.md`**, **`beast/about_global_variables.md`**, **`beast/_10_Episodic_memory/about_episodic_memory.md`**.

## Fourth level and gestalt

- **Files:** `conscience_level_4.js` (channel tick), `gestalt.js` (data and logic), `about_gestalt.md`.
- **Level 3:** at the start of `conscience_level_3_runFromChannel`, **`Gestalt_prepareContextForCycle`** — **`GestaltContextForLevel3`** gets a snapshot of the open gestalt for the goal image (if any).
- **Level 4:** in `conscience_level_4_runFromChannel` — **`Gestalt_onConsciousnessTick`** only for the **main** cycle.
- **EP:** after computing `effect` in **`closeLastFrame`**, **`Gestalt_onEpisodeFeedbackClosed`** runs.
- **UI:** in the “Information picture” row, indicator **gest: N** (`informing.js`).

## Important behavioral agreements

- **`orientationReflexWinner`:** OR winner is already chosen — the main-cycle interrupt threshold must not block starting new consciousness processing for “insufficient significance”.
- **`mainBlocksThoughtSilence`:** competitor significance reduction — only while the main cycle exists and is **not** `expired`.
- **EP waiting:** operator answer closes the frame; link to abstractions and **`MentalAutomatizms_tryCreateFromSemanticStructureRule`** — see `about_episodic_memory.md`.
- **Default goal “Cry” / action images:** when loading action images from IndexedDB, sync default goal `actionImageId` with canonical AID (`getOrCreateActionImageId(0, [1], '')`) — see `goals.js`, `actions_image.js`.
- **Food / Water (motivation 1–2):** effects include holding “Well” (`SetWellForHolding`); for OR, `OR_well_known` bypass applies with active stimuli 1001/1002; on activation `automatismRanForBranchIds` resets; info picture may suppress critical-vital indicator with “Well” + food/water — see `genetic_reflexes.js`, `orientation_reflex.js`, `stimuls_ui.js`, `info_detectors.js`.
- **Sleep mode:** when `SleepMode_isActive`, `getActiveBasicContexts` returns only the Sleep context (id 15), regardless of vitals; dreams use passive main cycle and `info_fantasizming` like normal passive; after the dream frame limit, `SleepMode_exit(true)` calls `Consciousness_deleteAllBackgroundCycles` (manual exit — no). See `beast/_12_Sleep/about_sleep.md`.

## What is considered stable

1. Pulse, vitals, contexts, stimulus UI, perception tree, reflexes — in the main loop.
2. **OR → consciousness → EP** at nominal thresholds; EP frame and waiting progress with full OR.
3. Main consciousness cycle marked **`expired`** on stagnation; cycle log respects `force` after automatism.
4. Level 3 does not blindly re-run while waiting for EP on an already-started automatism.

## Known limitations

1. Early pulses after load: contexts may be unready — OR readiness indicator can be briefly wrong.
2. Stimulus button indicator does not model full multi-candidate competition.
3. Level 2 and passive scenarios — area for growth; level 4 gestalt is basic; extensions — see `about_gestalt.md` and TODOs in code.

## Template message for a new chat

```
Context: BEAST project — read PROJECT_STATE_FOR_NEW_CHAT.md in the root first.

Goal: develop sleep and dream module

Constraints: do not break anything; sleep module is autonomous in `_12_Sleep` files but affects contexts (`prepare.js`) and pulse (`SleepDreams_onPulse` before dispatcher).
```

After architecture edits, **update this file** and matching `about_*.md` under `beast/`.
