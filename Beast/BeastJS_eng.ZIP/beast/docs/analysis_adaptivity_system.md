# Adaptivity system analysis: CR — OR — SM — EP

Assessment of mutual functionality, consistency, logic, and efficiency of the chain: **conditional reflexes (CR)** — **orientation reflex (OR)** — **semantic memory (SM)** — **episodic memory (EP)**.

---

## 1. Mutual functionality

### 1.1 Data flow

- **Stimulus (click)** → update `Active*Stimuls` → `setTimeout(OR, 0)` → OR runs on next tick.
- **OR** uses: perception tree (path), SM (importance/novelty), threshold `OR_well_known`; on pass — reflex block 2 pulses, hippocampus, consciousness, **SM registration** (once per activation), **EP frame create/close**.
- **Pulse** → `processGeneticReflexes`: first `tryRunSynonymReflexes` (CR); on match — `runGeneticActionFromSynonymReflex` (with OR block check); else genetic maps; if OR blocks, reflex goes to `delayedReflexes` with `noConditionalReflex: true`.
- **SM** keys: `(BadNormWell, emotionId, finalImageId)`. Registration only from OR — one `registerSemanticSample` per activation, no double count.
- **EP:** frame created in OR on each OR fire (after `OR_well_known`); response stimulus during wait does not check knownness threshold; wait only when `waitingStartedAt != null` (loaded open frame does not count as “in wait”); progress bar only when active wait this session; stimulus deactivation — no message. Action written to frame from `startAction` via `EpisodicMemory_setLastFrameActionFromActionId`; close on response stimulus during wait (check isInWaitingPeriod() before OR_well_known); timeout in `EpisodicMemory_onPulse` by pulses.

**Summary:** Roles split: OR decides “what matters now” and starts SM/EP; CR and genetic reflexes run on the pulse with OR block; SM and EP do not duplicate (SM = image importance, EP = rule sequence).

### 1.2 Context alignment

- **CR:** context = `getCurrentContextKey()` → `"well:id1,id2,..."` from `BadNormWell` and IDs in `BasicContextsActived`.
- **OR, SM, EP:** context = `BadNormWell` + `Emotions_getOrCreateEmotionId(BasicContextsActived)` (same contexts, numeric id).
- Same source (`BadNormWell`, `BasicContextsActived`), representations aligned.

---

## 2. Consistency

### 2.1 What aligns

- **FinalImageId block:** OR blocks by `winnerId` (FinalImageId); `processGeneticReflexes` checks `fullFinalImageId`; `runGeneticActionFromSynonymReflex` passes `finalImageId` — same key for genetic and CR.
- **Single semantic registration:** only in OR; `registerSemanticExperience` removed from `startAction` (stub), no extra `samplesCount`.
- **CR not formed on OR path:** delayed reflex carries `noConditionalReflex: true`, `startAction` skips `synonyms_onGeneticActionFired` — no CR formation for stimulus that triggered OR delay.
- **EP wait:** during wait a new stimulus only closes current frame with answer; no new frame and no new OR; pulse counter and single `EpisodicMemory_onPulse` avoid timer races.

### 2.2 Possible gaps

- **OR_well_known (10):** when `samplesCount < 10`, OR and EP frame are not created, but semantics still register ( `registerSemanticSample` before check). “Register first, decide second” is consistent, but 10 is a heuristic; other values change EP/OR rates.
- **EP:** frame and bar on each OR pass (after knownness). Response during wait skips OR_well_known. Details in about_episodic_memory.md and about_episodic_memory_rules.md.

---

## 3. Logic

### 3.1 Decision sequence

1. Stimulus activation → OR checks “novel/significant enough” and whether EP wait is active.
2. If wait — close frame with response stimulus, no new frame and no new OR.
3. If not — SM registration; if novelty/importance pass — reflex block, hippocampus, consciousness, EP frame if needed.
4. On pulse: if OR blocked, reflex delayed without CR formation; on fire (immediate or delayed) action goes to AID and last EP frame.

Chain “stimulus → attention (OR) → memory (SM/EP) → action (genetic/CR)” holds.

### 3.2 Semantic separation

- **SM:** “how important is this image in these conditions” (well, emotionId, finalImageId) — running average, grows with exposures.
- **EP:** “what followed what and what effect” — stimulus → action → effect/answer, order matters.
- **CR:** “in this context this image leads to this action” — fast, no full importance recompute.
- **OR:** picks “main” stimulus by novelty and importance; “known enough” threshold filters noise.

Roles do not overlap in meaning.

---

## 4. Efficiency

### 4.1 What works well

- SM lookup via `SemanticMemoryIndex[well][emotionId][finalImageId]` — O(1).
- SM frames for one `finalImageId` via index walk, not full `SemanticMemory` scan.
- Single EP wait handler on pulses, no multiple timers.
- Semantic registration in one place (OR), no duplication.

### 4.2 Bottlenecks

- **OR on every click:** full salience recompute over candidates and tree paths. Cost grows with many active stimuli and deep tree; fine at current scale.
- **CR:** linear `SynonymReflexes` scan each pulse. With many CRs, index by context and/or stimulus set (`activeIdsKey`).
- **EP:** array append/close O(1); very long history may need pagination or serialization cap.

---

## 5. Notes and suggestions

### 5.1 Documentation

- **Suggestion:** One place (e.g. `about_global_variables.md` or `docs/adaptivity_flow.md`) briefly document order: click → OR (semantics, block, EP) → pulse (CR, genetic, delayed with `noConditionalReflex`). Easier onboarding and debugging.
- **Suggestion:** In OR code, comment explicitly that `registerSemanticSample` is intentional once per activation and must not be duplicated elsewhere.

### 5.2 Thresholds

- **OR_well_known = 10**, **OR_HYSTERESIS**, **OR_BLOCK_PULSES = 2**, **response_waiting_period = 15** (pulses) — scattered. **Suggestion:** one config (e.g. `beast/config/adaptivity.js` or header sections in `orientation_reflex.js` and `episodic_memory.js`) with short comments for tuning.
- **Suggestion:** If “training modes” (aggressive/economical EP) appear, frame creation (`!hasSignificance || testMode`) as a function or flag to avoid spread conditions.

### 5.3 CR context vs emotion

- CR uses string context key; SM/OR use numeric `emotionId`. If emotions change (merge, normalize), sync `getCurrentContextKey` and `Emotions_getOrCreateEmotionId`. **Suggestion:** one review across CR, OR, SM when emotion format changes.

### 5.4 EP and “known” stimuli

- EP frame is not created when SM already has significance (non-test mode). If episodes are needed for known stimuli too (sequence analysis), widen `runEpisodic` without breaking single SM registration.

### 5.5 Scaling CR

- Large CR count: per-pulse array scan may hurt. **Suggestion:** index by `contextKey` and/or stimulus-set hash (`activeIdsKey`) for candidate filtering, same semantics (context + stimulus set).

### 5.6 EP test mode

- `EpisodicMemory_testMode` adds step messages and creates frames even with significance — good for debugging. Document that test mode **intentionally** broadens EP behavior vs “production.”

---

## 6. Short conclusion

- **Functionality:** OR, SM, EP, and CR align on flow (click → OR → semantics/block/episode; pulse → CR/genetic with block, no double SM).
- **Consistency:** one FinalImageId key, single SM source, EP wait avoids new frames/OR; nuances — OR_well_known and “EP only without significance” policy.
- **Logic:** role split (attention, importance, sequence, conditional action) and decision order are coherent.
- **Efficiency:** SM and EP wait are optimized; CR may need indexing as count grows.

The adaptivity system is coherent and extensible; suggestions above target easier tuning, docs, and scaling.
