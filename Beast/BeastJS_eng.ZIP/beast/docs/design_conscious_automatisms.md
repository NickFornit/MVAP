# Conscious automatisms and consciousness processing — implementation strategy

Document for the next stage: conscious automatisms and consciousness processing. The old implementation was in Go (OLD_CODE); the new JS stack already has stronger adaptive systems — avoid dragging obsolete patterns into JS, but keep the conceptual frame.

---

## 0. Project purpose and scope

**Purpose:** the project is not “a working creature and its upbringing,” but the **most adequate way to implement the theory** of individual adaptivity. As theories are formalized in math, adaptivity theory is best described by program implementation — an analog of math in physics, but more effective for describing **adaptivity system wiring**.

**Out of scope for the new implementation:**
- **Operator word/phrase input** and **verbal trees** (phrase recognition, words, symbols, tone and mood of messages). They greatly complicate the project; for theory formalization the layers suffice: homeostasis, contexts, stimuli (buttons), reflexes, conditional perception tree (by active stimuli), episodic and semantic memory, consciousness and automatisms.
- The perception tree keeps a **6-level** structure (BaseID, EmotionID, ActivityID, ToneMoodID, SimbolID, PhraseID) for theory compatibility and OLD_CODE mapping, but **levels 4–6 are not filled** from verbal input — they stay 0 or may later serve other non-verbal dimensions.

---

## 1. Where we are (JS)

Hooks for consciousness and automatisms already exist:

| Component | Role |
|-----------|------|
| **OR** | Pick most salient stimulus, block reflex for 2 pulses, hippocampus, **stimuls_consciousness(actual_stimul_ID)**, save EP. |
| **Hippocampus** | `active_stimulsArr_ID`, `actual_stimul_ID` — hold stimulus that triggered OR. |
| **_9_Conscience** | **stimuls_consciousness(actual_stimul_ID)** — stub; called from OR on new winner and on response stimulus during EP wait. Natural place to hang “consciousness processing.” |
| **Perception tree** | 6 levels, terminal node = conditions; reflex/automatism binding to branch is already described. |
| **EP** | Frame: conditions (perceptionNodeId), stimulus, action, effect, response stimulus — ready context for reasoning. |
| **AID** | Action images; stimulus → action link exists. |
| **CR** | Conditional reflexes by context (BadNormWell + emotion) and FinalImageId. |

So: a **channel to “cortex”** already exists (`stimuls_consciousness` call), **context** can be built from tree, EP, and AID. Missing: explicit “conscious automatism” model and the “consciousness processing” loop (what actually runs in this channel).

---

## 2. Recommendation: build on the new stack; OLD_CODE = concepts only

- **Do not port OLD_CODE to JS wholesale.** Language, data structures, and flows differ; pulse, OR, EP by pulses, tree, SM, CR with global ids may be missing or different there. Copy-paste “as before” is risky and creates friction.
- **Use OLD_CODE as a glossary of concepts and scenarios:** what was called “conscious automatism,” what “consciousness processing” included, call order. Terms and step order can be listed and mapped onto the current architecture.
- **Layer new logic on what exists:** perception tree (terminal = conditions), EP (frame with conditions, stimulus, action, effect, answer), AID, hippocampus, OR. Conscious automatisms become the next layer over conditional reflexes and tree (e.g. branch binding + consciousness). Consciousness processing is what runs inside or around `stimuls_consciousness` (what “passes” through the attention channel and how it is used).

If OLD_CODE is available (next to the project or another repo), it helps to:
- list key entities (automatism structures, consciousness steps);
- map them to current: perceptionNodeId, stimulusImageId, actionImageId, Episodes, FinalImage, tree;
- record gaps and decide in the JS architecture.

---

## 3. Possible shape of “conscious automatism” in the new stack

Without leaning on old code, a draft format:

- **Conscious automatism** — rule: under conditions **C** (perception branch, i.e. perceptionNodeId or path) and stimulus image **S** (FinalImageId) run action image **A** (AID), optionally after “consciousness processing” (decision confirmed/adjusted).
- Difference from conditional reflex: binding to a **tree node** (conditions unfolded by level), possible **episodic** context (recent EP frames), explicit **consciousness** step before/after action.

Then:
- inputs: current terminal tree node, actual_stimul_ID (and optionally recent EP frames);
- outputs: chosen/confirmed action (AID), possible memory updates (EP/SM) from consciousness result.

---

## 4. Possible shape of “consciousness processing”

- **Consciousness processing** — what happens on `stimuls_consciousness(actual_stimul_ID)` and, if needed, following pulses: what is “made conscious” and how it affects behavior and memory.
- Current code could pass not only `actual_stimul_ID` but a **context bundle**: terminal tree node, last/current EP frame (if any), flag “response stimulus during wait,” etc. Then “consciousness processing” is a function that takes the bundle and decides next steps (e.g. start conscious automatism, update priorities, write memory).

Implementation phases could be:
1. Extend `stimuls_consciousness` with context (tree, EP, OR/EP flags).
2. Define “conscious automatism” data structure and storage (array + persistence like CR/EP).
3. Add consciousness loop: pick automatism candidates from context, optionally run through “consciousness,” execute chosen action (existing effectors/AID).

---

## 5. Summary

- **OLD_CODE:** terms and ideas only; do not copy implementation.
- **New stack:** conscious automatisms and consciousness on top of current JS (pulse, OR, tree, EP, AID, SM, CR, hippocampus, `stimuls_consciousness`).
- **Next step:** if OLD_CODE is available, extract concepts and flows and align with this doc; then fix the `stimuls_consciousness` contract (input context) and conscious automatism format and implement in phases above.

---

## 6. Mapping to OLD_CODE (Go) — after loading the old implementation

**OLD_CODE** holds the old implementation (Go + PULT). Below: distilled concepts and flows for idea transfer to JS, without copying code.

### 6.1 Automatism tree (Go)

- **Files:** `OLD_CODE/GO/brain/psychic/automatism_tree.go`, `automatizm_functions.go`, `automatism_tree_func.go`.
- **Node structure:** 6 levels — BaseID, EmotionID, ActivityID, ToneMoodID, SimbolID, PhraseID (same as our perception tree). In JS, levels 4–6 (ToneMoodID, SimbolID, PhraseID) are **unused** — verbal input and verbal trees are out of scope (see §0).
- **Idea:** automatisms attach to tree branch; on branch activation a “default” automatism is chosen (Usefulness, Belief). Missing branch/automatism triggers OR and reasoning. Automatism with success == 1 blocks reflexes (“arbitrary control overcome”).
- **In JS:** perception tree exists (`_7_perception_tree`), node format compatible; active branch from levels 1–3 (BaseID, EmotionID, ActivityID). No “automatism per node” layer yet — layer above tree and CR.

### 6.2 Consciousness processing (Go)

- **Files:** `understanding.go`, `0_main_psychic.go`, `mental_automatizm_INFO_functions.go`, `dreaming.go`.
- **Chain:** per stimulus — **consciousnessElementary()** (levels 1–2). If problem remains — **consciousnessThinking(cID)** in thinking cycles. Cycles like **cycleInfo**, dispatcher **dispetchConsciousnessThinking()** per pulse.
- **consciousnessElementary():**
  - Finds “bursting” automatism by tree node: `atmtzmActualTreeNodeID = getAutomatizmFromNodeID(detectedActiveLastNodID)`.
  - Ignoring automatism counts as no reaction.
  - Checks: danger, theme/goal match (isStimulToForce), effect forecast, Rules (episodic). Decision: run default automatism, alternative, or block and hand off to thinking cycles.
- **consciousnessThinking():** thinking cycles (infoFunc*), problem dominance, passive reflection/dreams. Mental and motor automatisms from cycle.
- **In JS:** analog of “elementary” consciousness is extended **stimuls_consciousness(actual_stimul_ID)** with actual_stimul_ID + current terminal node + last EP frame (and “response stimulus” flag). Inside: is there automatism for node; if yes confirm/run; if no hand off to “thinking cycle” (in JS can start as a simple task queue or one EP/Rules heuristic step).

### 6.3 Automatism in Go

- **Structure:** tree node (TreeNodeID), action image (ActionsImageID), Usefulness, Belief (default / tentative / blocked). Motor and mental automatisms exist.
- **In JS:** AID exists. “Conscious automatism” in JS could be: perceptionNodeId + (optional stimulusImageId) → actionImageId, with usefulness/belief-like fields and priority vs CR (automatism blocks reflex on success).

### 6.4 What to take from OLD_CODE as ideas only

- Order: **pulse → tree activation → automatism by node → consciousnessElementary → consciousnessThinking if needed**.
- Concepts: default / ignoring / alternative automatism, answer wait after action, “Rules” (episodic frames) for effect forecast and alternative choice.
- Do not port literally: EvolushnStage, sleep/dreams, full infoFunc* set — implement as needed on EP, tree, AID in JS.

### 6.5 Suggested order in JS

1. Extend **stimuls_consciousness**: pass context (terminalNodeId, lastEpisodeFrame, isResponseStimulus).
2. Add **conscious automatism store**: perceptionNodeId (and optional stimulusImageId), actionImageId, usefulness/belief flags.
3. In **stimuls_consciousness**, from context: find automatism by node; if found and “default” — run action (via AID/effectors); if not — stub for future “thinking cycle” or simple EP Rules pick.
4. Reflex link: if successful automatism for node, skip conditional/genetic reflex (like Go: reflex blocked by automatism).
5. Optionally add per pulse a simplified “thinking dispatcher” (analog of dispetchConsciousnessThinking) for a queue of open situations.

Details of old structures (Automatizm, cycleInfo, infoFunc*) can be traced in `OLD_CODE/GO/brain/psychic/` when needed.
