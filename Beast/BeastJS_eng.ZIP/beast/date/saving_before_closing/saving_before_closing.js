/**
 * Save active data before closing the index.html window.
 *
 * Purpose:
 * - Sets and clears emergency-shutdown flag was_emergency_shutdown.
 * - Provides stub saving_before_closing() for future concrete save operations.
 * - Usable from index.html and other modules to detect prior crash shutdown.
 *
 * Concepts:
 * - was_emergency_shutdown == true  — last exit was abnormal
 *   (browser/OS hang, tab killed, saving_before_closing() did not run).
 * - was_emergency_shutdown == false — last exit was normal
 *   with saving_before_closing() and flag cleared.
 *
 * Flag storage:
 * - Global was_emergency_shutdown.
 * - Also mirrored in localStorage (not IndexedDB) across tab restarts.
 *
 * Usage:
 *
 *   init_saving_before_closing();
 *
 *   if (get_was_emergency_shutdown()) {
 *     // recovery / diagnostics
 *   }
 *
 * NOTE:
 * - saving_before_closing() is currently empty; extend with real persistence.
 */

(function (global) {
  'use strict';

  var EMERGENCY_FLAG_KEY = 'was_emergency_shutdown';

  var was_emergency_shutdown = false;
  try {
    was_emergency_shutdown = global.localStorage.getItem(EMERGENCY_FLAG_KEY) === 'true';
  } catch (e) {
    was_emergency_shutdown = false;
  }
  global.was_emergency_shutdown = was_emergency_shutdown;

  /**
   * Set emergency flag true (startup).
   */
  function set_emergency_flag_true() {
    was_emergency_shutdown = true;
    global.was_emergency_shutdown = true;
    try {
      global.localStorage.setItem(EMERGENCY_FLAG_KEY, 'true');
    } catch (e) {
      // ignore localStorage errors
    }
  }

  /**
   * Set emergency flag false (normal shutdown after saving_before_closing).
   */
  function set_emergency_flag_false() {
    was_emergency_shutdown = false;
    global.was_emergency_shutdown = false;
    try {
      global.localStorage.setItem(EMERGENCY_FLAG_KEY, 'false');
    } catch (e) {
      // ignore localStorage errors
    }
  }

  /**
   * @returns {boolean}
   */
  function get_was_emergency_shutdown() {
    return !!was_emergency_shutdown;
  }

  /**
   * Stub: persist active data before window close.
   * On success should call set_emergency_flag_false().
   */
  function saving_before_closing() {
    // TODO: add IndexedDB / log flush calls here.
    //   save_all_active_data();
    //   set_emergency_flag_false();
  }

  /**
   * Init beforeunload handling. Call once at index.html startup.
   * - On init set was_emergency_shutdown = true.
   * - On beforeunload run saving_before_closing() then clear flag.
   * - If process dies earlier, flag stays true next launch.
   */
  function init_saving_before_closing() {
    set_emergency_flag_true();

    global.addEventListener('beforeunload', function () {
      try {
        saving_before_closing();
        set_emergency_flag_false();
      } catch (e) {
        // on save error flag stays true
      }
    });
  }

  global.init_saving_before_closing = init_saving_before_closing;
  global.saving_before_closing = saving_before_closing;
  global.get_was_emergency_shutdown = get_was_emergency_shutdown;

})(window);
