/**
 * Wire save/load memory buttons on the main index.html page.
 *
 * Purpose:
 * - Attaches handlers to "Save memory" and "Load memory" buttons.
 * - Collect/apply data through unified registry BEAST.persistentModules:
 *   one array of { JSON key ↔ serialize/apply }; adding a module = one entry.
 *
 * Order and DOM: scripts at end of body; if moved to head, call init only after DOM ready (DOMContentLoaded or similar).
 *
 * Dependencies (must load before this script):
 * - beast/date/saving_all/saving_all.js (handle_save_memory_click, load_all_memory)
 * - beast/puls.js (Cur_puls_val, update_beast_pulse_view)
 *
 * Expected ids in index.html: btnSaveMemory, btnLoadMemory.
 */

(function (global) {
  'use strict';

  var PULSE_KEY = 'Cur_puls_val';

  if (!global.BEAST) global.BEAST = {};
  /**
   * Registry of persistable modules. Each item: { key, serialize, apply }.
   * key — field in JSON when saving to file.
   * serialize() — value to save (or undefined to omit key).
   * apply(data) — apply loaded value; called only if loaded has this key.
   * Adding storage = one entry here, no edits to collect_memory_data/apply_loaded_memory.
   */
  var persistentModules = [];
  global.BEAST.persistentModules = persistentModules;

  persistentModules.push({
    key: 'Cur_puls_val',
    serialize: function () {
      return global.Cur_puls_val;
    },
    apply: function (value) {
      var n = parseInt(value, 10);
      if (isNaN(n) || n < 0) return;
      global.Cur_puls_val = n;
      try {
        global.localStorage.setItem(PULSE_KEY, String(global.Cur_puls_val));
      } catch (e) {}
      if (typeof global.update_beast_pulse_view === 'function') {
        global.update_beast_pulse_view();
      }
    }
  });

  persistentModules.push({
    key: 'VitalsValues',
    serialize: function () {
      if (!global.VitalsArr || !global.VitalsArr.length) return undefined;
      var values = [];
      for (var i = 0; i < global.VitalsArr.length; i++) {
        values.push(global.VitalsArr[i].value);
      }
      return values;
    },
    apply: function (values) {
      if (!global.VitalsArr || !Array.isArray(values)) return;
      for (var i = 0; i < global.VitalsArr.length && i < values.length; i++) {
        var v = parseFloat(values[i]);
        if (isNaN(v)) continue;
        if (v < 0) v = 0;
        if (v > 100) v = 100;
        global.VitalsArr[i].value = v;
      }
      if (typeof global.saveVitalsToStorage === 'function') {
        global.saveVitalsToStorage();
      }
      if (typeof global.update_vitals_view === 'function') {
        global.update_vitals_view();
      }
    }
  });

  persistentModules.push({
    key: 'SemanticState',
    serialize: function () {
      if (typeof global.serializeSemanticState !== 'function') return undefined;
      return global.serializeSemanticState();
    },
    apply: function (data) {
      if (typeof global.applySemanticState !== 'function') return;
      global.applySemanticState(data);
    }
  });

  persistentModules.push({
    key: 'ConditionalReflexesState',
    serialize: function () {
      if (typeof global.serializeConditionalReflexesState !== 'function') return undefined;
      return global.serializeConditionalReflexesState();
    },
    apply: function (data) {
      if (typeof global.applyConditionalReflexesState !== 'function') return;
      global.applyConditionalReflexesState(data);
    }
  });

  persistentModules.push({
    key: 'PerceptionTreeState',
    serialize: function () {
      if (typeof global.PerceptionTree_serializeState !== 'function') return undefined;
      return global.PerceptionTree_serializeState();
    },
    apply: function (data) {
      if (typeof global.PerceptionTree_applyState !== 'function') return;
      global.PerceptionTree_applyState(data);
    }
  });

  persistentModules.push({
    key: 'ActionImagesState',
    serialize: function () {
      if (typeof global.ActionImages_serializeState !== 'function') return undefined;
      return global.ActionImages_serializeState();
    },
    apply: function (data) {
      if (typeof global.ActionImages_applyState !== 'function') return;
      global.ActionImages_applyState(data);
    }
  });

  persistentModules.push({
    key: 'EpisodesState',
    serialize: function () {
      if (typeof global.EpisodicMemory_serializeState !== 'function') return undefined;
      return global.EpisodicMemory_serializeState();
    },
    apply: function (data) {
      if (typeof global.EpisodicMemory_applyState !== 'function') return;
      global.EpisodicMemory_applyState(data);
    }
  });

  persistentModules.push({
    key: 'AutomatizmsState',
    serialize: function () {
      if (typeof global.Automatizms_serializeState !== 'function') return undefined;
      return global.Automatizms_serializeState();
    },
    apply: function (data) {
      if (typeof global.Automatizms_applyState !== 'function') return;
      global.Automatizms_applyState(data);
    }
  });

  persistentModules.push({
    key: 'GoalImagesState',
    serialize: function () {
      if (typeof global.Goals_serializeState !== 'function') return undefined;
      return global.Goals_serializeState();
    },
    apply: function (data) {
      if (typeof global.Goals_applyState !== 'function') return;
      global.Goals_applyState(data);
    }
  });

  persistentModules.push({
    key: 'SituationsTreeState',
    serialize: function () {
      if (typeof global.SituationsTree_serializeState !== 'function') return undefined;
      return global.SituationsTree_serializeState();
    },
    apply: function (data) {
      if (typeof global.SituationsTree_applyState !== 'function') return;
      global.SituationsTree_applyState(data);
    }
  });

  persistentModules.push({
    key: 'MentalAutomatizmsState',
    serialize: function () {
      if (typeof global.MentalAutomatizms_serializeState !== 'function') return undefined;
      return global.MentalAutomatizms_serializeState();
    },
    apply: function (data) {
      if (typeof global.MentalAutomatizms_applyState !== 'function') return;
      global.MentalAutomatizms_applyState(data);
    }
  });

  persistentModules.push({
    key: 'AbstractImagesState',
    serialize: function () {
      if (typeof global.AbstractImages_serializeState !== 'function') return undefined;
      return global.AbstractImages_serializeState();
    },
    apply: function (data) {
      if (typeof global.AbstractImages_applyState !== 'function') return;
      global.AbstractImages_applyState(data);
    }
  });

  /**
   * Build object for file save. Iterates persistentModules, calls serialize() on each.
   */
  function collect_memory_data() {
    var data = {};
    var list = global.BEAST.persistentModules;
    if (!Array.isArray(list)) return data;
    for (var i = 0; i < list.length; i++) {
      var mod = list[i];
      if (!mod || !mod.key) continue;
      try {
        var value = mod.serialize();
        if (value !== undefined) {
          data[mod.key] = value;
        }
      } catch (e) {
        if (typeof global.console !== 'undefined' && global.console.error) {
          global.console.error('collect_memory_data:', mod.key, e);
        }
      }
    }
    return data;
  }

  /**
   * Apply data loaded from file.
   * Iterates persistentModules, calls apply(loaded[key]) when key present.
   * Errors are logged; failing keys collected for user message.
   * @returns {string[]} keys where apply threw.
   */
  function apply_loaded_memory(loaded) {
    var errors = [];
    if (!loaded || typeof loaded !== 'object') return errors;
    var list = global.BEAST.persistentModules;
    if (!Array.isArray(list)) return errors;
    for (var i = 0; i < list.length; i++) {
      var mod = list[i];
      if (!mod || !mod.key || loaded[mod.key] === undefined) continue;
      if (typeof mod.apply !== 'function') continue;
      try {
        mod.apply(loaded[mod.key]);
      } catch (e) {
        if (typeof global.console !== 'undefined' && global.console.error) {
          global.console.error('apply_loaded_memory:', mod.key, e);
        }
        errors.push(mod.key);
      }
    }
    return errors;
  }

  function init() {
    var btnSave = global.document.getElementById('btnSaveMemory');
    var btnLoad = global.document.getElementById('btnLoadMemory');

    if (btnSave && typeof global.handle_save_memory_click === 'function') {
      btnSave.addEventListener('click', function () {
        global.handle_save_memory_click(collect_memory_data);
      });
    }

    if (btnLoad && typeof global.load_all_memory === 'function') {
      btnLoad.addEventListener('click', function () {
        global.load_all_memory()
          .then(function (loaded) {
            var errors = apply_loaded_memory(loaded);
            if (typeof global.show_alert === 'function') {
              if (errors.length) {
                global.show_alert('Memory loaded with errors for some keys: ' + errors.join(', ') + '. Check the console.', 0);
              } else {
                global.show_alert('Memory loaded successfully from file.', 2000);
              }
            }
          })
          .catch(function (error) {
            if (error && error.name === 'AbortError') return;
            if (typeof global.show_alert === 'function') {
              global.show_alert('Error loading memory: ' + (error && error.message ? error.message : String(error)), 0);
            }
          });
      });
    }
  }

  if (global.document.readyState === 'loading') {
    global.document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})(window);
