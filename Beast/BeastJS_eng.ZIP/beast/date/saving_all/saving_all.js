/**
 * Full export/import of creature memory to a local file via user choice (File System Access API).
 *
 * Purpose:
 * - On command from index.html ("Save memory") writes data to a file the user picks (window.showSaveFilePicker).
 * - Loads previously saved data from a user-picked file (window.showOpenFilePicker).
 *
 * Requirements:
 * - File System Access API is fully supported in Chrome.
 * - In browsers without the API, save/load attempts show show_alert: use Chrome for memory save/load.
 *
 * Main functions:
 * - save_all_memory(data)     — save to file (pick location).
 * - load_all_memory()         — load from picked file.
 * - handle_save_memory_click(collectDataFn) — "Save memory" button handler.
 *
 * Example (index.html):
 *
 *   document.getElementById('btnSaveMemory').addEventListener('click', function () {
 *     handle_save_memory_click(function collectData() {
 *       return { timestamp: Date.now(), version: 1 };
 *     });
 *   });
 *
 *   load_all_memory().then(function (loaded) { }).catch(function (error) { console.error(error); });
 */

(function (global) {
  'use strict';

  var SAVE_DEFAULT_NAME = 'beast_memory.json';
  var SAVE_ACCEPT = { 'application/json': ['.json'] };

  /**
   * @returns {boolean}
   */
  function is_file_system_access_supported() {
    return typeof global.showSaveFilePicker === 'function';
  }

  function alert_unsupported_browser() {
    if (typeof global.show_alert === 'function') {
      global.show_alert(
        'This browser does not support saving memory. Use Chrome.',
        0
      );
    }
  }

  /**
   * @param {Object} data - creature memory object (JSON-serialized).
   * @returns {Promise<void>}
   */
  function save_all_memory(data) {
    if (!is_file_system_access_supported()) {
      alert_unsupported_browser();
      return Promise.reject(new Error('File System Access API is not supported.'));
    }
    if (typeof global.showSaveIndicator === 'function') global.showSaveIndicator();

    var payloadString;
    try {
      payloadString = JSON.stringify(data || {}, null, 2);
    } catch (e) {
      if (typeof global.hideSaveIndicator === 'function') global.hideSaveIndicator();
      return Promise.reject(new Error('Failed to serialize data: ' + e.message));
    }

    var pickerOptions = {
      suggestedName: SAVE_DEFAULT_NAME,
      types: [{ description: 'JSON', accept: SAVE_ACCEPT }]
    };

    var startInPromise = typeof global.loadLastMemoryDirectory === 'function'
      ? global.loadLastMemoryDirectory()
      : Promise.resolve(undefined);

    return startInPromise
      .then(function (startIn) {
        if (startIn) pickerOptions.startIn = startIn;
        return global.showSaveFilePicker(pickerOptions);
      })
      .then(function (handle) {
        return handle.createWritable().then(function (writable) {
          return writable.write(payloadString)
            .then(function () {
              return writable.close();
            })
            .then(function () {
              if (typeof global.saveLastMemoryDirectory === 'function') {
                return global.saveLastMemoryDirectory(handle);
              }
            });
        });
      })
      .then(function () {
        if (typeof global.hideSaveIndicator === 'function') global.hideSaveIndicator();
      }, function (err) {
        if (typeof global.hideSaveIndicator === 'function') global.hideSaveIndicator();
        throw err;
      });
  }

  /**
   * @returns {Promise<Object>} parsed JSON object.
   */
  function load_all_memory() {
    if (!is_file_system_access_supported()) {
      alert_unsupported_browser();
      return Promise.reject(new Error('File System Access API is not supported.'));
    }

    var pickerOptions = {
      types: [{ description: 'JSON', accept: SAVE_ACCEPT }],
      multiple: false
    };

    var startInPromise = typeof global.loadLastMemoryDirectory === 'function'
      ? global.loadLastMemoryDirectory()
      : Promise.resolve(undefined);

    return startInPromise
      .then(function (startIn) {
        if (startIn) pickerOptions.startIn = startIn;
        return global.showOpenFilePicker(pickerOptions);
      })
      .then(function (handles) {
        if (!handles || handles.length === 0) {
          return Promise.reject(new Error('No file selected.'));
        }
        var fileHandle = handles[0];
        if (typeof global.saveLastMemoryDirectory === 'function') {
          global.saveLastMemoryDirectory(fileHandle).catch(function () {});
        }
        return fileHandle.getFile();
      })
      .then(function (file) {
        return file.text();
      })
      .then(function (text) {
        try {
          return JSON.parse(text);
        } catch (e) {
          throw new Error('File is not valid JSON: ' + e.message);
        }
      });
  }

  /**
   * @param {function(): Object} collectDataFn - returns object to save.
   * @returns {Promise<void>}
   */
  function handle_save_memory_click(collectDataFn) {
    if (!is_file_system_access_supported()) {
      alert_unsupported_browser();
      return Promise.reject(new Error('File System Access API is not supported.'));
    }

    var data;
    try {
      data = collectDataFn ? collectDataFn() : {};
    } catch (e) {
      if (typeof global.show_alert === 'function') {
        global.show_alert('Error collecting data: ' + e.message, 0);
      }
      return Promise.reject(e);
    }

    if (typeof global.show_alert === 'function') {
      global.show_alert('Choose where to save the memory file…', 2000);
    }

    return save_all_memory(data)
      .then(function () {
        if (typeof global.show_alert === 'function') {
          global.show_alert('Memory saved successfully to file.', 2000);
        }
      })
      .catch(function (error) {
        if (error && error.name === 'AbortError') {
          return;
        }
        if (typeof global.show_alert === 'function') {
          global.show_alert('Error saving memory: ' + (error && error.message ? error.message : String(error)), 0);
        }
        throw error;
      });
  }

  global.save_all_memory = save_all_memory;
  global.load_all_memory = load_all_memory;
  global.handle_save_memory_click = handle_save_memory_click;
  global.is_file_system_access_supported = is_file_system_access_supported;

})(window);
