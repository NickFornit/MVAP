# Automatisms (_11_Automatizms)

## Purpose

The module implements **automatisms** — rules bound to a perception-tree branch node (BranchID) and an action image (AID). Activation or blocking happens during consciousness (`stimuls_consciousness(actual_stimul_ID)`) when the matching tree node is active.

## Automatism structure

| Field | Type | Description |
|------|------|-------------|
| **id** | number | Unique id, auto-increment on create. |
| **branchId** | number | Perception-tree branch node id. |
| **usefulness** | number | Benefit/harm: &lt; 0 harm, &gt; 0 benefit; refined during wait after activity. |
| **actionsImageId** | number | Action image id (from _10_actions_image). May hold multiple actions and/or AID sequence string. |
| **count** | number | Reliability — run count for usefulness averaging. |
| **isDefault** | boolean | If true — default automatism for that branch (primary among branch automatisms). |

A branch may have many automatisms; only one has **isDefault=true**.

**Independence from primary reflex:** consciousness automatism may be changed arbitrarily (different AID, different default). No assumed link between primary reflex and secondary automatism: automatism is its own branch rule; action may differ from what the reflex first recorded.

## API

- **Automatizms_getAutomatizmsByBranchId(branchId)** — all automatisms on branch (indexed lookup).
- **Automatizms_getDefaultAutomatizmForBranch(branchId)** — default automatism (isDefault=true).
- **Automatizms_createAutomatizm(branchId, actionsImageId)** — create. No duplicate (branchId, actionsImageId); duplicate returns existing id. Requires valid actionsImageId in ActionImages. Returns 0 on bad args.
- **Automatizms_setDefaultAutomatizm(automatizmId)** — set default; other automatisms on same branch get isDefault=false.
- **Automatizms_addUsefulnessSample(automatizmId, effect)** — update usefulness and count (average). **effect** from EP (see “Shared effect” below).
- **Automatizms_serializeState** / **Automatizms_applyState** — serialize/restore for file and IndexedDB.

## Persistence

- **IndexedDB:** per-pulse save only when data changed (automatismsDirty + lastAutomatizmsSavedSig). DB `BEAST_Automatizms_DB`, store `automatizms_state`.
- **File:** key `AutomatizmsState` in `BEAST.persistentModules` (`saving_ui.js`).

## Shared effect evaluation (EP → automatism)

Automatism **effect matches EP**: same value computed in EP on frame close (`effect = diffAfter − diffBefore`) passed to branch default automatism via **addUsefulnessSample(automatizmId, effect)**. Single source — no duplicate; usefulness averages the same values as episode frames. See **about_episodic_memory.md** (“Shared effect evaluation”).

## Related modules

- **Perception tree** (_7_perception_tree) — branchId is tree node id.
- **Action images** (_10_actions_image) — actionsImageId references AID; create checks AID exists.
- **Consciousness** (_9_Conscience) — in `stimuls_consciousness` from OR context (branchId, novelty, significance, …) check default automatism; if present run action image (`runActionImage`). **On automatism start** `removeDelayedReflexesForBranch(branchId)` clears delayed reflex queue for that branch (no action comparison). If automatism rejected, removal skipped and delayed reflex runs after delay. Room for future acceptability check vs novelty.
- **Episodic memory** (_10_Episodic_memory) — on reflex fire create automatism (`createAutomatizm`, `setDefault` on first); on frame close same EP effect updates default usefulness (`addUsefulnessSample`). Shared effect — above.

## Files

- **automatizms.js** — Automatisms array, byBranchId index, create/default/usefulness averaging, IndexedDB, exported API.
