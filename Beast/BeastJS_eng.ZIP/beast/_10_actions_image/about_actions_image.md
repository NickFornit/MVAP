# Action images (_10_actions_image)

## Purpose

The module implements **action images (AIDs)** — analogous to perception images (FinalImage). Each AID links a perception image to one or more actions (parallel or sequential). EP frames store actionImageId — an AID id, not a raw BasicActions id.

## AID structure

- **id** — unique id.
- **finalImageId** — perception image (FinalImage) bound to this AID (0 if unset).
- **actionIds** — array of BasicActions ids: one or several parallel actions.
- **odSequence** — comma-separated ids of other AIDs for sequential execution (optional).

## Formation

Each FinalImage that has had at least one reaction creates or extends an AID. Multiple reactions from different stimuli in one image append to the AID’s action array. Registration from genetic_reflexes_engine (`ActionsImage_registerReaction`) in startAction; EP last frame uses `EpisodicMemory_setLastFrameActionFromActionId` with `stimulusImageId` already on the frame.

## Persistence

ActionImages array saves to IndexedDB (on pulse when changed) and file on Save / Load (`saving_ui.js`).

## Files

- **actions_image.js** — ActionImages array, getOrCreateActionImageId, registerReaction, serialize/restore, save-system registration.
