/*
Perception stimuli
Genetically predetermined reactions to stimuli.
Conditional reflexes can form to any such stimuli.
*/

/* Motivating stimuli:
vitalID — which vital they affect,
shift — effect each pulse while stimulus is active
bg — indicator background: 1 pink, 2 white, 3 light green
Water and food like Play and Teach should return Beast to normal via action
When Beast eats or drinks, improvement leads to Good until satiation (already implemented).
Rut should get similar treatment...
*/
window.StimulMotivarion = [
{ Id: 1, vitalID: 6, shift: 0, name: "Food",   bg: 3,   title: "Give food" },
{ Id: 2, vitalID: 3, shift: 0, name: "Water",   bg: 3,   title: "Give water" },
{ Id: 3, vitalID: 4, shift: -1, name: "Warmth",  bg: 2,    title: "Warm up" },
{ Id: 4, vitalID: 5, shift: -1, name: "Cold",   bg: 2,   title: "Cool down" },
{ Id: 5, vitalID: 2, shift: -2, name: "Air",  bg: 3,    title: "Fresh air" },
{ Id: 6, vitalID: 1, shift: -0.5, name: "Healing",  bg: 3,    title: "Start treatment" },
{ Id: 7, vitalID: 7, shift: 0, name: "Reward",  bg: 3,    title: "Reward" },
{ Id: 8, vitalID: 7, shift: 0, name: "Punish",  bg: 1,    title: "Punish" },
{ Id: 9, vitalID: 7, shift: 0, name: "Pleasant",   bg: 3,   title: "Make pleasant" },
{ Id: 10, vitalID: 7, shift: 0, name: "Unpleasant",  bg: 1,    title: "Cause pain" },
{ Id: 11, vitalID: 7, shift: 0, name: "Calm",  bg: 3,    title: "Calm" },
{ Id: 12, vitalID: 7, shift: 0, name: "Clear",   bg: 3,   title: "Clear / understood" },
{ Id: 13, vitalID: 7, shift: 0, name: "Unclear",  bg: 1,    title: "Unclear" },
{ Id: 14, vitalID: 7, shift: 0, name: "Forgive",  bg: 3,    title: "Forgive a misdeed" },
{ Id: 15, vitalID: 7, shift: 0, name: "Laugh",   bg: 3,   title: "Laugh" },
{ Id: 16, vitalID: 7, shift: 0, name: "Joy",  bg: 3,    title: "Show joy" },
{ Id: 17, vitalID: 8, shift: 2, name: "Crush",    bg: 2,  title: "Object of sexual interest" },
{ Id: 18, vitalID: 7, shift: 0, name: "Ignore",  bg: 1,    title: "Demonstratively ignore what was done" },
{ Id: 19, vitalID: 11, shift: 0, name: "Play",  bg: 3,    title: "Offer to play" },
{ Id: 20, vitalID: 12, shift: 0, name: "Teach",   bg: 2,   title: "Offer to learn" },
];

// Active motivating stimuli (by Id) for per-pulse shift
window.ActiveMotivationStimuls = [];

/* Positive stimuli — light green background
CANCELLED: On click button highlights and vital ID 7 changes by -10
On second click button deactivates, highlight removed.
Builds a picture of active buttons Beast will react to.
*/
window.StimulPositiv = [
  { Id: 1, name: "Smile" },
  { Id: 2, name: "Child" },
  { Id: 3, name: "Puppy" },
  { Id: 4, name: "Flower" },
  { Id: 5, name: "Sun" },
  { Id: 6, name: "Butterfly" },
  { Id: 7, name: "Berry" },
  { Id: 8, name: "Bell" },
  { Id: 9, name: "Laughter" },
  { Id: 10, name: "Singing" },
  { Id: 11, name: "Melody" },
  { Id: 12, name: "Rustle" },
  { Id: 13, name: "Purring" },
  { Id: 14, name: "Sweetness" },
 {  Id: 15, name: "Aroma" },
  { Id: 16, name: "Warmth" },
  { Id: 17, name: "Breeze" },
  { Id: 18, name: "Coolness" },
  { Id: 19, name: "Touch" },
  { Id: 20, name: "Caress" },
];
  
/* Negative stimuli — pink background
CANCELLED: On click button highlights and vital ID 7 increases by +10
On second click button deactivates, highlight removed.
Builds a picture of active buttons Beast will react to.
*/
window.StimulNegative = [
  { Id: 1, name: "Spite" },
  { Id: 2, name: "Blood" },
  { Id: 3, name: "Ruin" },
  { Id: 4, name: "Spider" },
  { Id: 5, name: "Snake" },
  { Id: 6, name: "Mushroom" },
  { Id: 7, name: "Rot" },
  { Id: 8, name: "Howl" },
  { Id: 9, name: "Moan" },
  { Id: 10, name: "Siren" },
  { Id: 11, name: "Squeak" },
  { Id: 12, name: "Creak" },
  { Id: 13, name: "Growl" },
  { Id: 14, name: "Shards" },
  { Id: 15, name: "Lightning" },
  { Id: 16, name: "Dagger" },
  { Id: 17, name: "Bitterness" },
  { Id: 18, name: "Sourness" },
  { Id: 19, name: "Stench" },
  { Id: 20, name: "Fire" }
];
/* Neutral stimuli — light gray background
On click button highlights.
On second click button deactivates, highlight removed.
Builds a picture of active buttons Beast will react to.
Conditional reflexes can form from these stimuli.
*/
window.StimulNeutral = [
  { Id: 1, name: "Brown" },
  { Id: 2, name: "Red" },
  { Id: 3, name: "Yellow" },
  { Id: 4, name: "Green" },
  { Id: 5, name: "Cyan" },
  { Id: 6, name: "Blue" },
  { Id: 7, name: "Violet" },
  { Id: 8, name: "Black" },
  { Id: 9, name: "White" },
  { Id: 10, name: "Circle" },
  { Id: 11, name: "Square" },
  { Id: 12, name: "Arc" },
  { Id: 13, name: "Dot" },
  { Id: 14, name: "Zigzag" },
  { Id: 15, name: "Line" },
  { Id: 16, name: "Star" },
  { Id: 17, name: "Cross" },
  { Id: 18, name: "Triangle" },
  { Id: 19, name: "Noise" },
  { Id: 20, name: "Whistle" },
  { Id: 21, name: "Hum" },
  { Id: 22, name: "Ring" },
  { Id: 23, name: "Vibration" },
  { Id: 24, name: "Book" },
  { Id: 25, name: "Table" },
  { Id: 26, name: "Chair" },
  { Id: 27, name: "Bed" },
  { Id: 28, name: "Light bulb" },
  { Id: 29, name: "Plant" },
  { Id: 30, name: "Animal" },
  { Id: 31, name: "Human" },
];

