# Perception and stimuli (_3_perception)

## Purpose

The module defines **perception stimuli** and their UI. Stimuli are inputs for genetic and conditional reflexes; active stimuli form the final image (FinalImage) and perception-tree branch.

## Stimulus kinds

- **StimulMotivarion** — motivating stimuli (Food, Water, Warmth, Cold, Reward, Punishment, Pleasant, Laughter, Play, Teach, etc.). Tied to vitals (`vitalID`, `shift`), can change vitals and contexts on activation.

- **StimulPositiv** — positive stimuli (Smile, Laughter, Singing, Caress, etc.).

- **StimulNegative** — negative stimuli (Malice, Howl, Moan, Fire, etc.).

- **StimulNeutral** — neutral stimuli (colors, shapes, objects).

Active sets: **ActiveMotivationStimuls**, **ActivePositivStimuls**, **ActiveNegativeStimuls**, **ActiveNeutralStimuls** (ID arrays).

## Files

- **stimuls.js** — stimulus arrays and active-set globals.
- **stimuls_ui.js** — stimulus buttons, toggle, context effects, **OrientationReflex_runOnStimulusActivation** after stimulus set changes.

On activate/deactivate, orientation reflex runs (deferred to next tick), images and perception tree update.

## “Orientation reflex readiness” indicator

In `stimuls_ui.js`, stimulus buttons show semantic maturity for OR.

- Border thickens when for their (conditional) `FinalImageId`, `samplesCount >= OR_well_known` (`remainingActivations === 0`).
- Border updates are **cheap**:
  - full recompute from `puls.js` **only on the 2nd pulse after start** (to pick up `BadNormWell` and `BasicContextsActived`);
  - then **point** updates for a given `finalImageId` after semantics change in `semantic_memory.js`.
- `mouseenter` only refreshes `title` (tooltip) so hover does not fight programmatic border logic.
