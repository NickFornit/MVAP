/**
 * Globally unique stimulus IDs (type * MULTIPLIER + localId).
 *
 * WHY: Different stimulus arrays (StimulMotivarion, StimulPositiv, StimulNegative, StimulNeutral)
 * reuse numeric Ids (e.g. 10 = "Unpleasant" in motivation and 10 = "Singing" in positive).
 * When saving perception images (FinalImage) and decoding by Id, names collide — wrong stimulus name.
 * Global Id encodes type + local Id so decoding and image comparison work for any array sizes (up to 999 per type).
 */
(function (global) {
  'use strict';

  /** Stimulus types (match array order in code). */
  var TYPE_MOTIVATION = 1;
  var TYPE_POSITIV = 2;
  var TYPE_NEGATIVE = 3;
  var TYPE_NEUTRAL = 4;

  /**
   * Max local id per type (1..MULTIPLIER-1).
   * Changing array sizes stays valid while each type has < 1000 entries.
   */
  var MULTIPLIER = 1000;

  /**
   * Global id from type and local id.
   * @param {number} type — 1=Motivation, 2=Positiv, 3=Negative, 4=Neutral
   * @param {number} localId — Id in the corresponding Stimul* array
   */
  function toGlobalStimulusId(type, localId) {
    var t = parseInt(type, 10);
    var id = parseInt(localId, 10);
    if (isNaN(t) || isNaN(id) || id <= 0) return 0;
    if (t < 1 || t > 4) return 0;
    return t * MULTIPLIER + id;
  }

  /**
   * Parse global id into type and local id.
   * @param {number} globalId
   * @returns {{ type: number, localId: number } | null}
   */
  function fromGlobalStimulusId(globalId) {
    var g = parseInt(globalId, 10);
    if (isNaN(g) || g < MULTIPLIER) return null;
    var type = Math.floor(g / MULTIPLIER);
    var localId = g % MULTIPLIER;
    if (type < 1 || type > 4 || localId <= 0) return null;
    return { type: type, localId: localId };
  }

  /**
   * Stimulus name by global id (alerts and UI).
   * Legacy: if globalId < MULTIPLIER, treated as local id without type
   * (backward compatibility with old saved images).
   */
  function getStimulusNameByGlobalId(globalId) {
    var g = parseInt(globalId, 10);
    if (isNaN(g) || g <= 0) return '';
    var parsed = fromGlobalStimulusId(g);
    var arr = null;
    if (parsed) {
      if (parsed.type === TYPE_MOTIVATION) arr = global.StimulMotivarion;
      else if (parsed.type === TYPE_POSITIV) arr = global.StimulPositiv;
      else if (parsed.type === TYPE_NEGATIVE) arr = global.StimulNegative;
      else if (parsed.type === TYPE_NEUTRAL) arr = global.StimulNeutral;
      if (arr && Array.isArray(arr)) {
        for (var i = 0; i < arr.length; i++) {
          if (arr[i] && arr[i].Id === parsed.localId) return arr[i].name || ('Id ' + parsed.localId);
        }
      }
      return '';
    }
    // Legacy: id < MULTIPLIER — search all arrays (first match).
    var groups = [global.StimulMotivarion, global.StimulPositiv, global.StimulNegative, global.StimulNeutral];
    for (var h = 0; h < groups.length; h++) {
      if (!groups[h] || !Array.isArray(groups[h])) continue;
      for (var k = 0; k < groups[h].length; k++) {
        if (groups[h][k] && groups[h][k].Id === g) return groups[h][k].name || ('Id ' + g);
      }
    }
    return '';
  }

  /**
   * Global ids for currently active stimuli (for getOrCreateFinalImageId).
   * Active arrays store local ids — translated here to global.
   */
  function getActiveGlobalStimulusIds() {
    var out = [];
    function add(type, activeArr) {
      if (!Array.isArray(activeArr)) return;
      for (var i = 0; i < activeArr.length; i++) {
        var localId = activeArr[i];
        if (typeof localId !== 'number' || localId <= 0) continue;
        var g = toGlobalStimulusId(type, localId);
        if (g && out.indexOf(g) === -1) out.push(g);
      }
    }
    add(TYPE_MOTIVATION, global.ActiveMotivationStimuls);
    add(TYPE_POSITIV, global.ActivePositivStimuls);
    add(TYPE_NEGATIVE, global.ActiveNegativeStimuls);
    add(TYPE_NEUTRAL, global.ActiveNeutralStimuls);
    out.sort(function (a, b) { return a - b; });
    return out;
  }

  /**
   * Stimulus type from UI row id string (for stimuls_ui).
   * @param {string} rowId — 'stimulsRowPositiv' | 'stimulsRowNegative' | 'stimulsRowNeutral' or motivation row
   */
  function getStimulusTypeFromRowId(rowId) {
    if (rowId === 'stimulsRowPositiv') return TYPE_POSITIV;
    if (rowId === 'stimulsRowNegative') return TYPE_NEGATIVE;
    if (rowId === 'stimulsRowNeutral') return TYPE_NEUTRAL;
    return TYPE_MOTIVATION;
  }

  /** Type from sourceType: 'motivation' | 'positive' | 'negative' | 'neutral'. */
  function getStimulusTypeFromSourceType(sourceType) {
    if (sourceType === 'motivation') return TYPE_MOTIVATION;
    if (sourceType === 'positive') return TYPE_POSITIV;
    if (sourceType === 'negative') return TYPE_NEGATIVE;
    if (sourceType === 'neutral') return TYPE_NEUTRAL;
    return TYPE_MOTIVATION;
  }

  global.StimulusGlobalId_toGlobal = toGlobalStimulusId;
  global.StimulusGlobalId_fromGlobal = fromGlobalStimulusId;
  global.StimulusGlobalId_getName = getStimulusNameByGlobalId;
  global.StimulusGlobalId_getActiveGlobalIds = getActiveGlobalStimulusIds;
  global.StimulusGlobalId_getTypeFromRowId = getStimulusTypeFromRowId;
  global.StimulusGlobalId_getTypeFromSourceType = getStimulusTypeFromSourceType;
  global.StimulusGlobalId_MULTIPLIER = MULTIPLIER;
})(typeof window !== 'undefined' ? window : this);
