/**
 * Central pulse of the Beast system.
 *
 * Purpose:
 * - Provides the basic “heartbeat” rhythm with a 1 second period.
 * - Maintains global window.Cur_puls_val — pulse count since the creature’s life began
 *   (not the index.html launch count).
 * - Updates the pulse indicator on the main index.html page:
 *   blinking green circle and numeric pulse counter.
 *
 * UI integration:
 * - index.html must contain elements with id "pulseCircle" and "pulseCounter".
 * - update_beast_pulse_view() may be called by other modules
 *   when the display must be refreshed (e.g. after loading a saved Cur_puls_val).
 *
 * Persisting pulse across runs:
 * - Cur_puls_val is periodically saved in localStorage under key 'Cur_puls_val'.
 */
(function (global) {
  'use strict';

  var PULSE_KEY = 'Cur_puls_val';

  // Initialize global Cur_puls_val from localStorage
  var saved = 0;
  try {
    var raw = global.localStorage.getItem(PULSE_KEY);
    if (raw !== null) {
      var n = parseInt(raw, 10);
      if (!isNaN(n) && n >= 0) {
        saved = n;
      }
    }
  } catch (e) {
    saved = 0;
  }

  global.Cur_puls_val = saved;

  /** Local pulse counter (increments each pulse), passed to getActiveBasicContexts. */
  global.cpuls = 0;

  var pulseCircle = null;
  var pulseCounterEl = null;

  /**
   * Refresh references to pulse indicator DOM nodes.
   * Called on first display update.
   */
  function ensure_dom_refs() {
    if (!pulseCircle) {
      pulseCircle = global.document.getElementById('pulseCircle');
    }
    if (!pulseCounterEl) {
      pulseCounterEl = global.document.getElementById('pulseCounter');
    }
  }

  /**
   * Update the displayed current pulse value on the page.
   * Exported as global update_beast_pulse_view.
   */
  function update_beast_pulse_view() {
    ensure_dom_refs();
    if (pulseCounterEl) {
      pulseCounterEl.textContent = String(global.Cur_puls_val);
    }
  }

  // Global pulse: used by sep_of_puls() — one cycle accounting for IndexedDB write time and blue indicator.
  var isOn = true;
  update_beast_pulse_view();

  global.update_beast_pulse_view = update_beast_pulse_view;

  function sep_of_puls() {
    var startTime = Date.now();
    try {
      if (typeof global.getDiffImportance === 'function') {
        global.PrevDiffForEpisode = global.getDiffImportance();
      }
      if (typeof global.runIndexedDBSavesForPulse === 'function') {
        global.runIndexedDBSavesForPulse();
      }

      if (global.Cur_puls_val === 0) {
        // initial data load from IndexedDB
      }

      global.Cur_puls_val += 1;
      update_beast_pulse_view();
      try {
        global.localStorage.setItem(PULSE_KEY, String(global.Cur_puls_val));
      } catch (e) {}

      if (typeof global.EpisodicMemory_onPulse === 'function') {
        global.EpisodicMemory_onPulse();
      }

      if (typeof global.performSensorOperations === 'function') {
        global.performSensorOperations();
      }
      global.cpuls++;
      if (typeof global.getActiveBasicContexts === 'function') {
        global.getActiveBasicContexts(global.cpuls);
      }
      if (typeof global.update_basic_contexts_view === 'function') {
        global.update_basic_contexts_view();
      }
      if (typeof global.PerceptionTree_updateActiveBranchView === 'function') {
        global.PerceptionTree_updateActiveBranchView();
      }
      // Sync Base / Emotion / Activity info picture with current perception tree branch.
      if (typeof global.Info_updateFromPerceptionTree === 'function') {
        global.Info_updateFromPerceptionTree();
      }
      // OR readiness borders: full recompute only when BadNormWell / emotion / branch ID changes
      // (see stimuls_ui.scheduleStimulusReadinessRefreshIfNeeded). Otherwise point updates in semantic_memory.js.
      if (typeof global.scheduleStimulusReadinessRefreshIfNeeded === 'function') {
        global.scheduleStimulusReadinessRefreshIfNeeded();
      }
      if (typeof global.SleepMode_refreshStimulusButtonVisuals === 'function') {
        global.SleepMode_refreshStimulusButtonVisuals();
      }
      // Sleep: dream machine (empty EM frame queue) — before FO step so dispetchConsciousnessThinking in this pulse
      // runs sleep passive main cycle after onPulse.
      if (typeof global.SleepDreams_onPulse === 'function') {
        global.SleepDreams_onPulse(global.cpuls);
      }
      // Passive mode: semantic processing of understanding models; new situation images may appear for later.
      var passiveMain = typeof global.Consciousness_getMainCycleThinkingMode === 'function' &&
        global.Consciousness_getMainCycleThinkingMode() === 'passive';
      if (passiveMain && typeof global.PassiveMode_processUnderstandingModels === 'function') {
        global.PassiveMode_processUnderstandingModels();
      }
      // Third pulse — orienting reflex starts consciousness: create first awareness cycle.
      if (global.cpuls === 3) {
        if (typeof global.Info_updateFromPerceptionTree === 'function') {
          global.Info_updateFromPerceptionTree();
        }
        if (typeof global.Info_updateFromStimulus === 'function') {
          global.Info_updateFromStimulus(0, 'external');
        }
        if (typeof global.Info_incrementStep === 'function') {
          global.Info_incrementStep();
        }
        if (typeof global.Info_thinkingFlash === 'function') {
          global.Info_thinkingFlash();
        }
        if (typeof global.stimuls_consciousness === 'function') {
          var branchId = typeof global.PerceptionTree_getActiveTerminalNodeId === 'function'
            ? global.PerceptionTree_getActiveTerminalNodeId()
            : 0;
          global.stimuls_consciousness({
            actual_stimul_ID: 0,
            branchId: branchId,
            well: global.BadNormWell || 0,
            emotionId: 0,
            activityID: 0,
            significance: 1
          });
        }
      }
      // Consciousness cycle dispatcher: one step for main cycle, background every 3 pulses.
      if (typeof global.dispetchConsciousnessThinking === 'function') {
        global.dispetchConsciousnessThinking(global.cpuls);
      }
      if (typeof global.processGeneticReflexes === 'function') {
        global.processGeneticReflexes();
      }
      global.EpisodicMemory_skipConditionalReflexFormation = false;

      ensure_dom_refs();
      if (pulseCircle) {
        isOn = !isOn;
        if (isOn) pulseCircle.classList.remove('off');
        else pulseCircle.classList.add('off');
      }
    } catch (e) {
      if (typeof global.console !== 'undefined' && global.console.error) {
        global.console.error('sep_of_puls:', e);
      }
    } finally {
      var elapsedTime = Date.now() - startTime;
      var delayTime = elapsedTime >= 1000 ? 0 : Math.max(0, 1000 - elapsedTime);
      global.setTimeout(sep_of_puls, delayTime);
    }
  }

  global.setTimeout(sep_of_puls, 1000);
})(window);
