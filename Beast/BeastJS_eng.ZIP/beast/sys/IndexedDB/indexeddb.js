/**
 * IndexedDB helper module for the BEAST project.
 *
 * Purpose:
 * - Thin wrapper over IndexedDB.
 * - Hides open/create store details and operations.
 * - Uniform read/write by key.
 *
 * Main functions:
 * - openDatabase(config)  — open/create DB and object stores.
 * - put(params)           — save or update a record.
 * - get(params)           — get one record by key.
 * - getAll(params)        — get all records in a store.
 * - remove(params)        — delete by key.
 * - clearStore(params)    — clear store.
 *
 * Example:
 *
 *   IndexedDBModule.openDatabase({
 *     dbName: 'BEAST_DB',
 *     version: 1,
 *     stores: [
 *       { name: 'samples', options: { keyPath: 'id' } }
 *     ]
 *   }).then(function (db) {
 *     return IndexedDBModule.put({
 *       db: db,
 *       storeName: 'samples',
 *       value: { id: 1, text: 'Hello, IndexedDB!' }
 *     });
 *   }).then(function () {
 *     return IndexedDBModule.getAll({
 *       db: db,
 *       storeName: 'samples'
 *     });
 *   }).then(function (allItems) {
 *     console.log(allItems);
 *   }).catch(function (error) {
 *     console.error('IndexedDB error:', error);
 *   });
 */

(function (global) {
  'use strict';

  /**
   * Open (or create) an IndexedDB database.
   *
   * @param {Object} config
   * @param {string} config.dbName
   * @param {number} [config.version]
   * @param {Array<Object>} [config.stores] — each: { name, options?, indexes? }
   * @returns {Promise<IDBDatabase>}
   */
  function openDatabase(config) {
    if (!config || !config.dbName) {
      return Promise.reject(new Error('Database name not set (config.dbName).'));
    }

    var dbName = config.dbName;
    var version = config.version || 1;
    var stores = Array.isArray(config.stores) ? config.stores : null;

    return new Promise(function (resolve, reject) {
      var request;
      try {
        request = global.indexedDB.open(dbName, version);
      } catch (e) {
        reject(e);
        return;
      }

      // Runs once on new DB or version bump.
      request.onupgradeneeded = function (event) {
        var db = event.target.result;

        if (!stores) {
          return;
        }

        stores.forEach(function (storeConfig) {
          if (!storeConfig || !storeConfig.name) {
            return;
          }

          if (db.objectStoreNames.contains(storeConfig.name)) {
            return;
          }

          var options = storeConfig.options || { keyPath: 'id' };
          var objectStore = db.createObjectStore(storeConfig.name, options);

          if (Array.isArray(storeConfig.indexes)) {
            storeConfig.indexes.forEach(function (idx) {
              if (!idx || !idx.name || !idx.keyPath) {
                return;
              }
              objectStore.createIndex(idx.name, idx.keyPath, idx.options || {});
            });
          }
        });
      };

      request.onsuccess = function (event) {
        var db = event.target.result;

        if (db.version !== version && version > db.version) {
          db.close();
          openDatabase({
            dbName: dbName,
            version: version,
            stores: stores
          }).then(resolve).catch(reject);
          return;
        }

        resolve(db);
      };

      request.onerror = function (event) {
        reject(event.target.error || new Error('Unknown error opening IndexedDB.'));
      };

      request.onblocked = function () {
        reject(new Error('IndexedDB upgrade blocked. Close other tabs with this app.'));
      };
    });
  }

  /**
   * Backward compatibility with older BEAST modules.
   * Old: IndexedDBModule.openDB({ dbName, version, storeName, keyPath })
   * New: { dbName, version, stores: [{ name, options: { keyPath } }] }
   */
  function openDB(config) {
    config = config || {};
    if (Array.isArray(config.stores)) {
      return openDatabase(config);
    }
    var storeName = config.storeName;
    var keyPath = config.keyPath || 'id';
    var desired = {
      dbName: config.dbName,
      version: config.version,
      stores: storeName ? [{ name: storeName, options: { keyPath: keyPath } }] : undefined
    };
    if (!storeName) {
      return openDatabase(desired);
    }
    return openDatabase(desired).then(function (db) {
      try {
        if (db && db.objectStoreNames && db.objectStoreNames.contains(storeName)) {
          return db;
        }
      } catch (e) {}
      var nextVersion = Math.max(parseInt(desired.version, 10) || 1, db && db.version ? db.version : 1) + 1;
      try { if (db) db.close(); } catch (e2) {}
      return openDatabase({
        dbName: desired.dbName,
        version: nextVersion,
        stores: desired.stores
      });
    });
  }

  /**
   * Run a single-store transaction.
   */
  function runTransaction(db, storeName, mode, operation) {
    if (!db) {
      return Promise.reject(new Error('Database not open.'));
    }
    if (!storeName) {
      return Promise.reject(new Error('storeName not set.'));
    }

    return new Promise(function (resolve, reject) {
      var tx;
      var store;
      try {
        tx = db.transaction(storeName, mode);
        store = tx.objectStore(storeName);
      } catch (e) {
        reject(e);
        return;
      }

      var request;
      try {
        request = operation(store);
      } catch (e) {
        reject(e);
        return;
      }

      request.onsuccess = function (event) {
        resolve(event.target.result);
      };

      request.onerror = function (event) {
        reject(event.target.error || new Error('IndexedDB operation error.'));
      };
    });
  }

  function put(params) {
    if (typeof global.showSaveIndicator === 'function') global.showSaveIndicator();
    var p = runTransaction(params.db, params.storeName, 'readwrite', function (store) {
      return store.put(params.value);
    });
    return p.then(function (r) {
      if (typeof global.hideSaveIndicator === 'function') global.hideSaveIndicator();
      return r;
    }, function (err) {
      if (typeof global.hideSaveIndicator === 'function') global.hideSaveIndicator();
      throw err;
    });
  }

  function get(params) {
    return runTransaction(params.db, params.storeName, 'readonly', function (store) {
      return store.get(params.key);
    });
  }

  function getAll(params) {
    return runTransaction(params.db, params.storeName, 'readonly', function (store) {
      if (typeof store.getAll === 'function') {
        return store.getAll();
      }

      var dummyRequest = {};
      setTimeout(function () {
        var tx = params.db.transaction(params.storeName, 'readonly');
        var st = tx.objectStore(params.storeName);
        var cursorRequest = st.openCursor();
        var items = [];

        cursorRequest.onsuccess = function (event) {
          var cursor = event.target.result;
          if (cursor) {
            items.push(cursor.value);
            cursor.continue();
          } else {
            if (typeof dummyRequest.onsuccess === 'function') {
              dummyRequest.onsuccess({ target: { result: items } });
            }
          }
        };

        cursorRequest.onerror = function (event) {
          if (typeof dummyRequest.onerror === 'function') {
            dummyRequest.onerror(event);
          }
        };
      }, 0);

      return dummyRequest;
    });
  }

  function remove(params) {
    if (typeof global.showSaveIndicator === 'function') global.showSaveIndicator();
    var p = runTransaction(params.db, params.storeName, 'readwrite', function (store) {
      return store.delete(params.key);
    });
    return p.then(function (r) {
      if (typeof global.hideSaveIndicator === 'function') global.hideSaveIndicator();
      return r;
    }, function (err) {
      if (typeof global.hideSaveIndicator === 'function') global.hideSaveIndicator();
      throw err;
    });
  }

  function clearStore(params) {
    if (typeof global.showSaveIndicator === 'function') global.showSaveIndicator();
    var p = runTransaction(params.db, params.storeName, 'readwrite', function (store) {
      return store.clear();
    });
    return p.then(function (r) {
      if (typeof global.hideSaveIndicator === 'function') global.hideSaveIndicator();
      return r;
    }, function (err) {
      if (typeof global.hideSaveIndicator === 'function') global.hideSaveIndicator();
      throw err;
    });
  }

  /**
   * Deferred save once per pulse (from puls.js).
   *
   * Dirty-flag pattern: set dirty only on real data change; in saver, if !dirty return;
   * if dirty, clear, serialize, compare sig to lastSavedSig; put only if changed.
   *
   * Modules that should registerIndexedDBSaver:
   * - semantic_memory.js
   * - perception_tree.js (dirty in addNode, not updateActiveBranchView)
   * - synonyms_reflexes.js
   * - episodic_memory.js
   * - actions_image.js
   * - automatizms.js
   * - goals.js
   * - situatioms_tree.js
   * - mental_automatism.js
   * - abstract_images.js
   * - gestalt.js
   */
  var indexedDBSavers = [];
  global.registerIndexedDBSaver = function (fn) {
    if (typeof fn === 'function') indexedDBSavers.push(fn);
  };
  global.runIndexedDBSavesForPulse = function () {
    for (var i = 0; i < indexedDBSavers.length; i++) {
      try {
        indexedDBSavers[i]();
      } catch (e) {
        if (typeof global.console !== 'undefined' && global.console.error) {
          global.console.error('IndexedDB saver error:', e);
        }
      }
    }
  };

  global.IndexedDBModule = {
    openDatabase: openDatabase,
    openDB: openDB,
    put: put,
    get: get,
    getAll: getAll,
    remove: remove,
    clearStore: clearStore
  };
})(window);
