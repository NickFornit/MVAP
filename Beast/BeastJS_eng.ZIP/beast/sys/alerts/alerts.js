/*
  Modal dialog module for the operator (BEAST project).

  Purpose:
  - Replaces standard alert/confirm/prompt with custom modal windows.
  - Provides a unified style and dialog management for the operator UI.
  - Used for interactive system–operator communication.

  Global API:
  - show_alert(message, timeShow = 0)
      Show an informational message.
      message  – HTML string with message text.
      timeShow – auto-close delay in milliseconds (0 = no auto-close).

  - show_confirm(message, callBack)
      Show a confirmation dialog with "Yes" / "No" buttons.
      message  – HTML string with the question.
      callBack – function(result) receiving 'OK' or 'NO'.

  - show_prompt(message, callBack)
      Show a text input dialog.
      message  – HTML string with instructions.
      callBack – function(value), called only on confirm.

  - close_alert()
      Force-close the active dialog.

  Usage examples: see beast/sys/alerts/samples.htm.
*/

(function (global) {
  'use strict';

  // Track active dialog and auto-close timer
  var activeDialog = null;
  var closeTimeout = null;
  var activeOnClose = null;
  var lastCloseUserInitiated = false;

  /**
   * Create (or return) the dimmed overlay behind the dialog.
   * @returns {HTMLElement}
   */
  function createOverlay() {
    var overlay = document.getElementById('alert-overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'alert-overlay';
      overlay.style.cssText =
        'position:fixed;top:0;left:0;width:100%;height:100%;' +
        'background-color:rgba(0,0,0,0.5);z-index:9998;display:none;' +
        'cursor:pointer;margin:0;padding:0;';
      document.body.appendChild(overlay);

      // Close on backdrop click (except plain alert)
      overlay.addEventListener('click', function () {
        if (activeDialog && activeDialog.dataset.type !== 'alert') {
          closeDialog();
        }
      });
    }
    return overlay;
  }

  /**
   * Build dialog structure.
   * @param {string} type - 'alert' | 'confirm' | 'prompt'
   * @returns {HTMLElement}
   */
  function createDialog(type) {
    if (activeDialog) {
      closeDialog();
    }

    var dialog = document.createElement('div');
    dialog.className = 'alert-dialog';
    dialog.dataset.type = type;
    dialog.style.cssText =
      'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);' +
      'z-index:9999;background-color:#ffffff;border-radius:8px;' +
      'box-shadow:0 4px 12px rgba(0,0,0,0.25);padding:20px;padding-top:40px;' +
      'max-width:90%;max-height:90vh;overflow:auto;' +
      'font-family:Arial,sans-serif;font-size:12pt;text-align:left;' +
      'box-sizing:border-box;margin:0;';

    var closeButton = document.createElement('button');
    closeButton.className = 'alert-close';
    closeButton.innerHTML = '&times;';
    closeButton.setAttribute('aria-label', 'Close');
    closeButton.style.cssText =
      'position:absolute;top:0;right:0;background-color:#f5f5f5;' +
      'border:1px solid #ddd;border-radius:0 8px 0 0;font-size:20px;' +
      'color:#666;cursor:pointer;padding:0;margin:0;width:32px;height:32px;' +
      'display:flex;align-items:center;justify-content:center;z-index:10000;' +
      'box-sizing:border-box;';
    closeButton.addEventListener('mouseenter', function () {
      closeButton.style.backgroundColor = '#e0e0e0';
      closeButton.style.color = '#000';
      closeButton.style.borderColor = '#ccc';
    });
    closeButton.addEventListener('mouseleave', function () {
      closeButton.style.backgroundColor = '#f5f5f5';
      closeButton.style.color = '#666';
      closeButton.style.borderColor = '#ddd';
    });
    closeButton.addEventListener('click', function (e) {
      e.stopPropagation();
      lastCloseUserInitiated = true;
      closeDialog();
    });
    dialog.appendChild(closeButton);

    var messageContainer = document.createElement('div');
    messageContainer.className = 'alert-message';
    messageContainer.style.cssText =
      'margin-bottom:15px;line-height:1.4;word-wrap:break-word;margin-top:0;';
    dialog.appendChild(messageContainer);

    document.body.appendChild(dialog);
    activeDialog = dialog;

    return dialog;
  }

  /**
   * Close current dialog and hide overlay.
   */
  function closeDialog() {
    if (closeTimeout) {
      clearTimeout(closeTimeout);
      closeTimeout = null;
    }

    if (activeDialog) {
      if (activeDialog.parentNode) {
        activeDialog.parentNode.removeChild(activeDialog);
      }
      activeDialog = null;
    }

    if (typeof activeOnClose === 'function') {
      try { activeOnClose({ userInitiated: !!lastCloseUserInitiated }); } catch (e) {}
    }
    activeOnClose = null;
    lastCloseUserInitiated = false;

    var overlay = document.getElementById('alert-overlay');
    if (overlay) {
      overlay.style.display = 'none';
    }
  }

  /**
   * Show informational dialog.
   * @param {string} message - HTML message.
   * @param {number} [timeShow=0] - auto-close ms (0 = none).
   */
  function show_alert(message, timeShow) {
    if (typeof timeShow === 'undefined') {
      timeShow = 0;
    }
    var opts = arguments.length >= 3 ? arguments[2] : null;
    if (typeof opts === 'function') {
      opts = { onClose: opts };
    }
    if (!opts || typeof opts !== 'object') opts = {};
    var dialogType = opts.dialogType || 'alert';

    // Do not replace foreign modals (confirm/prompt/alert) when showing cyclelog.
    if (dialogType === 'cyclelog' && activeDialog && activeDialog.dataset && activeDialog.dataset.type !== 'cyclelog') {
      return;
    }

    var dialog = createDialog(dialogType);
    activeOnClose = (typeof opts.onClose === 'function') ? opts.onClose : null;
    dialog.querySelector('.alert-message').innerHTML = message;

    if (timeShow === 0) {
      var buttonsContainer = document.createElement('div');
      buttonsContainer.className = 'alert-buttons';
      buttonsContainer.style.cssText =
        'display:flex;justify-content:flex-end;gap:10px;margin-top:15px;';

      var closeButton = document.createElement('button');
      closeButton.className = 'alert-button alert-button-close';
      closeButton.textContent = 'Close';
      closeButton.style.cssText =
        'padding:8px 16px;border:none;border-radius:4px;font-size:12pt;' +
        'cursor:pointer;min-width:80px;background-color:#2196F3;color:white;';
      closeButton.addEventListener('mouseenter', function () {
        closeButton.style.backgroundColor = '#0b7dda';
      });
      closeButton.addEventListener('mouseleave', function () {
        closeButton.style.backgroundColor = '#2196F3';
      });
      closeButton.addEventListener('click', function () {
        lastCloseUserInitiated = true;
        closeDialog();
      });

      buttonsContainer.appendChild(closeButton);
      dialog.appendChild(buttonsContainer);
    }

    if (timeShow > 0) {
      closeTimeout = global.setTimeout(closeDialog, timeShow);
    }
  }

  function getActiveDialogType() {
    return activeDialog && activeDialog.dataset ? (activeDialog.dataset.type || null) : null;
  }
  global.Alert_getActiveDialogType = getActiveDialogType;

  /**
   * Show confirmation dialog.
   * @param {string} message - HTML message.
   * @param {function(string)} callBack - handler ('OK' or 'NO').
   */
  function show_confirm(message, callBack) {
    var overlay = createOverlay();
    overlay.style.display = 'block';

    var dialog = createDialog('confirm');
    dialog.querySelector('.alert-message').innerHTML = message;

    var buttonsContainer = document.createElement('div');
    buttonsContainer.className = 'alert-buttons';
    buttonsContainer.style.cssText =
      'display:flex;justify-content:flex-end;gap:10px;margin-top:15px;';

    var noButton = document.createElement('button');
    noButton.className = 'alert-button alert-button-no';
    noButton.textContent = 'No';
    noButton.style.cssText =
      'padding:8px 16px;border:none;border-radius:4px;font-size:12pt;' +
      'cursor:pointer;min-width:80px;background-color:#f44336;color:white;';
    noButton.addEventListener('mouseenter', function () {
      noButton.style.backgroundColor = '#da190b';
    });
    noButton.addEventListener('mouseleave', function () {
      noButton.style.backgroundColor = '#f44336';
    });
    noButton.addEventListener('click', function () {
      closeDialog();
      if (typeof callBack === 'function') {
        callBack('NO');
      }
    });

    var okButton = document.createElement('button');
    okButton.className = 'alert-button alert-button-ok';
    okButton.textContent = 'Yes';
    okButton.style.cssText =
      'padding:8px 16px;border:none;border-radius:4px;font-size:12pt;' +
      'cursor:pointer;min-width:80px;background-color:#4CAF50;color:white;';
    okButton.addEventListener('mouseenter', function () {
      okButton.style.backgroundColor = '#45a049';
    });
    okButton.addEventListener('mouseleave', function () {
      okButton.style.backgroundColor = '#4CAF50';
    });
    okButton.addEventListener('click', function () {
      closeDialog();
      if (typeof callBack === 'function') {
        callBack('OK');
      }
    });

    buttonsContainer.appendChild(noButton);
    buttonsContainer.appendChild(okButton);
    dialog.appendChild(buttonsContainer);

    var escHandler = function (e) {
      if (e.key === 'Escape' && activeDialog && activeDialog.dataset.type === 'confirm') {
        closeDialog();
        global.document.removeEventListener('keydown', escHandler);
      }
    };
    global.document.addEventListener('keydown', escHandler);
  }

  /**
   * Show text input dialog.
   * @param {string} message - HTML message.
   * @param {function(string)} callBack - handler for entered value.
   */
  function show_prompt(message, callBack) {
    var overlay = createOverlay();
    overlay.style.display = 'block';

    var dialog = createDialog('prompt');
    dialog.querySelector('.alert-message').innerHTML = message;

    var input = document.createElement('input');
    input.className = 'alert-prompt-input';
    input.type = 'text';
    input.autofocus = true;
    input.style.cssText =
      'width:100%;padding:8px;border:1px solid #ccc;border-radius:4px;' +
      'font-size:12pt;box-sizing:border-box;margin-bottom:15px;';
    dialog.appendChild(input);

    var buttonsContainer = document.createElement('div');
    buttonsContainer.className = 'alert-buttons';
    buttonsContainer.style.cssText =
      'display:flex;justify-content:flex-end;gap:10px;margin-top:15px;';

    var cancelButton = document.createElement('button');
    cancelButton.className = 'alert-button alert-button-cancel';
    cancelButton.textContent = 'Cancel';
    cancelButton.style.cssText =
      'padding:8px 16px;border:none;border-radius:4px;font-size:12pt;' +
      'cursor:pointer;min-width:80px;background-color:#9e9e9e;color:white;';
    cancelButton.addEventListener('mouseenter', function () {
      cancelButton.style.backgroundColor = '#888888';
    });
    cancelButton.addEventListener('mouseleave', function () {
      cancelButton.style.backgroundColor = '#9e9e9e';
    });
    cancelButton.addEventListener('click', function () {
      closeDialog();
    });

    var okButton = document.createElement('button');
    okButton.className = 'alert-button alert-button-ok';
    okButton.textContent = 'OK';
    okButton.style.cssText =
      'padding:8px 16px;border:none;border-radius:4px;font-size:12pt;' +
      'cursor:pointer;min-width:80px;background-color:#4CAF50;color:white;';
    okButton.addEventListener('mouseenter', function () {
      okButton.style.backgroundColor = '#45a049';
    });
    okButton.addEventListener('mouseleave', function () {
      okButton.style.backgroundColor = '#4CAF50';
    });
    okButton.addEventListener('click', function () {
      var value = input.value;
      closeDialog();
      if (typeof callBack === 'function' && value !== '') {
        callBack(value);
      }
    });

    input.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        okButton.click();
      }
    });

    buttonsContainer.appendChild(cancelButton);
    buttonsContainer.appendChild(okButton);
    dialog.appendChild(buttonsContainer);

    var escHandler = function (e) {
      if (e.key === 'Escape' && activeDialog && activeDialog.dataset.type === 'prompt') {
        closeDialog();
        global.document.removeEventListener('keydown', escHandler);
      }
    };
    global.document.addEventListener('keydown', escHandler);
  }

  function close_alert() {
    closeDialog();
  }

  global.show_alert = show_alert;
  global.show_confirm = show_confirm;
  global.show_prompt = show_prompt;
  global.close_alert = close_alert;
})(window);
