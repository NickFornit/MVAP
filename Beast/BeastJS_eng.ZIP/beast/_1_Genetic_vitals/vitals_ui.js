/**
 * Vitals visualization on the main page.
 *
 * Purpose:
 * - Builds a row of indicators from window.VitalsArr.
 * - Indicator color depends on value in 0..100
 *   (0 — light green, 100 — red, smooth transition).
 * - Vital title is shown in the indicator title; name below in smaller font.
 */

(function (global) {
  'use strict';

  var ROW_ID = 'vitalsRow';
  var TITLE_ID = 'vitalsTitle';

  function valueToColor(value) {
    var v = value;
    if (v < 0) v = 0;
    if (v > 100) v = 100;
    var t = v / 100;
    var gStart = { r: 182, g: 247, b: 182 }; // light green
    var rEnd = { r: 255, g: 0, b: 0 };       // red
    var r = Math.round(gStart.r + (rEnd.r - gStart.r) * t);
    var g = Math.round(gStart.g + (rEnd.g - gStart.g) * t);
    var b = Math.round(gStart.b + (rEnd.b - gStart.b) * t);
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }

  function resetVitalsToDefaults() {
    if (global.VitalsArr && global.VitalsArrDefaults) {
      for (var i = 0; i < global.VitalsArr.length && i < global.VitalsArrDefaults.length; i++) {
        global.VitalsArr[i].value = global.VitalsArrDefaults[i].value;
        global.VitalsArr[i].shift = global.VitalsArrDefaults[i].shift;
      }
      global.isShockState = false;
      global.DeathSequenceStarted = false;
      if (typeof global.saveVitalsToStorage === 'function') {
        global.saveVitalsToStorage();
      }
      if (typeof global.update_vitals_view === 'function') {
        global.update_vitals_view();
      }
    }
  }

  function buildRowIfNeeded() {
    var row = global.document.getElementById(ROW_ID);
    if (row) {
      return row;
    }
    var content = global.document.querySelector('.beast-content');
    if (!content) {
      return null;
    }
    var titleWrap = global.document.getElementById(TITLE_ID);
    if (!titleWrap) {
      titleWrap = global.document.createElement('div');
      titleWrap.id = TITLE_ID;
      titleWrap.style.display = 'flex';
      titleWrap.style.alignItems = 'center';
      titleWrap.style.gap = '8px';
      titleWrap.style.marginBottom = '4px';

      var titleText = global.document.createElement('span');
      titleText.textContent = 'Life parameters (vitals), % deviation from normal';
      titleText.style.fontSize = '10pt';
      titleWrap.appendChild(titleText);

      var resetBtn = global.document.createElement('button');
      resetBtn.type = 'button';
      resetBtn.title = 'Reset vitals to default values';
      resetBtn.textContent = '×';
      resetBtn.style.cssText = 'width:25px;height:25px;padding:0;border-radius:50%;border:1px solid #0a0;background:#fff;color:#0a0;font-size:18px;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;';
      resetBtn.addEventListener('click', function () {
        if (!global.confirm('Reset for sure?')) {
          return;
        }
        resetVitalsToDefaults();
      });
      titleWrap.appendChild(resetBtn);

      content.insertBefore(titleWrap, content.firstChild || null);
    }
    row = global.document.createElement('div');
    row.id = ROW_ID;
    row.style.display = 'flex';
    row.style.flexWrap = 'wrap';
    row.style.gap = '6px';
    row.style.marginBottom = '10px';
    if (titleWrap.nextSibling) {
      content.insertBefore(row, titleWrap.nextSibling);
    } else {
      content.appendChild(row);
    }
    return row;
  }

  function ensureIndicators() {
    var row = buildRowIfNeeded();
    if (!row || !global.VitalsArr) {
      return;
    }
    if (row.children.length === global.VitalsArr.length) {
      return;
    }
    row.innerHTML = '';
    for (var i = 0; i < global.VitalsArr.length; i++) {
      var vital = global.VitalsArr[i];
      var item = global.document.createElement('div');
      item.style.display = 'flex';
      item.style.flexDirection = 'column';
      item.style.alignItems = 'stretch';
      item.style.flex = '1 1 80px';
      item.style.minWidth = '80px';
      item.style.maxWidth = '200px';

      var indicator = global.document.createElement('div');
      indicator.className = 'vital-indicator';
      indicator.setAttribute('data-vital-index', String(i));
      indicator.title = vital.title || '';
      indicator.style.width = '100%';
      indicator.style.height = '18px';
      indicator.style.borderRadius = '10%';
      indicator.style.border = '1px solid #888';
      indicator.style.boxSizing = 'border-box';
      indicator.style.backgroundColor = valueToColor(vital.value);
      indicator.style.display = 'flex';
      indicator.style.alignItems = 'center';
      indicator.style.justifyContent = 'center';
      indicator.style.fontSize = '10pt';
      indicator.style.color = '#000';
      indicator.style.cursor = 'pointer';

      var valueSpan = global.document.createElement('span');
      valueSpan.className = 'vital-value';
      valueSpan.textContent = vital.value.toFixed(1);
      indicator.appendChild(valueSpan);

      var nameEl = global.document.createElement('div');
      nameEl.className = 'vital-name';
      nameEl.textContent = vital.name || '';
      nameEl.style.fontSize = '9pt';
      nameEl.style.marginTop = '2px';
      nameEl.style.textAlign = 'center';

      indicator.addEventListener('click', (function (idx) {
        return function () {
          showVitalSetDialog(idx);
        };
      })(i));

      item.appendChild(indicator);
      item.appendChild(nameEl);
      row.appendChild(item);
    }
  }

  /**
   * Show dialog to edit vital value and shift; Apply writes both.
   * value is rounded to one decimal place.
   */
  function showVitalSetDialog(vitalIndex) {
    if (!global.VitalsArr || vitalIndex < 0 || vitalIndex >= global.VitalsArr.length) {
      return;
    }
    var vital = global.VitalsArr[vitalIndex];
    var overlay = global.document.createElement('div');
    overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.4);z-index:9998;display:flex;align-items:center;justify-content:center;';
    var box = global.document.createElement('div');
    box.style.cssText = 'background:#fff;padding:16px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.2);min-width:220px;';
    var label = global.document.createElement('div');
    label.textContent = vital.title || vital.name || 'Vital #' + vitalIndex;
    label.style.marginBottom = '8px';
    label.style.fontWeight = 'bold';

    var valueLabel = global.document.createElement('div');
    valueLabel.textContent = 'Value (0–100), %:';
    valueLabel.style.marginBottom = '4px';
    valueLabel.style.fontSize = '10pt';
    var input = global.document.createElement('input');
    input.type = 'text';
    input.inputMode = 'decimal';
    input.placeholder = '0–100';
    input.value = Number(vital.value).toFixed(1);
    input.style.cssText = 'width:100%;padding:6px;margin-bottom:10px;box-sizing:border-box;font-size:12pt;';

    var shiftLabel = global.document.createElement('div');
    shiftLabel.textContent = 'Shift (change rate per pulse):';
    shiftLabel.style.marginBottom = '4px';
    shiftLabel.style.fontSize = '10pt';
    var shiftInput = global.document.createElement('input');
    shiftInput.type = 'text';
    shiftInput.inputMode = 'decimal';
    shiftInput.value = String(vital.shift);
    shiftInput.style.cssText = 'width:100%;padding:6px;margin-bottom:10px;box-sizing:border-box;font-size:12pt;';

    var buttonsRow = global.document.createElement('div');
    buttonsRow.style.cssText = 'display:flex;justify-content:flex-end;gap:8px;margin-top:4px;';

    var cancelBtn = global.document.createElement('button');
    cancelBtn.textContent = 'Cancel';
    cancelBtn.style.cssText = 'padding:6px 12px;cursor:pointer;background:#f0f0f0;color:#333;border:1px solid #bbb;border-radius:4px;font-size:10pt;';
    cancelBtn.addEventListener('click', function () {
      if (overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
    });

    var btn = global.document.createElement('button');
    btn.textContent = 'Apply';
    btn.style.cssText = 'padding:8px 16px;cursor:pointer;background:#2196F3;color:#fff;border:none;border-radius:4px;font-size:12pt;';
    btn.addEventListener('click', function () {
      var v = parseFloat(input.value, 10);
      if (!isNaN(v)) {
        if (v < 0) v = 0;
        if (v > 100) v = 100;
        vital.value = Math.round(v * 10) / 10;
      }
      var s = parseFloat(shiftInput.value, 10);
      if (!isNaN(s)) {
        vital.shift = Math.round(s * 1000) / 1000;
      }
      if (typeof global.saveVitalsToStorage === 'function') {
        global.saveVitalsToStorage();
      }
      if (typeof global.update_vitals_view === 'function') {
        global.update_vitals_view();
      }
      if (overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
    });
    buttonsRow.appendChild(cancelBtn);
    buttonsRow.appendChild(btn);

    box.appendChild(label);
    box.appendChild(valueLabel);
    box.appendChild(input);
    box.appendChild(shiftLabel);
    box.appendChild(shiftInput);
    box.appendChild(buttonsRow);
    overlay.appendChild(box);
    global.document.body.appendChild(overlay);
    input.focus();
  }

  function update_vitals_view() {
    ensureIndicators();
    var row = global.document.getElementById(ROW_ID);
    if (!row || !global.VitalsArr) {
      return;
    }
    var indicators = row.querySelectorAll('.vital-indicator');
    var values = row.querySelectorAll('.vital-value');
    for (var i = 0; i < indicators.length && i < global.VitalsArr.length; i++) {
      var vital = global.VitalsArr[i];
      var el = indicators[i];
      el.style.backgroundColor = valueToColor(vital.value);
      el.title = vital.title || '';
      if (values[i]) {
        values[i].textContent = vital.value.toFixed(1);
      }
    }

    // Page background in different modes
    var doc = global.document;
    var root = doc.querySelector('.beast-root') || doc.body;
    if (!root.dataset) {
      root.dataset = {};
    }
    if (!root.dataset.originalBgColor) {
      // Remember original background; if not set inline, treat .beast-root as white
      var initial = root.style.backgroundColor || '';
      if (!initial) {
        initial = '#ffffff';
      }
      root.dataset.originalBgColor = initial;
    }
    if (!global.DeathSequenceStarted) {
      var bg = root.dataset.originalBgColor || '#ffffff';
      if (typeof global.SleepMode_isActive === 'function' && global.SleepMode_isActive()) {
        bg = (typeof global.SleepMode_PAGE_BACKGROUND === 'string')
          ? global.SleepMode_PAGE_BACKGROUND
          : '#e8e8e8';
      } else if (global.isShockState) {
        bg = '#f0f0f0'; // light gray in shock
      } else if (global.isAuthoritarianEducation) {
        bg = '#e0f2ff'; // light blue in authoritarian learning
      } else if (global.isGameMode) {
        bg = '#ffe6f0'; // light pink in game mode
      }
      root.style.backgroundColor = bg;
    }
  }

  global.update_vitals_view = update_vitals_view;

  function startDeathSequence() {
    var doc = global.document;
    var root = doc.querySelector('.beast-root') || doc.body;
    var originalBg = root.style.backgroundColor || '';

    var flashes = 0;
    function flashOnce() {
      root.style.transition = 'background-color 0.6s ease';
      root.style.backgroundColor = '#800000';
      setTimeout(function () {
        root.style.backgroundColor = '#000000';
        flashes++;
        if (flashes < 3) {
          setTimeout(flashOnce, 650);
        } else {
          showDeathOverlay();
        }
      }, 600);
    }

    function showDeathOverlay() {
      var overlay = doc.createElement('div');
      overlay.id = 'deathOverlay';
      overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:#000;z-index:10000;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;font-family:Arial,sans-serif;text-align:center;';

      var title = doc.createElement('div');
      title.textContent = 'HOMEOSTASIS SYSTEM DEATH';
      title.style.fontSize = '28pt';
      title.style.marginBottom = '20px';
      overlay.appendChild(title);

      var btn = doc.createElement('button');
      btn.textContent = 'Reset';
      btn.style.cssText = 'padding:10px 24px;font-size:12pt;border-radius:6px;border:1px solid #fff;background:#222;color:#fff;cursor:pointer;';
      btn.addEventListener('click', function () {
        resetVitalsToDefaults();
        var ov = doc.getElementById('deathOverlay');
        if (ov && ov.parentNode) {
          ov.parentNode.removeChild(ov);
        }
        root.style.backgroundColor = originalBg;
      });
      overlay.appendChild(btn);

      doc.body.appendChild(overlay);
    }

    flashOnce();
  }

  global.startDeathSequence = startDeathSequence;
  global.resetVitalsToDefaults = resetVitalsToDefaults;

  if (global.document.readyState === 'loading') {
    global.document.addEventListener('DOMContentLoaded', update_vitals_view);
  } else {
    update_vitals_view();
  }
})(window);

