/* Life parameters (vitals) — array definition only.
 *
 * Global declaration (in browser — becomes a window property)
 * value      - current parameter value (0..100); only value must be persisted
 * importance - significance weight
 * shift      - how much % parameters worsen or improve each pulse
 *
 * All load/save and recalculation logic is in vitals_prepare.js
 */
window.VitalsArr = [
  { Id: 1, value: 0, importance: 100, shift: -0.05, name: "Wounds",      title: "Damage / injuries" },
  { Id: 2, value: 0, importance: 90,  shift: -0.05, name: "Suffocation", title: "Hypoxia / oxygen deficit" },
  { Id: 3, value: 0, importance: 80,  shift: 0.003, name: "Thirst",     title: "Dehydration / water deficit" },
  { Id: 4, value: 0, importance: 70,  shift: 0,     name: "Heat",      title: "Overheating" },
  { Id: 5, value: 0, importance: 60,  shift: 0,     name: "Cold",     title: "Hypothermia" },
  { Id: 6, value: 0, importance: 50,  shift: 0.002, name: "Hunger",     title: "Hunger (energy deficit)" },
  { Id: 7, value: 0, importance: 40,  shift: -0.1,  name: "Stress",    title: "Stress" },
  { Id: 8, value: 0, importance: 30,  shift: 0.002, name: "Rut",       title: "Rut (sexual activity)" },
  { Id: 9, value: 0, importance: 20,  shift: 0.004, name: "Social",   title: "Need for social contact" },
  { Id: 10, value: 0, importance: 10,  shift: 0.004, name: "Interest",   title: "Need to explore / learn" }
];

// Degree of deviation of vitals from normal
window.BadVitalsValue = {
  1: 0,
  2: 0,
  3: 0,
  4: 0,
  5: 0,
  6: 0,
  7: 0,
  8: 0,
  9: 0,
  10: 0
};
  
// Integral significance of organism state
window.IntergalConditionImportance = 0;
// Previous integral significance of organism state
window.IntergalConditionImportanceOld = 0;
  
// Baseline organism state: Bad (1), Normal (2), Good (3)
window.BadNormWell = 0;  

// Change in baseline organism state vs previous value
window.DiffZnacher = 0; // significance differentiator

// Shock state (true when vital 1 >= 90%)
window.isShockState = false;

// Beast game mode
window.isGameMode = false;

// Authoritarian learning mode
window.isAuthoritarianEducation = false;

// Default value and shift for Reset button (snapshot at load)
window.VitalsArrDefaults = window.VitalsArr.map(function (v) {
  return { value: v.value, shift: v.shift };
});

// Sleep state
window.IsSpeeping = false;
