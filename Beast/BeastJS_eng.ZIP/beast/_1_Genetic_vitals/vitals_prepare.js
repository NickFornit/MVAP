/**
 * Vitals preparation: load/save value and recalculation by shift.
 *
 * Purpose:
 * - Restore vital value fields from localStorage on startup.
 * - Save values to localStorage (periodically and via “Save memory” button).
 * - performSensorOperations() — recalculate value by shift coefficient; called from the pulse.
 *
 * Dependency: vitals.js (window.VitalsArr) must be loaded before this script.
 */

(function (global) {
  'use strict';

  var STORAGE_KEY = 'VitalsValues';

  /**
   * Restore vital values from localStorage (if a save exists).
   * Only value fields are stored; other fields come from the source array.
   */
  function loadVitalsFromStorage() {
    var data;
    try {
      var raw = global.localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        return;
      }
      data = JSON.parse(raw);
    } catch (e) {
      return;
    }

    if (!Array.isArray(data) || !global.VitalsArr) {
      return;
    }

    for (var i = 0; i < global.VitalsArr.length && i < data.length; i++) {
      var v = parseFloat(data[i]);
      if (isNaN(v)) {
        continue;
      }
      if (v < 0) v = 0;
      if (v > 100) v = 100;
      global.VitalsArr[i].value = v;
    }
  }

  /**
   * Save current vital values to localStorage.
   * Only an array of numbers is stored.
   */
  function saveVitalsToStorage() {
    if (!global.VitalsArr) {
      return;
    }
    var values = [];
    for (var i = 0; i < global.VitalsArr.length; i++) {
      values.push(global.VitalsArr[i].value);
    }
    try {
      global.localStorage.setItem(STORAGE_KEY, JSON.stringify(values));
    } catch (e) {}
  }

  /**
   * Recalculate life parameters using the shift coefficient.
   * Called from the central pulse once per pulse.
   */
  function performSensorOperations() {
    if (!global.VitalsArr) {
      return;
    }

    for (var i = 0; i < global.VitalsArr.length; i++) {
      var vital = global.VitalsArr[i];
      var newVal = vital.value + vital.shift;
      if (newVal < 0) newVal = 0;
      if (newVal > 100) newVal = 100;
      vital.value = newVal;
    }

    // Extra rule: at high vitals 1–6, vital 1 increases.
    // If vitals with Id 1,2,3,4,5,6 reach 90% or more, vital 1 increases
    // by the sum of (importance / 1000) of those vitals. Example: Id 2 and 5 >= 90
    // adds 0.09 (90/1000) + 0.06 (60/1000).
    var vital1 = null;
    var extraGrowth = 0;
    for (var j = 0; j < global.VitalsArr.length; j++) {
      var v = global.VitalsArr[j];
      if (v.Id === 1) {
        vital1 = v;
      }
      if (v.Id >= 1 && v.Id <= 6 && v.value >= 90) {
        extraGrowth += (v.importance || 0) / 1000;
      }
    }
    if (vital1) {
      if (extraGrowth > 0) {
        var v1 = vital1.value + extraGrowth;
        if (v1 > 100) v1 = 100;
        if (v1 < 0) v1 = 0;
        vital1.value = v1;
      }
      // Shock state and death by vital 1
      if (vital1.value >= 90) {
        global.isShockState = true;
      } else {
        global.isShockState = false;
      }
      if (vital1.value >= 100 && !global.DeathSequenceStarted && typeof global.startDeathSequence === 'function') {
        global.DeathSequenceStarted = true;
        global.startDeathSequence();
      }
    }

    // Apply shift from active stimuli (shift each pulse)
    if (global.StimulMotivarion && global.ActiveMotivationStimuls && global.ActiveMotivationStimuls.length) {
      for (var si = 0; si < global.ActiveMotivationStimuls.length; si++) {
        var stimId = global.ActiveMotivationStimuls[si];
        for (var sj = 0; sj < global.StimulMotivarion.length; sj++) {
          var stim = global.StimulMotivarion[sj];
          if (stim.Id === stimId && stim.vitalID > 0 && stim.vitalID <= 10 && stim.shift) {
            for (var vk = 0; vk < global.VitalsArr.length; vk++) {
              var vv = global.VitalsArr[vk];
              if (vv.Id === stim.vitalID) {
                var nv = vv.value + stim.shift;
                if (nv < 0) nv = 0;
                if (nv > 100) nv = 100;
                vv.value = nv;
                break;
              }
            }
            break;
          }
        }
      }
    }

    saveVitalsToStorage();

    if (typeof global.update_vitals_view === 'function') {
      global.update_vitals_view();
    }
  }

  loadVitalsFromStorage();

  global.saveVitalsToStorage = saveVitalsToStorage;
  global.performSensorOperations = performSensorOperations;
})(window);
