# Genetic vitals (_1_Genetic_vitals)

## Purpose

The module defines and maintains **life parameters (vitals)** — genetically preset organism state indicators. Vital values and their dynamics underpin homeostatic regulation and affect baseline state (Bad / Norm / Well), context choice, and reactions.

## Main data

- **VitalsArr** — vital array. Each element:
  - `Id` — identifier;
  - `value` — current value (0..100), the field to persist across sessions;
  - `importance` — parameter importance weight;
  - `shift` — change in % per pulse (worsening or improvement);
  - `name`, `title` — label and tooltip.

- **BadVitalsValue** — how far vitals deviate from norm (for regulation).

- **IntergalConditionImportance** / **IntergalConditionImportanceOld** — integral importance of organism state.

## Files

- **vitals.js** — vital arrays and related globals.
- **vitals_prepare.js** — load/save, per-pulse vital recompute, link to baseline and contexts.
- **vitals_ui.js** — vital display in the UI.

Recalculation and persistence live in `vitals_prepare.js`; `vitals.js` only holds source data.
