/* Genetically predisposed reflexes
 *
 * Tabular data for stimulus effects on vitals, basic contexts,
 * and basic genetic actions.
 */

/* INTERNAL REFLEXES — somatic reflexes */

/* List of StimulMotivarion stimulus Id effects on VITALS (window.VitalsArr)
For each stimulus Id an array of effects:
  vitalID 1–10  — one-shot change to that vital by delta on stimulus activation
  vitalID 101  — call SetWellForHolding(), delta ignored
  vitalID 102  — call SetBadForHolding(), delta ignored
  vitalID 103  — set Beast game mode isGameMode=true, delta ignored
  vitalID 104  — set authoritarian learning isAuthoritarianEducation=true, delta ignored
  
These are “internal” (non-muscular) genetic reflexes; conditional somatic reflexes can form from them.
*/
window.StimulMotivarion_EffectsToBContexts = {
  // Food / Water: stress relief + hold Good (as in stimuls.js — normalization via Beast action)
  1:  [{ vitalID: 7,  delta: -20 }, { vitalID: 101, delta: 0 }],
  2:  [{ vitalID: 7,  delta: -20 }, { vitalID: 101, delta: 0 }],
  3:  [],
  4:  [],
  5:  [{ vitalID: 7,  delta: -20 }],
  6:  [{ vitalID: 7,  delta: -20 } ],
  7:  [{ vitalID: 7,  delta: -50 }, { vitalID: 101, delta: 0 }],
  8:  [{ vitalID: 7,  delta: 50 }, { vitalID: 102, delta: 0 }],
  9:  [{ vitalID: 7,  delta: -30 }, { vitalID: 17, delta: 20 }],
  10: [{ vitalID: 7,  delta: 30 }],
  11: [{ vitalID: 7,  delta: -20 }],
  12: [{ vitalID: 7,  delta: -20 } ],
  13: [{ vitalID: 7,  delta: 20 }],
  14: [{ vitalID: 7,  delta: -30 }],
  15: [{ vitalID: 7,  delta: -20 } ],
  16: [{ vitalID: 7,  delta: -40 } ],
  17: [{ vitalID: 7,  delta: 20 } ],
  18: [{ vitalID: 7,  delta: 20 }],
  19: [{ vitalID: 103, delta: 0 }],
  20: [{ vitalID: 104, delta: 0 }, ]
};

/* List of StimulPositiv stimulus Id effects on CONTEXTS (ids window.StimulMotivarion)
For each stimulus Id an array of effects:
  1–20  — activate corresponding context on stimulus for state_retention_period
for state_retention_period pulse-driven context selection is blocked.
  101  — SetWellForHolding(), 
  102  — SetBadForHolding(), 
  103  — isGameMode=true, 
  104  — isAuthoritarianEducation=true.
These are “internal” (non-muscular) genetic reflexes; conditional somatic reflexes can form from them.
*/
window.StimulPositiv_EffectsToBContexts = {
  1:  [13,11],
  2:  [11],
  3:  [13],
  4:  [12],
  5:  [12],
  6:  [12],
  7:  [5],
  8:  [12],
  9:  [13,11],
  10: [12],
  11: [12],
  12: [12],
  13: [13],
  14: [5],
  15: [5],
  16: [12],
  17: [12],
  18: [12],
  19: [13],
  20: [13,8],
};

/* List of StimulNegative stimulus Id effects on CONTEXTS (ids window.StimulMotivarion)
For each stimulus Id an array of effects:
  1–20  — activate corresponding context on stimulus for state_retention_period
for state_retention_period pulse-driven context selection is blocked.
  101  — SetWellForHolding(), 
  102  — SetBadForHolding(), 
  103  — isGameMode=true, 
  104  — isAuthoritarianEducation=true.
These are “internal” (non-muscular) genetic reflexes; conditional somatic reflexes can form from them.
*/
window.StimulNegative_EffectsToBContexts = {
  1:  [6, 9],
  2:  [6, 9],
  3:  [9],
  4:  [6, 9],
  5:  [6, 9, 7],
  6:  [9],
  7:  [9],
  8:  [6, 9],
  9:  [6],
  10: [6, 9, 102],
  11: [12],
  12: [12],
  13: [6, 9],
  14: [9],
  15: [6, 9],
  16: [6, 9],
  17: [9],
  18: [9],
  19: [9, 102],
  20: [6, 9, 102],
};
  
  /* EXTERNAL, motor REFLEXES 
Attempts at “independent” action in the 9–18 month crisis period
are driven mainly by internal autonomy development,
not perception stimuli alone.
Spontaneous actions tap natural psychic energy where the child explores the world without immediate external reward — basis for future volition.
One reflex kind — on active stimulus,
another — on urge to try something — semantic memory begins to accumulate.
  */
  
/* List of StimulMotivarion Id → basic genetic action IDs (window.BasicActions)
When action ID == 100 — every 5 pulses emit one random window.BasicVerbal sound — build understanding model.
(Previously defined twice — second overwrote first; single definition kept.)
*/
window.StimulMotivarion_GeneticReflexes = {
  1:  [3], // eat
  2:  [4], // drink
  3:  [23],
  4:  [30],
  5:  [],
  6:  [],
  7:  [2],
  8:  [1],
  9:  [27],
  10: [7],
  11: [25],
  12: [],
  13: [],
  14: [],
  15: [2],
  16: [27],
  17: [],
  18: [28],
  19: [12],
  20: [20,100],
}

/* List of StimulPositiv stimulus Id → basic genetic action IDs (window.BasicActions)
When action ID == 100 — every 5 pulses one random BasicVerbal — build understanding model.
*/
window.StimulPositiv_GeneticReflexes = {
  1:  [27],
  2:  [6,100],
  3:  [100],
  4:  [20],
  5:  [20],
  6:  [20],
  7:  [3],
  8:  [20],
  9:  [27],
  10: [20,100],
  11: [20],
  12: [20],
  13: [27],
  14: [3],
  15: [5],
  16: [23],
  17: [20, 27],
  18: [],
  19: [5],
  20: [27],
}

/* List of StimulNegative stimulus Id → basic genetic action IDs (window.BasicActions)

*/
window.StimulNegative_GeneticReflexes = {
  1:  [8],
  2:  [20],
  3:  [20],
  4:  [20],
  5:  [8],
  6:  [20],
  7:  [13],
  8:  [15],
  9:  [20],
  10: [8,15],
  11: [20],
  12: [20],
  13: [19],
  14: [20],
  15: [8],
  16: [20],
  17: [13],
  18: [13],
  19: [14],
  20: [8,20],
}

/* Hold action until vitals fully recover.
actionID — action being performed, vitalID — affected vital, shift — vital decrease per pulse.
Once started, held until vitalID reaches 0
or the motivating stimulus that triggered it is still active in window.StimulMotivarion.
*/
window.ActionProlongator = [
  { actionID: 3, vitalID: 6, shift: 5 },
  { actionID: 4, vitalID: 3, shift: 10 }
];

