# Genetic reflexes (_5_Genetic__reflexes)

## Purpose

The module implements **genetically specified motor reflexes**: on motivating/positive/negative stimulus activation, *_GeneticReflexes maps pick BasicActions, run with OR blocks, and register in semantics, action images, and episodic memory.

## Logic

- Each pulse calls **processGeneticReflexes()** (from puls.js).
- First **delayed reflexes** (delayedReflexes). OR-blocked genetic reflex is queued from OR (addBlockedReflexToQueue) with active tree branchId. **If stimuls_consciousness started an automatism**, all queue entries for that branch are removed (removeDelayedReflexesForBranch) — no action comparison, branchId only. If automatism is rejected, removal does not run and delayed reflex fires after delay.
- Then **conditional reflexes** (synonyms_tryRunReflexes); on hit — action via runGeneticActionFromSynonymReflex.
- Else for **newly** activated motivation/positive/negative stimuli, events from StimulMotivarion_GeneticReflexes, StimulPositiv_GeneticReflexes, StimulNegative_GeneticReflexes. If reflex blocked by OR (OrientationReflex_isReflexBlockedByOR), event goes to delayedReflexes with noConditionalReflex: true; else startAction.

**startAction** registers experience in semantic memory, updates “Beast activity,” prolonged actions (eating, drinking, etc.), action images (ActionsImage_registerReaction), and last EP frame (EpisodicMemory_setLastFrameActionFromActionId). synonyms_onGeneticActionFired (CR formation) is skipped for sourceType === 'synonym' or noConditionalReflex.

## Files

- **genetic_reflexes.js** — stimulus → action maps (StimulMotivarion_GeneticReflexes, StimulPositiv_GeneticReflexes, StimulNegative_GeneticReflexes), verbal reflex (Id 100), action prolongators.
- **genetic_reflexes_engine.js** — reflex processing, delayed queue, startAction, runGeneticActionFromSynonymReflex, activity display.
