/**
 * Genetically defined motor reflexes and Beast activity output.
 *
 * Logic:
 * - On stimulus activation (motivation, positive, negative) maps *_GeneticReflexes
 *   select basic actions (window.BasicActions).
 * - The chosen action name is shown in the “Beast activity” block
 *   (e.g. “Cries”, “Grasps”, …).
 * - For special action Id == 100, every 5 pulses a random “physiological sound”
 *   from window.BasicVerbal: “Says: ma-ma-ma”.
 * - For ActionProlongator entries, each pulse reduces the given vital by shift until 0.
 *
 * processGeneticReflexes() is called from the central pulse (puls.js) once per pulse.
 */
(function (global) {
  'use strict';

  var prevMotivation = [];
  var prevPositiv = [];
  var prevNegative = [];

  var prolongedActions = {}; // actionId -> { vitalID, shift }
  var verbalReflexActive = false;
  var verbalPulseCounter = 0;

  /**
   * Reflex delay: OR blocks immediate execution; queued in delayedReflexes from OR
   * (addBlockedReflexToQueue) with active branch branchId. If stimuls_consciousness runs an automatism,
   * reflexes for that branch are removed (removeDelayedReflexesForBranch).
   */
  var delayedReflexes = [];
  var OR_BLOCK_PULSES = 2;

  function getCurrentFullFinalImageId() {
    if (typeof global.FinalImages_getOrCreateFinalImageId !== 'function') return 0;
    // Global stimulus ids (type*1000+localId) avoid numeric id collisions across types.
    var ids = typeof global.StimulusGlobalId_getActiveGlobalIds === 'function'
      ? global.StimulusGlobalId_getActiveGlobalIds()
      : [];
    return ids.length ? global.FinalImages_getOrCreateFinalImageId(ids) : 0;
  }

  /**
   * Run delayed reflexes (OR-delayed by 2 pulses).
   * If automatism ran in stimuls_consciousness, reflex for that branch was already removed
   * (removeDelayedReflexesForBranch); match by branchId only, not action.
   */
  function runDelayedReflexes() {
    var pulse = typeof global.Cur_puls_val === 'number' ? global.Cur_puls_val : 0;
    for (var i = delayedReflexes.length - 1; i >= 0; i--) {
      var d = delayedReflexes[i];
      if (d.untilPulse > pulse) continue;
      delayedReflexes.splice(i, 1);
      startAction(d.actionId, d.sourceType, d.stimId, d.noConditionalReflex ? { noConditionalReflex: true } : undefined);
    }
  }

  /**
   * Remove all delayed reflex queue entries for this tree branch.
   * Called from stimuls_consciousness when automatism runs — reflex for branch cancelled without comparing actions.
   */
  function removeDelayedReflexesForBranch(branchId) {
    if (branchId == null) return;
    for (var i = delayedReflexes.length - 1; i >= 0; i--) {
      if (delayedReflexes[i].branchId === branchId) {
        delayedReflexes.splice(i, 1);
      }
    }
  }

  /**
   * First “new” genetic reflex from current active stimuli (for OR queue).
   */
  function getBlockedGeneticReflexEvent() {
    var activeMotiv = Array.isArray(global.ActiveMotivationStimuls) ? global.ActiveMotivationStimuls.slice() : [];
    var activePositiv = Array.isArray(global.ActivePositivStimuls) ? global.ActivePositivStimuls.slice() : [];
    var activeNegative = Array.isArray(global.ActiveNegativeStimuls) ? global.ActiveNegativeStimuls.slice() : [];
    var events = [];
    events = events.concat(
      collectNewActionEvents(activeMotiv, prevMotivation, global.StimulMotivarion_GeneticReflexes, 'motivation'),
      collectNewActionEvents(activePositiv, prevPositiv, global.StimulPositiv_GeneticReflexes, 'positive'),
      collectNewActionEvents(activeNegative, prevNegative, global.StimulNegative_GeneticReflexes, 'negative')
    );
    return events.length ? events[0] : null;
  }

  /**
   * Enqueue genetic reflex blocked by OR (call from OR on setBlockedReflex).
   * Reflex tied to branchId; automatism on that branch clears queue via removeDelayedReflexesForBranch.
   */
  function addBlockedReflexToQueue(branchId) {
    if (branchId == null) return;
    var ev = getBlockedGeneticReflexEvent();
    if (!ev) return;
    var pulse = typeof global.Cur_puls_val === 'number' ? global.Cur_puls_val : 0;
    delayedReflexes.push({
      actionId: ev.actionId,
      sourceType: ev.sourceType,
      stimId: ev.stimId,
      untilPulse: pulse + OR_BLOCK_PULSES,
      noConditionalReflex: true,
      branchId: branchId
    });
  }

  function getBasicActionName(actionId) {
    if (!global.BasicActions || !Array.isArray(global.BasicActions)) {
      return '';
    }
    for (var i = 0; i < global.BasicActions.length; i++) {
      if (global.BasicActions[i].Id === actionId) {
        return global.BasicActions[i].name || '';
      }
    }
    return '';
  }

  var activityHighlightTimeout = null;

  function setBeastActivityText(text) {
    if (!global.document) return;
    var block = global.document.getElementById('beastActivityBlock');
    if (!block) return;

    // Clear previous timer and restore base style
    if (activityHighlightTimeout !== null) {
      global.clearTimeout(activityHighlightTimeout);
      activityHighlightTimeout = null;
    }

    block.textContent = text || '';

    // Brief visual highlight for new reaction (1 second)
    if (text) {
      // During sleep, while fantasy runs on empty EM frame — pale gray activity text, not bright highlight.
      var paleDream = global.SleepDreams_paleActivityBeast === true;
      if (paleDream) {
        block.style.color = '#9e9e9e';
        block.style.fontWeight = 'normal';
        block.style.fontSize = '13pt';
        activityHighlightTimeout = global.setTimeout(function () {
          block.style.color = '#b0b0b0';
          block.style.fontWeight = '';
          block.style.fontSize = '12pt';
          activityHighlightTimeout = null;
        }, 800);
      } else {
        block.style.color = '#1565C0';       // blue
        block.style.fontWeight = 'bold';
        block.style.fontSize = '18pt';

        activityHighlightTimeout = global.setTimeout(function () {
          // Back to default (from CSS)
          block.style.color = '';
          block.style.fontWeight = '';
          block.style.fontSize = '';
          activityHighlightTimeout = null;
        }, 1000);
      }
    }
  }

  function registerProlongatedAction(actionId) {
    if (!global.ActionProlongator || !Array.isArray(global.ActionProlongator)) {
      return;
    }
    for (var i = 0; i < global.ActionProlongator.length; i++) {
      var cfg = global.ActionProlongator[i];
      if (cfg && cfg.actionID === actionId) {
        prolongedActions[String(actionId)] = {
          vitalID: cfg.vitalID,
          shift: cfg.shift
        };
        break;
      }
    }
  }

  function getStimulusName(sourceType, stimId) {
    var arr = null;
    if (sourceType === 'motivation') {
      arr = global.StimulMotivarion;
    } else if (sourceType === 'positive') {
      arr = global.StimulPositiv;
    } else if (sourceType === 'negative') {
      arr = global.StimulNegative;
    }
    if (!arr || !Array.isArray(arr)) {
      return '';
    }
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && arr[i].Id === stimId) {
        return arr[i].name || '';
      }
    }
    return '';
  }

  function getSemanticImportanceValue() {
    if (typeof global.getDiffImportance === 'function') {
      var z = global.getDiffImportance();
      if (typeof z === 'number' && !isNaN(z)) {
        return z;
      }
    }
    return null;
  }

  /**
   * Do not call from startAction or elsewhere.
   * Semantic accounting runs once per activation in orientation_reflex;
   * a second call would double the learning counter.
   * Stub prevents accidental double counting.
   */
  function registerSemanticExperience(sourceType, stimId, z) {
    return;
  }

  function startAction(actionId, sourceType, stimId, options) {
    if (actionId === 100) {
      verbalReflexActive = true;
      return;
    }
    var name = getBasicActionName(actionId);
    var stimulusName = getStimulusName(sourceType, stimId);

    // Semantic significance is counted once per activation in OR (orientation_reflex)
    // so the learning counter steps by 1 and averaging stays correct.
    // Here we only take z for “Beast activity” display, no re-registration.
    var z = null;
    if (sourceType !== 'synonym') {
      z = getSemanticImportanceValue();
    }
    var typeLabel = '';
    if (sourceType === 'automatism') {
      typeLabel = 'automatism';
    } else if (sourceType === 'synonym') {
      typeLabel = 'conditioned reflex';
    } else if (sourceType === 'motivation' || sourceType === 'positive' || sourceType === 'negative') {
      typeLabel = 'genetic reflex';
    }
    var line1 = name ? (name + (typeLabel ? ' (' + typeLabel + ')' : '')) : typeLabel;
    var line2 = '';
    if (stimulusName) {
      line2 = 'Semantic significance ' + stimulusName;
      if (z !== null) {
        var zStr = String(Math.round(z * 100) / 100);
        line2 += ' - ' + zStr;
      }
    }
    var line = line2 ? (line1 + '\n' + line2) : line1;
    setBeastActivityText(line || name || '');
    // Any executed reaction (genetic, conditioned, automatism) switches consciousness to target mode.
    if (typeof global.Info_setMode === 'function') {
      global.Info_setMode('target');
    }
    registerProlongatedAction(actionId);

    var fi = getCurrentFullFinalImageId();
    if (fi && typeof global.ActionsImage_registerReaction === 'function') {
      try {
        global.ActionsImage_registerReaction(fi, actionId);
      } catch (e) {}
    }
    if (typeof global.EpisodicMemory_setLastFrameActionFromActionId === 'function') {
      try {
        global.EpisodicMemory_setLastFrameActionFromActionId(actionId);
      } catch (e) {}
    }

    // Notify conditioned (synonym) reflex subsystem
    // ONLY for innate paths (motivation / positive / negative).
    // For sourceType === 'synonym' (fired by conditioned reflex) — no re-learning.
    // If stimulus drew OR (reflex was OR-delayed) — skip conditioned-reflex formation.
    // If EM frame is building (answer waiting) — no conditioned reflex.
    // If frame just closed on response stimulus — no CR from that reflex (flag clears next pulse).
    // Conditioned reflex needs stimulus combination: with one active stimulus, no pairing step / no CR.
    var noConditionalReflex = options && options.noConditionalReflex === true;
    var inEpWaiting = typeof global.EpisodicMemory_isInWaitingPeriod === 'function' && global.EpisodicMemory_isInWaitingPeriod();
    var skipBecauseResponseStimulus = global.EpisodicMemory_skipConditionalReflexFormation === true;
    var activeIdsForUR = typeof global.StimulusGlobalId_getActiveGlobalIds === 'function'
      ? global.StimulusGlobalId_getActiveGlobalIds() : [];
    var singleStimulusNoPairing = !activeIdsForUR || activeIdsForUR.length < 2;
    if (sourceType !== 'synonym' && !noConditionalReflex && !inEpWaiting && !skipBecauseResponseStimulus && !singleStimulusNoPairing &&
        typeof global.synonyms_onGeneticActionFired === 'function') {
      try {
        global.synonyms_onGeneticActionFired(stimId, sourceType, actionId);
      } catch (e) {}
    }
  }

  /**
   * Run action image (action schema): actionIds array and/or sequence of other ODs (odSequence).
   * Used when automatism fires in stimuls_consciousness.
   * @param {number} actionsImageId — action image ID
   */
  function runActionImage(actionsImageId) {
    if (!actionsImageId || typeof global.ActionImages_getActionImage !== 'function') return;
    var od = global.ActionImages_getActionImage(actionsImageId);
    if (!od) return;
    var ids = od.actionIds || [];
    for (var i = 0; i < ids.length; i++) {
      startAction(ids[i], 'automatism', 0);
    }
    var seq = (od.odSequence || '').split(',');
    for (var j = 0; j < seq.length; j++) {
      var nextId = parseInt(seq[j].trim(), 10);
      if (nextId) runActionImage(nextId);
    }
  }

  /**
   * External hook to run action from conditioned (synonym) reflex.
   * Wraps internal startAction so semantic accounting and prolonged actions stay unified.
   */
  function runGeneticActionFromSynonymReflex(actionId, sourceType, stimId) {
    var pulse = typeof global.Cur_puls_val === 'number' ? global.Cur_puls_val : 0;
    if (typeof global.OrientationReflex_isReflexBlockedByOR === 'function' &&
        global.OrientationReflex_isReflexBlockedByOR(stimId, actionId)) {
      var branchId = (typeof global.PerceptionTree_getActiveTerminalNodeId === 'function')
        ? global.PerceptionTree_getActiveTerminalNodeId() : 0;
      delayedReflexes.push({
        actionId: actionId,
        sourceType: sourceType || 'synonym',
        stimId: stimId,
        untilPulse: pulse + OR_BLOCK_PULSES,
        noConditionalReflex: true,
        branchId: branchId
      });
      return;
    }
    startAction(actionId, sourceType, stimId);
  }

  function updateProlongatedActions() {
    var hasChanges = false;
    if (!global.VitalsArr || !Array.isArray(global.VitalsArr)) {
      return;
    }
    for (var key in prolongedActions) {
      if (!Object.prototype.hasOwnProperty.call(prolongedActions, key)) continue;
      var cfg = prolongedActions[key];
      var vital = null;
      for (var i = 0; i < global.VitalsArr.length; i++) {
        if (global.VitalsArr[i].Id === cfg.vitalID) {
          vital = global.VitalsArr[i];
          break;
        }
      }
      if (!vital) {
        delete prolongedActions[key];
        continue;
      }
      if (vital.value <= 0) {
        delete prolongedActions[key];
        continue;
      }
      var newVal = vital.value - cfg.shift;
      if (newVal < 0) newVal = 0;
      if (newVal !== vital.value) {
        vital.value = newVal;
        hasChanges = true;
      }
      if (vital.value <= 0) {
        delete prolongedActions[key];
      }
    }
    if (hasChanges) {
      if (typeof global.update_vitals_view === 'function') {
        global.update_vitals_view();
      }
      if (typeof global.saveVitalsToStorage === 'function') {
        global.saveVitalsToStorage();
      }
    }
  }

  function collectNewActionEvents(activeIds, prevIds, mapping, sourceType) {
    var events = [];
    if (!activeIds || !activeIds.length || !mapping) {
      return events;
    }
    for (var i = 0; i < activeIds.length; i++) {
      var id = activeIds[i];
      if (prevIds.indexOf(id) !== -1) continue;
      var acts = mapping[id];
      if (!acts || !acts.length) continue;
      for (var j = 0; j < acts.length; j++) {
        var actId = acts[j];
        events.push({
          actionId: actId,
          sourceType: sourceType,
          stimId: id
        });
      }
    }
    return events;
  }

  function updateVerbalReflexFlag() {
    verbalReflexActive = false;
    function checkMapping(activeIds, mapping) {
      if (!activeIds || !activeIds.length || !mapping) return;
      for (var i = 0; i < activeIds.length; i++) {
        var id = activeIds[i];
        var acts = mapping[id];
        if (!acts || !acts.length) continue;
        for (var j = 0; j < acts.length; j++) {
          if (acts[j] === 100) {
            verbalReflexActive = true;
            return;
          }
        }
      }
    }
    checkMapping(global.ActiveMotivationStimuls, global.StimulMotivarion_GeneticReflexes);
    checkMapping(global.ActivePositivStimuls, global.StimulPositiv_GeneticReflexes);
    checkMapping(global.ActiveNegativeStimuls, global.StimulNegative_GeneticReflexes);
  }

  function handleVerbalReflex() {
    if (!verbalReflexActive) {
      verbalPulseCounter = 0;
      return;
    }
    verbalPulseCounter++;
    if (verbalPulseCounter % 5 !== 0) {
      return;
    }
    if (!global.BasicVerbal || !Array.isArray(global.BasicVerbal) || !global.BasicVerbal.length) {
      return;
    }
    var idx = Math.floor(Math.random() * global.BasicVerbal.length);
    if (idx < 0 || idx >= global.BasicVerbal.length) {
      return;
    }
    var phrase = global.BasicVerbal[idx];
    if (!phrase) return;
    var name = phrase.name || '';
    if (!name) return;
    setBeastActivityText('Says: ' + name);
  }

  function processGeneticReflexes() {
    var pulse = typeof global.Cur_puls_val === 'number' ? global.Cur_puls_val : 0;

    runDelayedReflexes();

    if (typeof global.synonyms_tryRunReflexes === 'function') {
      try {
        if (global.synonyms_tryRunReflexes()) {
          updateProlongatedActions();
          updateVerbalReflexFlag();
          handleVerbalReflex();
          return;
        }
      } catch (e) {}
    }

    var activeMotiv = Array.isArray(global.ActiveMotivationStimuls) ? global.ActiveMotivationStimuls.slice() : [];
    var activePositiv = Array.isArray(global.ActivePositivStimuls) ? global.ActivePositivStimuls.slice() : [];
    var activeNegative = Array.isArray(global.ActiveNegativeStimuls) ? global.ActiveNegativeStimuls.slice() : [];

    var events = [];
    events = events.concat(
      collectNewActionEvents(activeMotiv, prevMotivation, global.StimulMotivarion_GeneticReflexes, 'motivation'),
      collectNewActionEvents(activePositiv, prevPositiv, global.StimulPositiv_GeneticReflexes, 'positive'),
      collectNewActionEvents(activeNegative, prevNegative, global.StimulNegative_GeneticReflexes, 'negative')
    );

    if (events.length) {
      var ev = events[0];
      var currentBranchId = (typeof global.PerceptionTree_getActiveTerminalNodeId === 'function')
        ? global.PerceptionTree_getActiveTerminalNodeId() : 0;
      // Clear “automatism ran” only for other branches — on stimulus/context change genetic reflex allowed again.
      if (global.automatismRanForBranchIds && currentBranchId != null) {
        for (var bid in global.automatismRanForBranchIds) {
          if (Number(bid) !== Number(currentBranchId)) {
            delete global.automatismRanForBranchIds[bid];
          }
        }
      }
      var fullFinalImageId = getCurrentFullFinalImageId();
      var blocked = typeof global.OrientationReflex_isReflexBlockedByOR === 'function' &&
        global.OrientationReflex_isReflexBlockedByOR(fullFinalImageId, ev.actionId);
      var automatismRanForThisBranch = global.automatismRanForBranchIds && global.automatismRanForBranchIds[currentBranchId];
      if (blocked) {
        // Reflex already queued from OR (addBlockedReflexToQueue); do not duplicate.
      } else if (automatismRanForThisBranch) {
        // Automatism already ran on this branch in stimuls_consciousness — skip genetic reflex (no repeat).
      } else {
        startAction(ev.actionId, ev.sourceType, ev.stimId);
      }
    }

    prevMotivation = activeMotiv;
    prevPositiv = activePositiv;
    prevNegative = activeNegative;

    updateProlongatedActions();
    updateVerbalReflexFlag();
    handleVerbalReflex();
  }

  global.setBeastActivityText = setBeastActivityText;

  global.processGeneticReflexes = processGeneticReflexes;
  global.runGeneticActionFromSynonymReflex = runGeneticActionFromSynonymReflex;
  global.runActionImage = runActionImage;
  global.addBlockedReflexToQueue = addBlockedReflexToQueue;
  global.removeDelayedReflexesForBranch = removeDelayedReflexesForBranch;

  function copyTextToClipboard(text) {
    var t = (text || '').trim();
    if (!t) return;
    if (global.navigator && global.navigator.clipboard && typeof global.navigator.clipboard.writeText === 'function') {
      global.navigator.clipboard.writeText(t).catch(function () {
        fallbackCopy(t);
      });
      return;
    }
    fallbackCopy(t);
  }

  function fallbackCopy(text) {
    var doc = global.document;
    if (!doc || !doc.body) return;
    var ta = doc.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    ta.style.top = '0';
    doc.body.appendChild(ta);
    ta.focus();
    ta.select();
    try {
      doc.execCommand('copy');
    } catch (e) {}
    doc.body.removeChild(ta);
  }

  function showCopySuccessAlert() {
    if (typeof global.show_alert === 'function') {
      global.show_alert('Copied to clipboard');
      if (typeof global.close_alert === 'function') {
        global.setTimeout(function () {
          try {
            global.close_alert();
          } catch (e) {}
        }, 1500);
      }
    }
  }

  function bindCopyButtons() {
    var doc = global.document;
    if (!doc) return;
    var btnBranch = doc.getElementById('btnCopyActiveBranch');
    if (btnBranch && typeof btnBranch.addEventListener === 'function') {
      btnBranch.addEventListener('click', function () {
        var el = doc.getElementById('perceptionTreeActiveBranchText');
        if (el) {
          copyTextToClipboard(el.textContent);
          showCopySuccessAlert();
        }
      });
    }
    var btnActivity = doc.getElementById('btnCopyActivityBlock');
    if (btnActivity && typeof btnActivity.addEventListener === 'function') {
      btnActivity.addEventListener('click', function () {
        var block = doc.getElementById('beastActivityBlock');
        if (block) {
          copyTextToClipboard(block.textContent);
          showCopySuccessAlert();
        }
      });
    }
  }

  if (global.document.readyState === 'loading') {
    global.document.addEventListener('DOMContentLoaded', bindCopyButtons);
  } else {
    bindCopyButtons();
  }
})(window);

