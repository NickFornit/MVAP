/**
 * Basic context indicators below the vitals row.
 *
 * Purpose:
 * - Builds a row of indicators from window.BasicContexts.
 * - Default: light gray background. When active (context ID in BasicContextsActived):
 *   light green background and circular light-green glow.
 * - Context name is shown under each indicator in small type.
 *
 * Dependencies: BasicContexts.js (window.BasicContexts, window.BasicContextsActived).
 * Row is inserted after #vitalsRow (created in vitals_ui.js).
 *
 * On activation: call window.update_basic_contexts_view() after
 * BasicContextsActived changes (e.g. from getActiveBasicContexts).
 */

(function (global) {
  'use strict';

  var ROW_ID = 'basicContextsRow';
  var TITLE_ID = 'basicContextsTitle';
  var TITLE_TEXT = 'Basic behavioral context state';
  function ensureRowStyles(row) {
    row.style.display = 'flex';
    row.style.flexWrap = 'wrap';
    row.style.gap = '6px';
    row.style.marginBottom = '10px';
  }

  function fillRowWithIndicators(row) {
    if (!global.BasicContexts || !global.BasicContexts.length) {
      return;
    }
    if (row.children.length === global.BasicContexts.length) {
      return;
    }
    row.innerHTML = '';
    for (var i = 0; i < global.BasicContexts.length; i++) {
      var ctx = global.BasicContexts[i];
      var item = global.document.createElement('div');
      item.style.display = 'flex';
      item.style.flexDirection = 'column';
      item.style.alignItems = 'stretch';
      item.style.flex = '1 1 80px';
      item.style.minWidth = '80px';
      item.style.maxWidth = '200px';

      var indicator = global.document.createElement('div');
      indicator.className = 'basic-context-indicator';
      indicator.setAttribute('data-context-index', String(i));
      indicator.title = ctx.title || ctx.name || '';
      indicator.style.width = '100%';
      indicator.style.minHeight = '28px';
      indicator.style.borderRadius = '10%';
      indicator.style.border = '1px solid #999';
      indicator.style.boxSizing = 'border-box';
      indicator.style.transition = 'background-color 0.2s, box-shadow 0.2s';
      indicator.style.display = 'flex';
      indicator.style.alignItems = 'center';
      indicator.style.justifyContent = 'center';
      indicator.style.padding = '4px 6px';
      indicator.style.textAlign = 'center';

      var nameEl = global.document.createElement('span');
      nameEl.className = 'basic-context-name';
      nameEl.textContent = ctx.name || '';
      nameEl.style.fontSize = '9pt';

      indicator.appendChild(nameEl);
      item.appendChild(indicator);
      row.appendChild(item);
    }
  }

  var BADNORMWELL_ID = 'basicContextsBadNormWell';
  var DIFF_LABEL_ID = 'basicContextsDiffLabel';

  function getBadNormWellLabel() {
    var v = global.BadNormWell;
    if (v === 1) return 'Bad';
    if (v === 2) return 'Normal';
    if (v === 3) return 'Good';
    return '';
  }

  function getDiffLabelText() {
    var d = global.DiffZnacher;
    if (typeof d !== 'number') return '';
    var rounded = Math.round(Math.abs(d) * 10) / 10;
    if (rounded === 0) return '';
    var absVal = Math.abs(d).toFixed(1);
    return d < 0 ? 'worsened by ' + absVal : 'improved by ' + absVal;
  }

  function ensureTitle(row) {
    var title = global.document.getElementById(TITLE_ID);
    if (title) {
      return;
    }
    title = global.document.createElement('div');
    title.id = TITLE_ID;
    title.style.fontSize = '10pt';
    title.style.marginBottom = '4px';
    title.style.display = 'flex';
    title.style.justifyContent = 'space-between';
    title.style.alignItems = 'center';

    var leftPart = global.document.createElement('span');
    leftPart.appendChild(global.document.createTextNode(TITLE_TEXT + ' '));
    var stateSpan = global.document.createElement('span');
    stateSpan.id = BADNORMWELL_ID;
    stateSpan.style.fontWeight = 'bold';
    stateSpan.style.cursor = 'pointer';
    stateSpan.title = 'Click to show values';
    stateSpan.textContent = getBadNormWellLabel();
    stateSpan.addEventListener('click', function () {
      var d = global.DiffZnacher;
      var imp = global.IntergalConditionImportance;
      var impOld = global.IntergalConditionImportanceOld;
      var fmt = function (v) { return (typeof v === 'number' ? v.toFixed(1) : '—'); };
      var msg = '<b>State difference tracked each pulse</b><br>' + 
	  'DiffZnacher (normalized difference): ' + fmt(d) + '<br>' +
        'IntergalConditionImportance: ' + fmt(imp) + '<br>' +
        'IntergalConditionImportanceOld: ' + fmt(impOld);
      global.show_alert(msg);
    });
    leftPart.appendChild(stateSpan);
    leftPart.appendChild(global.document.createTextNode(' '));
    var diffSpan = global.document.createElement('span');
    diffSpan.id = DIFF_LABEL_ID;
    diffSpan.style.padding = '2px 6px';
    diffSpan.style.borderRadius = '4px';
    diffSpan.textContent = getDiffLabelText();
    leftPart.appendChild(diffSpan);
    title.appendChild(leftPart);

    var buttonsRow = global.document.createElement('div');
    buttonsRow.style.display = 'flex';
    buttonsRow.style.alignItems = 'center';
    buttonsRow.style.gap = '4px';
    buttonsRow.style.flexShrink = '0';
    buttonsRow.style.position = 'relative';

    var countdownLabel = global.document.createElement('span');
    countdownLabel.id = 'holdCountdownLabel';
    countdownLabel.style.position = 'absolute';
    countdownLabel.style.top = '-12px';
    countdownLabel.style.left = '0';
    countdownLabel.style.fontSize = '8pt';
    countdownLabel.style.color = '#666';
    countdownLabel.style.pointerEvents = 'none';
    countdownLabel.textContent = '';
    buttonsRow.appendChild(countdownLabel);

    // Sleep mode: square button before round B — toggles sleep_mode (Sleep context, stimuli, dreams).
    var sleepBtn = global.document.createElement('button');
    sleepBtn.type = 'button';
    sleepBtn.id = 'sleepModeToggleBtn';
    sleepBtn.textContent = 'Sleep';
    sleepBtn.title = 'Enable sleep mode (Sleep context only, limited stimuli)';
    sleepBtn.style.width = '28px';
    sleepBtn.style.height = '22px';
    sleepBtn.style.borderRadius = '2px';
    sleepBtn.style.border = '1px solid #888';
    sleepBtn.style.fontSize = '8pt';
    sleepBtn.style.fontWeight = 'bold';
    sleepBtn.style.color = '#334';
    sleepBtn.style.backgroundColor = '#f5f5f5';
    sleepBtn.style.cursor = 'pointer';
    sleepBtn.style.padding = '0';
    sleepBtn.style.flexShrink = '0';
    sleepBtn.addEventListener('click', function () {
      if (typeof global.SleepMode_toggle === 'function') {
        global.SleepMode_toggle();
      }
    });
    buttonsRow.appendChild(sleepBtn);
    if (typeof global.SleepMode_setSleepButtonVisual === 'function') {
      global.SleepMode_setSleepButtonVisual();
    }

    // Hold Bad button (B)
    var badHoldBtn = global.document.createElement('button');
    badHoldBtn.type = 'button';
    badHoldBtn.textContent = 'B';
    badHoldBtn.title = 'Start Bad holding period';
    badHoldBtn.style.width = '22px';
    badHoldBtn.style.height = '22px';
    badHoldBtn.style.borderRadius = '50%';
    badHoldBtn.style.border = '1px solid #888';
    badHoldBtn.style.fontSize = '11pt';
    badHoldBtn.style.fontWeight = 'bold';
    badHoldBtn.style.color = '#c00';
    badHoldBtn.style.backgroundColor = '#f5f5f5';
    badHoldBtn.style.cursor = 'pointer';
    badHoldBtn.style.padding = '0';
    badHoldBtn.style.flexShrink = '0';
    badHoldBtn.addEventListener('click', function () {
      if (typeof global.SetBadForHolding === 'function') {
        global.SetBadForHolding();
      }
    });
    buttonsRow.appendChild(badHoldBtn);

    var wellHoldBtn = global.document.createElement('button');
    wellHoldBtn.type = 'button';
    wellHoldBtn.textContent = 'W';
    wellHoldBtn.title = 'Start Good holding period';
    wellHoldBtn.style.width = '22px';
    wellHoldBtn.style.height = '22px';
    wellHoldBtn.style.borderRadius = '50%';
    wellHoldBtn.style.border = '1px solid #888';
    wellHoldBtn.style.fontSize = '11pt';
    wellHoldBtn.style.fontWeight = 'bold';
    wellHoldBtn.style.color = '#0a0';
    wellHoldBtn.style.backgroundColor = '#f5f5f5';
    wellHoldBtn.style.cursor = 'pointer';
    wellHoldBtn.style.padding = '0';
    wellHoldBtn.style.flexShrink = '0';
    wellHoldBtn.addEventListener('click', function () {
      if (typeof global.SetWellForHolding === 'function') {
        global.SetWellForHolding();
      }
    });
    buttonsRow.appendChild(wellHoldBtn);

    var diffBtn = global.document.createElement('button');
    diffBtn.type = 'button';
    diffBtn.textContent = 'diff';
    diffBtn.title = 'Measure difference between current and previous state';
    diffBtn.style.height = '18px';
    diffBtn.style.fontSize = '9pt';
    diffBtn.style.padding = '0 6px';
    diffBtn.style.cursor = 'pointer';
    diffBtn.addEventListener('click', function () {
      var prev = global.PrevDiffZnacherForGetDiff;
      var curr = typeof global.IntergalConditionImportance === 'number' ? global.IntergalConditionImportance : 0;
      var diff = typeof global.getDiffImportance === 'function' ? global.getDiffImportance() : 0;
      var fmt = function (v) { return (typeof v === 'number' ? v.toFixed(1) : '—'); };
      var msg = 'previous state-change value: ' + fmt(prev) + '<br>' +
        'new state-change value: ' + fmt(curr) + '<br>' +
		'difference: ' + fmt(prev - curr) + '<br>' +  
        'normalized difference: ' + fmt(diff);
      global.show_alert(msg);
    });
    buttonsRow.appendChild(diffBtn);

    var btnGroup = global.document.createElement('div');
    btnGroup.style.display = 'flex';
    btnGroup.style.alignItems = 'center';
    btnGroup.style.flexShrink = '0';
    btnGroup.appendChild(buttonsRow);
    title.appendChild(btnGroup);

    if (row.parentNode) {
      row.parentNode.insertBefore(title, row);
    }
  }

  function buildRowIfNeeded() {
    var row = global.document.getElementById(ROW_ID);
    if (!row) {
      return null;
    }
    if (!global.BasicContexts || !global.BasicContexts.length) {
      return row;
    }
    ensureTitle(row);
    ensureRowStyles(row);
    fillRowWithIndicators(row);
    return row;
  }

  function update_basic_contexts_view() {
    buildRowIfNeeded();
    var row = global.document.getElementById(ROW_ID);
    if (!row || !global.BasicContexts) {
      return;
    }
    var actived = Array.isArray(global.BasicContextsActived) ? global.BasicContextsActived : [];
    var indicators = row.querySelectorAll('.basic-context-indicator');
    for (var i = 0; i < indicators.length && i < global.BasicContexts.length; i++) {
      var el = indicators[i];
      var ctxId = global.BasicContexts[i].id;
      var active = actived.indexOf(ctxId) !== -1;
      if (active) {
        el.classList.add('active');
      } else {
        el.classList.remove('active');
      }
    }

    // Border around context row by Bad / Good
    var bnw = global.BadNormWell;
    var activityBlock = global.document.getElementById('beastActivityBlock');
    if (bnw === 1) {
      // Bad — pink border
      row.style.border = '3px solid #ff99c2';
      row.style.borderRadius = '8px';
      row.style.padding = '4px';
      if (activityBlock) {
        activityBlock.style.border = '2px solid #ff99c2';
      }
    } else if (bnw === 3) {
      // Good — light green border
      row.style.border = '3px solid #9fe6b8';
      row.style.borderRadius = '8px';
      row.style.padding = '4px';
      if (activityBlock) {
        activityBlock.style.border = '2px solid #9fe6b8';
      }
    } else {
      // Normal or undefined — no extra border
      row.style.border = 'none';
      row.style.padding = '0';
      if (activityBlock) {
        activityBlock.style.border = '2px solid transparent';
      }
    }
    var stateEl = global.document.getElementById(BADNORMWELL_ID);
    if (stateEl) {
      stateEl.textContent = getBadNormWellLabel();
    }
    var diffEl = global.document.getElementById(DIFF_LABEL_ID);
    if (diffEl) {
      var d = global.DiffZnacher;
      var txt = getDiffLabelText();
      diffEl.textContent = txt;
      if (typeof d === 'number' && d !== 0) {
        diffEl.style.backgroundColor = d < 0 ? '#fffacd' : '#d8f0d8';
      } else {
        diffEl.style.backgroundColor = 'transparent';
      }
    }
    var countdownLabel = global.document.getElementById('holdCountdownLabel');
    if (countdownLabel) {
      var badRem = global.BadHoldRemainingPulses;
      var wellRem = global.WellHoldRemainingPulses;
      if (typeof badRem === 'number' && badRem > 0) {
        countdownLabel.textContent = String(badRem);
        countdownLabel.style.left = '35px'; // above B (after square Sleep)
      } else if (typeof wellRem === 'number' && wellRem > 0) {
        countdownLabel.textContent = String(wellRem);
        countdownLabel.style.left = '61px'; // above W
      } else {
        countdownLabel.textContent = '';
      }
    }

    // Basic context hold period: block highlight and central countdown
    var ctxRem = typeof global.ContextHoldRemainingPulses === 'number' ? global.ContextHoldRemainingPulses : 0;
    var titleEl = global.document.getElementById(TITLE_ID);
    var overlayId = 'basicContextsHoldOverlay';
    var overlay = global.document.getElementById(overlayId);

    if (ctxRem > 0) {
      // Yellow background for block (caption + indicators)
      if (titleEl) {
        titleEl.style.backgroundColor = '#fffacd';
        titleEl.style.padding = '4px 8px';
        titleEl.style.borderRadius = '8px 8px 0 0';
      }
      row.style.backgroundColor = '#fffacd';
      row.style.borderRadius = '0 0 8px 8px';
      row.style.padding = '4px 8px';

      // Central fixed counter aligned with caption row height
      if (!overlay) {
        overlay = global.document.createElement('div');
        overlay.id = overlayId;
        overlay.style.position = 'fixed';
        overlay.style.left = '50%';
        overlay.style.transform = 'translateX(-50%)';
        overlay.style.zIndex = '9999';
        overlay.style.fontSize = '18pt';
        overlay.style.fontWeight = 'bold';
        overlay.style.color = '#c08000';
        overlay.style.textShadow = '0 0 4px #fff';
        global.document.body.appendChild(overlay);
      }
      overlay.textContent = String(ctxRem);
      var rect = titleEl ? titleEl.getBoundingClientRect() : row.getBoundingClientRect();
      // Position counter at caption row level
      overlay.style.top = Math.round(rect.top) + 'px';
    } else {
      // No hold: remove yellow background and overlay
      if (titleEl) {
        titleEl.style.backgroundColor = '';
        titleEl.style.padding = '0 0 4px 0';
        titleEl.style.borderRadius = '';
      }
      row.style.backgroundColor = '';
      row.style.borderRadius = row.style.border ? row.style.borderRadius : '';
      row.style.padding = row.style.border ? row.style.padding : '0';
      if (overlay && overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
    }
  }

  global.update_basic_contexts_view = update_basic_contexts_view;

  function init() {
    if (!global.BasicContexts || !global.BasicContexts.length) {
      return;
    }
    buildRowIfNeeded();
    update_basic_contexts_view();
  }

  function runInit() {
    if (global.document.readyState === 'loading') {
      global.document.addEventListener('DOMContentLoaded', function () {
        setTimeout(init, 0);
      });
    } else {
      setTimeout(init, 0);
    }
  }
  runInit();
})(window);
