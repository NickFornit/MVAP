/**
 * Preparation and activation of basic contexts from vitals.
 *
 * Simplified access:
 * - BadVitalsValue[vitalId] — vital deviation from normal (Kbad).
 * - VitalsContextsActivingArr[vitalId] — array of basic context ids to activate.
 * - BasicContextsActived — array of active basic context IDs (0–3 values); undefined until first call.
 * Globals BadVitalsValue and BasicContextsActived update only after calculations complete,
 * with no intermediate values. VitalsContextsActivingArr is read-only, never modified.
 *
 * After context activation: if none active — Rest (id=14) is activated;
 * IntergalConditionImportance, DiffZnacher are computed; GetBadNormWell() runs.
 * getDiffImportance() — on-demand function returning normalizeValue(current DiffZnacher − stored).
 * Raw diff before normalizeValue is stored in LastDiffImportanceRaw — for semantic “loop” in registerSemanticSample.
 */

(function (global) {
  'use strict';

  /** Pulses to hold Good (3) after leaving Bad or via SetWellForHolding(). */
  var state_retention_period = 15;

  /** Remaining pulses holding Good (3). */
  var hold_well_remaining = 0;

  /** Remaining pulses holding Bad (1). */
  var hold_bad_remaining = 0;

  /** Remaining pulses holding Normal (2). */
  var hold_norm_remaining = 0;

  /** Remaining pulses holding a forced set of basic contexts. */
  var hold_contexts_remaining = 0;

  /** Forcibly held basic contexts (their ids). */
  var forced_basic_contexts = null;

  /** BadNormWell from previous pulse (for detecting transition from Bad). */
  var lastSetBadNormWell = 0;

  /** Snapshot of vital values by Id from previous pulse — relative worsening threshold. */
  var prevVitalValuesSnapshot = null;

  /** Vital value rise in one pulse that triggers new consciousness cycle: (curr−prev)/prev ≥ threshold. */
  var VITAL_RELATIVE_WORSEN_THRESHOLD = 0.3;

  function snapshotVitalValues(VitalsArr) {
    var o = {};
    if (!VitalsArr || !VitalsArr.length) return o;
    for (var i = 0; i < VitalsArr.length; i++) {
      var v = VitalsArr[i];
      if (v && typeof v.Id === 'number') {
        o[v.Id] = typeof v.value === 'number' ? v.value : 0;
      }
    }
    return o;
  }

  /**
   * Value rise beyond VITAL_RELATIVE_WORSEN_THRESHOLD from previous, or transition to Bad.
   * When prev≈0: threshold “at least 30 points” (30% of 0…100 scale) so consciousness fires from zero.
   */
  function detectSharpVitalValueWorsening(VitalsArr, prevSnap) {
    if (!prevSnap || !VitalsArr || !VitalsArr.length) return false;
    for (var i = 0; i < VitalsArr.length; i++) {
      var v = VitalsArr[i];
      var vid = v.Id;
      var prevVal = prevSnap[vid];
      if (typeof prevVal !== 'number') prevVal = 0;
      var currVal = typeof v.value === 'number' ? v.value : 0;
      if (currVal <= prevVal) continue;
      if (prevVal > 0.001) {
        if ((currVal - prevVal) / prevVal >= VITAL_RELATIVE_WORSEN_THRESHOLD) return true;
      } else if (currVal >= 30) {
        return true;
      }
    }
    return false;
  }

  /**
   * Transition to Bad or sharp vital rise (>30% vs previous) — new main consciousness cycle.
   * Pulse 3 is skipped: separate starter FO call in puls.js.
   */
  function tryTriggerConsciousnessOnVitalWorsening(suddenBadTransition, sharpValueWorsening) {
    if (!suddenBadTransition && !sharpValueWorsening) return;
    if (typeof global.cpuls === 'number' && global.cpuls === 3) return;
    if (typeof global.stimuls_consciousness !== 'function') return;

    var branchId = typeof global.PerceptionTree_getActiveTerminalNodeId === 'function'
      ? global.PerceptionTree_getActiveTerminalNodeId()
      : 0;
    var emotionId = 0;
    if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
      emotionId = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
    }
    var igr = typeof global.IntergalConditionImportance === 'number' ? global.IntergalConditionImportance : 0;
    var significance = Math.max(12, igr / 50);

    global.stimuls_consciousness({
      actual_stimul_ID: 0,
      branchId: branchId,
      well: global.BadNormWell || 0,
      emotionId: emotionId,
      activityID: 0,
      significance: significance,
      vitalEmergency: true
    });
  }

  /** Global: remaining pulses holding Good (UI countdown). */
  global.WellHoldRemainingPulses = 0;
  /** Global: remaining pulses holding Bad (UI countdown). */
  global.BadHoldRemainingPulses = 0;
  /** Global: remaining pulses holding Normal (UI). */
  global.NormHoldRemainingPulses = 0;
  /** Global: remaining pulses holding basic contexts (UI). */
  global.ContextHoldRemainingPulses = 0;

  /** Base magnitude of state effect (tunable for optimization). */
  global.WellBadEffectManual = 5;

  function normalizeValue(value, k) {
    if (k === undefined) k = 0.5;
    var max = 10;
    return max * (1 - Math.exp(-k * Math.abs(value))) * (value >= 0 ? 1 : -1);
  }

  /**
   * Computes window.BadNormWell: Bad (1), Normal (2), Good (3).
   * 1. Normal or Bad from sum of BadVitalsValue.
   * 2. If DiffZnacher > 2 — Good holding period starts.
   * 3. At period end: if DiffZnacher > 2 again — new Good period; else Normal or Bad.
   */
  function GetBadNormWell() {
    // Priority: hold Bad if SetBadForHolding() is active
    if (hold_bad_remaining > 0) {
      hold_bad_remaining--;
      global.BadNormWell = 1;
      global.BadHoldRemainingPulses = hold_bad_remaining;
      global.WellHoldRemainingPulses = hold_well_remaining;
      global.NormHoldRemainingPulses = hold_norm_remaining;
      return;
    }
    if (hold_norm_remaining > 0) {
      hold_norm_remaining--;
      global.BadNormWell = 2;
      global.NormHoldRemainingPulses = hold_norm_remaining;
      global.BadHoldRemainingPulses = hold_bad_remaining;
      global.WellHoldRemainingPulses = hold_well_remaining;
      return;
    }
    var VitalsArr = global.VitalsArr || [];
    var sum = 0;
    for (var i = 0; i < VitalsArr.length; i++) {
      sum += global.BadVitalsValue[VitalsArr[i].Id] || 0;
    }
    var base = sum >= 2 ? 1 : 2; // 1 — Bad, 2 — Normal

    var d = typeof global.DiffZnacher === 'number' ? global.DiffZnacher : 0;

    if (hold_well_remaining > 0) {
      hold_well_remaining--;
      global.BadNormWell = 3;
      if (hold_well_remaining === 0 && d > 2) {
        hold_well_remaining = state_retention_period;
      } else if (hold_well_remaining === 0) {
        global.BadNormWell = base;
      }
    } else {
      if (d > 2) {
        hold_well_remaining = state_retention_period;
        global.BadNormWell = 3;
      } else {
        global.BadNormWell = base;
      }
    }
    global.WellHoldRemainingPulses = hold_well_remaining;
    global.BadHoldRemainingPulses = hold_bad_remaining;
    global.NormHoldRemainingPulses = hold_norm_remaining;
  }

  /**
   * Start holding Good (3) for state_retention_period pulses.
   */
  function SetWellForHolding() {
    hold_bad_remaining = 0;
    global.BadHoldRemainingPulses = 0;
    hold_norm_remaining = 0;
    global.NormHoldRemainingPulses = 0;
    hold_well_remaining = state_retention_period;
    global.WellHoldRemainingPulses = hold_well_remaining;
  }

  /**
   * Start holding Bad (1) for state_retention_period pulses.
   */
  function SetBadForHolding() {
    hold_norm_remaining = 0;
    global.NormHoldRemainingPulses = 0;
    hold_well_remaining = 0;
    global.WellHoldRemainingPulses = 0;
    hold_bad_remaining = state_retention_period;
    global.BadHoldRemainingPulses = hold_bad_remaining;
    // Holding Bad counts as orienting “things got worse”:
    // switch consciousness to target mode and flash thinking indicator.
    if (typeof global.Info_setMode === 'function') {
      global.Info_setMode('target');
    }
    if (typeof global.Info_thinkingFlash === 'function') {
      global.Info_thinkingFlash();
    }
  }

  /**
   * Start holding Normal (2) for state_retention_period pulses.
   */
  function SetNormForHolding() {
    hold_bad_remaining = 0;
    global.BadHoldRemainingPulses = 0;
    hold_well_remaining = 0;
    global.WellHoldRemainingPulses = 0;
    hold_norm_remaining = state_retention_period;
    global.NormHoldRemainingPulses = hold_norm_remaining;
  }

  /**
   * Start holding a given set of basic contexts for state_retention_period pulses.
   * During this period vital-driven context selection is blocked.
   * @param {number[]} contextIds - ids from window.BasicContexts.
   */
  function ActivateBasicContextsForHolding(contextIds) {
    if (!Array.isArray(contextIds) || !contextIds.length) {
      return;
    }
    forced_basic_contexts = contextIds.slice(0);
    hold_contexts_remaining = state_retention_period;
    global.ContextHoldRemainingPulses = hold_contexts_remaining;
  }

  /** Global: previous aggregate deviation (IntergalConditionImportance) for getDiffImportance. */
  global.PrevDiffZnacherForGetDiff = null;

  /**
   * Raw diff for semantics: (getWellBadEffect() + prev − curr) / 100 before normalizeValue in last getDiffImportance.
   * Used in semantic_memory.registerSemanticSample (“loop” when meanImportance near zero and vitals normal).
   */
  global.LastDiffImportanceRaw = null;

  /**
   * Diff offset from held baseline state.
   * Magnitude from WellBadEffectManual (default 5):
   *  - Good (BadNormWell=3) → +5,
   *  - Bad (BadNormWell=1) → -5,
   *  - otherwise (Normal etc.) → 0.
   */
  global.WellBadEffect = 0;

  function getWellBadEffect() {
    var base = (typeof global.WellBadEffectManual === 'number' && !isNaN(global.WellBadEffectManual))
      ? Math.abs(global.WellBadEffectManual)
      : 5;
    if (global.BadNormWell === 3) return base;
    if (global.BadNormWell === 1) return -base;
    return 0;
  }

  /**
   * On-demand: compare current IntergalConditionImportance to value stored at previous call.
   * @returns {number} normalizeValue(diff). Rising importance = worse (negative), falling = better (positive).
   */
  function getDiffImportance() {
    var curr = typeof global.IntergalConditionImportance === 'number' ? global.IntergalConditionImportance : 0;
    var prev = global.PrevDiffZnacherForGetDiff !== null && global.PrevDiffZnacherForGetDiff !== undefined
      ? global.PrevDiffZnacherForGetDiff
      : curr;
    global.PrevDiffZnacherForGetDiff = curr;
    var diff = (getWellBadEffect() + prev - curr) / 100;
    global.LastDiffImportanceRaw = diff;
    return normalizeValue(diff);
  }

  /**
   * Compute vital deviation (Kbad by vital Id).
   * Kbad = 0 when value <= 40; when value > 40: Kbad = 2^((value-40)*0.1).
   * @returns {Object} BadVitalsValue — vitalId -> Kbad. Empty if no vitals.
   */
  function calculateBadVitalsValues() {
    var VitalsArr = global.VitalsArr;
    var BadVitalsValue = {};
    if (!VitalsArr || !VitalsArr.length) return BadVitalsValue;
    for (var i = 0; i < VitalsArr.length; i++) {
      var vitalId = VitalsArr[i].Id;
      var value = VitalsArr[i].value;
      var Kbad = value > 40 ? Math.pow(2, 0.1 * (value - 40)) : 0;
      BadVitalsValue[vitalId] = Kbad;
    }
    return BadVitalsValue;
  }

  /**
   * Select active basic context IDs from calculated BadVitalsValue.
   * Vitals sorted by descending importance; at most 3 contexts.
   * Respects holding (forced_basic_contexts). If none — Rest (14).
   * Side effect: when holding is used, decrements hold_contexts_remaining.
   * @param {Object} badVitals — from calculateBadVitalsValues().
   * @returns {number[]} context IDs (BasicContextsActived).
   */
  function selectBasicContexts(badVitals) {
    var VitalsArr = global.VitalsArr;
    var VitalsContextsActivingArr = global.VitalsContextsActivingArr;
    var BasicContextsActived = [];

    if (!VitalsArr || !VitalsArr.length || !global.BasicContexts || !global.BasicContexts.length) {
      if (hold_contexts_remaining > 0 && Array.isArray(forced_basic_contexts) && forced_basic_contexts.length) {
        hold_contexts_remaining--;
        return forced_basic_contexts.slice(0);
      }
      return BasicContextsActived.length ? BasicContextsActived : [14];
    }

    var list = [];
    for (var i = 0; i < VitalsArr.length; i++) {
      list.push({
        vitalId: VitalsArr[i].Id,
        importance: VitalsArr[i].importance
      });
    }
    list.sort(function (a, b) { return b.importance - a.importance; });

    for (var s = 0; s < list.length; s++) {
      var vitalId = list[s].vitalId;
      var Kbad = badVitals[vitalId] || 0;
      if (Kbad > 0 && BasicContextsActived.length < 3 && VitalsContextsActivingArr) {
        var contextIds = VitalsContextsActivingArr[vitalId] || VitalsContextsActivingArr[String(vitalId)] || [];
        for (var c = 0; c < contextIds.length && BasicContextsActived.length < 3; c++) {
          var contextId = contextIds[c];
          if (BasicContextsActived.indexOf(contextId) === -1) BasicContextsActived.push(contextId);
        }
      }
    }

    if (hold_contexts_remaining > 0 && Array.isArray(forced_basic_contexts) && forced_basic_contexts.length) {
      hold_contexts_remaining--;
      BasicContextsActived = forced_basic_contexts.slice(0);
    }
    if (BasicContextsActived.length === 0) BasicContextsActived.push(14);

    return BasicContextsActived;
  }

  /**
   * Update global importance/diff metrics: IntergalConditionImportance, DiffZnacher,
   * and ContextHoldRemainingPulses for UI.
   * @param {Object} badVitals — from calculateBadVitalsValues().
   */
  function updateImportanceMetrics(badVitals) {
    var VitalsArr = global.VitalsArr || [];
    var IntergalConditionImportanceNew = 0;
    for (var v = 0; v < VitalsArr.length; v++) {
      var vid = VitalsArr[v].Id;
      var imp = VitalsArr[v].importance;
      IntergalConditionImportanceNew += (badVitals[vid] || 0) * imp;
    }
    var currentImportance = (typeof global.IntergalConditionImportance === 'number')
      ? global.IntergalConditionImportance
      : 0;

    global.IntergalConditionImportanceOld = currentImportance;
    global.IntergalConditionImportance = IntergalConditionImportanceNew;
    var rawDiff = (getWellBadEffect() + currentImportance - IntergalConditionImportanceNew) / 100;
    global.DiffZnacher = normalizeValue(rawDiff);
    // badState/suddenChange detectors update in getActiveBasicContexts (below).
    global.ContextHoldRemainingPulses = hold_contexts_remaining;
  }

  /**
   * Activate basic contexts from current vital values.
   * Three steps: compute BadVitalsValue, select contexts, update metrics and GetBadNormWell.
   *
   * @param {number} [cpuls] — pulse counter; at cpuls === 2 calls getDiffImportance() to init PrevDiffZnacherForGetDiff.
   * @returns {Object} — BadVitalsValue (Kbad by vital ID).
   */
  function getActiveBasicContexts(cpuls) {
    var VitalsArr = global.VitalsArr;
    if (!VitalsArr || !VitalsArr.length || !global.BasicContexts || !global.BasicContexts.length) {
      return global.BadVitalsValue || {};
    }

    // For «badState» and «suddenChange» detectors: compare previous and current baseline state.
    var prevBadNormWell = (typeof global.BadNormWell === 'number') ? global.BadNormWell : 0;

    var badVitals = calculateBadVitalsValues();
    var contextIds = selectBasicContexts(badVitals);
    // Sleep mode: only basic context «Sleep», no mix with Normal/others (even with critical vitals).
    if (typeof global.SleepMode_isActive === 'function' && global.SleepMode_isActive()) {
      var sleepCtx = (typeof global.SleepMode_CONTEXT_ID === 'number') ? global.SleepMode_CONTEXT_ID : 15;
      contextIds = [sleepCtx];
    }

    global.BadVitalsValue = badVitals;
    global.BasicContextsActived = contextIds;

    updateImportanceMetrics(badVitals);
    GetBadNormWell();

    // Info detectors from basic contexts and vitals:
    // badState/suddenChange, critical vital, game mode, learning / search interest, fear, aggression, defense.
    if (typeof global.InfoDet_updateBadState === 'function') {
      global.InfoDet_updateBadState(prevBadNormWell, global.BadNormWell || 0);
    }
    if (typeof global.InfoDet_updateCriticalVital === 'function') {
      global.InfoDet_updateCriticalVital(global.VitalsArr || []);
    }
    if (typeof global.InfoDet_updatePlayMode === 'function') {
      global.InfoDet_updatePlayMode(global.BasicContextsActived || []);
    }
    if (typeof global.InfoDet_updateLearningAndSearch === 'function') {
      global.InfoDet_updateLearningAndSearch(global.BasicContextsActived || [], global.VitalsArr || []);
    }
    // Fear (context id 6) and aggression (7) — see BasicContexts.js.
    var act = global.BasicContextsActived || [];
    var fearActive = act.indexOf(6) !== -1;
    var aggrActive = act.indexOf(7) !== -1;
    if (typeof global.InfoDet_updateFear === 'function') {
      global.InfoDet_updateFear(fearActive);
    }
    if (typeof global.InfoDet_updateAggression === 'function') {
      global.InfoDet_updateAggression(aggrActive);
    }
    if (typeof global.InfoDet_updateDefense === 'function') {
      global.InfoDet_updateDefense(fearActive || aggrActive);
    }

    var suddenBadTransition = (prevBadNormWell !== 1 && (global.BadNormWell || 0) === 1);
    var sharpValueWorsening = detectSharpVitalValueWorsening(VitalsArr, prevVitalValuesSnapshot);
    tryTriggerConsciousnessOnVitalWorsening(suddenBadTransition, sharpValueWorsening);
    prevVitalValuesSnapshot = snapshotVitalValues(VitalsArr);

    if (cpuls === 2) {
      getDiffImportance();
    }

    return badVitals;
  }

  global.getActiveBasicContexts = getActiveBasicContexts;
  global.GetBadNormWell = GetBadNormWell;
  global.getDiffImportance = getDiffImportance;
  global.normalizeValue = normalizeValue;
  global.SetWellForHolding = SetWellForHolding;
  global.SetBadForHolding = SetBadForHolding;
  global.SetNormForHolding = SetNormForHolding;
  global.ActivateBasicContextsForHolding = ActivateBasicContextsForHolding;
})(window);
