/* Basic contexts
 * Purpose and names of contexts follow the function of restoring parameters.
 */

window.BasicContexts = [
  { id: 1, importance: 90, name: "Ventilation", title: "Need for ventilation, restoring breathing" },
  { id: 2, importance: 80, name: "Drinking", title: "Need to quench thirst" },
  { id: 3, importance: 60, name: "Cooling", title: "Need to cool down, drive toward cold, seeking shade" },
  { id: 4, importance: 70, name: "Warming", title: "Need to warm up, drive toward heat" },
  { id: 5, importance: 70, name: "Feeding", title: "Need to satisfy hunger" },
  { id: 6, importance: 40, name: "Fear", title: "Fright, freezing, protective freezing" },
  { id: 7, importance: 30, name: "Aggression", title: "Aggressive behavior, rage, ruthlessness" },
  { id: 8, importance: 30, name: "Rut", title: "Reproductive behavior" },
  { id: 9, importance: 50, name: "Avoidance", title: "Caution, wariness, cunning" },
  { id: 10, importance: 100, name: "Healing", title: "Immobilization, self-care, need for healing" },
  { id: 11, importance: 30, name: "Play", title: "Play behavior, joyful mood" },
  { id: 12, importance: 30, name: "Curiosity", title: "Dissatisfaction with the status quo, research, search, experimenting" },
  { id: 13, importance: 30, name: "Sociability", title: "Sociality, kindness, empathy, altruism" },
  { id: 14, importance: 10, name: "Rest", title: "Minimally active exploratory / maintenance mode" },
  { id: 15, importance: 20, name: "Sleep", title: "Falling asleep, basic sleep and dream context" }
];

// Mapping: vital out-of-range ID → activation of basic context IDs
// Access: VitalsContextsActivingArr[2] → [1,9]
window.VitalsContextsActivingArr = {
  1: [10, 6, 9],
  2: [1,9],
  3: [2],
  4: [3,9],
  5: [4,9],
  6: [5,7],
  7: [7],
  8: [8],
  9: [13,11],
  10: [12, 11]
};

// Array of activated basic context IDs (0–3 values). Global. Updated each pulse in prepare.js.
window.BasicContextsActived = undefined;

// Global values updated in prepare.js each pulse (previous integral importance kept globally)
window.IntergalConditionImportanceOld = undefined;
window.IntergalConditionImportance = undefined;
window.DiffZnacher = undefined;
// Baseline organism state: Bad (1), Normal (2), Good (3). Initially 0.
window.BadNormWell = 0;

