# Genetic basic styles (_2_Genetic_basic_styles)

## Purpose

The module defines **basic contexts** (emotional-behavioral modes) and their link to vitals. Contexts shape the “situation image” and participate in reaction choice, conditional reflexes, perception tree, and semantic memory.

## Main data

- **BasicContexts** — basic context array (Ventilation, Drinking, Cooling, Warming, Feeding, Fear, Aggression, Rut, Avoidance, Treatment, Play, Curiosity, Sociability, Calm, Sleep). Each: `id`, `importance`, `name`, `title`.

- **VitalsContextsActivingArr** — map “vital out of norm” → contexts to activate (e.g. thirst activates Drinking).

- **BasicContextsActived** — IDs of currently active basic contexts (from vitals and external effects).

- **BadNormWell** — current baseline: 1 = Bad, 2 = Norm, 3 = Well. Used in homeostasis (including `prepare.js` with `WellBadEffect`), perception tree, and semantics.

## Files

- **BasicContexts.js** — context arrays and vital–context links.
- **prepare.js** — vital recompute, baseline (BadNormWell), integral importance; `WellBadEffect` in normalization.
- **basic_contexts_ui.js** — display and toggling of active contexts in the UI.

Contexts feed emotion (EmotionId), conditional reflexes, and the perception-tree branch.
