/**
 * Conditioned reflexes (stimulus synonyms) for Beast.
 *
 * Based on OLD_CODE/InsectAgent/sys/condition_reflex.js:
 * - a combination of (conditioned) stimuli pairs several times with an unconditioned stimulus
 *   that triggers an innate (genetic) reflex;
 * - in a specific combination of basic contexts (context = situation image);
 * - after several confirmations (tryCount > 3) the same stimulus combination
 *   in the same context triggers the same action.
 *
 * Extensions vs prototype:
 * - if several stimuli (any kind) are active at once, a composite final image is built (FinalImageId in FinalImage.js);
 * - that FinalImageId is the conditioned reflex “key”;
 * - the CR creates a response synonym not only for neutral but for any stimulus kinds;
 * - when forming/firing the CR, the corresponding composite stimulus (FinalImageId) must be active “here and now”,
 *   otherwise the CR neither forms nor fires.
 *
 * Action is an Id from window.BasicActions, run via runGeneticActionFromSynonymReflex() for shared Beast mechanics.
 */
(function (global) {
  'use strict';

  /**
   * Conditioned (synonym) reflex structure:
   * {
   *   id: number,
   *   context: string,      // "0,3,9" — basic context combination
   *   finalImageId: number, // Final image Id (FinalImageId)
   *   actionId: number,     // BasicActions Id
   *   birthTime: number,    // Cur_puls_val at creation
   *   lastActivation: number, // last fire (Cur_puls_val)
   *   tryCount: number      // confirmed pairings (maturity > 3)
   * }
   */

  if (!Array.isArray(global.SynonymReflexes)) {
    global.SynonymReflexes = [];
  }
  if (typeof global.NextSynonymReflexId !== 'number') {
    global.NextSynonymReflexId = 0;
  }

  var REFLEX_READY_THRESHOLD = 3; // CR maturity threshold (tryCount > threshold)
  var DEBUG_SYNONYM_REFLEX = false; // test alert off by default
  var PrevActiveStimulIdsKey = null; // active stimulus key to suppress repeat fire on same set

  /** Compare two arrays as sets (same elements, order ignored). */
  function setsEqual(a, b) {
    if (!Array.isArray(a) || !Array.isArray(b)) return false;
    var sa = a.slice(0).sort(function (x, y) { return x - y; });
    var sb = b.slice(0).sort(function (x, y) { return x - y; });
    if (sa.length !== sb.length) return false;
    for (var i = 0; i < sa.length; i++) {
      if (sa[i] !== sb[i]) return false;
    }
    return true;
  }

  /** Stable string key for stimulus id set (anti-spam). */
  function activeIdsKey(ids) {
    if (!Array.isArray(ids) || !ids.length) return '';
    var a = ids.slice(0).sort(function (x, y) { return x - y; });
    return a.join(',');
  }

  function getCurrentPulse() {
    var v = global.Cur_puls_val;
    if (typeof v === 'number' && !isNaN(v)) return v;
    return 0;
  }

  /**
   * Build string key of current context for conditioned reflexes.
   *
   * CONTEXT = combination of:
   * - baseline BadNormWell (1 — Bad, 2 — Normal, 3 — Good);
   * - active basic context ids (from BasicContextsActived).
   *
   * Key format: "BadNormWell:id1,id2,..." e.g. "1:10,13" or "3:9".
   * Stable across sessions (does not depend on internal EmotionId).
   * If BadNormWell not set yet — returns 'none'.
   */
  function getCurrentContextKey() {
    var well = global.BadNormWell || 0;
    if (!well) return 'none';

    var ctxIds = [];
    if (Array.isArray(global.BasicContextsActived)) {
      for (var i = 0; i < global.BasicContextsActived.length; i++) {
        var cid = global.BasicContextsActived[i];
        if (typeof cid === 'number') {
          ctxIds.push(cid);
        }
      }
    }
    ctxIds.sort(function (a, b) { return a - b; });
    var ctxPart = ctxIds.length ? ctxIds.join(',') : '0';

    return String(well) + ':' + ctxPart;
  }

  function findSynonymReflexIndex(contextKey, finalImageId, actionId) {
    for (var i = 0; i < global.SynonymReflexes.length; i++) {
      var cr = global.SynonymReflexes[i];
      if (!cr) continue;
      if (cr.context === contextKey &&
          cr.finalImageId === finalImageId &&
          cr.actionId === actionId) {
        return i;
      }
    }
    return -1;
  }

  function getActionName(actionId) {
    var name = '';
    if (Array.isArray(global.BasicActions)) {
      for (var i = 0; i < global.BasicActions.length; i++) {
        var a = global.BasicActions[i];
        if (a && a.Id === actionId) {
          name = a.name || '';
          break;
        }
      }
    }
    return name;
  }

  function showTransientAlert(message) {
    if (typeof global.show_alert !== 'function') return;
    try {
      global.show_alert(message);
      if (typeof global.close_alert === 'function') {
        global.setTimeout(function () {
          try {
            global.close_alert();
          } catch (e) {}
        }, 1500);
      }
    } catch (e2) {}
  }

  function debugAlert(message) {
    if (!DEBUG_SYNONYM_REFLEX) return;
  }

  // ---------- Save conditioned reflexes to IndexedDB ----------

  var urDb = null;
  var UR_DB_NAME = 'BEAST_UR_DB';
  var UR_DB_VERSION = 1;
  var UR_STORE = 'conditional_reflexes_state';
  var UR_KEY = 'ur_singleton';
  var urDirty = false;
  var lastURSavedSig = '';

  function openURDb() {
    if (!global.indexedDB || !global.IndexedDBModule) {
      return Promise.reject(new Error('IndexedDB is not supported or module not loaded.'));
    }
    if (urDb) {
      return Promise.resolve(urDb);
    }
    return global.IndexedDBModule.openDatabase({
      dbName: UR_DB_NAME,
      version: UR_DB_VERSION,
      stores: [
        { name: UR_STORE, options: { keyPath: 'id' } }
      ]
    }).then(function (db) {
      urDb = db;
      return db;
    });
  }

  function serializeConditionalReflexesState() {
    var list = [];
    if (Array.isArray(global.SynonymReflexes)) {
      for (var i = 0; i < global.SynonymReflexes.length; i++) {
        var r = global.SynonymReflexes[i];
        if (!r) continue;
        list.push({
          id: r.id,
          context: r.context,
          finalImageId: r.finalImageId,
          stimulIds: Array.isArray(r.stimulIds) ? r.stimulIds.slice(0) : [],
          actionId: r.actionId,
          birthTime: r.birthTime,
          lastActivation: r.lastActivation,
          tryCount: r.tryCount,
          isReady: !!r.isReady
        });
      }
    }
    return {
      reflexes: list,
      nextId: (typeof global.NextSynonymReflexId === 'number' ? global.NextSynonymReflexId : 0)
    };
  }

  function applyConditionalReflexesState(state) {
    if (!state) return;
    var list = Array.isArray(state.reflexes) ? state.reflexes : [];
    global.SynonymReflexes = [];
    for (var i = 0; i < list.length; i++) {
      var r = list[i];
      if (!r) continue;
      var tryCount = typeof r.tryCount === 'number' ? r.tryCount : 0;
      // After load, mature reflexes are treated ready to fire
      // so no extra “training step” is needed after page refresh.
      var isReady = tryCount > REFLEX_READY_THRESHOLD ? true : !!r.isReady;
      global.SynonymReflexes.push({
        id: r.id,
        context: r.context,
        finalImageId: r.finalImageId,
        stimulIds: Array.isArray(r.stimulIds) ? r.stimulIds.slice(0) : [],
        actionId: r.actionId,
        birthTime: r.birthTime,
        lastActivation: r.lastActivation,
        tryCount: tryCount,
        isReady: isReady
      });
    }
    if (typeof state.nextId === 'number' && state.nextId >= 0) {
      global.NextSynonymReflexId = state.nextId;
    } else {
      var maxId = 0;
      for (var j = 0; j < global.SynonymReflexes.length; j++) {
        if (global.SynonymReflexes[j].id > maxId) {
          maxId = global.SynonymReflexes[j].id;
        }
      }
      global.NextSynonymReflexId = maxId;
    }
  }

  function saveURStateToIndexedDB(state) {
    if (!global.IndexedDBModule) return;
    state = state || serializeConditionalReflexesState();
    function doPut(db) {
      return global.IndexedDBModule.put({
        db: db,
        storeName: UR_STORE,
        value: {
          id: UR_KEY,
          state: state,
          ts: Date.now()
        }
      }).catch(function () {});
    }
    if (urDb) {
      doPut(urDb);
      return;
    }
    openURDb().then(doPut).catch(function () {});
  }

  function scheduleURStateSave() {
    urDirty = true;
  }

  function loadURStateFromIndexedDB() {
    if (!global.IndexedDBModule) return;
    openURDb()
      .then(function (db) {
        return global.IndexedDBModule.get({
          db: db,
          storeName: UR_STORE,
          key: UR_KEY
        });
      })
      .then(function (record) {
        if (record && record.state) {
          applyConditionalReflexesState(record.state);
          lastURSavedSig = JSON.stringify(serializeConditionalReflexesState());
        }
      })
      .catch(function () {});
  }

  /**
   * Clear all conditioned reflexes in memory and remove from IndexedDB.
   * Called from the “Uh” button in the UI.
   */
  function clearAllConditionalReflexes() {
    global.SynonymReflexes = [];
    global.NextSynonymReflexId = 0;
    PrevActiveStimulIdsKey = null;
    var emptyState = { reflexes: [], nextId: 0 };
    lastURSavedSig = JSON.stringify(emptyState);
    if (global.IndexedDBModule) {
      function doPut(db) {
        global.IndexedDBModule.put({
          db: db,
          storeName: UR_STORE,
          value: {
            id: UR_KEY,
            state: emptyState,
            ts: Date.now()
          }
        }).catch(function () {});
      }
      if (urDb) {
        doPut(urDb);
      } else {
        openURDb().then(doPut).catch(function () {});
      }
    }
  }

  // Stub for neutral-stimulus UI compatibility.
  // Current CR logic uses composite FinalImageId,
  // so separate “previous neutral” memory is not needed.
  function onNeutralStimulusActivated(stimId) {
    void stimId;
  }

  /**
   * Try to form/strengthen a conditioned reflex.
   * Called from genetic_reflexes_engine when a genetic reflex fired
   * (from StimulMotivarion / StimulPositiv / StimulNegative).
   *
   * stimId     — unconditioned stimulus Id
   * sourceType — 'motivation' | 'positive' | 'negative'
   * actionId   — BasicActions Id that actually ran.
   */
  function onGeneticActionFired(stimId, sourceType, actionId) {
    if (typeof actionId !== 'number' || actionId < 0) return;
    if (typeof global.FinalImages_getOrCreateFinalImageId !== 'function') {
      return;
    }

    // Global stimulus ids (type*1000+localId) avoid array collisions (see stimulus_global_id.js).
    var activeIds = typeof global.StimulusGlobalId_getActiveGlobalIds === 'function'
      ? global.StimulusGlobalId_getActiveGlobalIds()
      : [];

    // No active stimuli — no CR formation.
    if (!activeIds.length) {
      return;
    }

    // Global id of stimulus that triggered reaction (excluded from CR composite).
    var triggerGlobalId = 0;
    if (typeof global.StimulusGlobalId_toGlobal === 'function' && typeof global.StimulusGlobalId_getTypeFromSourceType === 'function') {
      var type = global.StimulusGlobalId_getTypeFromSourceType(sourceType);
      triggerGlobalId = global.StimulusGlobalId_toGlobal(type, stimId);
    }

    // Do not form CR from the single stimulus that already triggered the reaction.
    if (activeIds.length === 1 && activeIds[0] === triggerGlobalId) {
      return;
    }

    // CR composite: all active stimuli EXCEPT trigger (global ids).
    var conditionalIds = [];
    for (var ci = 0; ci < activeIds.length; ci++) {
      if (activeIds[ci] !== triggerGlobalId) {
        conditionalIds.push(activeIds[ci]);
      }
    }
    if (!conditionalIds.length) {
      return;
    }

    var contextNow = getCurrentContextKey();
    if (!contextNow || contextNow === 'none') {
      return;
    }

    // Composite of preceding stimuli (FinalImageId) — CR key.
    var finalImageId = global.FinalImages_getOrCreateFinalImageId(conditionalIds);
    if (!finalImageId && finalImageId !== 0) {
      return;
    }

    var now = getCurrentPulse();

    var idx = findSynonymReflexIndex(contextNow, finalImageId, actionId);
    if (idx === -1) {
      // Create CR prototype
      global.NextSynonymReflexId += 1;
      var newReflex = {
        id: global.NextSynonymReflexId,
        context: contextNow,
        finalImageId: finalImageId,
        stimulIds: conditionalIds.slice(0), // preceding stimuli
        actionId: actionId,
        birthTime: now,
        lastActivation: now,
        tryCount: 1,
        isReady: false
      };
      global.SynonymReflexes.push(newReflex);

      // 1st stimulus–response pairing
      var aName1 = getActionName(actionId) || ('action ' + actionId);
      showTransientAlert('Recorded 1st stimulus–response pairing (“' + aName1 + '”).');

      if (typeof global.setBeastActivityText === 'function') {
        try {
          global.setBeastActivityText('Created conditioned reflex prototype (FinalImageId ' +
            finalImageId + ' → action ' + actionId + ')');
        } catch (e) {}
      }
      scheduleURStateSave();
    } else {
      // Strengthen existing prototype
      var cr = global.SynonymReflexes[idx];
      var oldCount = cr.tryCount;

      // Past maturity threshold: no more alerts or tryCount growth, only lastActivation.
      if (oldCount > REFLEX_READY_THRESHOLD) {
        cr.lastActivation = now;
      } else {
        cr.tryCount += 1;
        cr.lastActivation = now;

        // Nth pairing message (while reflex still strengthening)
        var aName2 = getActionName(actionId) || ('action ' + actionId);
        showTransientAlert('Recorded ' + cr.tryCount + 'th stimulus–response pairing (“' + aName2 + '”).');

        // Cross maturity threshold: new conditioned reflex formed.
        // Becomes “ready” only after participating stimuli fully extinguish.
        if (oldCount <= REFLEX_READY_THRESHOLD && cr.tryCount > REFLEX_READY_THRESHOLD) {
          showTransientAlert('New conditioned reflex formed with response “' + aName2 + '”.');
          cr.isReady = false; // true after full stimulus extinction
        }
      }

      if (typeof global.setBeastActivityText === 'function') {
        try {
          global.setBeastActivityText('Strengthened (' + cr.tryCount +
            ') conditioned reflex prototype (FinalImageId ' +
            finalImageId + ' → action ' + actionId + ')');
        } catch (e2) {}
      }
      scheduleURStateSave();
    }
  }

  /**
   * Try to fire formed conditioned reflexes.
   * Called from processGeneticReflexes() BEFORE genetic maps.
   *
   * Returns true if a CR fired.
   */
  function tryRunSynonymReflexes() {
    if (typeof global.FinalImages_getOrCreateFinalImageId !== 'function') {
      return false;
    }

    // Context matters: CR should fire only in the same (BadNormWell, EmotionId) it learned in.
    var contextNow = getCurrentContextKey();
    if (!contextNow || contextNow === 'none') {
      return false;
    }

    // Active composite — global ids (type*1000+localId), see stimulus_global_id.js.
    var activeIds = typeof global.StimulusGlobalId_getActiveGlobalIds === 'function'
      ? global.StimulusGlobalId_getActiveGlobalIds()
      : [];

    if (!activeIds.length) {
      // All stimuli off — reset key so CR can fire on next activation
      PrevActiveStimulIdsKey = null;
      // Update readiness: if composite not active, reflexes may become ready (extinction complete).
      var iReset;
      for (iReset = 0; iReset < global.SynonymReflexes.length; iReset++) {
        var r = global.SynonymReflexes[iReset];
        if (!r) continue;
        if (r.tryCount > REFLEX_READY_THRESHOLD) {
          r.isReady = true;
        }
      }
      // Persist updated readiness to IndexedDB
      scheduleURStateSave();
      return false;
    }

    // Match by stimulus set, not FinalImageId — after reload
    // same set may get another id if FinalImages loaded differently.
    var currentKey = activeIdsKey(activeIds);
    if (!currentKey) return false;

    if (PrevActiveStimulIdsKey !== null && PrevActiveStimulIdsKey === currentKey) {
      return false;
    }

    var now = getCurrentPulse();

    // Find mature ready reflex matching active set to reflex stimulIds.
    // First strict current context; if none, allow “close” context: same stimuli, different contextKey.
    var candidateAnyCtx = null;
    for (var j = 0; j < global.SynonymReflexes.length; j++) {
      var cr = global.SynonymReflexes[j];
      if (!cr) continue;
      if (!setsEqual(activeIds, cr.stimulIds)) continue;
      if (cr.context !== contextNow) continue;
      if (cr.tryCount <= REFLEX_READY_THRESHOLD) continue;
      if (!cr.isReady) continue;
      candidateAnyCtx = cr;
      break;
    }

    // If no strict context match — any mature UR with same stimuli, ignoring context,
    // so reflex can fire after reload if context string shifted (e.g. basic context order).
    if (!candidateAnyCtx) {
      for (var k = 0; k < global.SynonymReflexes.length; k++) {
        var cr2 = global.SynonymReflexes[k];
        if (!cr2) continue;
        if (!setsEqual(activeIds, cr2.stimulIds)) continue;
        if (cr2.tryCount <= REFLEX_READY_THRESHOLD) continue;
        if (!cr2.isReady) continue;
        candidateAnyCtx = cr2;
        break;
      }
    }

    var chosen = candidateAnyCtx;
    if (chosen) {
      var finalImageId = global.FinalImages_getOrCreateFinalImageId
        ? global.FinalImages_getOrCreateFinalImageId(activeIds) : 0;
      debugAlert('RUN: CR fired, actionId=' + chosen.actionId +
        ' FI=' + finalImageId);
      if (typeof global.runGeneticActionFromSynonymReflex === 'function') {
        global.runGeneticActionFromSynonymReflex(chosen.actionId, 'synonym', finalImageId);
      }
      chosen.lastActivation = now;
      chosen.tryCount += 1;
      PrevActiveStimulIdsKey = currentKey;
      // persist CR changes (counter, lastActivation) to IndexedDB
      scheduleURStateSave();
      return true;
    }

    return false;
  }

  // API export for UI and genetic reflexes
  global.synonyms_onNeutralStimulusActivated = onNeutralStimulusActivated;
  global.synonyms_onGeneticActionFired = onGeneticActionFired;
  global.synonyms_tryRunReflexes = tryRunSynonymReflexes;

  // Helper for debugging
  global.get_cur_context_for_synonyms = getCurrentContextKey;
  global.serializeConditionalReflexesState = serializeConditionalReflexesState;
  global.applyConditionalReflexesState = applyConditionalReflexesState;
  global.clearAllConditionalReflexes = clearAllConditionalReflexes;

  // Load saved conditioned reflexes on module init
  loadURStateFromIndexedDB();

  // “Uh” button — clear all conditioned reflexes
  (function bindResetButton() {
    try {
      var btn = global.document && global.document.getElementById('btnResetConditionalReflexes');
      if (btn && typeof btn.addEventListener === 'function') {
        btn.addEventListener('click', function () {
          if (!global.confirm('Delete all conditioned reflexes?')) return;
          clearAllConditionalReflexes();
        });
      }
    } catch (e) {}
  })();

  if (typeof global.registerIndexedDBSaver === 'function') {
    global.registerIndexedDBSaver(function () {
      if (!urDirty) return;
      urDirty = false;
      var state = serializeConditionalReflexesState();
      var sig = JSON.stringify(state);
      if (sig === lastURSavedSig) return;
      lastURSavedSig = sig;
      saveURStateToIndexedDB(state);
    });
  }

})(window);

