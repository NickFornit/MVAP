# Conditional reflexes — stimulus synonyms (_5_2_synonyms_reflexes)

## Purpose

The module implements **conditional (synonym) reflexes**: after several pairings of “combined stimulus image + unconditional reaction” in one context, the same image in the same context triggers the same action without the unconditional stimulus. The key is FinalImageId (combined active stimuli), not a single button.

## Formation conditions

- A conditional reflex **does not form** on the stimulus that directly triggered the unconditional reaction (prevents self-reference).
- Combined image for the key uses the **set of active stimuli** except what directly fired the reflex.
- **Context** matters: string from baseline (BadNormWell) and active basic contexts (EmotionId). Reflex fires only in matching context.
- After **REFLEX_READY_THRESHOLD** (3) confirmed pairings, reflex is mature (isReady) and can fire on conditional stimulus alone.

## Reflex structure

- `id`, `context` (string), `finalImageId`, `actionId`, `birthTime`, `lastActivation`, `tryCount`, `isReady`. Persisted in IndexedDB and file on Save.

## Files

- **synonyms_reflexes.js** — SynonymReflexes array, formation/strengthening (onGeneticActionFired), tryRunSynonymReflexes, OR block check via genetic_reflexes_engine, save/load, **Uh** clears all conditional reflexes.

Action from conditional reflex runs through **runGeneticActionFromSynonymReflex** in genetic_reflexes_engine; if OR blocks, enqueue with noConditionalReflex to avoid re-learning on the same stimulus.
