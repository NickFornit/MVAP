/**
 * Second level of consciousness (conscience_level_2).
 * At the second level, processing determines the goal — targeted or passive continuation.
 *
 * Called from stimuls_consciousness when the first level could not pick
 * an acceptable automatic action (neither by EP nor by default automatism)
 * and an unresolved problem is set: unsolved_problem = current stimulus.
 * This is the transition to the second level in target mode (problem with automatism).
 *
 * Target mode, second-level iteration:
 *   — First the operator response is handled (isOperatorAnswerReceived), if any.
 *   — Then goal and actions: the "survival" branch (criticalVital / shockState / suddenChange /
 *     isShockState) — Goals_findBestLifeGoalPositiveUsefulness, EpisodicMemory_findChainForGoalStack
 *     chain when usedRule, else ExactRule / InaccurateRule lookup from EP and start automatism or defer L3;
 *     without survival — Goals_determineGoalInSituation (including default "meaning" goal when stimulus
 *     significance >3 and no goal on that branch), then when currentGoalType === 'meaning' — forecast from EP frames,
 *     Gestalt_bumpFromMeaningForecast, AbstractImages_boostSemanticRulesForAction; isPlayMode / isLearningMode flags for L3.
 *   — During episodic search, new goal images accumulate via Goals_* and EP.
 *
 * Operator response to reaction after automatism ("waiting for EP-frame feedback" branch):
 *   • In the info picture, isOperatorAnswerReceived (and related detectors) is set when the frame is closed
 *     by a response stimulus — see EpisodicMemory (closeLastFrame / orienting reflex while waiting).
 *   • The comprehension-cycle object for the same session gets automatismOperatorAnswerReceived and
 *     awaitingAutomatismEpisodeFeedback; while the cycle "waits", the dispatcher runs runOneStep on pulses.
 *   • The first executable conscience_level_2 block (not after goal assignment) handles this response:
 *     by the closed frame's effect — baseline usefulness adjustment for the cycle goal (cycle.goalImageId),
 *     then refinement via detectors; end of waiting cycle (expired).
 *   • The call from runOneStep passes _operatorAnswerCycleOnly: then after the response block we exit
 *     without mixing ImportantProblem / goals in the same tick.
 *
 * @param {Object} context
 *   at minimum expects:
 *   - actualId  — FinalImageId of current stimulus;
 *   - branchId  — current terminal node of perception tree;
 *   - well      — base state (1/2/3);
 *   - emotionId — current emotion;
 *   - activityID — FinalImageId for conditions (as in the tree);
 *   - sourceCycle — comprehension-cycle object (for automatism-response branch);
 *   - _operatorAnswerCycleOnly — if true: only operator-response block and exit (call from runOneStep).
 *   plus any fields from the original OR context.
 */
(function (global) {
  'use strict';

  var puls = function () { return typeof global.cpuls === 'number' ? global.cpuls : 0; };

  /** FO cycle log: main cycle or force (e.g. before expired). */
  function appendCycleLog(cycle, text, force) {
    if (!cycle || typeof global.Consciousness_cycleAppendLog !== 'function') return;
    if (!force && !cycle.isMainCycle) return;
    global.Consciousness_cycleAppendLog(cycle, text, puls(), force ? { force: true } : undefined);
  }

  /**
   * One-shot handling of operator response to automatism (level 2, "semantic" reaction to feedback).
   *
   * Meaning: for the closed EP frame, effect is known; situation detectors are set in the info picture.
   * First, when effect is numeric: AbstractImages_applyEpisodeEffectToSemanticContextAbstractions — averaging meanImportance
   * of perception/action clones when semanticStructure matches the frame (effect>0 strengthens, effect<0 weakens).
   * When effect > 0 additionally: MentalAutomatizms_tryCreateFromSemanticStructureRule — mental automatism;
   * both steps even when goalImageId === 0 (L3).
   * Then the cycle goal image (cycle.goalImageId) receives the waiting outcome: Goals_applyWaitingPeriodEffectToGoalUsefulness
   * (when goal count === 1 usefulness = effect, else averaging). Then — adjustments via Goals_mergeUsefulnessSampleForGoalId.
   *
   * Guard against re-entry: operatorAnswerPipelineConsumed — otherwise usefulness could double on multiple pulses
   * or double calls.
   *
   * Detectors (situation components, situatioms_tree.js):
   *   negativeMotorEffect (6), positiveActionEffect (26), lowAutomatismUsefulness (32).
   */
  function conscience_level_2_operatorAnswerPipeline(cycle) {
    if (!cycle) return;
    if (cycle.operatorAnswerPipelineConsumed) return;
    cycle.operatorAnswerPipelineConsumed = true;
    var goalId = typeof cycle.goalImageId === 'number' ? cycle.goalImageId : 0;
    var info = (typeof global.Info_initIfNeeded === 'function')
      ? global.Info_initIfNeeded()
      : global.InfoPicture;
    if (!info) return;

    var episodeEffect = cycle.lastAutomatismEpisodeEffect;
    if ((episodeEffect === null || episodeEffect === undefined) &&
        typeof global.EpisodicMemory_lastClosedFrameEffect === 'number') {
      episodeEffect = global.EpisodicMemory_lastClosedFrameEffect;
    }

    var effIsNum = (typeof episodeEffect === 'number' && !isNaN(episodeEffect));
    if (effIsNum) {
      var tcx = cycle.context || {};
      var mb = parseInt(tcx.branchId, 10) || 0;
      var mst = parseInt(tcx.actual_stimul_ID, 10) || 0;
      if (!mst && info.stimulus && info.stimulus.finalImageId) {
        mst = info.stimulus.finalImageId;
      }
      var msit = typeof info.situationId === 'number' ? info.situationId : 0;
      if (mb && mst) {
        if (typeof global.AbstractImages_applyEpisodeEffectToSemanticContextAbstractions === 'function') {
          global.AbstractImages_applyEpisodeEffectToSemanticContextAbstractions({
            perceptionNodeId: mb,
            situationId: msit,
            actualStimulusImageId: mst,
            effect: episodeEffect
          });
        }
        if (episodeEffect > 0 && typeof global.MentalAutomatizms_tryCreateFromSemanticStructureRule === 'function') {
          if (global.MentalAutomatizms_tryCreateFromSemanticStructureRule({
            perceptionNodeId: mb,
            situationId: msit,
            actualStimulusImageId: mst,
            episodeEffect: episodeEffect
          })) {
            appendCycleLog(cycle, 'L2: effect>0 — mental automatism from semanticStructure rule (perception clone).', true);
          }
        }
      }
    }

    if (!goalId) {
      if (typeof global.Info_updateView === 'function') global.Info_updateView();
      return;
    }
    if (effIsNum && typeof global.Goals_applyWaitingPeriodEffectToGoalUsefulness === 'function') {
      global.Goals_applyWaitingPeriodEffectToGoalUsefulness(goalId, episodeEffect);
    }

    if (typeof global.Goals_mergeUsefulnessSampleForGoalId !== 'function') {
      if (typeof global.Info_updateView === 'function') global.Info_updateView();
      return;
    }

    // negativeMotorEffect — component 6: reduce goal usefulness.
    if (info.negativeMotorEffect) {
      global.Goals_mergeUsefulnessSampleForGoalId(goalId, -2);
    }
    // positiveActionEffect — component 26: boost by detector magnitude (capped).
    if (info.positiveActionEffect) {
      var pe = typeof info.positiveActionEffect === 'number' ? info.positiveActionEffect : 0;
      if (pe > 0) {
        global.Goals_mergeUsefulnessSampleForGoalId(goalId, Math.min(pe, 3));
      }
    }
    var effZero = !effIsNum || episodeEffect === 0;
    // lowAutomatismUsefulness — component 32: when frame effect is zero.
    if (effZero && info.lowAutomatismUsefulness) {
      global.Goals_mergeUsefulnessSampleForGoalId(goalId, -1);
    }

    if (typeof global.Info_updateView === 'function') global.Info_updateView();
  }

  /** End waiting phase (clear flags, expired). When the phase starts — see conscious_attention_channel.js, runElementary, automatismStarted branch. */
  function conscience_level_2_finalizeAutomatismAnswerCycle(cycle) {
    if (!cycle || cycle.automatismAnswerLevel2Done) return;
    if (!cycle.awaitingAutomatismEpisodeFeedback || !cycle.automatismOperatorAnswerReceived) return;
    cycle.automatismAnswerLevel2Done = true;
    cycle.awaitingAutomatismEpisodeFeedback = false;
    cycle.expired = true;
    cycle.isMainCycle = false;
    if (typeof global.Info_setField === 'function') {
      global.Info_setField('isOperatorAnswerReceived', 0);
    } else if (global.InfoPicture) {
      global.InfoPicture.isOperatorAnswerReceived = 0;
    }
    appendCycleLog(cycle, 'L2: automatism response processed, waiting period ended — cycle expired.', true);
    if (typeof global.Info_updateView === 'function') global.Info_updateView();
  }

  /** Survival: shock / sharp deterioration / critical vital (global isShockState included). */
  function conscience_level_2_isSurvivalContext(info) {
    if (!info) return !!global.isShockState;
    return !!(
      global.isShockState ||
      info.shockState ||
      (info.suddenChange && info.suddenChange !== 0) ||
      (info.criticalVital && info.criticalVital !== 0)
    );
  }

  /**
   * Vital criticality "before Stress" by VitalsArr order (Ids 1…6 matter more than 7-Stress):
   * either active criticalVital < 7, or BadVitalsValue > 70 for any Id 1…6.
   */
  /**
   * Goal image id from EP frame for survival: addOrUpdate when effect &gt; 0; if id=0 but goal key is complete —
   * retry with minimal positive effect (rule still recorded as cycle goal image).
   */
  function conscience_level_2_survivalLifeGoalIdFromFrame(frame) {
    if (!frame || typeof global.Goals_addOrUpdateLifeGoalFromFrame !== 'function') return 0;
    var gid = global.Goals_addOrUpdateLifeGoalFromFrame(frame);
    if (gid) return gid;
    var pn = frame.perceptionNodeId != null ? frame.perceptionNodeId : 0;
    var ai = frame.actionImageId != null ? frame.actionImageId : 0;
    if (!pn || !ai) return 0;
    var eff = typeof frame.effect === 'number' ? frame.effect : 0;
    if (eff > 0) return 0;
    var f2 = {
      perceptionNodeId: pn,
      stimulusImageId: frame.stimulusImageId != null ? frame.stimulusImageId : 0,
      actionImageId: ai,
      situationId: frame.situationId != null ? frame.situationId : 0,
      effect: 1,
      usefulness: frame.usefulness
    };
    return global.Goals_addOrUpdateLifeGoalFromFrame(f2) || 0;
  }

  /**
   * Goal "what does this mean to me?": forecast consequences from EP frames, gestalt bump and abstractions with rule by action image.
   */
  function conscience_level_2_tryMeaningGoalForecast(context, info, cycle) {
    var meaningId = typeof global.Goals_getDefaultMeaningGoalId === 'function'
      ? global.Goals_getDefaultMeaningGoalId() : 0;
    if (!meaningId) return;
    var branchId = context.branchId != null ? context.branchId : 0;
    var situationId = info && typeof info.situationId === 'number' ? info.situationId : 0;
    var stimId = context.actualId != null ? context.actualId : 0;
    if (!stimId && info && info.stimulus && info.stimulus.finalImageId) {
      stimId = info.stimulus.finalImageId;
    }
    stimId = parseInt(stimId, 10) || 0;

    var frames = [];
    if (typeof global.EpisodicMemory_getFramesByStimulus === 'function' && stimId) {
      frames = global.EpisodicMemory_getFramesByStimulus(stimId);
    }
    if ((!frames || !frames.length) && branchId && typeof global.EpisodicMemory_getFramesByPerceptionAndSituation === 'function') {
      frames = global.EpisodicMemory_getFramesByPerceptionAndSituation(branchId, situationId);
    }
    if (!frames || !frames.length) {
      if (cycle) appendCycleLog(cycle, 'L2 (meaning goal): EP forecast — no consequence frames.', false);
      return;
    }

    var candidates = [];
    for (var i = 0; i < frames.length; i++) {
      var f = frames[i];
      if (!f) continue;
      var aid = f.actionImageId != null ? parseInt(f.actionImageId, 10) : 0;
      if (!aid) continue;
      candidates.push(f);
    }
    candidates.sort(function (a, b) {
      return (typeof b.effect === 'number' ? b.effect : 0) - (typeof a.effect === 'number' ? a.effect : 0);
    });
    var taken = candidates.slice(0, 5);
    if (cycle) {
      appendCycleLog(cycle, 'L2 (meaning goal): EP frame forecast — ' + String(taken.length) + ' rule(s) with action image.', false);
    }

    for (var j = 0; j < taken.length; j++) {
      var fr = taken[j];
      var actionId = fr.actionImageId != null ? parseInt(fr.actionImageId, 10) : 0;
      if (!actionId) continue;
      var eff = typeof fr.effect === 'number' ? fr.effect : 0;
      if (typeof global.Gestalt_bumpFromMeaningForecast === 'function') {
        global.Gestalt_bumpFromMeaningForecast(meaningId, actionId, fr, cycle);
      }
      if (typeof global.AbstractImages_boostSemanticRulesForAction === 'function') {
        var delta = eff > 0 ? Math.min(3, Math.max(0.5, eff / 3)) : 0.5;
        global.AbstractImages_boostSemanticRulesForAction(actionId, delta);
      }
    }
  }

  function conscience_level_2_hasCriticalVitalBeforeStress(info) {
    var cv = info && info.criticalVital ? parseInt(info.criticalVital, 10) : 0;
    if (cv > 0 && cv < 7) return true;
    var bad = global.BadVitalsValue;
    var vitals = global.VitalsArr;
    if (!bad || !Array.isArray(vitals)) return false;
    var TH = 70;
    for (var i = 0; i < vitals.length; i++) {
      if (vitals[i].Id >= 7) break;
      var k = bad[vitals[i].Id] || bad[String(vitals[i].Id)] || 0;
      if (k > TH) return true;
    }
    return false;
  }

  /**
   * Start automatism from L2 (survival). Enables the same EP-frame waiting phase as level-1 automatism start
   * (info_automatismWithEpisodeFeedbackAndExpireCycle in infofunctions.js).
   * End phase after operator response — conscience_level_2_finalizeAutomatismAnswerCycle.
   */
  function conscience_level_2_startSurvivalAutomatism(cycle, branchId, actionImageId, goalId) {
    if (!cycle || !branchId || !actionImageId) return false;
    var automatizmId = 0;
    if (typeof global.Automatizms_createAutomatizm === 'function') {
      automatizmId = global.Automatizms_createAutomatizm(branchId, actionImageId);
      if (automatizmId && typeof global.Automatizms_setDefaultAutomatizm === 'function') {
        global.Automatizms_setDefaultAutomatizm(automatizmId);
      }
    }
    if (typeof global.info_automatismWithEpisodeFeedbackAndExpireCycle === 'function') {
      return global.info_automatismWithEpisodeFeedbackAndExpireCycle(
        cycle,
        branchId,
        actionImageId,
        automatizmId,
        goalId || 0,
        'L2 (survival): automatism started from goal/rule, waiting for EP.'
      );
    }
    return false;
  }

  /**
   * Survival mode: goal/rule and action by the conditional algorithm.
   * Chain on Target_rule_stack — like chess: move → reply → next move uses the chain
   * of rules already present in EP (not necessarily adjacent frames; order is fixed in Episodes tape).
   */
  function conscience_level_2_trySurvivalGoalAndRules(context, info, cycle) {
    var branchId = context.branchId != null ? context.branchId : 0;
    var situationId = info && typeof info.situationId === 'number' ? info.situationId : 0;
    var stimulusImageId = context.actualId != null ? context.actualId : 0;
    if (!stimulusImageId && info && info.stimulus && info.stimulus.finalImageId) {
      stimulusImageId = info.stimulus.finalImageId;
    }
    if (!branchId || !cycle) return;

    appendCycleLog(cycle, 'L2 survival: goal and EP rule analysis (perception/stimulus/situation branch).');

    var lifeGoal = typeof global.Goals_findBestLifeGoalPositiveUsefulness === 'function'
      ? global.Goals_findBestLifeGoalPositiveUsefulness(branchId, situationId) : null;
    if (lifeGoal && lifeGoal.actionImageId) {
      appendCycleLog(cycle, 'L2 survival: goal image with positive usefulness, goalId=' + String(lifeGoal.id) + ', action image=' + String(lifeGoal.actionImageId) + '.');
      if (lifeGoal.id && typeof global.TargetRuleStack_push === 'function') global.TargetRuleStack_push(lifeGoal.id);
      if (typeof global.Info_setField === 'function') global.Info_setField('usedRule', lifeGoal.id || 0);
      if (typeof global.Goals_setCurrentGoalInInfoPicture === 'function') {
        global.Goals_setCurrentGoalInInfoPicture('life', lifeGoal.id, 0);
      }
      conscience_level_2_startSurvivalAutomatism(cycle, branchId, lifeGoal.actionImageId, lifeGoal.id);
      return;
    }

    var usedRuleVal = info && typeof info.usedRule === 'number' ? info.usedRule : (parseInt(info.usedRule, 10) || 0);
    if (usedRuleVal && Array.isArray(global.Target_rule_stack) && global.Target_rule_stack.length &&
        typeof global.EpisodicMemory_findChainForGoalStack === 'function') {
      var chainGoals = global.Target_rule_stack.slice();
      var chainFrames = global.EpisodicMemory_findChainForGoalStack(chainGoals);
      if (chainFrames && chainFrames.length) {
        appendCycleLog(cycle, 'L2 survival: EP frame chain found for Target_rule_stack (' + String(chainFrames.length) + ' link(s)).');
        var lastFr = chainFrames[chainFrames.length - 1];
        var gidChain = conscience_level_2_survivalLifeGoalIdFromFrame(lastFr);
        if (gidChain && lastFr.actionImageId) {
          if (typeof global.TargetRuleStack_push === 'function') global.TargetRuleStack_push(gidChain);
          if (typeof global.Info_setField === 'function') global.Info_setField('usedRule', gidChain);
          if (typeof global.Goals_setCurrentGoalInInfoPicture === 'function') {
            global.Goals_setCurrentGoalInInfoPicture('life', gidChain, 0);
          }
          conscience_level_2_startSurvivalAutomatism(cycle, branchId, lastFr.actionImageId, gidChain);
          return;
        }
      }
      appendCycleLog(cycle, 'L2 survival: chain from usedRule/Target_rule_stack not built — fall through to single-rule search.');
    }

    if (typeof global.TargetRuleStack_clear === 'function') global.TargetRuleStack_clear();
    if (typeof global.Info_setField === 'function') global.Info_setField('usedRule', 0);
    appendCycleLog(cycle, 'L2 survival: cleared Target_rule_stack and usedRule; selecting ExactRule/InaccurateRule from EP.');

    var ruleBundle = typeof global.info_bestEpisodicRule === 'function'
      ? global.info_bestEpisodicRule(branchId, situationId, {
        filterByStimulus: false,
        stimulusImageId: stimulusImageId,
        allowStimulusFallback: true
      })
      : null;
    var bestFrame = ruleBundle && ruleBundle.frame ? ruleBundle.frame : null;
    var exactRule = !!(ruleBundle && ruleBundle.exactRule);

    var inaccurate = !!bestFrame && !exactRule;

    function applyFromFrame(frame) {
      var gid = conscience_level_2_survivalLifeGoalIdFromFrame(frame);
      if (!gid || !frame.actionImageId) return false;
      if (typeof global.TargetRuleStack_push === 'function') global.TargetRuleStack_push(gid);
      if (typeof global.Info_setField === 'function') global.Info_setField('usedRule', gid);
      if (typeof global.Goals_setCurrentGoalInInfoPicture === 'function') {
        global.Goals_setCurrentGoalInInfoPicture('life', gid, 0);
      }
      conscience_level_2_startSurvivalAutomatism(cycle, branchId, frame.actionImageId, gid);
      return true;
    }

    if (exactRule && bestFrame) {
      appendCycleLog(cycle, 'L2 survival: ExactRule — best EP frame (branch+situation), effect=' + String(bestFrame.effect) + '.');
      applyFromFrame(bestFrame);
      return;
    }
    if (inaccurate && conscience_level_2_hasCriticalVitalBeforeStress(info) && bestFrame) {
      appendCycleLog(cycle, 'L2 survival: InaccurateRule with critical vitals before Stress — start action from EP frame, effect=' + String(bestFrame.effect) + '.');
      applyFromFrame(bestFrame);
      return;
    }
    if (inaccurate && bestFrame && !conscience_level_2_hasCriticalVitalBeforeStress(info)) {
      appendCycleLog(cycle, 'L2 survival: InaccurateRule without urgent vitals — no reckless action, L3 scheduled.');
      cycle.survivalDeferredLevel3Planning = true;
      return;
    }

    if (!bestFrame) {
      var cryOd = 0;
      var cryGoalId = 0;
      var critV = info && info.criticalVital ? parseInt(info.criticalVital, 10) : 0;
      if (critV && critV !== 0) {
        if (typeof global.Goals_ensureDefaultCryGoal === 'function') {
          global.Goals_ensureDefaultCryGoal();
        }
        if (typeof global.Goals_getDefaultCryGoalId === 'function') {
          cryGoalId = global.Goals_getDefaultCryGoalId();
        }
        if (cryGoalId && typeof global.Goals_getGoalById === 'function') {
          var cryG = global.Goals_getGoalById(cryGoalId);
          if (cryG && cryG.actionImageId) {
            cryOd = cryG.actionImageId;
          }
        }
      }
      if (!cryOd && typeof global.ActionImages_getOrCreateActionImageId === 'function') {
        cryOd = global.ActionImages_getOrCreateActionImageId(stimulusImageId || 0, [1], '');
      }
      if (cryOd) {
        if (typeof global.Info_setField === 'function') global.Info_setField('usedRule', 0);
        if (cryGoalId && typeof global.Goals_setCurrentGoalInInfoPicture === 'function') {
          global.Goals_setCurrentGoalInInfoPicture('life', cryGoalId, 0);
        }
        appendCycleLog(
          cycle,
          cryGoalId
            ? 'L2 survival: critical vital, no other goals — default goal Cry, automatism from action image.'
            : 'L2 survival: no positive rules in EP — Cry automatism (action image), then L3.',
          !!cryGoalId
        );
        conscience_level_2_startSurvivalAutomatism(cycle, branchId, cryOd, cryGoalId || 0);
      } else {
        appendCycleLog(cycle, 'L2 survival: no EP rules and could not create Cry action image — L3 only.', true);
      }
      cycle.survivalCryLevel3Pending = true;
    }
  }

  function conscience_level_2(context) {
    if (!context) return;

    var info = (typeof global.Info_initIfNeeded === 'function')
      ? global.Info_initIfNeeded()
      : global.InfoPicture;

    // ========== isOperatorAnswerReceived block (required at start of L2) ==========
    // Condition in info picture: operator gave response stimulus during EP wait after reaction
    // (value comes from episodic/OR; see also InfoDet_updateOperatorAnswer when clearing).
    //
    // Why this block here, not after goals/ImportantProblem: operator response is a separate event,
    // it must be applied before further second-level logic in the same call when context is full;
    // when called only from runOneStep, _operatorAnswerCycleOnly restricts work to this block.
    //
    // Cycle binding:
    //   • Reliable path — context.sourceCycle (runOneStep passes this for the same cycle that waited).
    //   • Fallback — EpisodicMemory_waitingAutomatismCycleId + Consciousness_getCycle: useful
    //     if id is not yet cleared in closeLastFrame; after closing frame with response id is often reset,
    //     so the main contract is always pass sourceCycle when the cycle is known.
    //
    // Extra constraints on cycle: both awaitingAutomatismEpisodeFeedback (we are in "waiting for frame" branch)
    // and automatismOperatorAnswerReceived (episodic marked response on this cycle). Otherwise raised
    // isOperatorAnswerReceived could belong to another session — do not touch foreign cycle.
    if (info && info.isOperatorAnswerReceived) {
      var opCycle = context.sourceCycle;
      if (!opCycle && typeof global.EpisodicMemory_waitingAutomatismCycleId === 'number' && global.EpisodicMemory_waitingAutomatismCycleId &&
          typeof global.Consciousness_getCycle === 'function') {
        opCycle = global.Consciousness_getCycle(global.EpisodicMemory_waitingAutomatismCycleId);
      }
      if (opCycle && opCycle.awaitingAutomatismEpisodeFeedback && opCycle.automatismOperatorAnswerReceived) {
        // Semantic goal adjustments first (once), then archive waiting-cycle state.
        if (!opCycle.operatorAnswerPipelineConsumed) {
          conscience_level_2_operatorAnswerPipeline(opCycle);
        }
        conscience_level_2_finalizeAutomatismAnswerCycle(opCycle);
      }
      // Dispatcher mode: one tick — automatism response only, no further conscience_level_2 body.
      if (context._operatorAnswerCycleOnly) return;
    }

    if (info) {
      info.ImportantProblem = (info.criticalVital && info.criticalVital !== 0) ? 1 : 0;
    }

    // --- Goal and action determination (after operator response): survival branch / modes ---
    var cycle = context.sourceCycle;
    var survival = conscience_level_2_isSurvivalContext(info);
    if (survival && cycle) {
      appendCycleLog(cycle, 'L2: survival context active (critical vital / shock / sharp drop / isShockState).');
      conscience_level_2_trySurvivalGoalAndRules(context, info, cycle);
    } else if (info) {
      // Not survival: dissatisfaction — isDissatisfaction flag / L3 block in runOneStep;
      // play and learning modes — explicit flags for L3 (sync with playMode / learningMode).
      info.isPlayMode = info.playMode ? 1 : 0;
      info.isLearningMode = info.learningMode ? 1 : 0;
      if (cycle) {
        appendCycleLog(cycle, 'L2: not survival — Goals_determineGoalInSituation, isPlayMode=' + String(info.isPlayMode) + ', isLearningMode=' + String(info.isLearningMode) + '.');
      }
      if (typeof global.Goals_determineGoalInSituation === 'function') {
        global.Goals_determineGoalInSituation(context);
      }
      if (cycle && info && (
        info.currentGoalType === 'meaning' ||
        (typeof global.Goals_isDefaultMeaningGoalId === 'function' && global.Goals_isDefaultMeaningGoalId(info.currentGoalId))
      )) {
        conscience_level_2_tryMeaningGoalForecast(context, info, cycle);
      }
      if (typeof global.Info_updateView === 'function') global.Info_updateView();
    }
  }

  global.conscience_level_2 = conscience_level_2;
  global.conscience_level_2_operatorAnswerPipeline = conscience_level_2_operatorAnswerPipeline;
})(window);
