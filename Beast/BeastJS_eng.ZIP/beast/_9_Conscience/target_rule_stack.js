(function (global) {
  'use strict';

  /**
   * Goal stack for rules (LIFO), depth at most 3.
   * Stores FinalImageId of goal images; array indices: [0] bottom, [length-1] top.
   */
  var MAX_DEPTH = 3;

  if (!Array.isArray(global.Target_rule_stack)) {
    global.Target_rule_stack = [];
  }

  function normalize() {
    while (global.Target_rule_stack.length > MAX_DEPTH) {
      global.Target_rule_stack.shift();
    }
  }

  /**
   * Push goal image ID onto stack top (0 ignored).
   */
  function TargetRuleStack_push(finalImageId) {
    var id = parseInt(finalImageId, 10) || 0;
    if (!id) return;
    global.Target_rule_stack.push(id);
    normalize();
  }

  /** Pop stack top, return ID or 0. */
  function TargetRuleStack_pop() {
    if (!global.Target_rule_stack.length) return 0;
    return global.Target_rule_stack.pop() || 0;
  }

  /** Stack top without popping. */
  function TargetRuleStack_peek() {
    var a = global.Target_rule_stack;
    return a.length ? (a[a.length - 1] || 0) : 0;
  }

  function TargetRuleStack_clear() {
    global.Target_rule_stack.length = 0;
  }

  function TargetRuleStack_depth() {
    return global.Target_rule_stack.length;
  }

  global.TargetRuleStack_push = TargetRuleStack_push;
  global.TargetRuleStack_pop = TargetRuleStack_pop;
  global.TargetRuleStack_peek = TargetRuleStack_peek;
  global.TargetRuleStack_clear = TargetRuleStack_clear;
  global.TargetRuleStack_depth = TargetRuleStack_depth;
})(typeof window !== 'undefined' ? window : globalThis);
