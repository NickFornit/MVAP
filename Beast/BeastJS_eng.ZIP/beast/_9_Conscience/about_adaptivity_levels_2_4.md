# Consciousness adaptivity: levels 2 and 4 (as implemented)

This document records **actual code behavior** for how level 2 and level 4 relate to semantics, episodic memory, and adjacent paths. It is not a future spec; gaps are **current implementation boundaries**.

---

## 1. Level 2 (`conscience_level_2.js`)

Implemented as **goal setting/review** and **action-outcome processing** when motor ran and episodic memory (EP) provides feedback.

### 1.1 Branches (as in code)

| Branch | Implemented behavior |
|--------|----------------------|
| Operator answer / EP frame | `AbstractImages_applyEpisodeEffectToSemanticContextAbstractions`; on numeric `effect > 0` — `MentalAutomatizms_tryCreateFromSemanticStructureRule`; goal usefulness adjustment (`Goals_applyWaitingPeriodEffectToGoalUsefulness`, `Goals_mergeUsefulnessSampleForGoalId`) with detectors (`negativeMotorEffect`, `positiveActionEffect`, `lowAutomatismUsefulness`). Re-entry guard: `operatorAnswerPipelineConsumed`. |
| Survival | Conditions: `conscience_level_2_isSurvivalContext`, vital criticality; life-experience goals (`Goals_addOrUpdateLifeGoalFromFrame` and related); chains via `Target_rule_stack` / `EpisodicMemory_findChainForGoalStack` when `usedRule`; automatism with EP wait (`info_automatismWithEpisodeFeedbackAndExpireCycle`, `conscience_level_2_startSurvivalAutomatism`). |
| “Meaning” goal | `conscience_level_2_tryMeaningGoalForecast`: EP frames by stimulus/branch, forecast; `Gestalt_bumpFromMeaningForecast`; `AbstractImages_boostSemanticRulesForAction`. |
| Wait phase end | `conscience_level_2_finalizeAutomatismAnswerCycle` — clear wait flags, cycle `expired`. |

### 1.2 Links to other modules

- **EP:** frames, effect, frame close → operator-answer pipeline input.
- **`abstract_images.js`:** average semantics on feedback; strengthen rules by AID for “meaning” goal.
- **`mental_automatism.js`:** create mental automatism on positive effect with `semanticStructure` match.
- **`goals.js`:** life-experience goal images, usefulness, “meaning” goal.
- **`gestalt.js`:** calls from “meaning” branch (`Gestalt_bumpFromMeaningForecast`).

---

## 2. Level 4 (`conscience_level_4.js`)

Implemented as a **thin wrapper** over the gestalt module: main channel tick calls `Gestalt_onConsciousnessTick(cycle)` (see `gestalt.js`). `conscience_level_4(context)` exists with log and **TODO** for extensions (meta-reflection, etc.) — **not** fully fleshed there.

### 2.1 Level 4 role in code

- **Main** running cycle only in `Gestalt_onConsciousnessTick` (background filtered inside gestalt).
- Bind leading gestalt to goal (`cycle.goalImageId` / `InfoPicture.currentGoalId` in main target mode).
- Process **`GestaltResonanceBuffer`** (FIFO closed EP signatures), score heuristic → analogical insight, update `analogyPool` and gestalt status.
- Possible second `Gestalt_prepareContextForLevel3` after insights.
- Resonance buffer fill **not** in this tick: on EP frame close (`EpisodicMemory_closeLastFrame` → `Gestalt_onEpisodeFeedbackClosed`).

### 2.2 Relation to level 3

- Start of level 3 calls `Gestalt_prepareContextForLevel3` — snapshot of open gestalt in `GestaltContextForLevel3`; level 3 does not fully replace its own rule search with that context — see comments in `conscience_level_3.js` and `conscience_level_4.js`.

---

## 3. Consistency levels 2 ↔ 3 ↔ 4 (facts)

**Implemented:**

1. Closed loop: motor / automatism → EP → level-2 answer handling → further `runOneStep` ticks with levels 3 and 4.
2. EP wait gate: while `awaitingAutomatismEpisodeFeedback` without operator answer, full level-3 pass is skipped (`conscience_level_3_shouldSkipBecauseAwaitingEpisodeFeedback` and related).
3. `semanticStructure` frame check before motor: `conscience_level_3_semanticStructureFrameAllowsMotor` (teacher frame and positive episodic effect).
4. Level 4 does not duplicate level-3 rule search; adds gestalt layer and resonance over closed frames.

**Current boundaries (observation, not bug list):**

1. Main level-4 adaptivity lives in **`gestalt.js`**, not the body of `conscience_level_4.js`.
2. Rules with `ruleKind === 'fantasy'` (after `info_new_abstract_semantic` / `AbstractImages_upsertSemanticRuleFromFantasyFrame`) are **not** explicitly listed in `conscience_level_3_semanticStructureFrameAllowsMotor` — fantasy motor policy is separate from episodic/teacher in that gate.
3. Passive cycle mode (`cycle.thinkingMode === 'passive'`) and `info_fantasizming` in **`Consciousness_runOneStep`** bypass levels 3–4 in the same tick; plot consolidation `info_new_abstract_semantic` in `infofunctions.js` is a **separate** call, not wired into default gestalt tick.
4. Two sources for `semanticStructure`: real EP frames and fantasy slots; teacher slot is **not overwritten** by fantasy update (`AbstractImages_upsertSemanticRuleFromFantasyFrame`).

---

## 4. Adaptive qualities (current implementation)

| Aspect | What the system records |
|--------|-------------------------|
| Learning from outcomes | Level 2: EP feedback, semantic context and goal updates. |
| Threat priority | Separate survival branch in level 2. |
| Long memory of open problems | Gestalts, “meaning” goal, EP forecast in level 2. |
| Analogy and transfer | Resonance buffer, score heuristic, `analogyPool` in `gestalt.js`. |
| Internal simulation | Passive fantasy, fantasy → semantics via `info_new_abstract_semantic` — separate path from level 3–4 tick. |

---

## 5. Related files

| File | Role |
|------|------|
| `conscience_level_2.js` | Level 2 |
| `conscience_level_3.js` | Level 3 (channel, semantics/EP gates) |
| `conscience_level_4.js` | Level 4 (gestalt call) |
| `gestalt.js` | Gestalts, resonance, analogical insight |
| `abstract_images.js` | Clones, `semanticStructure`, fantasy upsert |
| `infofunctions.js` | `info_new_abstract_semantic`, other info_* |
| `conscious_attention_channel.js` | `runOneStep`, passive branch |
| `consciousness_dispatcher.js` | Cycle dispatcher, stagnation, signatures |

---

*Text aligned with the level 2–4 adaptivity overview and phrased as “what the code does today.”*
