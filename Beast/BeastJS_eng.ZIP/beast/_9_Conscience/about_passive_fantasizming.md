# Passive mode and fantasy (`info_fantasizming`)

## Mode roles

- Thinking mode (**`target`** | **`passive`**) lives on the **consciousness cycle** (`cycle.thinkingMode`), **not** in `InfoPicture`. Main and background cycles may differ; info picture is the shared “screen” and data cells without a “mode” field.
- Target and passive are **antagonistic at the cycle step**: when **`thinkingMode === 'passive'`**, levels 3–4 are **not** called; **`info_fantasizming(cycle)`** runs (unless anti-stagnation gate fires).
- **Main** cycle in passive extends plot in **`InfoPicture.fantasmPlotRules`** (“Fantasy plot”) and uses **`fantazmingPlot` / `lastGeneratedActionId`** on the cycle as continuation context.
- **Background** cycle in passive **does not** write `fantasmPlotRules`; it accumulates context in **`cycle.fantasizmArr`** and **`cycle.fantazmingPlot`** (chain and anchor for next step).

## Anchor frame and “EpisodicTreeNode”

Frames live in **`Episodes`**. For a fantasy step, entry is **stimulus id** `currentStimulusId` (see `info_fantasizming`); for main without anchor, **`InfoPicture.currentGoalId`** is allowed; for background — not.

## Anti-stagnation

After a step, progress signature is stored in **`cycle.passiveFantasyLastSig`**. **Main:** **`Consciousness_getInfoPictureSignature()`** (global info-picture changes). **Background:** local string from **`fantazmingPlot` + `fantasizmArr`** (no info-picture write). If **streak ≥ 3** matches last snapshot, **`info_fantasizming`** is skipped.

## One step `info_fantasizming(cycle)`

1. **`cycle.thinkingMode === 'passive'`**; else exit.
2. **Current stimulus** priority: `lastGeneratedActionId` → `context.actual_stimul_ID` → (main only) `InfoPicture.currentGoalId`.
3. EP frames with **`responseStimulusImageId === currentStimulusId`**, best by **|effect|**.
4. Always into **`fantazmingPlot`** and **`fantasizmArr`**; into **`fantasmPlotRules`** **only if cycle is main**.
5. Insight over threshold → **`info_insight`** (sets cycle **`thinkingMode = 'target'`**).
6. Else: **main** — `runActionImage`, `Info_updateFromStimulus`, info-picture step; **background** — no global info-picture change, no motor imitation.

## Gestalts and resonance

Further work — object priorities, `curConditions`, gestalts / **`GestaltResonanceBuffer`**.

## Sleep mode

Dreams use the same **`info_fantasizming`** for the main cycle: orchestrator in `beast/_12_Sleep/sleep_dream_process.js` creates main cycle with `thinkingMode === 'passive'` and after pulse series fills “empty” EP frame from `fantazmingPlot.chain`. Details — **`beast/_12_Sleep/about_sleep.md`**.
