/* Detectors for active info-picture flags. These detect occurring situations.
Info detectors (beast/_9_Conscience/info_detectors.js) set InfoPicture fields such as criticalVital, badState, playMode, searchInterest, etc.

Building the “situation composition” — in beast/_9_Conscience/situatioms_tree.js, function extractSituationComponentsFromInfo(info): for each key in DETECTOR_COMPONENT_IDS map, if info value is a number and ≠ 0, the matching numeric component id is added to the situation set. If the set is empty but Norm/Good (BadNormWell 2/3), basic context Rest (id 14) is active and there is no critical vital — synthetic peaceNormBaseline (36) is added; otherwise a calm norm phase would not form a situation.

Creating/strengthening situation images — in SituationsTree_onPerceptionTreeActivated():
situationComps are taken; when non-empty, findOrCreateSituationImage(mode, situationComps) is called (count counter, later ready when count > 3).

Call site — from Info_updateFromPerceptionTree() in informing.js after perception branch update, SituationsTree_onPerceptionTreeActivated() is invoked.
*/

(function (global) {
  'use strict';

  // Safe write helper for InfoPicture.
  function setInfo(name, value) {
    if (typeof global.Info_setField === 'function') {
      global.Info_setField(name, value);
    } else if (global.InfoPicture) {
      global.InfoPicture[name] = value;
    }
  }

  // -------- Target mode / Theme / Situation --------

  /**
   * Target / passive thinking mode of main consciousness cycle (thinkingMode), not an InfoPicture field.
   * The “Mode” cell in UI updates via Info_updateView (Consciousness_getMainCycleThinkingMode).
   */
  function InfoDet_updateTargetMode(isTarget) {
    if (typeof global.Consciousness_getMainCycle === 'function') {
      var mc = global.Consciousness_getMainCycle();
      if (mc) {
        mc.thinkingMode = isTarget ? 'target' : 'passive';
      }
    }
    if (typeof global.Info_updateView === 'function') {
      global.Info_updateView();
    }
  }

  /**
   * Current comprehension theme.
   * Active theme image — ID or 0.
   */
  function InfoDet_updateCurrentTheme(themeId) {
    setInfo('themeId', themeId || 0);
  }

  /**
   * Current comprehension situation.
   * Active situation image — ID or 0.
   */
  function InfoDet_updateCurrentSituation(situationId) {
    setInfo('situationId', situationId || 0);
  }

  // -------- Vitals and basic contexts --------

  /**
   * Critical vital:
   * if any vital exceeds 70, its ID is returned.
   * If several qualify — the vital with the largest value wins and its ID is stored.
   * @param {Array<{Id:number,value:number}>} vitalsArr
   */
  function InfoDet_updateCriticalVital(vitalsArr) {
    // With Good and active food/water feed, info picture must not show critical vital —
    // stimulus immediately sets Good hold (SetWellForHolding) and semantically overrides “criticality”.
    var bnw = typeof global.BadNormWell === 'number' ? global.BadNormWell : 0;
    if (bnw === 3 && Array.isArray(global.ActiveMotivationStimuls)) {
      var am = global.ActiveMotivationStimuls;
      if (am.indexOf(1) !== -1 || am.indexOf(2) !== -1) {
        setInfo('criticalVital', 0);
        setInfo('ImportantProblem', 0);
        return;
      }
    }
    if (!Array.isArray(vitalsArr) || !vitalsArr.length) {
      setInfo('criticalVital', 0);
      setInfo('ImportantProblem', 0);
      return;
    }
    var bestId = 0;
    var bestVal = 70;
    for (var i = 0; i < vitalsArr.length; i++) {
      var v = vitalsArr[i];
      if (!v || typeof v.value !== 'number') continue;
      if (v.value > bestVal) {
        bestVal = v.value;
        bestId = v.Id || 0;
      }
    }
    setInfo('criticalVital', bestId);
    setInfo('ImportantProblem', bestId ? 1 : 0);
  }

  /**
   * Sharp deterioration / Bad state.
   * Sharp drop: 1 — state switched to Bad; else 0.
   * Bad state: badState = 1 when BadNormWell=1, else 0.
   * @param {number} lastBadNormWell - previous BadNormWell
   * @param {number} badNormWell - current BadNormWell (1/2/3)
   */
  function InfoDet_updateBadState(lastBadNormWell, badNormWell) {
    if (typeof badNormWell !== 'number') badNormWell = 0;
    if (typeof lastBadNormWell !== 'number') lastBadNormWell = 0;
    // badState: current Bad.
    setInfo('badState', badNormWell === 1 ? 1 : 0);
    // suddenChange: 1 if was not Bad and became Bad.
    var sudden = (lastBadNormWell !== 1 && badNormWell === 1) ? 1 : 0;
    setInfo('suddenChange', sudden);
  }

  /**
   * Play mode (“Play” cell):
   * — basic context Play (id=11), or
   * — console “Play” button (global.isGameMode), see stimuls_ui.js.
   * @param {number[]} basicContextsActived
   */
  function InfoDet_updatePlayMode(basicContextsActived) {
    var active = Array.isArray(basicContextsActived) &&
      basicContextsActived.indexOf(11) !== -1;
    if (global.isGameMode) {
      active = true;
    }
    setInfo('playMode', active ? 1 : 0);
  }

  /**
   * Learning mode / search interest:
   * Learning (“Learning” cell): Curiosity context (id=12), or Interest>70,
   * or “Teach” button (global.isAuthoritarianEducation).
   * Search interest: only vital Interest > 70 (without “Teach” button).
   * @param {number[]} basicContextsActived
   * @param {Array<{Id:number,value:number}>} vitalsArr
   *   (vital with Id==10 expected, or by convention as "Interest")
   */
  function InfoDet_updateLearningAndSearch(basicContextsActived, vitalsArr) {
    var curiosityActive = Array.isArray(basicContextsActived) &&
      basicContextsActived.indexOf(12) !== -1;
    var interestHigh = false;
    if (Array.isArray(vitalsArr)) {
      for (var i = 0; i < vitalsArr.length; i++) {
        var v = vitalsArr[i];
        if (!v || typeof v.value !== 'number') continue;
        // Assume vital "Interest" has Id == 10 (or another in practice).
        if (v.Id === 10 && v.value > 70) {
          interestHigh = true;
          break;
        }
      }
    }
    setInfo('searchInterest', interestHigh ? 1 : 0);
    var learning = curiosityActive || interestHigh || !!global.isAuthoritarianEducation;
    setInfo('learningMode', learning ? 1 : 0);
  }

  // -------- Action and automatism effects --------

  /**
   * Negative effect of motor automatism:
   * getDiffImportance(), called on stimulus during wait for motor automatism outcome, returns < 0.
   * @param {number} z - getDiffImportance() value during wait
   */
  function InfoDet_updateNegativeMotorEffect(z) {
    if (typeof z !== 'number' || isNaN(z)) {
      setInfo('negativeMotorEffect', 0);
      return;
    }
    setInfo('negativeMotorEffect', z < 0 ? z : 0);
  }

  /**
   * Negative effect of mental automatism:
   * same idea as motor, for mental automatisms.
   * May be stub: accept z and write if < 0.
   * @param {number} z
   */
  function InfoDet_updateNegativeMentalEffect(z) {
    if (typeof z !== 'number' || isNaN(z)) {
      setInfo('negativeMentalEffect', 0);
      return;
    }
    setInfo('negativeMentalEffect', z < 0 ? z : 0);
  }

  /**
   * Positive / negative action effect:
   * when EP frame closes after automatism.
   * @param {number} effect - last.effect from EP (diffAfter - diffBefore)
   */
  function InfoDet_updateActionEffect(effect) {
    if (typeof effect !== 'number' || isNaN(effect)) {
      setInfo('positiveActionEffect', 0);
      setInfo('negativeActionEffect', 0);
      return;
    }
    setInfo('positiveActionEffect', effect > 0 ? effect : 0);
    setInfo('negativeActionEffect', effect < 0 ? effect : 0);
  }

  /**
   * No reaction to stimulus:
   * automatism result wait period ended without response stimulus.
   * @param {boolean} noReaction
   */
  function InfoDet_updateNoReaction(noReaction) {
    setInfo('noReactionToStimulus', noReaction ? 1 : 0);
  }

  /**
   * Active answer wait:
   * wait for automatism result started from comprehension function.
   * @param {boolean} active
   */
  function InfoDet_updateActiveWaiting(active) {
    setInfo('activeWaitingAnswer', active ? 1 : 0);
  }

  /**
   * Low automatism usefulness:
   * effect during wait does not exceed 1 in absolute value.
   * @param {number} usefulnessSample
   */
  function InfoDet_updateLowAutomatismUsefulness(usefulnessSample) {
    if (typeof usefulnessSample !== 'number' || isNaN(usefulnessSample)) {
      setInfo('lowAutomatismUsefulness', 0);
      return;
    }
    if (Math.abs(usefulnessSample) <= 1 && usefulnessSample !== 0) {
      setInfo('lowAutomatismUsefulness', usefulnessSample);
    } else {
      setInfo('lowAutomatismUsefulness', 0);
    }
  }

  /**
   * While suitable automatism found:
   * comprehension cycle continues in target mode.
   * @param {boolean} active
   */
  function InfoDet_updateFoundSuitableAutomatism(active) {
    setInfo('foundSuitableAutomatism', active ? 1 : 0);
  }

  // -------- Stimuli and semantics --------

  /**
   * Console stimulus:
   * new current stimulus appeared, triggering orienting reflex.
   * Stores stimulus image ID (FinalImageId) or 0.
   * @param {number} finalImageId
   */
  function InfoDet_updateConsoleStimulus(finalImageId) {
    if (typeof finalImageId !== 'number' || finalImageId <= 0) {
      setInfo('consoleStimulus', 0);
    } else {
      setInfo('consoleStimulus', finalImageId);
    }
  }

  /**
   * High-importance object present:
   * current actual stimulus image contains a stimulus with high semantic importance
   * in this condition context. Caller is expected to have detected it
   * and pass its ID or level.
   * @param {number} objectIdOrLevel
   */
  function InfoDet_updateHighImportanceObject(objectIdOrLevel) {
    if (typeof objectIdOrLevel !== 'number' || objectIdOrLevel <= 0) {
      setInfo('highImportanceObject', 0);
    } else {
      setInfo('highImportanceObject', objectIdOrLevel);
    }
  }

  /**
   * Mood improving:
   * Good state appeared or improvement by more than 5 units.
   * @param {number} diffLevel - positive difference (normalized), if any.
   */
  function InfoDet_updateMoodImproving(diffLevel) {
    if (typeof diffLevel !== 'number' || isNaN(diffLevel)) {
      setInfo('moodImproving', 0);
      return;
    }
    if (diffLevel > 5) {
      setInfo('moodImproving', diffLevel);
    } else {
      setInfo('moodImproving', 0);
    }
  }

  /**
   * Image novelty:
   * OR novelty detector gives large novelty value.
   * @param {number} novelty
   * @param {number} threshold
   */
  function InfoDet_updateImageNovelty(novelty, threshold) {
    if (typeof novelty !== 'number' || isNaN(novelty)) {
      setInfo('imageNovelty', 0);
      return;
    }
    if (typeof threshold !== 'number' || isNaN(threshold)) threshold = 0.5;
    setInfo('imageNovelty', novelty > threshold ? novelty : 0);
  }

  /**
   * High semantic importance:
   * for current image, semantics >> 0.
   * @param {number} meanImportance
   */
  function InfoDet_updateHighSemanticImportance(meanImportance) {
    if (typeof meanImportance !== 'number' || isNaN(meanImportance)) {
      setInfo('highSemanticImportance', 0);
      return;
    }
    setInfo('highSemanticImportance', meanImportance > 0 ? meanImportance : 0);
  }

  /**
   * Conflicting semantics:
   * for this image semantics near zero at high measurement strength (samplesCount),
   * while other conditions have both large positive and large negative values.
   * Caller is expected to have analyzed and pass 1/0.
   * @param {boolean} hasConflict
   */
  function InfoDet_updateConflictingSemantics(hasConflict) {
    setInfo('conflictingSemantics', hasConflict ? 1 : 0);
  }

  // -------- Comprehension cycle / problems --------

  /**
   * Teacher learning:
   * 1 — on when comprehension yields Unsolved problem
   * during a non-stopping cycle of solution attempts (operator action tracking mode).
   * @param {boolean} active
   */
  function InfoDet_updateTeacherLearning(active) {
    setInfo('teacherLearning', active ? 1 : 0);
  }

  /**
   * Operator ignoring:
   * motivating stimulus “Ignore” active, or no stimulus during wait after reaction and period ended.
   * @param {boolean} active
   */
  var operatorIgnoring_waiting = false;
  var operatorIgnoring_stimulus = false;

  function InfoDet_recalcOperatorIgnoring() {
    setInfo('operatorIgnoring', (operatorIgnoring_waiting || operatorIgnoring_stimulus) ? 1 : 0);
  }

  /**
   * Source 1: wait-period / missing-response logic.
   */
  function InfoDet_updateOperatorIgnoring(active) {
    operatorIgnoring_waiting = !!active;
    InfoDet_recalcOperatorIgnoring();
  }

  /**
   * Source 2: motivating stimulus “Ignore” active (StimulMotivarion.Id = 18).
   * Call on stimulus switch or bulk stimulus reset.
   */
  function InfoDet_updateOperatorIgnoringFromStimulus() {
    var arr = global.ActiveMotivationStimuls;
    operatorIgnoring_stimulus = Array.isArray(arr) && arr.indexOf(18) !== -1;
    InfoDet_recalcOperatorIgnoring();
  }

  /**
   * Dissatisfaction with the existing:
   * basic context Rest active, no current stimuli and passive-mode comprehension cycle finished.
   * @param {boolean} active
   */
  function InfoDet_updateDissatisfaction(active) {
    var v = active ? 1 : 0;
    setInfo('dissatisfaction', v);
    setInfo('isDissatisfaction', v);
  }

  /**
   * Misunderstanding:
   * comprehension cycle reached end in target mode or iteration step count exceeded 10.
   * @param {boolean} active
   */
  function InfoDet_updateMisunderstanding(active) {
    setInfo('misunderstanding', active ? 1 : 0);
  }

  /**
   * Doubt in default automatism:
   * second comprehension level started in target mode.
   * @param {boolean} active
   */
  function InfoDet_updateDoubtInDefaultAutomatism(active) {
    setInfo('doubtInDefaultAutomatism', active ? 1 : 0);
  }

  /**
   * Defense:
   * basic context Fear and/or Aggression active.
   * @param {boolean} active
   */
  function InfoDet_updateDefense(active) {
    setInfo('defense', active ? 1 : 0);
  }

  /**
   * Fear:
   * basic context Fear active.
   * @param {boolean} active
   */
  function InfoDet_updateFear(active) {
    setInfo('fear', active ? 1 : 0);
  }

  /**
   * Aggression:
   * basic context Aggression active.
   * @param {boolean} active
   */
  function InfoDet_updateAggression(active) {
    setInfo('aggression', active ? 1 : 0);
  }

  /**
   * Hard problem:
   * images for which unsolved problem persists more than 10 steps and cycle ends in target mode.
   * Caller is expected to maintain such array and pass level/counter.
   * @param {number} level
   */
  function InfoDet_updateHardProblem(level) {
    if (typeof level !== 'number' || isNaN(level)) {
      setInfo('hardProblem', 0);
    } else {
      setInfo('hardProblem', level);
    }
  }

  /**
   * Operator answer received:
   * @param {boolean} received
   */
  function InfoDet_updateOperatorAnswer(received) {
    setInfo('operatorAnswerReceived', received ? 1 : 0);
    if (!received) {
      setInfo('isOperatorAnswerReceived', 0);
    }
  }

  /**
   * Series of episodes without effect:
   * @param {number} length
   */
  function InfoDet_updateSeriesWithoutEffect(length) {
    if (typeof length !== 'number' || isNaN(length) || length <= 0) {
      setInfo('seriesWithoutEffect', 0);
    } else {
      setInfo('seriesWithoutEffect', length);
    }
  }

  // Export detectors to global
  global.InfoDet_updateTargetMode = InfoDet_updateTargetMode;
  global.InfoDet_updateCurrentTheme = InfoDet_updateCurrentTheme;
  global.InfoDet_updateCurrentSituation = InfoDet_updateCurrentSituation;
  global.InfoDet_updateCriticalVital = InfoDet_updateCriticalVital;
  global.InfoDet_updateBadState = InfoDet_updateBadState;
  global.InfoDet_updatePlayMode = InfoDet_updatePlayMode;
  global.InfoDet_updateLearningAndSearch = InfoDet_updateLearningAndSearch;
  global.InfoDet_updateNegativeMotorEffect = InfoDet_updateNegativeMotorEffect;
  global.InfoDet_updateNegativeMentalEffect = InfoDet_updateNegativeMentalEffect;
  global.InfoDet_updateActionEffect = InfoDet_updateActionEffect;
  global.InfoDet_updateNoReaction = InfoDet_updateNoReaction;
  global.InfoDet_updateActiveWaiting = InfoDet_updateActiveWaiting;
  global.InfoDet_updateLowAutomatismUsefulness = InfoDet_updateLowAutomatismUsefulness;
  global.InfoDet_updateFoundSuitableAutomatism = InfoDet_updateFoundSuitableAutomatism;
  global.InfoDet_updateConsoleStimulus = InfoDet_updateConsoleStimulus;
  global.InfoDet_updateHighImportanceObject = InfoDet_updateHighImportanceObject;
  global.InfoDet_updateMoodImproving = InfoDet_updateMoodImproving;
  global.InfoDet_updateImageNovelty = InfoDet_updateImageNovelty;
  global.InfoDet_updateHighSemanticImportance = InfoDet_updateHighSemanticImportance;
  global.InfoDet_updateConflictingSemantics = InfoDet_updateConflictingSemantics;
  global.InfoDet_updateTeacherLearning = InfoDet_updateTeacherLearning;
  global.InfoDet_updateOperatorIgnoring = InfoDet_updateOperatorIgnoring;
  global.InfoDet_updateOperatorIgnoringFromStimulus = InfoDet_updateOperatorIgnoringFromStimulus;
  global.InfoDet_updateDissatisfaction = InfoDet_updateDissatisfaction;
  global.InfoDet_updateMisunderstanding = InfoDet_updateMisunderstanding;
  global.InfoDet_updateDoubtInDefaultAutomatism = InfoDet_updateDoubtInDefaultAutomatism;
  global.InfoDet_updateDefense = InfoDet_updateDefense;
  global.InfoDet_updateFear = InfoDet_updateFear;
  global.InfoDet_updateAggression = InfoDet_updateAggression;
  global.InfoDet_updateHardProblem = InfoDet_updateHardProblem;
  global.InfoDet_updateOperatorAnswer = InfoDet_updateOperatorAnswer;
  global.InfoDet_updateSeriesWithoutEffect = InfoDet_updateSeriesWithoutEffect;

})(window);
