/* Abstractions
Neocortex images (_10_actions_image) form hierarchies of perception; terminal images are fixed in development. Loss of a recognizer is lifelong; compensation uses indirect recognition.

On comprehension, terminal images selected by orienting reflex hold attention to PFC; a clone forms that reactivates with parietal activation (mirror-like) but not vice versa. Rigid perception and action images get PFC clones; unlike the originals, clones are freely manipulable. We call those flexible images abstractions.

Episode rules store rigid perception/action; hippocampal reverberation links new neurons to parietal activity. When operating on abstractions, episodes can store pointers to abstractions — mental rules, including sequences of successful/failed thought steps; mental automatisms accrue alongside.

Effect enables hypotheses (“what if the apple flies?”) unavailable to rigid images. Episode rules can bind parietal and PFC (abstraction), e.g. stimulus → mental split → diagram effect, with failure traces.

Example A (abacus to numbers): sensory five beads → PFC “five” gestalt; teacher “add two” first motorizes, then becomes pure PFC transform without real abacus. Random cross-ops on clones yield creative (even absurd) composites — recorded as episodes.

Implementation: clone rigid perception/action on stimulus comprehension and episode write, passing salience into abstractions. Arrays start empty; each aware stimulus+action pair grows abstract perception/action records with semanticStructure, conditions, and averaged importance for passive-mode composition.
*/

(function (global) {
  'use strict';

  /**
   * Abstract image system stub (clone rigid perception/action).
   *
   * EP entry: only AbstractImages_cloneFromEpisodeFrame, from episodic_memory.closeLastFrame
   * after effect is computed (not when opening a new frame).
   *
   * ID rules:
   * - perceptionNodeId and stimulusImageId must be non-zero; else clonePerception returns 0 (no touch).
   * - actionImageId: truthy — cloneAction; 0 from incomplete-frame fill — skip action clone, but perception clone
   *   and meanImportance from effect still update.
   * - effect: EP contract — number [-10,+10]; coerced to 0 if not numeric (legacy data).
   *
   * Mental rules (mental_automatism.js): use abstractActionId || abstractPerceptionId, so with no action image
   * the perception-linked rule is averaged.
   *
   * semanticStructure — condition-keyed semantic frame (not FinalImage salience):
   * { frames: [ { perceptionNodeId, situationId, ruleKind, stimulusImageId, actionImageId, effect?, responseStimulusImageId? } ] }.
   * Condition key: (perception branch, situation branch). Slot: episodic / teacher / fantasy (fantasy from fantasy chain, does not override teacher).
   */

  /** Marker: closed EP frame; on conflict larger effect wins. */
  var RULE_KIND_EPISODIC = 'episodic';
  /** Marker: teacher rule (operator response); overrides episodic for same condition pair. */
  var RULE_KIND_TEACHER = 'teacher';
  /** Marker: rule from passive fantasy chain (sleep / info_new_abstract_semantic); does not override teacher. */
  var RULE_KIND_FANTASY = 'fantasy';

  // --- Data ---
  if (!Array.isArray(global.AbstractPerceptionImages)) global.AbstractPerceptionImages = [];
  if (!Array.isArray(global.AbstractActionImages)) global.AbstractActionImages = [];

  var nextAbstractPerceptionId = 1;
  var nextAbstractActionId = 1;

  // Indexes for fast update without duplicates.
  var byPerceptionKey = Object.create(null); // key = perceptionNodeId|stimulusImageId -> obj
  var byActionKey = Object.create(null);     // key = perceptionNodeId|actionImageId -> obj

  var absDirty = false;
  var lastSavedSig = '';

  function normalizeSemanticStructureForRecord(rec) {
    if (!rec) return;
    if (!rec.semanticStructure || typeof rec.semanticStructure !== 'object') {
      rec.semanticStructure = { frames: [] };
      return;
    }
    if (!Array.isArray(rec.semanticStructure.frames)) {
      rec.semanticStructure.frames = [];
    }
  }

  function classifyRuleKindFromEpisodeFrame(epFrame) {
    if (!epFrame) return null;
    var resp = epFrame.responseStimulusImageId != null ? parseInt(epFrame.responseStimulusImageId, 10) : 0;
    if (resp > 0) return RULE_KIND_TEACHER;
    return RULE_KIND_EPISODIC;
  }

  function buildSemanticRuleSnapshot(epFrame) {
    var kind = classifyRuleKindFromEpisodeFrame(epFrame);
    if (!kind || !epFrame) return null;
    var stim = epFrame.stimulusImageId != null ? parseInt(epFrame.stimulusImageId, 10) || 0 : 0;
    var act = epFrame.actionImageId != null ? parseInt(epFrame.actionImageId, 10) : 0;
    if (!act) act = null;
    var eff = epFrame.effect;
    if (typeof eff !== 'number' || isNaN(eff)) eff = null;
    var respOut = epFrame.responseStimulusImageId != null ? parseInt(epFrame.responseStimulusImageId, 10) : 0;
    return {
      perceptionNodeId: parseInt(epFrame.perceptionNodeId, 10) || 0,
      situationId: epFrame.situationId != null ? parseInt(epFrame.situationId, 10) || 0 : 0,
      ruleKind: kind,
      stimulusImageId: stim,
      actionImageId: act,
      effect: kind === RULE_KIND_TEACHER ? null : eff,
      responseStimulusImageId: respOut > 0 ? respOut : null,
      updatedAt: Date.now()
    };
  }

  function shouldReplaceSemanticRule(existing, incoming) {
    if (!incoming) return false;
    if (!existing) return true;
    if (incoming.ruleKind === RULE_KIND_TEACHER) return true;
    if (existing.ruleKind === RULE_KIND_TEACHER) return false;
    var ee = typeof existing.effect === 'number' && !isNaN(existing.effect) ? existing.effect : -Infinity;
    var ie = typeof incoming.effect === 'number' && !isNaN(incoming.effect) ? incoming.effect : -Infinity;
    return ie > ee;
  }

  /**
   * Add/update condition frame in abstraction semanticStructure from closed EP frame.
   * @param {Object} obj — AbstractPerceptionImages or AbstractActionImages record
   * @param {Object} epFrame — EP frame after closeLastFrame
   */
  function AbstractImages_upsertSemanticRuleFromEpisodeFrame(obj, epFrame) {
    if (!obj || !epFrame) return;
    var p = parseInt(epFrame.perceptionNodeId, 10) || 0;
    if (!p) return;
    var snap = buildSemanticRuleSnapshot(epFrame);
    if (!snap) return;
    normalizeSemanticStructureForRecord(obj);
    var frames = obj.semanticStructure.frames;
    var condP = snap.perceptionNodeId;
    var condS = snap.situationId;
    var idx = -1;
    for (var i = 0; i < frames.length; i++) {
      var fr = frames[i];
      if (!fr) continue;
      if ((fr.perceptionNodeId || 0) === condP && (fr.situationId || 0) === condS) {
        idx = i;
        break;
      }
    }
    if (idx === -1) {
      frames.push(snap);
      absDirty = true;
    } else if (shouldReplaceSemanticRule(frames[idx], snap)) {
      frames[idx] = snap;
      absDirty = true;
    }
  }

  function buildSemanticRuleSnapshotFantasy(epFrame) {
    if (!epFrame) return null;
    var p = parseInt(epFrame.perceptionNodeId, 10) || 0;
    if (!p) return null;
    var stim = epFrame.stimulusImageId != null ? parseInt(epFrame.stimulusImageId, 10) || 0 : 0;
    var act = epFrame.actionImageId != null ? parseInt(epFrame.actionImageId, 10) : 0;
    if (!act) act = null;
    var eff = epFrame.effect;
    if (typeof eff !== 'number' || isNaN(eff)) eff = 0;
    var respOut = epFrame.responseStimulusImageId != null ? parseInt(epFrame.responseStimulusImageId, 10) : 0;
    return {
      perceptionNodeId: p,
      situationId: epFrame.situationId != null ? parseInt(epFrame.situationId, 10) || 0 : 0,
      ruleKind: RULE_KIND_FANTASY,
      stimulusImageId: stim,
      actionImageId: act,
      effect: eff,
      responseStimulusImageId: respOut > 0 ? respOut : null,
      updatedAt: Date.now()
    };
  }

  /**
   * Fantasy plot frame → clone semanticStructure; does not overwrite teacher slot.
   * With existing episodic / fantasy frame averages effect and marks fantasy.
   *
   * @param {Object} obj — AbstractPerceptionImages or AbstractActionImages
   * @param {Object} epFrame — like EP frame (perceptionNodeId, situationId, stimulusImageId, actionImageId, effect, responseStimulusImageId)
   * @returns {boolean} true if slot changed or added
   */
  function AbstractImages_upsertSemanticRuleFromFantasyFrame(obj, epFrame) {
    if (!obj || !epFrame) return false;
    var snap = buildSemanticRuleSnapshotFantasy(epFrame);
    if (!snap) return false;
    normalizeSemanticStructureForRecord(obj);
    var frames = obj.semanticStructure.frames;
    var condP = snap.perceptionNodeId;
    var condS = snap.situationId;
    var idx = -1;
    for (var i = 0; i < frames.length; i++) {
      var fr = frames[i];
      if (!fr) continue;
      if ((fr.perceptionNodeId || 0) === condP && (fr.situationId || 0) === condS) {
        idx = i;
        break;
      }
    }
    if (idx === -1) {
      frames.push(snap);
      absDirty = true;
      return true;
    }
    var existing = frames[idx];
    if (existing.ruleKind === RULE_KIND_TEACHER) {
      return false;
    }
    var merged = Object.assign({}, existing, snap);
    var e1 = typeof existing.effect === 'number' && !isNaN(existing.effect) ? existing.effect : null;
    var e2 = typeof snap.effect === 'number' && !isNaN(snap.effect) ? snap.effect : null;
    if (e1 !== null && e2 !== null) {
      merged.effect = (e1 + e2) / 2;
    } else if (e2 !== null) {
      merged.effect = e2;
    } else if (e1 !== null) {
      merged.effect = e1;
    }
    merged.ruleKind = RULE_KIND_FANTASY;
    merged.stimulusImageId = snap.stimulusImageId;
    merged.actionImageId = snap.actionImageId;
    merged.responseStimulusImageId = snap.responseStimulusImageId;
    merged.updatedAt = Date.now();
    frames[idx] = merged;
    absDirty = true;
    return true;
  }

  function rebuildIndex() {
    byPerceptionKey = Object.create(null);
    byActionKey = Object.create(null);
    var arrP = global.AbstractPerceptionImages;
    for (var i = 0; i < arrP.length; i++) {
      var o = arrP[i];
      if (!o) continue;
      normalizeSemanticStructureForRecord(o);
      byPerceptionKey[String(o.perceptionNodeId) + '|' + String(o.stimulusImageId)] = o;
      if (typeof o.id === 'number' && o.id >= nextAbstractPerceptionId) nextAbstractPerceptionId = o.id + 1;
    }
    var arrA = global.AbstractActionImages;
    for (var j = 0; j < arrA.length; j++) {
      var a = arrA[j];
      if (!a) continue;
      normalizeSemanticStructureForRecord(a);
      byActionKey[String(a.perceptionNodeId) + '|' + String(a.actionImageId)] = a;
      if (typeof a.id === 'number' && a.id >= nextAbstractActionId) nextAbstractActionId = a.id + 1;
    }
  }

  rebuildIndex();

  function addUsefulnessSample(obj, effect) {
    if (!obj) return;
    if (typeof effect !== 'number' || isNaN(effect)) return;
    var c = typeof obj.count === 'number' ? obj.count : 0;
    var cur = typeof obj.meanImportance === 'number' ? obj.meanImportance : 0;
    obj.meanImportance = (cur * c + effect) / (c + 1);
    obj.count = c + 1;
    obj.lastUsedAt = Date.now();
  }

  function clonePerception(perceptionNodeId, stimulusImageId, effect) {
    // Zero ids invalid: such EP frames are invalid; do not create record.
    if (!perceptionNodeId || !stimulusImageId) return 0;
    var key = String(perceptionNodeId) + '|' + String(stimulusImageId);
    var obj = byPerceptionKey[key];
    if (!obj) {
      obj = {
        id: nextAbstractPerceptionId++,
        perceptionNodeId: perceptionNodeId,
        stimulusImageId: stimulusImageId, // rigid FinalImageId being cloned
        meanImportance: 0,
        count: 0,
        createdAt: Date.now(),
        lastUsedAt: Date.now(),
        semanticStructure: { frames: [] }
      };
      global.AbstractPerceptionImages.push(obj);
      byPerceptionKey[key] = obj;
    }
    addUsefulnessSample(obj, effect);
    absDirty = true;
    return obj.id;
  }

  function cloneAction(perceptionNodeId, actionImageId, effect) {
    if (!perceptionNodeId || !actionImageId) return 0;
    var key = String(perceptionNodeId) + '|' + String(actionImageId);
    var obj = byActionKey[key];
    if (!obj) {
      obj = {
        id: nextAbstractActionId++,
        perceptionNodeId: perceptionNodeId,
        actionImageId: actionImageId, // rigid ActionImageId being cloned
        meanImportance: 0,
        count: 0,
        createdAt: Date.now(),
        lastUsedAt: Date.now(),
        semanticStructure: { frames: [] }
      };
      global.AbstractActionImages.push(obj);
      byActionKey[key] = obj;
    }
    addUsefulnessSample(obj, effect);
    absDirty = true;
    return obj.id;
  }

  /**
   * Perception clone without effect averaging (L3, teacher): create if missing or bump lastUsedAt.
   */
  function ensurePerceptionAbstraction(perceptionNodeId, stimulusImageId) {
    if (!perceptionNodeId || !stimulusImageId) return null;
    var key = String(perceptionNodeId) + '|' + String(stimulusImageId);
    var obj = byPerceptionKey[key];
    if (obj) {
      obj.lastUsedAt = Date.now();
      absDirty = true;
      return obj;
    }
    obj = {
      id: nextAbstractPerceptionId++,
      perceptionNodeId: perceptionNodeId,
      stimulusImageId: stimulusImageId,
      meanImportance: 0,
      count: 0,
      createdAt: Date.now(),
      lastUsedAt: Date.now(),
      semanticStructure: { frames: [] }
    };
    global.AbstractPerceptionImages.push(obj);
    byPerceptionKey[key] = obj;
    absDirty = true;
    return obj;
  }

  /**
   * Action clone without effect averaging (L3, teacher).
   */
  function ensureActionAbstraction(perceptionNodeId, actionImageId) {
    if (!perceptionNodeId || !actionImageId) return null;
    var key = String(perceptionNodeId) + '|' + String(actionImageId);
    var obj = byActionKey[key];
    if (obj) {
      obj.lastUsedAt = Date.now();
      absDirty = true;
      return obj;
    }
    obj = {
      id: nextAbstractActionId++,
      perceptionNodeId: perceptionNodeId,
      actionImageId: actionImageId,
      meanImportance: 0,
      count: 0,
      createdAt: Date.now(),
      lastUsedAt: Date.now(),
      semanticStructure: { frames: [] }
    };
    global.AbstractActionImages.push(obj);
    byActionKey[key] = obj;
    absDirty = true;
    return obj;
  }

  /**
   * L3 / teacher: activate clones for current FinalImage and action image from rule; store teacher slot
   * in semanticStructure of both (key condition — current branch and consciousness situationId).
   *
   * @param {Object} params
   * @param {number} params.perceptionNodeId — branch node
   * @param {number} params.situationId
   * @param {number} params.actualStimulusImageId — current stimulus (FinalImageId)
   * @param {Object} params.teacherEpisodicFrame — frame from info_teacherEpisodicRuleForAction
   * @returns {{ abstractPerceptionId: number, abstractActionId: number }}
   */
  function AbstractImages_activateTeacherRuleOnAbstractions(params) {
    params = params || {};
    var branchId = parseInt(params.perceptionNodeId, 10) || 0;
    var situationId = parseInt(params.situationId, 10) || 0;
    var actualStim = parseInt(params.actualStimulusImageId, 10) || 0;
    var tf = params.teacherEpisodicFrame;
    if (!branchId || !actualStim || !tf) {
      return { abstractPerceptionId: 0, abstractActionId: 0 };
    }
    var odId = tf.actionImageId != null ? parseInt(tf.actionImageId, 10) : 0;
    if (!odId) {
      return { abstractPerceptionId: 0, abstractActionId: 0 };
    }

    var apObj = ensurePerceptionAbstraction(branchId, actualStim);
    var aaObj = ensureActionAbstraction(branchId, odId);

    var respRaw = tf.responseStimulusImageId != null ? parseInt(tf.responseStimulusImageId, 10) : 0;
    var eff = tf.effect;
    if (typeof eff !== 'number' || isNaN(eff)) eff = 0;

    var synth = {
      perceptionNodeId: branchId,
      situationId: situationId,
      stimulusImageId: actualStim,
      actionImageId: odId,
      effect: eff,
      responseStimulusImageId: respRaw > 0 ? respRaw : null
    };

    if (apObj) {
      AbstractImages_upsertSemanticRuleFromEpisodeFrame(apObj, synth);
    }
    if (aaObj) {
      AbstractImages_upsertSemanticRuleFromEpisodeFrame(aaObj, synth);
    }

    return {
      abstractPerceptionId: apObj && apObj.id ? apObj.id : 0,
      abstractActionId: aaObj && aaObj.id ? aaObj.id : 0
    };
  }

  /**
   * Perception clone semanticStructure entry exactly matching context (node, situation, current FinalImage).
   *
   * @param {Object} params — perceptionNodeId, situationId, actualStimulusImageId
   * @returns {Object|null} frame from frames with non-zero actionImageId or null
   */
  function AbstractImages_findRuleFrameMatchingContext(params) {
    params = params || {};
    var branchId = parseInt(params.perceptionNodeId, 10) || 0;
    var situationId = parseInt(params.situationId, 10) || 0;
    var actualStim = parseInt(params.actualStimulusImageId, 10) || 0;
    if (!branchId || !actualStim) return null;

    var arr = global.AbstractPerceptionImages;
    if (!Array.isArray(arr)) return null;

    var rec = null;
    for (var fi = 0; fi < arr.length; fi++) {
      var o = arr[fi];
      if (!o) continue;
      if ((o.perceptionNodeId || 0) !== branchId) continue;
      if ((o.stimulusImageId || 0) !== actualStim) continue;
      rec = o;
      break;
    }
    if (!rec) return null;
    normalizeSemanticStructureForRecord(rec);
    var frames = rec.semanticStructure.frames;
    for (var fj = 0; fj < frames.length; fj++) {
      var fr = frames[fj];
      if (!fr) continue;
      if ((fr.perceptionNodeId || 0) !== branchId) continue;
      if ((fr.situationId || 0) !== situationId) continue;
      if ((fr.stimulusImageId || 0) !== actualStim) continue;
      var aid = fr.actionImageId != null ? parseInt(fr.actionImageId, 10) : 0;
      if (!aid) continue;
      return fr;
    }
    return null;
  }

  /**
   * After operator response to automatism: if semanticStructure has a frame for (branch, situation, stimulus),
   * average meanImportance of perception and action clones with same EP frame effect (positive — strengthen, negative — weaken).
   *
   * @param {Object} params — perceptionNodeId, situationId, actualStimulusImageId, effect (number, usually [-10,+10])
   */
  function AbstractImages_applyEpisodeEffectToSemanticContextAbstractions(params) {
    params = params || {};
    var branchId = parseInt(params.perceptionNodeId, 10) || 0;
    var situationId = parseInt(params.situationId, 10) || 0;
    var actualStim = parseInt(params.actualStimulusImageId, 10) || 0;
    var effect = params.effect;
    if (typeof effect !== 'number' || isNaN(effect)) return;
    if (!branchId || !actualStim) return;

    var fr = AbstractImages_findRuleFrameMatchingContext({
      perceptionNodeId: branchId,
      situationId: situationId,
      actualStimulusImageId: actualStim
    });
    if (!fr) return;

    var pKey = String(branchId) + '|' + String(actualStim);
    var apObj = byPerceptionKey[pKey];
    if (apObj) {
      addUsefulnessSample(apObj, effect);
      absDirty = true;
    }
    var odId = fr.actionImageId != null ? parseInt(fr.actionImageId, 10) : 0;
    if (odId) {
      var aKey = String(branchId) + '|' + String(odId);
      var aaObj = byActionKey[aKey];
      if (aaObj) {
        addUsefulnessSample(aaObj, effect);
        absDirty = true;
      }
    }
  }

  /**
   * Main clone hook on EP write: called after frame close.
   * Frame effect by then is numeric in [-10, +10] (see episodic_memory.closeLastFrame).
   * @param {Object} frame - EP frame (perceptionNodeId, stimulusImageId, actionImageId, effect, ...)
   * @returns {{abstractPerceptionId:number, abstractActionId:number}}
   */
  function AbstractImages_cloneFromEpisodeFrame(frame) {
    if (!frame) return { abstractPerceptionId: 0, abstractActionId: 0 };
    var perceptionNodeId = frame.perceptionNodeId;
    var stimulusImageId = frame.stimulusImageId;
    var actionImageId = frame.actionImageId;
    var effect = frame.effect;
    if (typeof effect !== 'number' || isNaN(effect)) {
      effect = 0;
    }
    var ap = clonePerception(perceptionNodeId, stimulusImageId, effect);
    // actionImageId === 0 means no action image (close after timeout without reaction) — perception only.
    var aa = actionImageId ? cloneAction(perceptionNodeId, actionImageId, effect) : 0;

    var pKey = String(perceptionNodeId) + '|' + String(stimulusImageId);
    var apObj = byPerceptionKey[pKey];
    if (apObj) {
      AbstractImages_upsertSemanticRuleFromEpisodeFrame(apObj, frame);
    }
    if (aa) {
      var aKey = String(perceptionNodeId) + '|' + String(actionImageId);
      var aaObj = byActionKey[aKey];
      if (aaObj) {
        AbstractImages_upsertSemanticRuleFromEpisodeFrame(aaObj, frame);
      }
    }

    return { abstractPerceptionId: ap, abstractActionId: aa };
  }

  // -------------------- Save/restore (file + IndexedDB) --------------------

  function serializeState() {
    return {
      nextAbstractPerceptionId: nextAbstractPerceptionId,
      nextAbstractActionId: nextAbstractActionId,
      abstractPerceptionImages: global.AbstractPerceptionImages.slice(0),
      abstractActionImages: global.AbstractActionImages.slice(0)
    };
  }

  function applyState(state) {
    state = state || {};
    nextAbstractPerceptionId = parseInt(state.nextAbstractPerceptionId, 10);
    if (isNaN(nextAbstractPerceptionId) || nextAbstractPerceptionId < 1) nextAbstractPerceptionId = 1;
    nextAbstractActionId = parseInt(state.nextAbstractActionId, 10);
    if (isNaN(nextAbstractActionId) || nextAbstractActionId < 1) nextAbstractActionId = 1;

    global.AbstractPerceptionImages = Array.isArray(state.abstractPerceptionImages) ? state.abstractPerceptionImages.slice(0) : [];
    global.AbstractActionImages = Array.isArray(state.abstractActionImages) ? state.abstractActionImages.slice(0) : [];
    absDirty = false;
    try { lastSavedSig = JSON.stringify(serializeState()); } catch (e) { lastSavedSig = ''; }
    rebuildIndex();
  }

  var ABS_DB_NAME = 'BEAST_AbstractImages_DB';
  /** Do not decrease: IndexedDB VersionError if browser already has higher (e.g. after deploy). */
  var ABS_DB_VERSION = 2;
  var STORE = 'abstract_images_state';
  var KEY = 'abstract_images_singleton';
  /** Single open connection — as in actions_image / episodic_memory (openDB per put is unreliable). */
  var absDb = null;

  function openAbsDb() {
    if (!global.indexedDB || !global.IndexedDBModule || typeof global.IndexedDBModule.openDatabase !== 'function') {
      return Promise.reject(new Error('IndexedDB unavailable or module not loaded.'));
    }
    if (absDb) return Promise.resolve(absDb);
    return global.IndexedDBModule.openDatabase({
      dbName: ABS_DB_NAME,
      version: ABS_DB_VERSION,
      stores: [{ name: STORE, options: { keyPath: 'id' } }]
    }).then(function (db) {
      absDb = db;
      return db;
    });
  }

  function saveAbsStateToIndexedDB(state) {
    if (!global.IndexedDBModule) return Promise.reject(new Error('IndexedDBModule'));
    state = state || serializeState();
    function doPut(db) {
      return global.IndexedDBModule.put({
        db: db,
        storeName: STORE,
        value: { id: KEY, state: state, ts: Date.now() }
      });
    }
    if (absDb) {
      return doPut(absDb);
    }
    return openAbsDb().then(doPut);
  }

  /**
   * Write IndexedDB when absDirty; lastSavedSig and absDirty only after successful put.
   */
  function tryPersistAbstractImagesToIndexedDB() {
    if (!absDirty) return;
    if (!global.indexedDB || !global.IndexedDBModule) return;
    var state = serializeState();
    var sig = '';
    try {
      sig = JSON.stringify(state);
    } catch (e) {
      sig = '';
    }
    if (sig && sig === lastSavedSig) {
      absDirty = false;
      return;
    }
    saveAbsStateToIndexedDB(state)
      .then(function () {
        lastSavedSig = sig;
        absDirty = false;
        saveAbsStateToLocalStorage(state);
      })
      .catch(function (err) {
        if (typeof global.console !== 'undefined' && global.console.warn) {
          global.console.warn('abstract_images IndexedDB put', err);
        }
        saveAbsStateToLocalStorage(state);
      });
  }

  var LS_ABS_KEY = 'BEAST_AbstractImages_LS';

  function saveAbsStateToLocalStorage(state) {
    try {
      state = state || serializeState();
      global.localStorage.setItem(LS_ABS_KEY, JSON.stringify({ state: state, ts: Date.now() }));
    } catch (e) {}
  }

  function tryLoadFromLocalStorage() {
    try {
      var raw = global.localStorage.getItem(LS_ABS_KEY);
      if (!raw) return;
      var parsed = JSON.parse(raw);
      if (parsed && parsed.state) {
        var pLen = Array.isArray(global.AbstractPerceptionImages) ? global.AbstractPerceptionImages.length : 0;
        var aLen = Array.isArray(global.AbstractActionImages) ? global.AbstractActionImages.length : 0;
        if (pLen > 0 || aLen > 0) return;
        applyState(parsed.state);
      }
    } catch (e) {}
  }

  function loadFromIndexedDB() {
    openAbsDb()
      .then(function (db) {
        return global.IndexedDBModule.get({ db: db, storeName: STORE, key: KEY });
      })
      .then(function (record) {
        if (record && record.state) {
          var pLen = Array.isArray(global.AbstractPerceptionImages) ? global.AbstractPerceptionImages.length : 0;
          var aLen = Array.isArray(global.AbstractActionImages) ? global.AbstractActionImages.length : 0;
          if (pLen > 0 || aLen > 0) {
            return;
          }
          applyState(record.state);
          saveAbsStateToLocalStorage();
        } else {
          tryLoadFromLocalStorage();
        }
      })
      .catch(function (err) {
        if (typeof global.console !== 'undefined' && global.console.warn) {
          global.console.warn('abstract_images IndexedDB load', err);
        }
        tryLoadFromLocalStorage();
      });
  }

  loadFromIndexedDB();

  if (typeof global.registerIndexedDBSaver === 'function') {
    global.registerIndexedDBSaver(tryPersistAbstractImagesToIndexedDB);
  }

  // Flush after EP frame close — otherwise F5 before next pulse misses IndexedDB.
  if (global.window && global.window.addEventListener) {
    global.window.addEventListener('beforeunload', function () {
      if (absDirty) tryPersistAbstractImagesToIndexedDB();
    });
  }

  /**
   * L2, meaning goal: average meanImportance of abstractions whose semanticStructure has a rule with given action image.
   */
  function boostSemanticRulesForActionInArray(arr, actionImageId, deltaEffect) {
    var aid = parseInt(actionImageId, 10) || 0;
    if (!aid || typeof deltaEffect !== 'number' || isNaN(deltaEffect)) return;
    if (!Array.isArray(arr)) return;
    for (var i = 0; i < arr.length; i++) {
      var obj = arr[i];
      if (!obj) continue;
      normalizeSemanticStructureForRecord(obj);
      var frames = obj.semanticStructure.frames;
      var hit = false;
      for (var j = 0; j < frames.length; j++) {
        var fr = frames[j];
        if (!fr) continue;
        var a = fr.actionImageId != null ? parseInt(fr.actionImageId, 10) : 0;
        if (a === aid) {
          hit = true;
          break;
        }
      }
      if (hit) addUsefulnessSample(obj, deltaEffect);
    }
  }

  function AbstractImages_boostSemanticRulesForAction(actionImageId, deltaEffect) {
    boostSemanticRulesForActionInArray(global.AbstractPerceptionImages, actionImageId, deltaEffect);
    boostSemanticRulesForActionInArray(global.AbstractActionImages, actionImageId, deltaEffect);
    absDirty = true;
  }

  // --- Export ---
  global.AbstractImages_RULE_KIND_EPISODIC = RULE_KIND_EPISODIC;
  global.AbstractImages_RULE_KIND_TEACHER = RULE_KIND_TEACHER;
  global.AbstractImages_RULE_KIND_FANTASY = RULE_KIND_FANTASY;
  global.AbstractImages_ensurePerceptionAbstraction = ensurePerceptionAbstraction;
  global.AbstractImages_ensureActionAbstraction = ensureActionAbstraction;
  global.AbstractImages_cloneFromEpisodeFrame = AbstractImages_cloneFromEpisodeFrame;
  global.AbstractImages_upsertSemanticRuleFromEpisodeFrame = AbstractImages_upsertSemanticRuleFromEpisodeFrame;
  global.AbstractImages_upsertSemanticRuleFromFantasyFrame = AbstractImages_upsertSemanticRuleFromFantasyFrame;
  global.AbstractImages_activateTeacherRuleOnAbstractions = AbstractImages_activateTeacherRuleOnAbstractions;
  global.AbstractImages_findRuleFrameMatchingContext = AbstractImages_findRuleFrameMatchingContext;
  global.AbstractImages_applyEpisodeEffectToSemanticContextAbstractions = AbstractImages_applyEpisodeEffectToSemanticContextAbstractions;
  global.AbstractImages_boostSemanticRulesForAction = AbstractImages_boostSemanticRulesForAction;
  global.AbstractImages_serializeState = serializeState;
  global.AbstractImages_applyState = applyState;
  global.AbstractImages_flushIndexedDB = tryPersistAbstractImagesToIndexedDB;
})(window);

