/**
 * Fourth consciousness level (conscience_level_4).
 *
 * Implemented: gestalt level — resonance buffer, gestalt updates from EP, Gestalt_onConsciousnessTick tick
 * (see beast/_9_Conscience/gestalt.js, about_gestalt.md). Additional triggers (metaReflection, etc.) —
 * via conscience_level_4({ sourceCycle, reason }).
 *
 * Called from FO channel: conscience_level_4_runFromChannel(cycle) — after L3 in the same tick runOneStep.
 *
 * @param {Object} context
 * @param {Object} context.sourceCycle
 * @param {string} [context.reason]
 */
(function (global) {
  'use strict';

  function puls() {
    return typeof global.cpuls === 'number' ? global.cpuls : 0;
  }

  function appendCycleLog(cycle, text, force) {
    if (!cycle || typeof global.Consciousness_cycleAppendLog !== 'function') return;
    if (!force && !cycle.isMainCycle) return;
    global.Consciousness_cycleAppendLog(cycle, text, puls(), force ? { force: true } : undefined);
  }

  function conscience_level_4(context) {
    var cycle = context && context.sourceCycle;
    var reason = (context && context.reason) || '';
    if (!cycle) return;

    appendCycleLog(
      cycle,
      'L4: ' + (reason || 'manual call') + ' — extension (conscience_level_4.js).',
      false
    );

    // TODO: entry conditions (cycle flags / info picture), goal hierarchy, long plans — call subsystems separately.
  }

  /**
   * One FO-channel tick for L4 (from Consciousness_runOneStep *after* L3 in the same pulse).
   *
   * Gestalts at this level (implementation in beast/_9_Conscience/gestalt.js):
   *
   * 1) What runs here
   *    Resonance buffer and gestalt handling run only for the *main* running cycle
   *    (Gestalt_onConsciousnessTick itself skips background cycles). So resonance is not
   *    processed once per background process per pulse.
   *
   * 2) What already ran *before* L4 this tick
   *    At the start of L3, Gestalt_prepareContextForCycle ran: global.GestaltContextForLevel3 holds a snapshot
   *    of the open dominant by goal image (if a goal exists). L3 uses this only as context;
   *    rule search and motor follow their own paths.
   *
   * 3) What Gestalt_onConsciousnessTick(cycle) does
   *    • Binds the “leading” open gestalt to the main cycle goal (cycle.goalImageId or
   *      InfoPicture.currentGoalId in target mode): updates Gestalt_activeGestaltId and related fields.
   *    • If that gestalt is not yet “partial solution” (below PARTIAL), scans
   *      GestaltResonanceBuffer — FIFO of signatures of successful/closed EP frames. For each
   *      (signature × open gestalt) pair an analogy score is computed; above threshold —
   *      analogy insight, automatism list and analogyPool updates, possible status 0→1.
   *    • Calls Gestalt_prepareContextForCycle again: after possible resonance insights
   *      the context for the next pulse and for other modules is updated.
   *
   * 4) What this call does *not* do
   *    Closing an EP frame and writing a new signature to the buffer happens in episodic_memory.closeLastFrame →
   *    Gestalt_onEpisodeFeedbackClosed (not here). L4 does not start motor or replace L3.
   *
   * 5) Extensions
   *    Additional branches (meta-reflection, cycle flags) can be added below, next to conditional
   *    conscience_level_4({ sourceCycle, reason }) calls.
   */
  function conscience_level_4_runFromChannel(cycle) {
    if (!cycle || cycle.status !== 'running') return;
    if (typeof global.Gestalt_onConsciousnessTick === 'function') {
      try {
        global.Gestalt_onConsciousnessTick(cycle);
      } catch (e) {}
    }
    // Example future condition:
    // if (cycle.metaReflectionPending) { conscience_level_4({ sourceCycle: cycle, reason: 'meta' }); }
  }

  global.conscience_level_4 = conscience_level_4;
  global.conscience_level_4_runFromChannel = conscience_level_4_runFromChannel;
})(window);
