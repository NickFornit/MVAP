/**
 * Third level of consciousness (conscience_level_3).
 *
 * Action search by semantics and EP:
 *  — select getSemanticFramesForFinalImageId(current stimulus);
 *  — among semantic frames prioritizing current (well, emotion) pick most positive (max meanImportance);
 *  — EP frames: first perceptionNodeId + situationId, if no rule — perceptionNodeId only (situationId = 0);
 *  — from selection — best closed rule with effect > 0 and same stimulusImageId as current stimulus;
 *  — on find: info_automatismWithEpisodeFeedbackAndExpireCycle (EP frame wait, cycle expired). Response —
 *    conscience_level_2 from episodic_memory.closeLastFrame; finalize — conscience_level_2_finalizeAutomatismAnswerCycle.
 *  — if no such rule: teacher fallback — info_teacherEpisodicRuleForAction on branch default action image;
 *    mirrors “wants to play” / “wants to teach” (BasicMirrorActions 88, 89); on teacher frame —
 *    AbstractImages_activateTeacherRuleOnAbstractions (clones for current stimulus and action image, rule in semanticStructure),
 *    then info_automatismWithEpisodeFeedbackAndExpireCycle. Teacher search does not rank by effect;
 *    motor does not start if frame has numeric effect ≤ 0 (aligned with “importance” axis).
 *
 * L3 start: when default mental automatism ready (branch+situation) matches current semanticStructure frame
 * (same action image as mental image sourceActionImageId) — mental run first
 * (MentalAutomatizms_run), then motor automatism; no further L3 in that pass.
 * Else: on exact semanticStructure match — automatism with EP wait; then semantics+EP,
 * then teacher fallback.
 *
 * Called from consciousness channel: conscience_level_3_runFromChannel(cycle).
 *
 * Robustness and importance consistency (in code):
 *  — While cycle waits for EP frame close after automatism (`awaitingAutomatismEpisodeFeedback` without operator
 *    answer), full L3 pass is skipped: otherwise second/third channel call in same tick would hit “rule not found”.
 *    Cycle log lines — Consciousness_scheduler Consciousness_cycleAppendLog (often { force: true }: cycle after automatism is `expired`, else
 *    consciousness_dispatcher drops non-force entries).
 *  — Motor on semanticStructure frame (shortcut and mental path): only “positive salience” —
 *    teacher (`ruleKind === 'teacher'` or non-zero operator answer on action image), or episodic with numeric effect > 0.
 *  — Semantics+EP path: if best semantic frame meanImportance for stimulus < 0, motor from EP rule not started
 *    (stimulus semantics as demotivator).
 *
 * Attempt order in conscience_level_3: mental automatism → semanticStructure shortcut → episodic → teacher.
 *
 * @param {Object} context
 * @param {Object} context.sourceCycle
 * @param {string} [context.reason]
 */
(function (global) {
  'use strict';

  /**
   * Gate “automatism already running, waiting for EP”. Repeat L3 entry in same or next step must not
   * search again and reach “rule not found” — early exit in conscience_level_3 and
   * conscience_level_3_runFromChannel.runLevel3.
   */
  function conscience_level_3_shouldSkipBecauseAwaitingEpisodeFeedback(cycle) {
    return !!(cycle && cycle.awaitingAutomatismEpisodeFeedback && !cycle.automatismOperatorAnswerReceived);
  }

  /**
   * Single check of semanticStructure frame salience before motor (shortcut, mental path).
   * Matches abstract_images.js: teacher / operator answer on action image = trusted positive
   * signal; episodic slot without positive numeric effect does not authorize motor (zero/negative/no number).
   * @param {Object|null} fr — frame from AbstractImages_findRuleFrameMatchingContext
   */
  function conscience_level_3_semanticStructureFrameAllowsMotor(fr) {
    if (!fr) return false;
    if (fr.ruleKind === 'teacher') return true;
    var resp = fr.responseStimulusImageId != null ? parseInt(fr.responseStimulusImageId, 10) : 0;
    if (resp > 0) return true;
    var eff = fr.effect;
    if (typeof eff === 'number' && !isNaN(eff)) return eff > 0;
    return false;
  }

  function puls() {
    return typeof global.cpuls === 'number' ? global.cpuls : 0;
  }

  /**
   * Cycle debugLog via consciousness_dispatcher.Consciousness_cycleAppendLog(cycle, text, puls, opts).
   * Without force: main cycle only (as before). With force: also background and after expired cycle
   * (see cycleAppendLog in dispatcher: expired && !opts.force → skip).
   */
  function appendCycleLog(cycle, text, force) {
    if (!cycle || typeof global.Consciousness_cycleAppendLog !== 'function') return;
    if (!force && !cycle.isMainCycle) return;
    global.Consciousness_cycleAppendLog(cycle, text, puls(), force ? { force: true } : undefined);
  }

  function reasonLabel(reason) {
    switch (reason) {
      case 'level2_survival_inaccurate_no_rush':
        return 'InaccurateRule without urgent vitals — deferred planning';
      case 'level2_survival_cry':
        return 'Cry branch / no rules in EP';
      case 'dissatisfaction':
        return 'isDissatisfaction';
      default:
        return reason || '(no reason)';
    }
  }

  /**
   * Among SemanticObjectImportance frames for stimulus: if entries exist for current (well, emotion) — only those;
   * else full array. Returns object with maximum meanImportance.
   */
  function conscience_level_3_pickBestSemanticFrame(semFrames, well, emotionId) {
    if (!Array.isArray(semFrames) || !semFrames.length) return null;
    var narrowed = [];
    if (well && emotionId) {
      for (var i = 0; i < semFrames.length; i++) {
        var s = semFrames[i];
        if (s && s.wellNormaBad === well && s.emotionId === emotionId) narrowed.push(s);
      }
    }
    var pool = narrowed.length ? narrowed : semFrames;
    var best = null;
    var bestM = null;
    for (var j = 0; j < pool.length; j++) {
      var p = pool[j];
      if (!p) continue;
      var m = typeof p.meanImportance === 'number' && !isNaN(p.meanImportance) ? p.meanImportance : 0;
      if (best === null || m > bestM) {
        best = p;
        bestM = m;
      }
    }
    return best;
  }

  /**
   * Single motor start point for L3: create/default automatism + info_automatismWithEpisodeFeedbackAndExpireCycle.
   * All salience gates for chosen path (semanticStructure / EP / teacher) must pass before call.
   */
  function conscience_level_3_startAutomatismFromEpisodicRule(cycle, branchId, actionImageId) {
    if (!cycle || !branchId || !actionImageId) return false;
    var automatizmId = 0;
    if (typeof global.Automatizms_createAutomatizm === 'function') {
      automatizmId = global.Automatizms_createAutomatizm(branchId, actionImageId);
      if (automatizmId && typeof global.Automatizms_setDefaultAutomatizm === 'function') {
        global.Automatizms_setDefaultAutomatizm(automatizmId);
      }
    }
    if (typeof global.info_automatismWithEpisodeFeedbackAndExpireCycle === 'function') {
      return global.info_automatismWithEpisodeFeedbackAndExpireCycle(
        cycle,
        branchId,
        actionImageId,
        automatizmId,
        0,
        'L3: automatism from EP rule started, waiting for EP frame.'
      );
    }
    if (typeof global.Consciousness_cycleAppendLog === 'function') {
      global.Consciousness_cycleAppendLog(cycle, 'L3: info_automatismWithEpisodeFeedbackAndExpireCycle unavailable — motor not started.', puls(), { force: true });
    }
    return false;
  }

  /**
   * @returns {boolean} true if automatism started
   */
  function conscience_level_3_trySemanticEpisodicAutomatism(cycle) {
    if (!cycle || cycle.status !== 'running') return false;
    if (cycle.awaitingAutomatismEpisodeFeedback && !cycle.automatismOperatorAnswerReceived) return false;

    var cx = cycle.context || {};
    var branchId = parseInt(cx.branchId, 10) || 0;
    var actualStim = parseInt(cx.actual_stimul_ID, 10) || 0;
    var info = typeof global.Info_initIfNeeded === 'function' ? global.Info_initIfNeeded() : global.InfoPicture;
    if (!actualStim && info && info.stimulus && info.stimulus.finalImageId) {
      actualStim = info.stimulus.finalImageId;
    }
    var situationId = info && typeof info.situationId === 'number' ? info.situationId : 0;
    var well = global.BadNormWell || 0;
    var emotionId = 0;
    if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
      emotionId = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
    }

    if (!branchId || !actualStim) {
      appendCycleLog(cycle, 'L3: missing branchId or actual stimulus — skip rule search.');
      return false;
    }

    var semFrames = typeof global.getSemanticFramesForFinalImageId === 'function'
      ? global.getSemanticFramesForFinalImageId(actualStim) : [];
    if (!semFrames.length) {
      appendCycleLog(cycle, 'L3: no semantic frames for FinalImageId=' + String(actualStim) + '.');
      return false;
    }

    var semBest = conscience_level_3_pickBestSemanticFrame(semFrames, well, emotionId);
    if (!semBest) {
      appendCycleLog(cycle, 'L3: could not pick semantic frame.');
      return false;
    }

    appendCycleLog(cycle, 'L3: semantic frame with max meanImportance=' + String(semBest.meanImportance) +
      ' (well=' + String(semBest.wellNormaBad) + ', emotionId=' + String(semBest.emotionId) + ').');

    if (typeof global.info_bestEpisodicRule !== 'function') {
      appendCycleLog(cycle, 'L3: info_bestEpisodicRule unavailable.');
      return false;
    }

    var ruleBundle = global.info_bestEpisodicRule(branchId, situationId, {
      filterByStimulus: true,
      stimulusImageId: actualStim
    });
    var bestFrame = ruleBundle && ruleBundle.frame ? ruleBundle.frame : null;
    if (bestFrame) {
      appendCycleLog(cycle, 'L3: EP rule for stimulus ' + String(actualStim) + ', effect=' + String(bestFrame.effect) + ', action image=' + String(bestFrame.actionImageId) + '.');
    }

    if (!bestFrame || !bestFrame.actionImageId) {
      appendCycleLog(cycle, 'L3: no closed rule with positive effect for stimulus ' + String(actualStim) + '.');
      return false;
    }

    // Stimulus salience in semantic memory: negative — demotivator; do not override episodic effect
    // with positive rule if stimulus context is already “bad” by averaged importance.
    var semZ = typeof semBest.meanImportance === 'number' && !isNaN(semBest.meanImportance) ? semBest.meanImportance : null;
    if (semZ !== null && semZ < 0) {
      if (typeof global.Consciousness_cycleAppendLog === 'function') {
        global.Consciousness_cycleAppendLog(cycle, 'L3: stimulus semantics negative (meanImportance=' + String(semZ) + ') — not starting motor from EP.', puls(), { force: true });
      }
      return false;
    }

    return conscience_level_3_startAutomatismFromEpisodicRule(cycle, branchId, bestFrame.actionImageId);
  }

  /**
   * Teacher EP rule for branch default action image: search does not rank by effect; motor blocked if frame
   * has explicit numeric effect ≤ 0. Mirrors 88, 89 — provoke learning mode.
   * @returns {boolean}
   */
  function conscience_level_3_tryTeacherEpisodicAutomatism(cycle) {
    if (!cycle || cycle.status !== 'running') return false;
    if (cycle.awaitingAutomatismEpisodeFeedback && !cycle.automatismOperatorAnswerReceived) return false;

    var cx = cycle.context || {};
    var branchId = parseInt(cx.branchId, 10) || 0;
    if (!branchId) {
      appendCycleLog(cycle, 'L3 (teacher): no branchId.', true);
      return false;
    }

    var info = typeof global.Info_initIfNeeded === 'function' ? global.Info_initIfNeeded() : global.InfoPicture;
    var situationId = info && typeof info.situationId === 'number' ? info.situationId : 0;
    var actualStim = parseInt(cx.actual_stimul_ID, 10) || 0;
    if (!actualStim && info && info.stimulus && info.stimulus.finalImageId) {
      actualStim = info.stimulus.finalImageId;
    }

    var def = typeof global.Automatizms_getDefaultAutomatizmForBranch === 'function'
      ? global.Automatizms_getDefaultAutomatizmForBranch(branchId)
      : null;
    var odId = def && def.actionsImageId != null ? parseInt(def.actionsImageId, 10) : 0;
    if (!odId) {
      appendCycleLog(cycle, 'L3 (teacher): branch has no default action image — skip teacher rule search.', true);
      return false;
    }

    var bundle = typeof global.info_teacherEpisodicRuleForAction === 'function'
      ? global.info_teacherEpisodicRuleForAction(branchId, situationId, odId)
      : null;

    if (typeof global.activateStimulusForBasicMirrorActionId === 'function') {
      global.activateStimulusForBasicMirrorActionId(88);
      global.activateStimulusForBasicMirrorActionId(89);
    }

    if (!bundle || !bundle.frame || !bundle.frame.actionImageId) {
      appendCycleLog(cycle, 'L3 (teacher): no EP frame with operator answer for action image ' + String(odId) + '.', true);
      return false;
    }

    var tEff = bundle.frame.effect;
    if (typeof tEff === 'number' && !isNaN(tEff) && tEff <= 0) {
      if (typeof global.Consciousness_cycleAppendLog === 'function') {
        global.Consciousness_cycleAppendLog(cycle, 'L3 (teacher): EP frame with effect ≤ 0 — automatism start skipped.', puls(), { force: true });
      }
      return false;
    }

    if (actualStim && typeof global.AbstractImages_activateTeacherRuleOnAbstractions === 'function') {
      var ar = global.AbstractImages_activateTeacherRuleOnAbstractions({
        perceptionNodeId: branchId,
        situationId: situationId,
        actualStimulusImageId: actualStim,
        teacherEpisodicFrame: bundle.frame
      });
      if (ar && (ar.abstractPerceptionId || ar.abstractActionId)) {
        appendCycleLog(cycle, 'L3 (teacher): abstractions #' + String(ar.abstractPerceptionId || 0) + ' (perception) / #' +
          String(ar.abstractActionId || 0) + ' (action) — teacher slot in semanticStructure.', true);
      }
    } else {
      appendCycleLog(cycle, 'L3 (teacher): no current FinalImageId — skip abstractions and semanticStructure.', true);
    }

    appendCycleLog(cycle, 'L3 (teacher): ' + (bundle.exactRule ? 'full condition (branch+situation)' : 'branch only') +
      ', action image=' + String(bundle.frame.actionImageId) + ', operator answer FinalImageId=' +
      String(bundle.frame.responseStimulusImageId) + ' — starting automatism.', true);

    return conscience_level_3_startAutomatismFromEpisodicRule(cycle, branchId, bundle.frame.actionImageId);
  }

  /**
   * Ready mental automatism: semanticStructure frame matches mental image sourceActionImageId;
   * motor — only when frame has positive salience (see conscience_level_3_semanticStructureFrameAllowsMotor).
   * @returns {boolean}
   */
  function conscience_level_3_tryReadyMentalAutomatismThenMotor(cycle) {
    if (!cycle || cycle.status !== 'running') return false;
    if (cycle.awaitingAutomatismEpisodeFeedback && !cycle.automatismOperatorAnswerReceived) return false;

    var cx = cycle.context || {};
    var branchId = parseInt(cx.branchId, 10) || 0;
    var actualStim = parseInt(cx.actual_stimul_ID, 10) || 0;
    var info = typeof global.Info_initIfNeeded === 'function' ? global.Info_initIfNeeded() : global.InfoPicture;
    if (!actualStim && info && info.stimulus && info.stimulus.finalImageId) {
      actualStim = info.stimulus.finalImageId;
    }
    var situationId = info && typeof info.situationId === 'number' ? info.situationId : 0;

    if (!branchId || !actualStim) return false;
    if (typeof global.MentalAutomatizms_getDefaultForThemeSituation !== 'function') return false;
    if (typeof global.AbstractImages_findRuleFrameMatchingContext !== 'function') return false;

    var fr = global.AbstractImages_findRuleFrameMatchingContext({
      perceptionNodeId: branchId,
      situationId: situationId,
      actualStimulusImageId: actualStim
    });
    if (!fr || fr.actionImageId == null) return false;
    var frameOd = parseInt(fr.actionImageId, 10) || 0;
    if (!frameOd) return false;

    var ma = global.MentalAutomatizms_getDefaultForThemeSituation(branchId, situationId);
    if (!ma || !ma.mentalActionImageId) return false;

    if (typeof global.MentalActionImages_get !== 'function') return false;
    var mai = global.MentalActionImages_get(ma.mentalActionImageId);
    if (!mai) return false;
    var srcOd = parseInt(mai.sourceActionImageId, 10) || 0;
    if (!srcOd || srcOd !== frameOd) return false;

    if (!conscience_level_3_semanticStructureFrameAllowsMotor(fr)) {
      if (typeof global.Consciousness_cycleAppendLog === 'function') {
        global.Consciousness_cycleAppendLog(cycle, 'L3: mental automatism — semanticStructure frame not positive salience, motor not started.', puls(), { force: true });
      }
      return false;
    }

    if (typeof global.Consciousness_cycleAppendLog === 'function') {
      global.Consciousness_cycleAppendLog(cycle, 'L3: ready mental automatism #' + String(ma.id) + ' (MAI #' +
        String(ma.mentalActionImageId) + ') → motor action image ' + String(srcOd) + '.', puls(), { force: true });
    }

    if (typeof global.MentalAutomatizms_run === 'function') {
      global.MentalAutomatizms_run(ma.id);
    }

    return conscience_level_3_startAutomatismFromEpisodicRule(cycle, branchId, srcOd);
  }

  /**
   * Rule in perception clone semanticStructure for branch/situation/stimulus; motor when frame salience positive.
   * @returns {boolean}
   */
  function conscience_level_3_tryAbstractSemanticStructureShortcut(cycle) {
    if (!cycle || cycle.status !== 'running') return false;
    if (cycle.awaitingAutomatismEpisodeFeedback && !cycle.automatismOperatorAnswerReceived) return false;

    var cx = cycle.context || {};
    var branchId = parseInt(cx.branchId, 10) || 0;
    var actualStim = parseInt(cx.actual_stimul_ID, 10) || 0;
    var info = typeof global.Info_initIfNeeded === 'function' ? global.Info_initIfNeeded() : global.InfoPicture;
    if (!actualStim && info && info.stimulus && info.stimulus.finalImageId) {
      actualStim = info.stimulus.finalImageId;
    }
    var situationId = info && typeof info.situationId === 'number' ? info.situationId : 0;

    if (!branchId || !actualStim) return false;
    if (typeof global.AbstractImages_findRuleFrameMatchingContext !== 'function') return false;

    var fr = global.AbstractImages_findRuleFrameMatchingContext({
      perceptionNodeId: branchId,
      situationId: situationId,
      actualStimulusImageId: actualStim
    });
    if (!fr || fr.actionImageId == null) return false;

    var aid = parseInt(fr.actionImageId, 10) || 0;
    if (!aid) return false;

    if (!conscience_level_3_semanticStructureFrameAllowsMotor(fr)) {
      if (typeof global.Consciousness_cycleAppendLog === 'function') {
        global.Consciousness_cycleAppendLog(cycle, 'L3: semanticStructure present but frame salience not positive — motor shortcut skipped.', puls(), { force: true });
      }
      return false;
    }

    if (typeof global.Consciousness_cycleAppendLog === 'function') {
      global.Consciousness_cycleAppendLog(cycle, 'L3: perception semanticStructure — exact match (ruleKind=' + String(fr.ruleKind || '') +
        '), action image=' + String(aid) + '.', puls(), { force: true });
    }

    return conscience_level_3_startAutomatismFromEpisodicRule(cycle, branchId, aid);
  }

  function conscience_level_3(context) {
    var cycle = context && context.sourceCycle;
    var reason = (context && context.reason) || '';
    if (!cycle) return;

    if (conscience_level_3_shouldSkipBecauseAwaitingEpisodeFeedback(cycle)) {
      if (typeof global.Consciousness_cycleAppendLog === 'function') {
        global.Consciousness_cycleAppendLog(cycle, 'L3: full pipeline skipped — waiting for EP frame from earlier automatism.', puls(), { force: true });
      }
      return;
    }

    if (typeof global.Consciousness_cycleAppendLog === 'function' && cycle.isMainCycle) {
      var msg;
      switch (reason) {
        case 'level2_survival_inaccurate_no_rush':
          msg = 'L3: after L2 (InaccurateRule without urgent vitals).';
          break;
        case 'level2_survival_cry':
          msg = 'L3: after L2 (Cry branch / no rules in EP).';
          break;
        case 'dissatisfaction':
          msg = 'Trigger isDissatisfaction: opening third consciousness level.';
          break;
        default:
          msg = 'L3: ' + reasonLabel(reason) + '.';
      }
      global.Consciousness_cycleAppendLog(cycle, msg, puls());
    }

    if (conscience_level_3_tryReadyMentalAutomatismThenMotor(cycle)) {
      return;
    }

    if (conscience_level_3_tryAbstractSemanticStructureShortcut(cycle)) {
      return;
    }

    if (conscience_level_3_trySemanticEpisodicAutomatism(cycle)) {
      return;
    }

    if (conscience_level_3_tryTeacherEpisodicAutomatism(cycle)) {
      return;
    }

    // No path started motor; cycle stays without new automatism — onward L3 planning stub.
    if (typeof global.Consciousness_cycleAppendLog === 'function') {
      global.Consciousness_cycleAppendLog(cycle, 'L3: rule not found — continuation (stub).', puls(), { force: true });
    }
  }

  function conscience_level_3_runFromChannel(cycle) {
    if (!cycle || cycle.status !== 'running') return;

    /**
     * Gestalt (L4): before L3 pipeline sets global.GestaltContextForLevel3 — goal image and status
     * of open dominance if any. Does not change L3 branching.
     */
    if (typeof global.Gestalt_prepareContextForCycle === 'function') {
      try {
        global.Gestalt_prepareContextForCycle(cycle);
      } catch (eGestaltPrep) {}
    }

    /**
     * One conscience_level_3 call per reason; if prior reason in same tick already started automatism,
     * do not re-enter pipeline — log (Consciousness_cycleAppendLog with force).
     */
    function runLevel3(reason) {
      if (!cycle || cycle.status !== 'running') return;
      if (conscience_level_3_shouldSkipBecauseAwaitingEpisodeFeedback(cycle)) {
        if (typeof global.Consciousness_cycleAppendLog === 'function') {
          global.Consciousness_cycleAppendLog(cycle, 'L3: repeat entry skipped (reason=' + String(reason) + ') — already waiting for EP frame from automatism.', puls(), { force: true });
        }
        return;
      }
      conscience_level_3({ sourceCycle: cycle, reason: reason });
    }

    if (cycle.survivalDeferredLevel3Planning) {
      runLevel3('level2_survival_inaccurate_no_rush');
      cycle.survivalDeferredLevel3Planning = false;
    }

    if (cycle.survivalCryLevel3Pending) {
      runLevel3('level2_survival_cry');
      cycle.survivalCryLevel3Pending = false;
    }

    if (global.InfoPicture && global.InfoPicture.isDissatisfaction) {
      runLevel3('dissatisfaction');
    }
  }

  global.conscience_level_3 = conscience_level_3;
  global.conscience_level_3_runFromChannel = conscience_level_3_runFromChannel;
})(window);
