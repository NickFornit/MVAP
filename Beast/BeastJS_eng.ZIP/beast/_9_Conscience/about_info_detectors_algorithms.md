# Info detectors: activation, hold, and reset algorithms

This document lists all info-picture detectors, their numeric fields in `InfoPicture`, and three condition groups each:

- **Activation** — when the detector becomes active (field ≠ 0).
- **Hold** — when it stays active.
- **Reset** — when it must return to 0.

## General principles

- Detector values are **integers** (or floats for “levels”). Zero always means inactive / not detected.
- Each `InfoDet_updateXxx(...)` in `info_detectors.js`:
  - takes inputs from “information gathering” (vitals, contexts, EP effects, wait state, etc.);
  - **itself** decides whether to set nonzero or reset to 0 from the three conditions.
- Callers must pass **current data** on every material change (pulse, OR, EP frame close, wait start/end, etc.), even when “nothing happened” — so the detector can reset itself.

Detectors are loosely grouped as:

- **Snapshot (state)** — recomputed from current state (BadNormWell, BasicContextsActived, semantics, etc.).
- **Event** — capture a moment/fact in time (wait ended without answer, novelty jump, etc.); hold and reset matter especially.

---

## 1. Consciousness mode, Theme, Situation

### 1.1 Target consciousness mode (main cycle + “Mode” cell)

- **Source:** `thinkingMode` on the **main** cycle (`'passive'` \| `'target'`); updates via `InfoDet_updateTargetMode` / `Info_setMode` / insight. UI “Mode” reads `Consciousness_getMainCycleThinkingMode()`.
- **Activation:**  
  - When starting a reaction/automatism that needs target consciousness (e.g. OR with semantically salient stimulus, or consciousness cycle from `unsolved_problem`): `InfoDet_updateTargetMode(true)`.
- **Hold:**  
  - While target consciousness runs or automatism outcome evaluation (wait period) is active.
- **Reset:**  
  - When target cycle ends (problem solved or dropped) and no new target consciousness → `InfoDet_updateTargetMode(false)`.

### 1.2 Current Theme (`InfoPicture.themeId`, “Theme” cell)

- **Field:** `themeId`: `0` — none, >0 — theme image id from situation tree.
- **Activation:**  
  - On each `SituationsTree_onPerceptionTreeActivated()`, best ready theme image for current mode and `tree.BaseID/EmotionID/ActivityID`:
    - if a ready image exists (ready and score>0) → `InfoDet_updateCurrentTheme(themeId)`.
- **Hold:**  
  - While current (Base, Emotion, Activity) stays closest to that ready theme image.
- **Reset:**  
  - If on next activation:
    - no ready images (all count ≤ 3),  
    - or no ready image has nonzero score,  
    → `InfoDet_updateCurrentTheme(0)`.

### 1.3 Current Situation (`InfoPicture.situationId`, “Situation” cell)

- **Field:** `situationId`: `0` — none, >0 — situation image id from situation tree.
- **Activation:**  
  - In `SituationsTree_onPerceptionTreeActivated()`, detector components from info picture form a vector; among ready images pick best match:
    - if score>0 and ready=true → `InfoDet_updateCurrentSituation(situationId)`.
- **Hold:**  
  - While current detector set stays closest to that situation.
- **Reset:**  
  - On next call, if:
    - no ready situations for current mode,
    - or all scores are 0,  
    → `InfoDet_updateCurrentSituation(0)`.

---

## 2. Vitals and basic contexts

### 2.1 Critical vital (`InfoPicture.criticalVital`, “Crit. vital” cell)

- **Field:** `criticalVital`:  
  - `0` — none;  
  - `>0` — vital id with value >70 and maximum among all.
- **Activation:**  
  - In `updateImportanceMetrics(badVitals)` or `getActiveBasicContexts(cpuls)`:
    - scan `VitalsArr`, find vital with `value > 70` and max value;
    - if found → `InfoPicture.criticalVital = vitalId`.
- **Hold:**  
  - While on later calls some vital stays >70; on leader change, update id.
- **Reset:**  
  - If no vital >70 on next call → `criticalVital = 0`.

### 2.2 Bad state (`InfoPicture.badState`, “Bad” cell)

- **Field:** `badState`: `0` — not Bad, `1` — Bad (BadNormWell=1).
- **Activation:**  
  - In `InfoDet_updateBadState(lastBadNormWell, badNormWell)`:
    - if `badNormWell === 1` → `badState = 1`.
- **Hold:**  
  - While `BadNormWell` stays 1.
- **Reset:**  
  - On any `BadNormWell != 1` on next call → `badState = 0`.

### 2.3 Sudden deterioration (`InfoPicture.suddenChange`, “Sharp chg.” cell)

- **Field:** `suddenChange`:  
  - `0` — none;  
  - `1` — transition to Bad (per spec); may store finer level.
- **Activation:**  
  - In `InfoDet_updateBadState(lastBadNormWell, badNormWell)`:
    - if `lastBadNormWell !== 1` and `badNormWell === 1` → `suddenChange = 1`.
- **Hold:**  
  - Event detector: may hold `1` for one consciousness step or one/few pulses so the event is visible.
- **Reset:**  
  - On next call without another transition to Bad → `suddenChange = 0`.

### 2.4 Play mode (`InfoPicture.playMode`, “Play” cell)

- **Field:** `playMode`: `0` — off, `1` — Play basic context active.
- **Activation:**  
  - In `getActiveBasicContexts` after `BasicContextsActived`:
    - if context id == 11 (Play) → `playMode = 1`.
- **Hold:**  
  - While Play stays in `BasicContextsActived`.
- **Reset:**  
  - If Play not active on next call → `playMode = 0`.

### 2.5 Learning mode (`InfoPicture.learningMode`, “Learning” cell)

- **Field:** `learningMode`: `0` — off, `1` — learning mode active.
- **Activation:**  
  - In `InfoDet_updateLearningAndSearch(BasicContextsActived, VitalsArr)`:
    - if Curiosity context (id=12) **or** Interest vital `value > 70` → `learningMode = 1`.
- **Hold:**  
  - While either condition holds.
- **Reset:**  
  - If no Curiosity and Interest≤70 → `learningMode = 0`.

### 2.6 Search interest (`InfoPicture.searchInterest`, “Search” cell)

- **Field:** `searchInterest`: `0` — off, `1` — Interest vital >70.
- **Activation:**  
  - In `InfoDet_updateLearningAndSearch`:
    - if Interest vital (agreed id, e.g. 10) has `value > 70` → `searchInterest = 1`.
- **Hold:**  
  - While Interest>70.
- **Reset:**  
  - On next call with Interest≤70 → `searchInterest = 0`.

### 2.7 Fear (`InfoPicture.fear`, “Fear” cell)

- **Field:** `fear`: `0` — off, `1` — Fear context active.
- **Activation:**  
  - In `getActiveBasicContexts`:
    - if `BasicContextsActived` contains id=6 (Fear) → `fear = 1`.
- **Hold:**  
  - While Fear active.
- **Reset:**  
  - If id=6 missing on next call → `fear = 0`.

### 2.8 Aggression (`InfoPicture.aggression`, “Aggression” cell)

- **Field:** `aggression`: `0` — off, `1` — Aggression context active.
- **Activation:**  
  - If `BasicContextsActived` contains id=7 (Aggression) → `aggression = 1`.
- **Hold:**  
  - While Aggression active.
- **Reset:**  
  - If id=7 missing on next call → `aggression = 0`.

### 2.9 Defense (`InfoPicture.defense`, “Defense” cell)

- **Field:** `defense`: `0` — off, `1` — defense mode.
- **Activation:**  
  - If `fear == 1` or `aggression == 1` → `defense = 1`.
- **Hold:**  
  - While fear or aggression active.
- **Reset:**  
  - If `fear == 0` and `aggression == 0` → `defense = 0`.

---

## 3. Semantics and orientation reflex

### 3.1 Console stimulus (`InfoPicture.consoleStimulus`, “From panel” cell)

- **Field:** `consoleStimulus`:  
  - `0` — none;  
  - `>0` — `FinalImageId` of winning stimulus image.
- **Activation:**  
  - In `runOROnStimulusActivation` after choosing `winnerId`:
    - `InfoDet_updateConsoleStimulus(winnerId)`.
- **Hold:**  
  - May hold until next OR (last salient stimulus).
- **Reset:**  
  - On explicit no active stimuli or branch change policy:
    - `InfoDet_updateConsoleStimulus(0)`.

### 3.2 High semantic importance (`InfoPicture.highSemanticImportance`)

- **Field:** `0` — none; `>0` — mean `meanImportance` in current conditions.
- **Activation:**  
  - In `orientation_reflex.js` after `semWinner`:
    - if `meanImportance > 0` → `highSemanticImportance = meanImportance`.
- **Hold:**  
  - While winner and conditions (well, emotionId) unchanged.
- **Reset:**  
  - On new OR or no semantics → `highSemanticImportance = 0`.

### 3.3 High-importance object (`InfoPicture.highImportanceObject`)

- **Field:** `0` — none; `>0` — FinalImageId with |semantics|>5.
- **Activation:**  
  - In `orientation_reflex.js`:
    - if `Math.abs(meanImportance) > 5` → `highImportanceObject = winnerId`.
- **Hold:**  
  - While same stimulus and similar conditions.
- **Reset:**  
  - On stimulus/context change or |meanImportance| ≤ 5 → `highImportanceObject = 0`.

### 3.4 Image novelty (`InfoPicture.imageNovelty`)

- **Field:** `0` — none; `>0` — novelty above threshold.
- **Activation:**  
  - In `orientation_reflex.js` after `novelty`:
    - if `novelty > threshold` → `imageNovelty = novelty`.
- **Hold:**  
  - Until next OR.
- **Reset:**  
  - On new OR with `novelty ≤ threshold` → `imageNovelty = 0`.

### 3.5 Conflicting semantics (`InfoPicture.conflictingSemantics`)

- **Field:** `0` — none; `1` — conflicting semantics detected.
- **Activation:**  
  - Understanding analysis finds:
    - mean importance near 0 with large `samplesCount`,
    - materially positive and negative values across conditions.
  - Then → `conflictingSemantics = 1`.
- **Hold:**  
  - Until conflict resolves.
- **Reset:**  
  - If next analysis drops conflict signs → `conflictingSemantics = 0`.

---

## 4. Action effects and automatisms

### 4.1 Positive / negative action effect (`positiveActionEffect`, `negativeActionEffect`)

- **Fields:**  
  - `positiveActionEffect`: 0 or >0 — last positive effect magnitude;  
  - `negativeActionEffect`: 0 or <0 — last negative effect magnitude.
- **Activation:**  
  - In `closeLastFrame` (`episodic_memory.js`) after `last.effect`:
    - if `effect > 0` → `positiveActionEffect = effect`, `negativeActionEffect = 0`;
    - if `effect < 0` → `negativeActionEffect = effect`, `positiveActionEffect = 0`;
    - if `effect == 0` → both 0.
- **Hold:**  
  - Last closed EP frame value.
- **Reset:**  
  - On new frame without effect or explicit history clear → both 0.

### 4.2 Negative motor automatism effect (`negativeMotorEffect`)

- **Field:** `0` — none; `<0` — negative z during motor automatism wait.
- **Activation:**  
  - On motor automatism fire, measure `z = getDiffImportance()` during wait:
    - if `z < 0` → `negativeMotorEffect = z`.
- **Hold:**  
  - Until new z for another motor automatism.
- **Reset:**  
  - On next `z >= 0` or wait end without negative effect → `negativeMotorEffect = 0`.

### 4.3 Negative mental automatism effect (`negativeMentalEffect`)

- Same as motor but for automatisms started from consciousness:
  - if `z < 0` in wait → `negativeMentalEffect = z`,
  - else → 0.

### 4.4 Low automatism usefulness (`lowAutomatismUsefulness`)

- **Field:** `0` — none; |value| ≤ 1 — low usefulness.
- **Activation:**  
  - On each new `effectSample` into automatism usefulness:
    - if `0 < |effectSample| ≤ 1` → `lowAutomatismUsefulness = effectSample`.
- **Hold:**  
  - Until next sample with |effect| > 1.
- **Reset:**  
  - On `|effectSample| > 1` or `effectSample == 0` → `lowAutomatismUsefulness = 0`.

### 4.5 Suitable automatism found (`foundSuitableAutomatism`)

- **Field:** `0` — none; `1` — target-mode cycle found and uses an automatism.
- **Activation:**  
  - On choosing and starting a suitable automatism in target mode → `foundSuitableAutomatism = 1`.
- **Hold:**  
  - While cycle keeps using that automatism.
- **Reset:**  
  - On cycle end or automatism dropped → `foundSuitableAutomatism = 0`.

---

## 5. Operator wait and answers

### 5.1 No reaction to stimulus (`noReactionToStimulus`)

- **Field:** `0` — none; `1` — no reaction to stimulus recorded.
- **Activation:**  
  - In `EpisodicMemory_onPulse`, when `last.actionImageId === null` and wait expired without reaction → `noReactionToStimulus = 1`.
- **Hold:**  
  - Until new wait or explicit reset.
- **Reset:**  
  - On reaction or new wait start → `noReactionToStimulus = 0`.

### 5.2 Operator ignoring (`operatorIgnoring`)

- **Field:** `0` — none; `1` — operator ignored the action.
- **Activation:**  
  - In `EpisodicMemory_onPulse`, if `last.actionImageId != null` (there was reaction/automatism) and wait ended without response stimulus → `operatorIgnoring = 1`.
- **Hold:**  
  - Until response stimulus in a new wait.
- **Reset:**  
  - In `orientation_reflex.js`, on response stimulus during wait (`EpisodicMemory_isInWaitingPeriod`):
    - `operatorIgnoring = 0`.

### 5.3 Operator answer received (`operatorAnswerReceived`)

- **Field:** `0` — none; `1` — operator answer received.
- **Activation:**  
  - In `orientation_reflex.js`, OR during wait closing frame with response stimulus → `operatorAnswerReceived = 1`.
- **Hold:**  
  - Until next wait frame or explicit reset.
- **Reset:**  
  - On new wait start or after processing answer → `operatorAnswerReceived = 0`.

### 5.4 Active answer wait (`activeWaitingAnswer`)

- **Field:** `0` — none; `1` — automatism result wait active.
- **Activation:**  
  - On EP frame tied to automatism (especially mental from consciousness) → `activeWaitingAnswer = 1`.
- **Hold:**  
  - Until wait ends (answer or timeout).
- **Reset:**  
  - On frame close (with or without answer) → `activeWaitingAnswer = 0`.

### 5.5 Episode series without effect (`seriesWithoutEffect`)

- **Field:** `0` — none; >0 — length of last run of frames with `effect == 0`.
- **Activation / hold:**  
  - EP logic increments on each closed frame with `effect == 0`, clears on nonzero effect; on length change calls `InfoDet_updateSeriesWithoutEffect(length)`.
- **Reset:**  
  - On nonzero effect or explicit EP clear → `seriesWithoutEffect = 0`.

---

## 6. Consciousness and hard problems

These depend on consciousness cycle (`conscience_level_2`) and `unsolved_problem`.

### 6.1 Teacher learning (`teacherLearning`)

- **Field:** `0` — off; `1` — teacher-learning mode.
- **Activation:**  
  - When consciousness records an **unsolved problem** for an image that stays unsolved across repeated target-mode attempts.
- **Hold:**  
  - While “hand initiative to operator” mode runs: track actions and prompt answers.
- **Reset:**  
  - On problem solved (operator answer or internal solution) or step limit → `teacherLearning = 0`.

### 6.2 Dissatisfaction (`dissatisfaction`)

- **Field:** `0` — none; `1` — dissatisfaction present.
- **Activation:**  
  - When Calm context active, no salient stimuli, consciousness cycle finished passive without new ideas/changes.
- **Hold:**  
  - Until environment changes or new stimulus/interest.
- **Reset:**  
  - On new stimuli, context change, or target cycle start → `dissatisfaction = 0`.

### 6.3 Misunderstanding (`misunderstanding`)

- **Field:** `0` — none; `1` — misunderstanding state.
- **Activation:**  
  - If target-mode cycle ends **or** iteration steps exceed limit (e.g. 10) and problem unsolved.
- **Hold:**  
  - Until cycle restarted with different conditions or problem solved.
- **Reset:**  
  - On solve or restart with new configuration → `misunderstanding = 0`.

### 6.4 Doubt in default automatism (`doubtInDefaultAutomatism`)

- **Field:** `0` — none; `1` — doubt present.
- **Activation:**  
  - On level-2 start in target mode for a branch where default automatism gives ambiguous/unacceptable results.
- **Hold:**  
  - While level 2 considers alternatives to default automatism.
- **Reset:**  
  - On new default choice or confirmation of old → `doubtInDefaultAutomatism = 0`.

### 6.5 Hard problem (`hardProblem`)

- **Field:** `0` — none; >0 — difficulty level/counter for problem image.
- **Activation / hold:**  
  - Per image, count cases where:
    - `unsolved_problem` for that image,
    - target cycle ends without solve,
    - consciousness steps exceed threshold.
  - On each case increment and pass to `InfoDet_updateHardProblem(level)`.
- **Reset:**  
  - On solve (image marked solved) → level cleared, image removed from hard list, `hardProblem = 0`.

---

This document defines target algorithms for all info detectors; `InfoDet_update...` in `info_detectors.js` should follow these rules, and call sites (prepare.js, orientation_reflex.js, episodic_memory.js, conscience_level_2.js, etc.) should pass relevant parameters whenever state changes.
