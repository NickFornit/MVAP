/**
 * Conscious attention channel: stimulus awareness after the orienting reflex.
 *
 * stimuls_consciousness(context) — called from the OR. context may be a number (actual_stimul_ID)
 * or an object: actual_stimul_ID, branchId, novelty, significance,
 * samplesCount, pathArr, well, emotionId, activityID, isResponseStimulus.
 * OR novelty of conditions is passed for analysis and future automatism-start suitability.
 */
(function (global) {
  'use strict';

  // ========== "Thought silence" tuning (interrupt threshold for ongoing thought) ==========
  /**
   * Attention threshold ratio: effective significance of the new stimulus must be
   * ≥ (main cycle significance × this ratio). Higher = harder to interrupt, "quieter" thought.
   * Example: 1.5 = need 50% above main process significance.
   */
  var INTERRUPT_THRESHOLD_ATTENTION_RATIO = 1.5;

  /**
   * When info-picture theme/situation mismatches main cycle theme/situation at creation,
   * competing stimulus significance for comparison is multiplied by this factor (< 1 = harder to switch).
   * Not applied to stimuli from a connected EM frame chain with reactions, nor to ImportantProblem lowering.
   */
  var INTERRUPT_THEME_MISMATCH_COMPETITOR_FACTOR = 0.5;

  // Background stack: on interrupt by a more salient stimulus, current main cycle context is saved here;
  // dispatcher promotes next from stack when main finishes (promoteFromBackgroundStack).
  /** Interrupt queue: stack of cycle IDs that became background on interrupt (LIFO). */
  if (!Array.isArray(global.ConsciousnessBackgroundStack)) {
    global.ConsciousnessBackgroundStack = [];
  }
  var MAX_INTERRUPTED_STACK = 10;

  /**
   * Stimulus awareness (called from OR).
   *
   * First level:
   * 1) Semantic significance in current conditions (well, emotionId, activityID).
   *    If meanImportance < 0, search EM under broader conditions (parent tree node)
   *    for the same stimulus. If a frame with positive effect is found, take "positive"
   *    action from actionImageId, create/update automatism for current branch, run that action. Return.
   * 2) If step 1 did not run, check branch default automatism.
   *    If usefulness is not negative (>= 0 or count == 0), run its action.
   *    If usefulness < 0, level 1 defers (stub for level 2).
   *
   * On any automatism run: removeDelayedReflexesForBranch(branchId) and set
   * automatismRanForBranchIds[branchId] so genetic reflex from processGeneticReflexes does not fire after OR block ends.
   *
   * @param {number|Object} context — FinalImageId or OR context with branchId, novelty,
   *    orientationReflexWinner (if true, OR already picked this winner; thought-silence threshold skipped).
   */
  function stimuls_consciousness(context) {
    var actualId = 0;      // stimulus FinalImageId (0 = initial cycle without stimulus)
    var branchId = 0;      // current terminal tree node
    var well = 0;
    var emotionId = 0;
    var activityID = 0;    // FinalImageId for conditions (as in tree)
    var callImportance = 0; // significance of this FO call (competition between thought streams)

    if (typeof context === 'number') {
      if (context <= 0) return;
      actualId = context;
      branchId = (typeof global.PerceptionTree_getActiveTerminalNodeId === 'function')
        ? global.PerceptionTree_getActiveTerminalNodeId() : 0;
      well = global.BadNormWell || 0;
      if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
        emotionId = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
      }
      activityID = actualId;
    } else if (context && typeof context === 'object') {
      actualId = context.actual_stimul_ID;
      branchId = context.branchId != null
        ? context.branchId
        : ((typeof global.PerceptionTree_getActiveTerminalNodeId === 'function')
          ? global.PerceptionTree_getActiveTerminalNodeId() : 0);
      well = context.well != null ? context.well : (global.BadNormWell || 0);
      emotionId = context.emotionId != null ? context.emotionId : 0;
      activityID = context.activityID != null ? context.activityID : (actualId || 0);
      if (typeof context.significance === 'number') {
        callImportance = Math.abs(context.significance);
      }
    }
    var orWinner = !!(context && typeof context === 'object' && context.orientationReflexWinner === true);
    var vitalEmergency = !!(context && typeof context === 'object' && context.vitalEmergency === true);
    if (typeof branchId !== 'number' && (branchId == null || branchId === undefined)) return;

    // --- Thought-stream competition: see INTERRUPT_* constants at top ---
    var info = (typeof global.Info_initIfNeeded === 'function')
      ? global.Info_initIfNeeded()
      : (global.InfoPicture || null);
    var currentThinkingImportance = info && typeof info.thinkingImportance === 'number'
      ? info.thinkingImportance
      : 0;

    var mainForInterrupt = typeof global.Consciousness_getMainCycle === 'function'
      ? global.Consciousness_getMainCycle() : null;
    /** Thought silence and down-ranking weak stimuli vs main only while main is not expired. */
    var mainBlocksThoughtSilence = !!(mainForInterrupt && !mainForInterrupt.expired);
    var isMainExpired = !!(mainForInterrupt && mainForInterrupt.expired);
    var importantProblem = !!(info && info.ImportantProblem);
    var themeSituationMismatch = false;
    if (mainBlocksThoughtSilence && mainForInterrupt && info) {
      var mt = mainForInterrupt.createdThemeId != null ? mainForInterrupt.createdThemeId : 0;
      var ms = mainForInterrupt.createdSituationId != null ? mainForInterrupt.createdSituationId : 0;
      var it = info.themeId != null ? info.themeId : 0;
      var is = info.situationId != null ? info.situationId : 0;
      themeSituationMismatch = (mt !== it || ms !== is);
    }

    var episodicChainPriority = typeof global.EpisodicMemory_isStimulusEpisodicChainPriority === 'function' &&
      global.EpisodicMemory_isStimulusEpisodicChainPriority(actualId);

    var effectiveCallImportance = callImportance;
    if (mainBlocksThoughtSilence && !episodicChainPriority) {
      effectiveCallImportance *= (themeSituationMismatch ? INTERRUPT_THEME_MISMATCH_COMPETITOR_FACTOR : 1);
      if (importantProblem) {
        effectiveCallImportance *= 0.5;
      }
    }
    var ratio = (mainBlocksThoughtSilence && !episodicChainPriority)
      ? INTERRUPT_THRESHOLD_ATTENTION_RATIO
      : 1.0;
    var requiredMin = currentThinkingImportance * ratio;

    var skipImportanceCheck = !mainBlocksThoughtSilence || episodicChainPriority || orWinner || vitalEmergency;
    if (!skipImportanceCheck && currentThinkingImportance > 0 && effectiveCallImportance < requiredMin) {
      if (typeof global.show_alert === 'function') {
        var stimIdWeak = (context && typeof context.actual_stimul_ID === 'number') ? context.actual_stimul_ID : actualId;
        global.show_alert(
          'Stimulus FinalImageId=' + String(stimIdWeak) +
          ': stimulus significance ' + String(callImportance) +
          (themeSituationMismatch
            ? ', for comparison ×0.5 (theme/situation ≠ main cycle) → effective ' + String(effectiveCallImportance)
            : '') +
          '<br>Need ≥ ' + String(Math.round(requiredMin * 100) / 100) +
          ' (' + String(ratio * 100) + '% of main cycle significance ' + String(currentThinkingImportance) + (isMainExpired ? ', main expired' : '') + ').',
          1500
        );
      }
      return;
    }

    // Interrupt: demote current main (isMainCycle=false), push its id on interrupt stack.
    // Cycle stays in registry; dispatcher gives it a step every 5 pulses. When new main finishes,
    // promote interrupted cycles in order (pop stack).
    var createCycle = global.Consciousness_createCycle;
    var setMainCycle = global.Consciousness_setMainCycle;
    var getMainCycle = global.Consciousness_getMainCycle;
    if (typeof getMainCycle === 'function') {
      var main = getMainCycle();
      if (main && Array.isArray(global.ConsciousnessBackgroundStack) && global.ConsciousnessBackgroundStack.length < MAX_INTERRUPTED_STACK) {
        global.ConsciousnessBackgroundStack.push(main.id);
      }
    }

    var runContext = {
      actual_stimul_ID: actualId,
      branchId: branchId,
      well: well,
      emotionId: emotionId,
      activityID: activityID,
      significance: context && typeof context.significance === 'number' ? context.significance : callImportance
    };
    if (typeof createCycle !== 'function') return;
    var cycle = createCycle(runContext);
    if (!cycle) return;
    runContext.processId = cycle.id;
    if (typeof setMainCycle === 'function') setMainCycle(cycle.id);
    global.ConsciousnessCurrentProcessId = cycle.id;

    // New salient stimulus passes its significance to main cycle (weight may change during run).
    if (info && callImportance) {
      info.thinkingImportance = callImportance;
      info.thinkingProcessId = cycle.id;
      if (typeof global.Info_updateView === 'function') global.Info_updateView();
    }
    if (cycle && typeof callImportance === 'number' && callImportance > 0) {
      cycle.weight = callImportance;
    }

    if (typeof global.Consciousness_cycleAppendLog === 'function' && cycle && cycle.isMainCycle) {
      global.Consciousness_cycleAppendLog(cycle, 'FO: new main cycle #' + String(cycle.id) + ', FinalImageId=' + String(actualId) + ', branch=' + String(branchId) + '.', typeof global.cpuls === 'number' ? global.cpuls : 0);
    }

    if (typeof global.Consciousness_runElementary === 'function') {
      global.Consciousness_runElementary(cycle);
    }
  }

  /**
   * Elementary awareness pass (levels 1 and 2): one call per cycle context.
   * On create or promote from background. Ends with cycle.status 'finished' (automatism started)
   * or cycle.step = 1 and handoff to level 2.
   * @param {Object} cycle - registry cycle (cycle.context, cycle.id)
   */
  function runElementary(cycle) {
    if (!cycle || !cycle.context) return;
    if (cycle.status !== 'running') return;
    var ctx = cycle.context;
    var actualId = ctx.actual_stimul_ID != null ? ctx.actual_stimul_ID : 0;
    var branchId = ctx.branchId != null ? ctx.branchId : 0;
    var well = ctx.well != null ? ctx.well : (global.BadNormWell || 0);
    var emotionId = ctx.emotionId != null ? ctx.emotionId : 0;
    var activityID = ctx.activityID != null ? ctx.activityID : actualId;

    global.EpisodicMemory_pendingFeedbackAutomatizmId = 0;
    cycle.waitingFeedbackAutomatizmId = 0;

    var automatismStarted = false;

/////////////////////////////////// FIRST depth level of awareness //////////////////
// Find "positive" action from semantics + EM, then branch default automatism.
    if (actualId && branchId) {
      if (typeof global.Consciousness_cycleAppendLog === 'function' && cycle && cycle.isMainCycle) {
        global.Consciousness_cycleAppendLog(cycle, 'Level 1: semantics/EM analysis and automatism start (if possible).', typeof global.cpuls === 'number' ? global.cpuls : 0);
      }
      var semanticObj = (typeof global.getSemanticObjectFast === 'function' && well && (emotionId || activityID))
        ? global.getSemanticObjectFast(well, emotionId, activityID)
        : null;
      if (semanticObj && typeof semanticObj.meanImportance === 'number' && semanticObj.meanImportance < 0) {
        var parentNodeId = 0;
        if (typeof global.PerceptionTree_getNode === 'function') {
          var node = global.PerceptionTree_getNode(branchId);
          if (node && typeof node.parentId === 'number') parentNodeId = node.parentId;
        }
        if (parentNodeId && Array.isArray(global.Episodes)) {
          var bestActionImageId = null;
          var bestEffect = 0;
          for (var i = 0; i < global.Episodes.length; i++) {
            var f = global.Episodes[i];
            if (!f || f.perceptionNodeId !== parentNodeId || f.stimulusImageId !== actualId) continue;
            if (typeof f.effect !== 'number' || f.effect <= 0 || f.actionImageId == null) continue;
            if (bestActionImageId === null || f.effect > bestEffect) {
              bestActionImageId = f.actionImageId;
              bestEffect = f.effect;
            }
          }
          if (bestActionImageId != null) {
            if (typeof global.Consciousness_cycleAppendLog === 'function' && cycle && cycle.isMainCycle) {
              global.Consciousness_cycleAppendLog(cycle, 'Positive EM reaction found: running action image ' + String(bestActionImageId) + '.', typeof global.cpuls === 'number' ? global.cpuls : 0);
            }
            var automatizmIdEp = 0;
            if (typeof global.Automatizms_createAutomatizm === 'function') {
              automatizmIdEp = global.Automatizms_createAutomatizm(branchId, bestActionImageId);
              if (automatizmIdEp && typeof global.Automatizms_setDefaultAutomatizm === 'function') {
                global.Automatizms_setDefaultAutomatizm(automatizmIdEp);
              }
            }
            if (typeof global.info_automatismWithEpisodeFeedbackAndExpireCycle === 'function') {
              automatismStarted = global.info_automatismWithEpisodeFeedbackAndExpireCycle(
                cycle,
                branchId,
                bestActionImageId,
                automatizmIdEp,
                0,
                'Positive EM reaction found: running action image ' + String(bestActionImageId) + '.'
              );
            }
          }
        }
      }

      if (!automatismStarted) {
        var defaultAutomatizm = (typeof global.Automatizms_getDefaultAutomatizmForBranch === 'function')
          ? global.Automatizms_getDefaultAutomatizmForBranch(branchId) : null;
        if (defaultAutomatizm && defaultAutomatizm.actionsImageId) {
          var u = typeof defaultAutomatizm.usefulness === 'number' ? defaultAutomatizm.usefulness : 0;
          var c = typeof defaultAutomatizm.count === 'number' ? defaultAutomatizm.count : 0;
          if (!(c > 0 && u < 0)) {
            if (typeof global.Consciousness_cycleAppendLog === 'function' && cycle && cycle.isMainCycle) {
              global.Consciousness_cycleAppendLog(cycle, 'Branch default automatism: running action image ' + String(defaultAutomatizm.actionsImageId) + '.', typeof global.cpuls === 'number' ? global.cpuls : 0);
            }
            if (typeof global.info_automatismWithEpisodeFeedbackAndExpireCycle === 'function') {
              automatismStarted = global.info_automatismWithEpisodeFeedbackAndExpireCycle(
                cycle,
                branchId,
                defaultAutomatizm.actionsImageId,
                defaultAutomatizm.id,
                0,
                'Branch default automatism: running action image ' + String(defaultAutomatizm.actionsImageId) + '.'
              );
            }
          }
        }
      }
    }

/////////////////////////////////// SECOND depth level of awareness //////////////////
// If level 1 did not start automatism, record problem and hand to level 2.
    /*
     * Phase: wait for automatism feedback (automatism started from L1).
     *
     * Waiting event: cycle stays running, step = 1, awaitingAutomatismEpisodeFeedback = true,
     * until EM yields result (operator answer in waiting window, etc.). Episodic memory and
     * info picture bind cycle to automatism (EpisodicMemory_waitingAutomatismCycleId, activeWaitingAnswer).
     *
     * Start + wait: info_automatismWithEpisodeFeedbackAndExpireCycle — cycle immediately expired and not main;
     * operator answer pulls conscience_level_2 from episodic_memory.closeLastFrame. Finalize:
     * conscience_level_2_finalizeAutomatismAnswerCycle (clear awaiting, isOperatorAnswerReceived, etc.).
     */
    if (automatismStarted) {
      return;
    }

    global.unsolved_problem = actualId;
    if (typeof global.Info_setProblemFromUnsolved === 'function') global.Info_setProblemFromUnsolved(actualId);
    // Doubt default automatism: L1 could not start automatism → L2.
    if (typeof global.InfoDet_updateDoubtInDefaultAutomatism === 'function') {
      global.InfoDet_updateDoubtInDefaultAutomatism(true);
    }
    if (typeof global.Consciousness_cycleAppendLog === 'function' && cycle && cycle.isMainCycle) {
      global.Consciousness_cycleAppendLog(cycle, 'Automatism not started. Level 2: unresolved problem and goal choice.', typeof global.cpuls === 'number' ? global.cpuls : 0);
    }
    if (typeof global.conscience_level_2 === 'function') {
      global.conscience_level_2({
        actualId: actualId,
        branchId: branchId,
        well: well,
        emotionId: emotionId,
        activityID: activityID,
        sourceContext: cycle.context,
        sourceCycle: cycle
      });
    }
    cycle.step = 1;
  }

  /**
   * Local signature of passive fantasy progress for background cycle (no global info picture write).
   */
  function passiveFantasyLocalSig(cycle) {
    var plot = cycle && cycle.fantazmingPlot;
    var ch = plot && plot.chain ? plot.chain.length : 0;
    var last = plot && plot.lastGeneratedActionId != null ? plot.lastGeneratedActionId : 0;
    var fa = cycle && Array.isArray(cycle.fantasizmArr) ? cycle.fantasizmArr.length : 0;
    return String(ch) + '|' + String(last) + '|' + String(fa);
  }

  /**
   * One thought-cycle step (for dispatcher). Each pulse for main cycle.
   * step === 0 handled by elementary pass on create/promote; here — thought steps.
   *
   * If cycle.thinkingMode === 'passive', levels 3–4 skipped: only info_fantasizming.
   * Main: anti-stagnation via info picture signature; background: local plot (fantazmingPlot / fantasizmArr).
   *
   * @param {Object} cycle
   */
  function runOneStep(cycle) {
    if (!cycle || cycle.status !== 'running') return;
    if (cycle.step === 0) return;
    if (cycle.step >= 1) {
      // After automatism, cycle waits for EM frame; operator stimulus closes frame,
      // sets automatismOperatorAnswerReceived. Info: isOperatorAnswerReceived.
      // Until automatismAnswerLevel2Done, each pulse may hit here — real handling once inside conscience_level_2.
      if (cycle.awaitingAutomatismEpisodeFeedback && cycle.automatismOperatorAnswerReceived && !cycle.automatismAnswerLevel2Done) {
        var inf = global.InfoPicture;
        // Double check: cycle flag (from EM) + info flag (operator answer in UI/detectors).
        if (inf && inf.isOperatorAnswerReceived && typeof global.conscience_level_2 === 'function') {
          if (typeof global.Consciousness_cycleAppendLog === 'function' && cycle.isMainCycle) {
            global.Consciousness_cycleAppendLog(cycle, 'FO runOneStep: operator answer received — enter L2 (pipeline).', typeof global.cpuls === 'number' ? global.cpuls : 0);
          }
          var cx = cycle.context || {};
          global.conscience_level_2({
            sourceCycle: cycle,
            actualId: cx.actual_stimul_ID,
            branchId: cx.branchId,
            well: cx.well,
            emotionId: cx.emotionId,
            activityID: cx.activityID,
            // Only isOperatorAnswerReceived block at start of conscience_level_2; goals/ImportantProblem untouched here.
            _operatorAnswerCycleOnly: true
          });
        }
        // Always return for waiting cycle: do not run L3+ same tick.
        return;
      }

      // Waiting for EM answer without answer yet — skip L3–4 (avoid rule search every pulse).
      if (cycle.awaitingAutomatismEpisodeFeedback && !cycle.automatismOperatorAnswerReceived) {
        return;
      }

      // --- Passive thinking mode — antagonist to target L3–4 pipeline.
      // Stored on cycle, not InfoPicture. Main writes fantasy plot to info; background only
      // fantasizmArr + fantazmingPlot on cycle (see info_fantasizming).
      if (cycle.thinkingMode === 'passive') {
        var sigBefore;
        var sigAfter;
        if (cycle.isMainCycle) {
          var sigGet = global.Consciousness_getInfoPictureSignature;
          sigBefore = typeof sigGet === 'function' ? sigGet() : '';
          if ((cycle.passiveFantasyNoChangeStreak || 0) >= 3 && sigBefore === cycle.passiveFantasyLastSig) {
            return;
          }
          if (typeof global.info_fantasizming === 'function') {
            global.info_fantasizming(cycle);
          }
          sigAfter = typeof sigGet === 'function' ? sigGet() : '';
        } else {
          sigBefore = passiveFantasyLocalSig(cycle);
          if ((cycle.passiveFantasyNoChangeStreak || 0) >= 3 && sigBefore === cycle.passiveFantasyLastSig) {
            return;
          }
          if (typeof global.info_fantasizming === 'function') {
            global.info_fantasizming(cycle);
          }
          sigAfter = passiveFantasyLocalSig(cycle);
        }
        if (sigBefore === sigAfter) {
          cycle.passiveFantasyNoChangeStreak = (cycle.passiveFantasyNoChangeStreak || 0) + 1;
        } else {
          cycle.passiveFantasyNoChangeStreak = 0;
        }
        cycle.passiveFantasyLastSig = sigAfter;
        return;
      }

/////////////////////////////////// THIRD depth level //////////////////
// Tick conditions — conscience_level_3.js (conscience_level_3_runFromChannel).
      if (typeof global.conscience_level_3_runFromChannel === 'function') {
        global.conscience_level_3_runFromChannel(cycle);
      }

/////////////////////////////////// FOURTH depth level //////////////////
// Stub tick — conscience_level_4.js (conscience_level_4_runFromChannel).
      if (typeof global.conscience_level_4_runFromChannel === 'function') {
        global.conscience_level_4_runFromChannel(cycle);
      }
    }
  }

  global.Consciousness_runElementary = runElementary;
  global.Consciousness_runOneStep = runOneStep;

  /**
   * Background variant of awareness.
   * Invoked when a new, more salient stimulus interrupts the current main cycle.
   * This stub only logs; real logic to be added separately.
   */
  function stimuls_consciousness_background(context) {
    if (!context) return;
    if (global.console && typeof global.console.log === 'function') {
      global.console.log('stimuls_consciousness_background invoked', context);
    }
  }

  global.stimuls_consciousness = stimuls_consciousness;
  global.stimuls_consciousness_background = stimuls_consciousness_background;
})(window);
