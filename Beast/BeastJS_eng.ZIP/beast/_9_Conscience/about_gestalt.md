# Gestalt and level 4 — full description (BEAST)

Full theory and project documentation. Executable logic and data structures live in `gestalt.js`; this file is a reading and editing guide without parsing only sources.

---

## 1. Theory

In psychology, “gestalt” is a holistic situation image tending toward closure. In BEAST, a gestalt is a persistent record of an **open task**: link “goal image ↔ attempts ↔ progress.” It is not a copy of an episodic memory frame or a single EP rule — it is a **dominant** that can outlive one consciousness cycle and guides meta-level (level 4) until the task is dropped or generalized into stable experience.

**Why a separate entity**

- EP records past events; gestalt records an **open** problem and accumulated solution hypotheses (automatism ids, status).
- Level 3 handles “here and now”; level 4 **holds** the task in the background, matches it to success in other cycles, and narrows uncertainty.

Central phenomenon — **insight** (section 2 below).

---

## 2. Insights

### 2.1 What counts as insight in BEAST

An insight is an **event** (not only a `status` number change) where the system links the **gestalt goal image** to a **concrete solution candidate** so the task becomes actionable — up to EP verification.

### 2.2 Insight kinds

1. **Local** — inside the owner cycle.
2. **Cross-cycle / analogical** — success signature from another cycle resonates with the gestalt (see resonance buffer in `gestalt.js`).
3. **On feedback** — after closing an EP frame (`Gestalt_onEpisodeFeedbackClosed`).

### 2.3 Phases (α–ε)

See comments in `gestalt.js` and fields `lastInsightKind`, `insightChainCount`.

---

## 3. Data model

| Field | Meaning |
|------|--------|
| `id` | Record id |
| `problemTreeId` | Problem-tree node / branch (often `perceptionNodeId`) |
| `situationId` | Info-picture situation |
| `goalImageId` | Goal image (uniqueness among open — see code) |
| `automatismIds` | Tried automatisms |
| `status` | 0…4 |
| `lastInsightPuls`, `lastInsightKind`, `insightChainCount` | Insight accounting |
| `analogyPool` | Tail of analogy proposals (bounded size) |

---

## 4. Statuses

- **0** — created, no stable solution.
- **1** — started (candidates, including after resonance).
- **2** — partial (positive EP feedback, branch/situation refined).
- **3** — successful closure (strong positive effect in implementation — threshold in code).
- **4** — archive / inactive (reserved).

---

## 5. Implemented structures (code)

### 5.1 `GestaltResonanceBuffer`

FIFO queue of signatures of successful/closed episodes (after `closeLastFrame`). Each entry: `id`, `atPuls`, `sourceCycleId`, `goalImageId`, `problemTreeId`, `situationId`, `perceptionNodeId`, `automatismId`, `actionImageId`, `effect`, `kind`. Max length is a constant in `gestalt.js`.

### 5.2 Assembly (analogyPool)

Open gestalt accumulates buffer match records (`score`); detailed “gestalt assembly” and simulation — extension area (TODOs marked in code).

---

## 6. Integration points

| Location | Role |
|---------|------|
| `conscience_level_3_runFromChannel` | `Gestalt_prepareContextForCycle` — context for level 3 before pipeline |
| `conscience_level_4_runFromChannel` | `Gestalt_onConsciousnessTick` — resonance, leading gestalt |
| `episodic_memory.closeLastFrame` | `Gestalt_onEpisodeFeedbackClosed` — feedback, closure, buffer fill |

---

## 7. Alignment with consciousness levels

- Levels 1–3 are **not** rewritten: only context prep calls and logs are added.
- Gestalt **does not** drive motor by itself in this iteration: only statuses, buffer, context for later ticks.

---

## 8. Operator UI (`index.html`, `informing.js`)

- In **“Information picture:”** header row, after the “situations” indicator, badge **`gest: N`** (`#infoGestaltsIndicator`), style like “goals:”, “auto:”, etc.
- **`Info_updateView`** refreshes `N` and tooltip (record count and resonance buffer length).
- Click → **`Info_showGestaltsList`** — gestalt id list; by id → **`Info_showGestaltDetail`** (links to goal image, branch, situation, automatisms, JSON `analogyPool`).

---

*If the contract changes, update `beast/about_global_variables.md` and as needed `PROJECT_STATE_FOR_NEW_CHAT.md` and `beast/_9_Conscience/about_conscience.md`.*

**See also:** level 2 ↔ 4 adaptivity wiring — `about_adaptivity_levels_2_4.md`.
