/**
 * Thought-cycle dispatcher (after OLD_CODE/GO brain/psychic understanding.go + understanding_cycle.go).
 * One cycle = one thought process with a unique ID. Each pulse the dispatcher gives the main cycle
 * one runOneStep; background cycles run less often. Recursive FO calls are replaced by iterative execution
 * via the cycle registry and dispatcher.
 */
(function (global) {
  'use strict';

  /**
   * Count completed thought cycles (expired main or finished).
   * When ConsciousnessFinCyclesTotal > 100 sleep_mode may enable sleep even with critical vitals (contexts overridden in prepare).
   */
  function notifyFinCycleCompleted() {
    global.ConsciousnessFinCyclesTotal = (typeof global.ConsciousnessFinCyclesTotal === 'number' ? global.ConsciousnessFinCyclesTotal : 0) + 1;
    if (typeof global.SleepMode_tryAutoAfterFinCycles === 'function') {
      global.SleepMode_tryAutoAfterFinCycles();
    }
  }

  /**
   * Max cycles in registry (memory of past thoughts).
   * If over MAX_CYCLES, on new cycle remove oldest with expired=true.
   * Simple alternative to competitive lateral inhibition.
   */
  var MAX_CYCLES = 100;

  /** Creation order (always unique) */
  var curCycleOrder = 0;

  /** Cycle registry: id -> cycleInfo */
  if (typeof global.ConsciousnessCycles !== 'object' || global.ConsciousnessCycles === null) {
    global.ConsciousnessCycles = Object.create(null);
  }

  /** Next cycle id */
  if (typeof global.ConsciousnessProcessNextId !== 'number' || global.ConsciousnessProcessNextId <= 0) {
    global.ConsciousnessProcessNextId = 1;
  }

  /** Current main (conscious) cycle id */
  if (typeof global.ConsciousnessCurrentProcessId !== 'number') {
    global.ConsciousnessCurrentProcessId = 0;
  }

  /**
   * Whether main cycle may modify the info picture.
   * Dispatcher sets false before a background cycle step.
   */
  if (typeof global.ConsciousnessCanModifyInfo !== 'boolean') {
    global.ConsciousnessCanModifyInfo = true;
  }

  /** First main cycle id after page load (conditional auto-log). */
  if (typeof global.ConsciousnessFirstMainCycleId !== 'number') {
    global.ConsciousnessFirstMainCycleId = 0;
  }
  /** See stimuls_ui / OrientationReflex_getOrReadinessForFinalImageId; set on 2nd pulse. */
  if (typeof global.OrientationReflex_anyStimulusReadyForOr !== 'boolean') {
    global.OrientationReflex_anyStimulusReadyForOr = false;
  }

  /**
   * Thought cycle shape (like cycleInfo in Go).
   * @typedef {Object} CycleInfo
   * @property {number} id
   * @property {number} order - creation order
   * @property {boolean} isMainCycle
   * @property {string} status - 'running' | 'finished' | 'cancelled'
   * @property {number} step - 0 = elementary pass done, 1+ = thought
   * @property {number} count - runOneStep invocations (background steps are rarer)
   * @property {number} birthPuls - global.cpuls at creation
   * @property {number} weight - significance (pick main when another ends)
   * @property {Object} context
   * @property {number} createdAt
   * @property {number} lastPuls
   * @property {boolean} expired - kept as memory
   * @property {number} noInfoChangeStreak - main: consecutive iterations without info picture change
   * @property {string} lastInfoSig
   * @property {Array<Object>} events
   * @property {number} createdThemeId
   * @property {number} createdSituationId
   * @property {string} thinkingMode - 'target' | 'passive' (not stored in info picture)
   * @property {number} goalImageId - GoalImagesLife; passive → 0; target → currentGoalId
   * @property {number} waitingFeedbackAutomatizmId - automatism from FO L1; EM frame effect pending (0 = none)
   * @property {number} lastGestaltConsciencePuls - last L4/gestalt tick pulse for this cycle
   * @property {boolean} passiveWorkAfterGestaltExpire - expired same pulse as gestalt stagnation → passive mode
   * @property {Array<Object>} fantasizmArr - EM frame snapshots; synced with info_fantasizming
   * @property {boolean} fantasizmPassiveFillStarted - reserved
   * @property {Object} fantazmingPlot - { chain, lastGeneratedActionId }; chain links { fromStimulusId, actionImageId, episodeIndex, effect }
   * @property {number} currentFantazmingStimulus - debug/UI focus
   * @property {number} passiveFantasyNoChangeStreak - passive steps without signature change (anti-stagnation)
   * @property {string} passiveFantasyLastSig - signature after last passive runOneStep
   */
  function snapshotGoalImageIdForCycle() {
    var info = global.InfoPicture;
    if (!info || typeof info !== 'object') return 0;
    var main = getMainCycle();
    if (main && main.thinkingMode === 'passive') return 0;
    return typeof info.currentGoalId === 'number' ? info.currentGoalId : 0;
  }

  function createCycleInfo(id, context) {
    curCycleOrder += 1;
    var weight = 0;
    if (context && typeof context.significance === 'number') {
      weight = Math.abs(context.significance);
    }
    var info = global.InfoPicture;
    var createdThemeId = 0;
    var createdSituationId = 0;
    if (info && typeof info === 'object') {
      createdThemeId = typeof info.themeId === 'number' ? info.themeId : (info.themeId || 0);
      createdSituationId = typeof info.situationId === 'number' ? info.situationId : (info.situationId || 0);
    }
    return {
      id: id,
      order: curCycleOrder,
      isMainCycle: true,
      status: 'running',
      step: 0,
      count: 0,
      weight: weight,
      createdThemeId: createdThemeId,
      createdSituationId: createdSituationId,
      goalImageId: snapshotGoalImageIdForCycle(),
      thinkingMode: 'target',
      waitingFeedbackAutomatizmId: 0,
      awaitingAutomatismEpisodeFeedback: false,
      automatismOperatorAnswerReceived: false,
      automatismAnswerLevel2Done: false,
      lastAutomatismEpisodeEffect: null,
      context: context || {},
      createdAt: typeof Date.now === 'function' ? Date.now() : 0,
      lastPuls: 0,
      birthPuls: typeof global.cpuls === 'number' ? global.cpuls : 0,
      expired: false,
      noInfoChangeStreak: 0,
      lastInfoSig: '',
      events: []
      ,
      lastGestaltConsciencePuls: 0,
      passiveWorkAfterGestaltExpire: false,
      // Human-readable cycle log (operator).
      debugLog: [],
      // If operator closed log modal, suppress auto-show for this cycle.
      debugLogSuppressed: false,
      fantasizmArr: [],
      fantasizmPassiveFillStarted: false,
      /** Fantasy plot: chain of { fromStimulusId, actionImageId, episodeIndex, effect }; lastGeneratedActionId anchors next EM search. */
      fantazmingPlot: { chain: [], lastGeneratedActionId: 0 },
      /** Last fantasy focus (UI/debug; often lastGeneratedActionId after a step). */
      currentFantazmingStimulus: 0,
      /** Pulses in a row without info signature change on passive step (anti-stagnation with passiveFantasyLastSig). */
      passiveFantasyNoChangeStreak: 0,
      /** Last info picture signature after passive runOneStep branch. */
      passiveFantasyLastSig: ''
    };
  }

  function escapeHtml(s) {
    s = String(s == null ? '' : s);
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function cycleAppendLog(cycle, text, pulsCount, opts) {
    if (!cycle) return;
    opts = opts && typeof opts === 'object' ? opts : {};
    // After expired, stop appending (except forced system lines).
    if (cycle.expired && !opts.force) return;
    if (!Array.isArray(cycle.debugLog)) cycle.debugLog = [];
    var msg = (typeof text === 'string') ? text : String(text);
    cycle.debugLog.push({
      atPuls: typeof pulsCount === 'number' ? pulsCount : 0,
      atMs: typeof Date.now === 'function' ? Date.now() : 0,
      text: msg
    });
    // cap size
    if (cycle.debugLog.length > 200) {
      cycle.debugLog.splice(0, cycle.debugLog.length - 200);
    }
  }

  function formatCycleLogHtml(cycle) {
    if (!cycle || !Array.isArray(cycle.debugLog) || !cycle.debugLog.length) {
      return '<i>log empty</i>';
    }
    var lines = [];
    var from = Math.max(0, cycle.debugLog.length - 40);
    for (var i = from; i < cycle.debugLog.length; i++) {
      var e = cycle.debugLog[i];
      var p = (e && typeof e.atPuls === 'number') ? e.atPuls : 0;
      var t = e && e.text != null ? e.text : '';
      lines.push('[' + String(p) + '] ' + String(t));
    }
    return '<pre style="white-space:pre-wrap;margin:6px 0 0 0;font-size:10pt">' + escapeHtml(lines.join('\n')) + '</pre>';
  }

  function maybeShowMainCycleLog(main, pulsCount) {
    if (!main || !main.isMainCycle || main.status !== 'running') return;
    if (main.debugLogSuppressed) return;
    if (main.expired) return;
    var isFirstMainAfterLoad = (global.ConsciousnessFirstMainCycleId > 0 && main.id === global.ConsciousnessFirstMainCycleId);
    if (isFirstMainAfterLoad && !global.OrientationReflex_anyStimulusReadyForOr) return;
    if (typeof global.show_alert !== 'function') return;
    var curLen = Array.isArray(main.debugLog) ? main.debugLog.length : 0;
    if (typeof main.debugLogLastShownLen === 'number' && main.debugLogLastShownLen === curLen) {
      return;
    }
    main.debugLogLastShownLen = curLen;
    // Do not clash with other modals.
    if (typeof global.Alert_getActiveDialogType === 'function') {
      var tp = global.Alert_getActiveDialogType();
      if (tp && tp !== 'cyclelog') return;
    }
    var stimId = (main.context && typeof main.context.actual_stimul_ID === 'number') ? main.context.actual_stimul_ID : 0;
    var title = '<b>Main cycle #' + String(main.id) + '</b>' +
      (stimId ? (' (stimulus FinalImageId=' + String(stimId) + ')') : '') +
      (main.expired ? ' <b>expired</b>' : '');
    var body = title +
      '<br><small>Updates every pulse. If you close it, it will not show again for this cycle.</small>' +
      '<br>' + formatCycleLogHtml(main);
    global.show_alert(body, 0, {
      dialogType: 'cyclelog',
      onClose: function (info) {
        if (info && info.userInitiated) {
          main.debugLogSuppressed = true;
        }
      }
    });
  }

  /**
   * Decay background cycle weights by factor (default 0.5) after problem solved / scenario exhausted.
   */
  function decayBackgroundOperativeMemory(factor) {
    factor = typeof factor === 'number' && factor > 0 && factor < 1 ? factor : 0.5;
    var registry = global.ConsciousnessCycles;
    for (var k in registry) {
      if (!Object.prototype.hasOwnProperty.call(registry, k)) continue;
      var c = registry[k];
      if (!c || c.isMainCycle || c.status !== 'running') continue;
      var w = typeof c.weight === 'number' ? c.weight : 0;
      c.weight = Math.max(0.01, w * factor);
    }
  }

  function addCycleEvent(cycle, type, data, pulsCount) {
    if (!cycle) return;
    if (!Array.isArray(cycle.events)) cycle.events = [];
    cycle.events.push({
      atPuls: typeof pulsCount === 'number' ? pulsCount : 0,
      atMs: typeof Date.now === 'function' ? Date.now() : 0,
      type: type || 'event',
      data: data || null
    });
    // cap events journal
    if (cycle.events.length > 50) {
      cycle.events.splice(0, cycle.events.length - 50);
    }
  }

  function getInfoPictureSignature() {
    var info = global.InfoPicture;
    if (!info || typeof info !== 'object') return '';
    // Omit thinkingImportance/thinkingProcessId — they change when switching cycles.
    var snap = {
      themeId: info.themeId || 0,
      situationId: info.situationId || 0,
      problemFinalImageId: info.problemFinalImageId || 0,
      step: info.step || 0,
      stimulusFinalImageId: info.stimulus && info.stimulus.finalImageId ? info.stimulus.finalImageId : 0,
      tree: info.tree ? [
        info.tree.baseID || 0,
        info.tree.emotionID || 0,
        info.tree.activityID || 0,
        info.tree.toneMoodID || 0,
        info.tree.simbolID || 0,
        info.tree.phraseID || 0
      ] : [0, 0, 0, 0, 0, 0]
    };
    // Detectors: all numeric fields except those above and internals.
    for (var k in info) {
      if (!Object.prototype.hasOwnProperty.call(info, k)) continue;
      if (k === 'themeId' || k === 'situationId' || k === 'problemFinalImageId' || k === 'step' ||
          k === 'tree' || k === 'stimulus' || k === 'thinkingImportance' || k === 'thinkingProcessId' ||
          k === 'currentGoalType' || k === 'currentGoalId' || k === 'currentGoalVitalId') {
        continue;
      }
      var v = info[k];
      if (typeof v === 'number') {
        snap[k] = v;
      }
    }
    try {
      return JSON.stringify(snap);
    } catch (e) {
      return '';
    }
  }

  function pruneCyclesIfNeeded(pulsCount) {
    var registry = global.ConsciousnessCycles;
    var keys = Object.keys(registry);
    if (keys.length <= MAX_CYCLES) return;

    // Remove oldest expired=true first.
    var oldestExpired = null;
    for (var i = 0; i < keys.length; i++) {
      var c = registry[keys[i]];
      if (!c || !c.expired) continue;
      if (!oldestExpired || (c.order || 0) < (oldestExpired.order || 0)) oldestExpired = c;
    }
    if (oldestExpired) {
      deleteCycle(oldestExpired.id);
      return;
    }

    // If none expired — remove oldest non-main (last resort so new cycles can be created).
    var oldestBg = null;
    for (var j = 0; j < keys.length; j++) {
      var c2 = registry[keys[j]];
      if (!c2 || c2.isMainCycle) continue;
      if (!oldestBg || (c2.order || 0) < (oldestBg.order || 0)) oldestBg = c2;
    }
    if (oldestBg) {
      deleteCycle(oldestBg.id);
    }
  }

  /**
   * Create and register a new thought cycle.
   * @param {Object} context
   * @returns {CycleInfo|null}
   */
  function createConsciousnessCycle(context) {
    var registry = global.ConsciousnessCycles;
    var id = global.ConsciousnessProcessNextId++;
    var cycle = createCycleInfo(id, context);
    registry[id] = cycle;
    if (cycle.isMainCycle && !(global.ConsciousnessFirstMainCycleId > 0)) {
      global.ConsciousnessFirstMainCycleId = id;
    }
    addCycleEvent(cycle, 'created', { context: context || null }, 0);
    cycleAppendLog(cycle, 'Cycle created. Stimulus FinalImageId=' + String(context && context.actual_stimul_ID ? context.actual_stimul_ID : 0) + '.', typeof global.cpuls === 'number' ? global.cpuls : 0);
    pruneCyclesIfNeeded(typeof global.cpuls === 'number' ? global.cpuls : 0);
    return cycle;
  }

  /**
   * Set cycleId as main; others get isMainCycle = false.
   */
  function setMainCycle(cycleId) {
    var registry = global.ConsciousnessCycles;
    for (var k in registry) {
      if (Object.prototype.hasOwnProperty.call(registry, k)) {
        registry[k].isMainCycle = (Number(k) === Number(cycleId));
      }
    }
    global.ConsciousnessCurrentProcessId = cycleId;
  }

  /** @returns {CycleInfo|null} running main cycle */
  function getMainCycle() {
    var registry = global.ConsciousnessCycles;
    for (var k in registry) {
      if (!Object.prototype.hasOwnProperty.call(registry, k)) continue;
      var c = registry[k];
      if (c && c.isMainCycle && c.status === 'running') return c;
    }
    return null;
  }

  /** @returns {CycleInfo|null} */
  function getCycle(id) {
    var c = global.ConsciousnessCycles[Number(id)];
    return c || null;
  }

  /** Set status cancelled; runOneStep ignores. */
  function cancelConsciousnessProcess(id) {
    var c = getCycle(id);
    if (c) c.status = 'cancelled';
  }

  /** Remove from registry; if was main, promote by max weight among running. */
  function deleteCycle(id) {
    var registry = global.ConsciousnessCycles;
    var wasMain = false;
    var cycle = registry[id];
    if (cycle) {
      wasMain = cycle.isMainCycle;
      delete registry[id];
    }
    if (wasMain) {
      var nextMain = null;
      var maxWeight = -1;
      for (var k in registry) {
        if (!Object.prototype.hasOwnProperty.call(registry, k)) continue;
        var c = registry[k];
        if (c && c.status === 'running' && c.weight > maxWeight) {
          maxWeight = c.weight;
          nextMain = c;
        }
      }
      if (nextMain) {
        setMainCycle(nextMain.id);
      } else {
        global.ConsciousnessCurrentProcessId = 0;
      }
    }
  }

  /**
   * Remove all background running cycles. Interrupt stack filtered to existing ids.
   * Only from SleepMode_exit(true) (dream end by frame limit); manual wake does not touch background.
   */
  function deleteAllBackgroundCycles() {
    var registry = global.ConsciousnessCycles;
    var ids = [];
    for (var kb in registry) {
      if (!Object.prototype.hasOwnProperty.call(registry, kb)) continue;
      var cb = registry[kb];
      if (cb && !cb.isMainCycle && cb.status === 'running') ids.push(cb.id);
    }
    for (var i = 0; i < ids.length; i++) {
      deleteCycle(ids[i]);
    }
    var stack = global.ConsciousnessBackgroundStack;
    if (Array.isArray(stack) && stack.length) {
      var filtered = [];
      for (var s = 0; s < stack.length; s++) {
        var sid = stack[s];
        if (registry[sid] != null) filtered.push(sid);
      }
      global.ConsciousnessBackgroundStack = filtered;
    }
  }

  /** One cycle step; calls global Consciousness_runOneStep if defined. */
  function runOneStep(cycle, pulsCount) {
    if (!cycle || cycle.status !== 'running') return;
    cycle.lastPuls = pulsCount;
    cycle.count += 1;
    if (typeof global.Consciousness_runOneStep === 'function') {
      global.Consciousness_runOneStep(cycle);
    }
  }

  /**
   * Promote background to main: interrupt stack first, else max weight.
   * Only relabel and info-edit rights; cycle id unchanged.
   */
  function promoteFromBackgroundCycle() {
    var stack = global.ConsciousnessBackgroundStack;
    if (Array.isArray(stack) && stack.length > 0) {
      while (stack.length > 0) {
        var id = stack.pop();
        var c = getCycle(id);
        if (c && c.status === 'running' && !c.expired) {
          setMainCycle(c.id);
          if (typeof global.InfoPicture !== 'undefined' && global.InfoPicture) {
            global.InfoPicture.thinkingImportance = c.weight;
            global.InfoPicture.thinkingProcessId = c.id;
            if (typeof global.Info_updateView === 'function') global.Info_updateView();
          }
          if (typeof global.show_alert === 'function') {
            var stimId = (c.context && typeof c.context.actual_stimul_ID === 'number') ? c.context.actual_stimul_ID : 0;
            global.show_alert(
              'Resuming interrupted process ID=' + String(c.id) + ' as main (stimulus FinalImageId=' + String(stimId) + ', significance=' + String(c.weight || 0) + ').',
              1500
            );
          }
          return;
        }
      }
    }
    var registry = global.ConsciousnessCycles;
    var best = null;
    var bestWeight = -1;
    for (var k in registry) {
      if (!Object.prototype.hasOwnProperty.call(registry, k)) continue;
      var c = registry[k];
      if (!c || c.isMainCycle || c.status !== 'running' || c.expired) continue;
      var w = typeof c.weight === 'number' ? c.weight : 0;
      if (w > bestWeight) {
        bestWeight = w;
        best = c;
      }
    }
    if (!best) return;
    setMainCycle(best.id);
    if (typeof global.InfoPicture !== 'undefined' && global.InfoPicture) {
      global.InfoPicture.thinkingImportance = best.weight;
      global.InfoPicture.thinkingProcessId = best.id;
      if (typeof global.Info_updateView === 'function') global.Info_updateView();
    }
    if (typeof global.show_alert === 'function') {
      var stimId = (best.context && typeof best.context.actual_stimul_ID === 'number') ? best.context.actual_stimul_ID : 0;
      global.show_alert(
        'Resuming background process ID=' + String(best.id) + ' as main (stimulus FinalImageId=' + String(stimId) + ', significance=' + String(best.weight || 0) + ').',
        1500
      );
    }
  }

  /**
   * Legacy: promote from stack by creating new cycle from saved context.
   * Prefer promoteFromBackgroundCycle().
   */
  function promoteFromBackgroundStack() {
    var stack = global.ConsciousnessBackgroundStack;
    if (!Array.isArray(stack) || stack.length === 0) return;
    var bg = stack.pop();
    if (!bg || !bg.context) return;
    var cycle = createConsciousnessCycle(bg.context);
    if (!cycle) return;
    setMainCycle(cycle.id);
    if (typeof global.InfoPicture !== 'undefined' && global.InfoPicture && bg.importance != null) {
      global.InfoPicture.thinkingImportance = bg.importance;
      global.InfoPicture.thinkingProcessId = cycle.id;
      if (typeof global.Info_updateView === 'function') global.Info_updateView();
    }
    if (typeof global.Consciousness_runElementary === 'function') {
      global.Consciousness_runElementary(cycle);
    }
  }

  /** Registry maintenance; background cycles kept as memory. Only prune via pruneCyclesIfNeeded. */
  function cleanupCycles(pulsCount) {
    pruneCyclesIfNeeded(pulsCount);
  }

  /**
   * Thought dispatcher, each pulse: promote main if missing; main runOneStep; on main finished delete and promote;
   * background running cycles step every 5 pulses; cleanup.
   */
  function dispetchConsciousnessThinking(pulsCount) {
    pulsCount = typeof pulsCount === 'number' ? pulsCount : 0;

    var main = getMainCycle();

    if (!main) {
      promoteFromBackgroundCycle();
      cleanupCycles(pulsCount);
      return;
    }

    global.ConsciousnessCanModifyInfo = true;
    // Expired logic: info picture snapshot before/after main step.
    var sigBefore = getInfoPictureSignature();
    runOneStep(main, pulsCount);
    var sigAfter = getInfoPictureSignature();
    if (sigBefore && sigAfter && sigBefore === sigAfter) {
      main.noInfoChangeStreak = (main.noInfoChangeStreak || 0) + 1;
    } else {
      main.noInfoChangeStreak = 0;
    }
    main.lastInfoSig = sigAfter;
    var skipStagnationExpire = !!(main.awaitingAutomatismEpisodeFeedback && !main.automatismAnswerLevel2Done);
    if (!main.expired && main.noInfoChangeStreak >= 3 && !skipStagnationExpire) {
      cycleAppendLog(main, 'Cycle marked expired (3 iterations without info picture change).', pulsCount, { force: true });
      main.expired = true;
      notifyFinCycleCompleted();
      main.isMainCycle = false; // idle cycle no longer receives steps via getMainCycle()
      addCycleEvent(main, 'expired', { reason: '3 iterations without InfoPicture changes' }, pulsCount);
      var gestaltTickSamePuls = (typeof main.lastGestaltConsciencePuls === 'number' &&
        main.lastGestaltConsciencePuls === pulsCount);
      if (gestaltTickSamePuls) {
        main.passiveWorkAfterGestaltExpire = true;
        addCycleEvent(main, 'passiveAfterGestaltStagnation', { puls: pulsCount }, pulsCount);
        main.thinkingMode = 'passive';
        if (typeof global.Info_updateView === 'function') global.Info_updateView();
        cycleAppendLog(main, 'After L4/gestalt tick: stagnation expired — main cycle switched to passive thinkingMode.', pulsCount, { force: true });
      }
      decayBackgroundOperativeMemory(0.5);
      var mw = typeof main.weight === 'number' ? main.weight : 0;
      main.weight = Math.max(0.01, mw * 0.5);
      if (typeof global.InfoPicture !== 'undefined' && global.InfoPicture) {
        global.InfoPicture.thinkingImportance = main.weight;
        if (typeof global.Info_updateView === 'function') global.Info_updateView();
      }
    }

    // "Dissatisfaction with status quo" detector:
    // main expired and Rest basic context (id=14) active for >20 pulses → InfoDet_updateDissatisfaction.
    (function () {
      var info = global.InfoPicture;
      var peaceActive = Array.isArray(global.BasicContextsActived) && global.BasicContextsActived.indexOf(14) !== -1;
      if (main && main.expired && peaceActive) {
        main.expiredPeacePulses = (typeof main.expiredPeacePulses === 'number' ? main.expiredPeacePulses : 0) + 1;
      } else if (main) {
        main.expiredPeacePulses = 0;
      }
      var should = !!(main && main.expiredPeacePulses > 20);
      if (typeof global.InfoDet_updateDissatisfaction === 'function') {
        global.InfoDet_updateDissatisfaction(should);
      } else if (info) {
        info.dissatisfaction = should ? 1 : 0;
        info.isDissatisfaction = should ? 1 : 0;
        if (typeof global.Info_updateView === 'function') global.Info_updateView();
      }
    })();

    // "Misunderstanding" detector: target thinking mode + long iteration or expired while target.
    (function () {
      var info = global.InfoPicture;
      var isTarget = !!(main && main.thinkingMode !== 'passive');
      var tooLong = !!(main && typeof main.count === 'number' && main.count > 10);
      var expiredTarget = !!(main && main.expired && isTarget);
      var flag = !!(isTarget && (tooLong || expiredTarget));
      if (typeof global.InfoDet_updateMisunderstanding === 'function') {
        global.InfoDet_updateMisunderstanding(flag);
      } else if (info) {
        info.misunderstanding = flag ? 1 : 0;
        if (typeof global.Info_updateView === 'function') global.Info_updateView();
      }
    })();

    // Auto-show/update main cycle log unless operator suppressed.
    maybeShowMainCycleLog(main, pulsCount);

    if (main.status === 'finished' || main.status === 'cancelled') {
      addCycleEvent(main, main.status, null, pulsCount);
      cycleAppendLog(main, 'Cycle finished: ' + String(main.status) + '.', pulsCount, { force: true });
      if (main.status === 'finished') {
        notifyFinCycleCompleted();
      }
      decayBackgroundOperativeMemory(0.5);
      deleteCycle(main.id);
      promoteFromBackgroundCycle();
    }

    var registry = global.ConsciousnessCycles;
    for (var k in registry) {
      if (!Object.prototype.hasOwnProperty.call(registry, k)) continue;
      var c = registry[k];
      if (!c || c.isMainCycle || c.status !== 'running') continue;
      var fastBgAwait = !!(c.awaitingAutomatismEpisodeFeedback && c.automatismOperatorAnswerReceived && !c.automatismAnswerLevel2Done);
      if (fastBgAwait || pulsCount % 5 === 0) {
        global.ConsciousnessCanModifyInfo = false;
        runOneStep(c, pulsCount);
        // Background fantasy plot: info_fantasizming (conscious_attention_channel, passive mode).
        // Background cycles are not auto-closed — memory of past thought.
      }
    }

    cleanupCycles(pulsCount);
  }

  /** Background running cycle count (UI "background: N"). */
  function getBackgroundCyclesCount() {
    var registry = global.ConsciousnessCycles;
    var n = 0;
    for (var k in registry) {
      if (!Object.prototype.hasOwnProperty.call(registry, k)) continue;
      var c = registry[k];
      if (c && !c.isMainCycle && c.status === 'running') n += 1;
    }
    return n;
  }

  /** Background cycles list for UI drill-down. */
  function getBackgroundCyclesList() {
    var registry = global.ConsciousnessCycles;
    var list = [];
    for (var k in registry) {
      if (!Object.prototype.hasOwnProperty.call(registry, k)) continue;
      var c = registry[k];
      if (c && !c.isMainCycle && c.status === 'running') list.push(c);
    }
    list.sort(function (a, b) { return (b.weight || 0) - (a.weight || 0); });
    return list;
  }

  /** May current step modify InfoPicture? Main true, background false. */
  function canModifyInfoPicture() {
    return !!global.ConsciousnessCanModifyInfo;
  }

  /** Main cycle thinkingMode; no main → 'target'. Not stored on InfoPicture (only traces like fantasy plot). */
  function getMainCycleThinkingMode() {
    var c = getMainCycle();
    if (!c) return 'target';
    return c.thinkingMode === 'passive' ? 'passive' : 'target';
  }

  global.Consciousness_createCycle = createConsciousnessCycle;
  global.Consciousness_setMainCycle = setMainCycle;
  global.Consciousness_getMainCycle = getMainCycle;
  global.Consciousness_getMainCycleThinkingMode = getMainCycleThinkingMode;
  global.Consciousness_getCycle = getCycle;
  global.Consciousness_cancelProcess = cancelConsciousnessProcess;
  global.Consciousness_deleteCycle = deleteCycle;
  global.Consciousness_deleteAllBackgroundCycles = deleteAllBackgroundCycles;
  global.Consciousness_promoteFromBackgroundCycle = promoteFromBackgroundCycle;
  global.Consciousness_promoteFromBackgroundStack = promoteFromBackgroundStack;
  global.Consciousness_getBackgroundCyclesCount = getBackgroundCyclesCount;
  global.Consciousness_getBackgroundCyclesList = getBackgroundCyclesList;
  global.Consciousness_canModifyInfoPicture = canModifyInfoPicture;
  global.Consciousness_decayBackgroundOperativeMemory = decayBackgroundOperativeMemory;
  global.Consciousness_cycleAppendLog = function (cycle, text, pulsCount, opts) {
    cycleAppendLog(cycle, text, pulsCount, opts);
  };
  global.dispetchConsciousnessThinking = dispetchConsciousnessThinking;
  global.Consciousness_getInfoPictureSignature = getInfoPictureSignature;
})(window);
