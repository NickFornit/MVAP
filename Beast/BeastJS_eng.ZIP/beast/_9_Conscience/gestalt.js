/**
 * Gestalts (dominants of unresolved tasks) and resonance buffer for level 4.
 *
 * Full theory: beast/_9_Conscience/about_gestalt.md
 *
 * Data flow (short):
 *   1) At the start of a tick, level 3 calls Gestalt_prepareContextForLevel3 — a snapshot of the open gestalt
 *      for the main cycle goal (if any) is stored in global.GestaltContextForLevel3.
 *   2) Level 4 calls Gestalt_onConsciousnessTick — bind "owner", process GestaltResonanceBuffer,
 *      refresh context after possible analogy insights.
 *   3) EpisodicMemory_closeLastFrame → Gestalt_onEpisodeFeedbackClosed — a signature of the closed EM frame
 *      is pushed to the buffer; if the waiting cycle has goalImageId, the gestalt row is updated.
 *
 * Cycle logs: Consciousness_cycleAppendLog(cycle, text, puls [, { force: true }]).
 * Dispatcher contract: see consciousness_dispatcher.js — for expired / non-main cycles use force,
 * otherwise cycleAppendLog drops the entry.
 */
(function (global) {
  'use strict';

  /** Gestalt statuses: 0 new → 1 started → 2 partial → 3 closed success → 4 archive. */
  var GESTALT_STATUS = {
    NEW: 0,
    STARTED: 1,
    PARTIAL: 2,
    CLOSED_SUCCESS: 3,
    ARCHIVED: 4
  };

  /** Insight kind labels for lastInsightKind and log lines. */
  var INSIGHT_KIND = {
    PRE: 'pre',
    LOCAL: 'local',
    ANALOGY: 'analogy',
    FEEDBACK: 'feedback'
  };

  /** Max entries in resonance buffer (FIFO, oldest evicted). */
  var MAX_RESONANCE_BUFFER = 48;
  /** Max analogyPool items per gestalt. */
  var MAX_ANALOGY_POOL = 16;
  /**
   * Threshold for "strong" effect closing the gestalt (transition to CLOSED_SUCCESS).
   * effect range in EM: [-10, 10] — see episodic_memory.closeLastFrame.
   */
  var EFFECT_STRONG_CLOSE = 6;
  /** Minimum score for resonance insight (heuristic v1, see scoreResonanceAgainstGestalt). */
  var RESONANCE_SCORE_INSIGHT = 0.55;

  var gestaltDirty = false;
  var lastSavedSig = '';

  if (!Array.isArray(global.GestaltArr)) global.GestaltArr = [];
  if (typeof global.GestaltNextId !== 'number' || global.GestaltNextId < 1) global.GestaltNextId = 1;
  if (!Array.isArray(global.GestaltResonanceBuffer)) global.GestaltResonanceBuffer = [];
  if (typeof global.GestaltResonanceSeq !== 'number' || global.GestaltResonanceSeq < 1) global.GestaltResonanceSeq = 1;
  if (typeof global.Gestalt_activeMasterCycleId !== 'number') global.Gestalt_activeMasterCycleId = 0;
  if (typeof global.Gestalt_activeGestaltId !== 'number') global.Gestalt_activeGestaltId = 0;

  global.GESTALT_STATUS = GESTALT_STATUS;
  global.GESTALT_INSIGHT_KIND = INSIGHT_KIND;

  function puls() {
    return typeof global.cpuls === 'number' ? global.cpuls : 0;
  }

  function markDirty() {
    gestaltDirty = true;
  }

  /**
   * Normalize gestalt object shape on create and after IndexedDB load.
   * Copy arrays so serialization does not accidentally share live state.
   */
  function normalizeGestalt(g) {
    return {
      id: g.id,
      problemTreeId: g.problemTreeId || 0,
      situationId: g.situationId || 0,
      goalImageId: g.goalImageId || 0,
      automatismIds: Array.isArray(g.automatismIds) ? g.automatismIds.slice() : [],
      status: typeof g.status === 'number' ? g.status : 0,
      lastInsightPuls: typeof g.lastInsightPuls === 'number' ? g.lastInsightPuls : 0,
      lastInsightKind: typeof g.lastInsightKind === 'string' ? g.lastInsightKind : '',
      insightChainCount: typeof g.insightChainCount === 'number' ? g.insightChainCount : 0,
      analogyPool: Array.isArray(g.analogyPool) ? g.analogyPool.slice() : []
    };
  }

  /** At most one row per goalImageId in GestaltArr (invariant on create). */
  function findGestaltByGoal(goalImageId) {
    var gid = parseInt(goalImageId, 10) || 0;
    if (!gid) return null;
    for (var i = 0; i < global.GestaltArr.length; i++) {
      var g = global.GestaltArr[i];
      if (g && g.goalImageId === gid) return g;
    }
    return null;
  }

  /**
   * Open gestalt: status 0, 1, or 2.
   * TODO (scenarios): on a repeated unresolved task for the same goal after status 3 — either a new row
   * with new id (if multiple archive rows per goal allowed), or reopen this row (reset status).
   * Current: one row per goalImageId; after 3 updates only via feedback (rare reopen — manual/API).
   */
  function isGestaltOpen(g) {
    return g && g.status !== GESTALT_STATUS.CLOSED_SUCCESS && g.status !== GESTALT_STATUS.ARCHIVED;
  }

  /** Append automatism id to tried list, no duplicates. */
  function appendAutomatismIfNew(g, aid) {
    aid = parseInt(aid, 10) || 0;
    if (!aid) return false;
    if (!Array.isArray(g.automatismIds)) g.automatismIds = [];
    for (var i = 0; i < g.automatismIds.length; i++) {
      if (g.automatismIds[i] === aid) return false;
    }
    g.automatismIds.push(aid);
    return true;
  }

  /**
   * Wrapper over Consciousness_cycleAppendLog: third arg is pulse number (as in dispatcher).
   * Without force, only main cycle; force: true for background and after expired (like level 3).
   */
  function logToCycle(cycle, text, force) {
    if (!cycle || typeof global.Consciousness_cycleAppendLog !== 'function') return;
    if (!force && !cycle.isMainCycle) return;
    global.Consciousness_cycleAppendLog(cycle, text, puls(), force ? { force: true } : undefined);
  }

  /** If cycle omitted — try main (EM events without FO step binding). */
  function logToCycleOrMain(cycle, text, force) {
    var c = cycle;
    if (!c && typeof global.Consciousness_getMainCycle === 'function') {
      c = global.Consciousness_getMainCycle();
    }
    logToCycle(c, text, force);
  }

  /**
   * Record insight on gestalt fields and append cycle log line (if cycleForLog given).
   * Always force: true — insight matters; waiting cycle often expired / not main.
   */
  function registerInsight(g, kind, detail, cycleForLog) {
    g.lastInsightPuls = puls();
    g.lastInsightKind = kind;
    g.insightChainCount = (g.insightChainCount || 0) + 1;
    var msg = 'Gestalt #' + g.id + ' (goal ' + g.goalImageId + '): insight [' + String(kind) + '] ' + String(detail || '');
    if (cycleForLog) logToCycle(cycleForLog, msg, true);
    markDirty();
    if (typeof global.info_insight === 'function') {
      global.info_insight(cycleForLog, { insightKind: kind, detail: detail });
    }
  }

  /**
   * Create row if none for goalImageId yet.
   * @param {Object} [hint] — problemTreeId, situationId (hint from branch / info picture)
   */
  function Gestalt_createOrGetForGoal(goalImageId, hint) {
    var gid = parseInt(goalImageId, 10) || 0;
    if (!gid) return null;
    var ex = findGestaltByGoal(gid);
    if (ex) return ex;
    hint = hint || {};
    var id = global.GestaltNextId++;
    var rec = normalizeGestalt({
      id: id,
      problemTreeId: hint.problemTreeId || 0,
      situationId: hint.situationId || 0,
      goalImageId: gid,
      automatismIds: [],
      status: GESTALT_STATUS.NEW,
      lastInsightPuls: 0,
      lastInsightKind: '',
      insightChainCount: 0,
      analogyPool: []
    });
    global.GestaltArr.push(rec);
    markDirty();
    logToCycleOrMain(null, 'Gestalt: created row #' + rec.id + ' for goal image goalImageId=' + gid +
      (hint.problemTreeId ? (', branch ' + hint.problemTreeId) : '') +
      (hint.situationId ? (', situation ' + hint.situationId) : '') + '.', false);
    return rec;
  }

  /**
   * Resonance buffer: each entry is a signature of a closed EM frame for cross-cycle analogy.
   * @returns {Object} created signature (for log in caller).
   *
   * TODO (extension): goal_vector / precondition_mask from semantics — see about_gestalt.md §6.
   */
  function Gestalt_pushResonanceSignature(entry) {
    var e = entry || {};
    var sig = {
      id: global.GestaltResonanceSeq++,
      atPuls: puls(),
      sourceCycleId: parseInt(e.sourceCycleId, 10) || 0,
      goalImageId: parseInt(e.goalImageId, 10) || 0,
      problemTreeId: parseInt(e.problemTreeId, 10) || 0,
      situationId: parseInt(e.situationId, 10) || 0,
      perceptionNodeId: parseInt(e.perceptionNodeId, 10) || 0,
      automatismId: parseInt(e.automatismId, 10) || 0,
      actionImageId: parseInt(e.actionImageId, 10) || 0,
      effect: typeof e.effect === 'number' && !isNaN(e.effect) ? e.effect : null,
      kind: e.kind || 'episode_close'
    };
    global.GestaltResonanceBuffer.push(sig);
    while (global.GestaltResonanceBuffer.length > MAX_RESONANCE_BUFFER) {
      global.GestaltResonanceBuffer.shift();
    }
    markDirty();
    return sig;
  }

  /**
   * Heuristic similarity of buffer signature to gestalt (v1: scalar ID matches).
   * Higher = more "about my task" for an open gestalt.
   */
  function scoreResonanceAgainstGestalt(sig, g) {
    var score = 0;
    if (sig.goalImageId && g.goalImageId === sig.goalImageId) score += 1.0;
    var branch = sig.perceptionNodeId || sig.problemTreeId;
    if (branch && g.problemTreeId && branch === g.problemTreeId) score += 0.28;
    if (sig.situationId && g.situationId && sig.situationId === g.situationId) score += 0.35;
    if (!g.situationId && sig.situationId) score += 0.08;
    if (sig.effect !== null && sig.effect > 0) score += 0.12;
    return score;
  }

  /**
   * Walk resonance buffer: for entries with effect > 0 and open gestalts — score; if score ≥ threshold —
   * analogy insight, append automatismIds and analogyPool (simplified "gestalt assembly").
   *
   * @returns {number} number of (signature×gestalt) pairs that passed threshold and changed insight.
   *
   * TODO: mark buffer entries consumed to avoid re-walking unchanged buffer.
   */
  function Gestalt_processResonanceBufferForCycle(cycle) {
    var buf = global.GestaltResonanceBuffer;
    if (!buf.length) return 0;

    var applied = 0;
    for (var b = 0; b < buf.length; b++) {
      var sig = buf[b];
      if (!sig || sig.effect === null || sig.effect <= 0) continue;

      for (var i = 0; i < global.GestaltArr.length; i++) {
        var g = global.GestaltArr[i];
        if (!isGestaltOpen(g)) continue;

        var sc = scoreResonanceAgainstGestalt(sig, g);
        if (sc < RESONANCE_SCORE_INSIGHT) continue;

        if (sig.automatismId) appendAutomatismIfNew(g, sig.automatismId);

        if (!Array.isArray(g.analogyPool)) g.analogyPool = [];
        g.analogyPool.push({
          resonanceId: sig.id,
          atPuls: sig.atPuls,
          score: sc,
          automatismId: sig.automatismId || 0,
          sourceCycleId: sig.sourceCycleId || 0
        });
        while (g.analogyPool.length > MAX_ANALOGY_POOL) g.analogyPool.shift();

        if (g.status === GESTALT_STATUS.NEW) {
          g.status = GESTALT_STATUS.STARTED;
          registerInsight(g, INSIGHT_KIND.ANALOGY, 'resonance score=' + sc.toFixed(2) + ' resonanceId=' + sig.id, cycle);
          applied++;
        } else if (g.status === GESTALT_STATUS.STARTED) {
          registerInsight(g, INSIGHT_KIND.ANALOGY, 'analogy refinement score=' + sc.toFixed(2), cycle);
          applied++;
        }

        if (sig.situationId && !g.situationId) g.situationId = sig.situationId;
        var br = sig.perceptionNodeId || sig.problemTreeId;
        if (br && !g.problemTreeId) g.problemTreeId = br;
      }
    }
    return applied;
  }

  /**
   * Leading open gestalt by goal image.
   * goalImageId priority: cycle field (EM waiting session), else InfoPicture.currentGoalId in target thinking mode.
   */
  function Gestalt_bindActiveMaster(cycle) {
    var goalId = 0;
    if (cycle && typeof cycle.goalImageId === 'number' && cycle.goalImageId > 0) {
      goalId = cycle.goalImageId;
    }
    var info = global.InfoPicture;
    var cycleTarget;
    if (cycle) {
      cycleTarget = cycle.thinkingMode !== 'passive';
    } else if (typeof global.Consciousness_getMainCycleThinkingMode === 'function') {
      cycleTarget = global.Consciousness_getMainCycleThinkingMode() !== 'passive';
    } else {
      cycleTarget = true;
    }
    if (!goalId && cycleTarget && info && typeof info.currentGoalId === 'number' && info.currentGoalId > 0) {
      goalId = info.currentGoalId;
    }
    if (!goalId) {
      global.Gestalt_activeGestaltId = 0;
      global.Gestalt_activeMasterCycleId = 0;
      return null;
    }

    var hint = {
      situationId: info && typeof info.situationId === 'number' ? info.situationId : 0,
      problemTreeId: (cycle && cycle.context && typeof cycle.context.branchId === 'number') ? cycle.context.branchId : 0
    };
    var g = findGestaltByGoal(goalId);
    if (!g) {
      g = Gestalt_createOrGetForGoal(goalId, hint);
    } else if (isGestaltOpen(g)) {
      if (hint.situationId && !g.situationId) g.situationId = hint.situationId;
      if (hint.problemTreeId && !g.problemTreeId) g.problemTreeId = hint.problemTreeId;
    }

    if (g && isGestaltOpen(g)) {
      global.Gestalt_activeGestaltId = g.id;
      global.Gestalt_activeMasterCycleId = cycle ? cycle.id : 0;
    } else {
      global.Gestalt_activeGestaltId = 0;
      global.Gestalt_activeMasterCycleId = cycle ? cycle.id : 0;
    }
    return g && isGestaltOpen(g) ? g : null;
  }

  /**
   * Start of level 3: fills GestaltContextForLevel3. Log on id+status change (no spam every pulse).
   */
  function Gestalt_prepareContextForCycle(cycle) {
    if (!cycle || cycle.status !== 'running') {
      global.GestaltContextForLevel3 = null;
      return;
    }
    var g = Gestalt_bindActiveMaster(cycle);
    if (g && cycle.isMainCycle) {
      global.GestaltContextForLevel3 = {
        gestaltId: g.id,
        goalImageId: g.goalImageId,
        gestaltStatus: g.status,
        problemTreeId: g.problemTreeId,
        situationId: g.situationId
      };
      var snap = String(g.id) + '_' + String(g.status);
      if (cycle._gestaltPrepareLogSnap !== snap) {
        cycle._gestaltPrepareLogSnap = snap;
        logToCycle(cycle, 'Gestalt: context for L3 — id=' + g.id + ', goal=' + g.goalImageId +
          ', status=' + g.status + ', branch=' + g.problemTreeId + ', situation=' + g.situationId + '.', false);
      }
    } else {
      global.GestaltContextForLevel3 = null;
    }
  }

  /**
   * Level 4 tick: main cycle only. Resonance while status < PARTIAL; then refresh context.
   */
  function Gestalt_onConsciousnessTick(cycle) {
    if (!cycle || cycle.status !== 'running' || !cycle.isMainCycle) return;

    /** For dispatcher: match cpuls on this step → expired by stagnation after gestalt (see consciousness_dispatcher). */
    cycle.lastGestaltConsciencePuls = puls();

    var g = Gestalt_bindActiveMaster(cycle);
    var applied = 0;
    if (g && g.status < GESTALT_STATUS.PARTIAL) {
      applied = Gestalt_processResonanceBufferForCycle(cycle);
    }
    if (applied > 0) {
      logToCycle(cycle, 'L4/gestalt: resonance — buffer matches processed: ' + applied + '.', false);
    }

    Gestalt_prepareContextForCycle(cycle);
  }

  /**
   * EM frame closed: resonance buffer + gestalt update by waiting cycle goalImageId.
   */
  function Gestalt_onEpisodeFeedbackClosed(payload) {
    var p = payload || {};
    var waitCycleId = parseInt(p.waitCycleId, 10) || 0;
    var last = p.lastFrame || {};
    var effect = typeof p.effect === 'number' && !isNaN(p.effect) ? p.effect : null;
    var autoId = parseInt(p.automatismId, 10) || 0;

    var perceptionNodeId = last.perceptionNodeId || 0;
    var situationId = last.situationId || 0;

    var oc = waitCycleId && typeof global.Consciousness_getCycle === 'function'
      ? global.Consciousness_getCycle(waitCycleId) : null;
    var goalId = oc && typeof oc.goalImageId === 'number' ? oc.goalImageId : 0;

    var pushedSig = Gestalt_pushResonanceSignature({
      sourceCycleId: waitCycleId,
      goalImageId: goalId,
      problemTreeId: perceptionNodeId,
      situationId: situationId,
      perceptionNodeId: perceptionNodeId,
      automatismId: autoId,
      actionImageId: last.actionImageId || 0,
      effect: effect,
      kind: effect !== null && effect > 0 ? 'positive_feedback' : 'non_positive'
    });

    if (pushedSig) {
      var logC = oc || (typeof global.Consciousness_getMainCycle === 'function' ? global.Consciousness_getMainCycle() : null);
      var forceEp = !!(logC && (!logC.isMainCycle || logC.expired));
      logToCycle(logC, 'Gestalt/EM: resonance — signature #' + pushedSig.id +
        ' (wait cycle=' + waitCycleId + ', goal=' + pushedSig.goalImageId + ', effect=' + String(pushedSig.effect) +
        ', auto=' + pushedSig.automatismId + ', buffer len=' + global.GestaltResonanceBuffer.length + ').', forceEp);
    }

    if (!goalId) {
      if (oc) {
        logToCycle(oc, 'Gestalt/EM: goalImageId not set — gestalt row unchanged (signature still in buffer).', true);
      }
      return;
    }

    var g = findGestaltByGoal(goalId);
    if (!g) {
      g = Gestalt_createOrGetForGoal(goalId, {
        problemTreeId: perceptionNodeId,
        situationId: situationId
      });
    }
    if (!g) return;

    if (!isGestaltOpen(g)) {
      logToCycle(oc, 'Gestalt: goal ' + goalId + ' already closed (status≥3) — status change skipped.', true);
      return;
    }

    if (autoId) {
      var added = appendAutomatismIfNew(g, autoId);
      if (added && oc) {
        logToCycle(oc, 'Gestalt #' + g.id + ': automatism id=' + autoId + ' added to tried list.', true);
      }
    }

    if (effect !== null && effect > 0) {
      if (!g.problemTreeId && perceptionNodeId) g.problemTreeId = perceptionNodeId;
      if (!g.situationId && situationId) g.situationId = situationId;

      if (effect >= EFFECT_STRONG_CLOSE) {
        g.status = GESTALT_STATUS.CLOSED_SUCCESS;
        registerInsight(g, INSIGHT_KIND.FEEDBACK, 'strong effect ≥' + String(EFFECT_STRONG_CLOSE) + ' — gestalt closed (effect=' + String(effect) + ')', oc);
      } else if (g.status <= GESTALT_STATUS.STARTED) {
        g.status = GESTALT_STATUS.PARTIAL;
        registerInsight(g, INSIGHT_KIND.FEEDBACK, 'effect=' + String(effect) + ' auto=' + String(autoId) + ' — status→PARTIAL', oc);
      }
    } else if (effect !== null && effect <= 0) {
      registerInsight(g, INSIGHT_KIND.PRE, 'effect≤0 — reinterpret? (effect=' + String(effect) + ')', oc);
    }
    markDirty();
  }

  /**
   * Level 2, goal "value": if open gestalt is for this goal or lists automatism with this action image — bump status / insight.
   */
  function Gestalt_bumpFromMeaningForecast(meaningGoalId, actionImageId, frame, cycleForLog) {
    var mg = parseInt(meaningGoalId, 10) || 0;
    var act = parseInt(actionImageId, 10) || 0;
    if (!mg || !act) return;

    function automatismMatchesAction(automatismId, odId) {
      var aid = parseInt(automatismId, 10) || 0;
      if (!aid || !Array.isArray(global.Automatizms)) return false;
      for (var ai = 0; ai < global.Automatizms.length; ai++) {
        var az = global.Automatizms[ai];
        if (az && az.id === aid && az.actionsImageId === odId) return true;
      }
      return false;
    }

    for (var i = 0; i < global.GestaltArr.length; i++) {
      var g = global.GestaltArr[i];
      if (!g || !isGestaltOpen(g)) continue;
      var match = g.goalImageId === mg;
      if (!match && Array.isArray(g.automatismIds)) {
        for (var j = 0; j < g.automatismIds.length; j++) {
          if (automatismMatchesAction(g.automatismIds[j], act)) {
            match = true;
            break;
          }
        }
      }
      if (!match) continue;

      if (g.status === GESTALT_STATUS.NEW) {
        g.status = GESTALT_STATUS.STARTED;
        registerInsight(g, INSIGHT_KIND.LOCAL, 'forecast from stimulus meaning, action image=' + act, cycleForLog);
      } else if (g.status === GESTALT_STATUS.STARTED) {
        g.status = GESTALT_STATUS.PARTIAL;
        registerInsight(g, INSIGHT_KIND.LOCAL, 'forecast refinement, action image=' + act, cycleForLog);
      } else if (g.status === GESTALT_STATUS.PARTIAL) {
        registerInsight(g, INSIGHT_KIND.LOCAL, 'forecast reinforcement, action image=' + act, cycleForLog);
      }
    }
  }

  // ---- IndexedDB: save on dirty + state signature compare ----
  var db = null;
  var DB_NAME = 'BEAST_Gestalt_DB';
  var DB_VERSION = 1;
  var STORE = 'gestalt_state';
  var KEY = 'gestalt_singleton';

  function serializeState() {
    return {
      gestaltArr: global.GestaltArr.map(function (g) { return normalizeGestalt(g); }),
      nextId: global.GestaltNextId,
      resonanceBuffer: global.GestaltResonanceBuffer.slice(),
      resonanceSeq: global.GestaltResonanceSeq,
      activeMasterCycleId: global.Gestalt_activeMasterCycleId,
      activeGestaltId: global.Gestalt_activeGestaltId
    };
  }

  function applyState(state) {
    if (!state || typeof state !== 'object') return;
    global.GestaltArr = Array.isArray(state.gestaltArr) ? state.gestaltArr.map(normalizeGestalt) : [];
    global.GestaltNextId = typeof state.nextId === 'number' && state.nextId > 0 ? state.nextId : 1;
    global.GestaltResonanceBuffer = Array.isArray(state.resonanceBuffer) ? state.resonanceBuffer : [];
    global.GestaltResonanceSeq = typeof state.resonanceSeq === 'number' && state.resonanceSeq > 0 ? state.resonanceSeq : 1;
    global.Gestalt_activeMasterCycleId = typeof state.activeMasterCycleId === 'number' ? state.activeMasterCycleId : 0;
    global.Gestalt_activeGestaltId = typeof state.activeGestaltId === 'number' ? state.activeGestaltId : 0;
    lastSavedSig = JSON.stringify(serializeState());
    gestaltDirty = false;
    if (typeof global.Info_updateView === 'function') {
      try {
        global.Info_updateView();
      } catch (eInfo) {}
    }
  }

  function openDb() {
    if (!global.indexedDB || !global.IndexedDBModule) return Promise.reject(new Error('IndexedDB is not available'));
    if (db) return Promise.resolve(db);
    return global.IndexedDBModule.openDatabase({
      dbName: DB_NAME,
      version: DB_VERSION,
      stores: [{ name: STORE, options: { keyPath: 'id' } }]
    }).then(function (d) {
      db = d;
      return d;
    });
  }

  function saveToIndexedDB(state) {
    if (!global.IndexedDBModule) return;
    state = state || serializeState();
    function put(database) {
      return global.IndexedDBModule.put({
        db: database,
        storeName: STORE,
        value: { id: KEY, state: state, ts: Date.now() }
      }).catch(function () {});
    }
    if (db) put(db);
    else openDb().then(put).catch(function () {});
  }

  function loadFromIndexedDB() {
    if (!global.IndexedDBModule) return;
    openDb()
      .then(function (d) {
        return global.IndexedDBModule.get({ db: d, storeName: STORE, key: KEY });
      })
      .then(function (record) {
        if (record && record.state) applyState(record.state);
      })
      .catch(function () {});
  }

  if (typeof global.GestaltContextForLevel3 === 'undefined') {
    global.GestaltContextForLevel3 = null;
  }

  if (typeof global.registerIndexedDBSaver === 'function') {
    global.registerIndexedDBSaver(function () {
      if (!gestaltDirty) return;
      var state = serializeState();
      var sig = JSON.stringify(state);
      if (sig === lastSavedSig) {
        gestaltDirty = false;
        return;
      }
      lastSavedSig = sig;
      gestaltDirty = false;
      saveToIndexedDB(state);
    });
  }

  loadFromIndexedDB();

  global.Gestalt_createOrGetForGoal = Gestalt_createOrGetForGoal;
  global.Gestalt_findGestaltByGoal = findGestaltByGoal;
  global.Gestalt_pushResonanceSignature = Gestalt_pushResonanceSignature;
  global.Gestalt_prepareContextForCycle = Gestalt_prepareContextForCycle;
  global.Gestalt_onConsciousnessTick = Gestalt_onConsciousnessTick;
  global.Gestalt_onEpisodeFeedbackClosed = Gestalt_onEpisodeFeedbackClosed;
  global.Gestalt_bindActiveMaster = Gestalt_bindActiveMaster;
  global.Gestalt_processResonanceBufferForCycle = Gestalt_processResonanceBufferForCycle;
  global.Gestalt_bumpFromMeaningForecast = Gestalt_bumpFromMeaningForecast;
})(window);
