/**
 * Passive fantasy: one step building an associative chain from episodic memory (EP) frames.
 *
 * Idea: in a teacher frame “operator answered with stimulus X” → responseStimulusImageId = X.
 * We set X as current focus (anchor stimulus), find matching frames, pick the strongest by |effect|,
 * take its action image (action image id) as the next X for the next pulse — a plot “if life went like this, then…”
 * without a real environment stimulus (simulated via runActionImage + info picture update).
 *
 * “Passive” thinking is cycle.thinkingMode === 'passive' (not InfoPicture).
 * Main cycle appends to InfoPicture.fantasmPlotRules; background — only cycle.fantasizmArr and
 * fantazmingPlot. While passive, L3–4 do not run (Consciousness_runOneStep). See about_passive_fantasizming.md.
 *
 * Dependencies: EpisodicMemory_getFramesByResponseStimulus, EpisodicMemory_pickBestFrameByAbsEffect,
 * runActionImage, Info_updateFromStimulus, Consciousness_cycleAppendLog, info_insight (FANTASMI_INSITE_COMPARE threshold).
 */
(function (global) {
  'use strict';

  /** Default |effect| threshold: above this the frame is significant enough for insight (switch to target). */
  var DEFAULT_INSITE_COMPARE = 5;

  function puls() {
    return typeof global.cpuls === 'number' ? global.cpuls : 0;
  }

  /** FO cycle log: background cycles use force so messages are not dropped. */
  function appendCycleLog(cycle, text, opts) {
    if (typeof global.Consciousness_cycleAppendLog !== 'function') return;
    var o = opts && typeof opts === 'object' ? opts : {};
    if (o.force === undefined) o.force = !cycle.isMainCycle;
    global.Consciousness_cycleAppendLog(cycle, text, puls(), o);
  }

  /** Init plot structure on cycle: chain links and last action image id as anchor for next EP lookup. */
  function ensureFantazmingPlot(cycle) {
    if (!cycle) return { chain: [], lastGeneratedActionId: 0 };
    if (!cycle.fantazmingPlot || typeof cycle.fantazmingPlot !== 'object') {
      cycle.fantazmingPlot = { chain: [], lastGeneratedActionId: 0 };
    }
    if (!Array.isArray(cycle.fantazmingPlot.chain)) cycle.fantazmingPlot.chain = [];
    if (cycle.fantazmingPlot.lastGeneratedActionId == null) cycle.fantazmingPlot.lastGeneratedActionId = 0;
    return cycle.fantazmingPlot;
  }

  /**
   * Append “fantasy plot” fragment to InfoPicture (fantasmPlotRules) for operator display.
   * Tail trim — avoid unbounded growth on long chains.
   */
  function appendFantasmSnapshotToInfoPicture(frameLike) {
    var info = typeof global.Info_initIfNeeded === 'function' ? global.Info_initIfNeeded() : global.InfoPicture;
    if (!info) return;
    if (!Array.isArray(info.fantasmPlotRules)) info.fantasmPlotRules = [];
    info.fantasmPlotRules.push({
      perceptionNodeId: frameLike.perceptionNodeId || 0,
      stimulusImageId: frameLike.stimulusImageId || 0,
      situationId: frameLike.situationId || 0,
      actionImageId: frameLike.actionImageId != null ? frameLike.actionImageId : null,
      effect: frameLike.effect != null ? frameLike.effect : null,
      responseStimulusImageId: frameLike.responseStimulusImageId != null ? frameLike.responseStimulusImageId : null,
      episodeIndex: frameLike._episodeIndex != null ? frameLike._episodeIndex : null
    });
    while (info.fantasmPlotRules.length > 80) info.fantasmPlotRules.shift();
  }

  /** Duplicate frame snapshot into cycle.fantasizmArr — working tape for debug / future cross-cycle links. */
  function syncFantasizmArr(cycle, frameLike) {
    if (!Array.isArray(cycle.fantasizmArr)) cycle.fantasizmArr = [];
    cycle.fantasizmArr.push({
      perceptionNodeId: frameLike.perceptionNodeId || 0,
      stimulusImageId: frameLike.stimulusImageId || 0,
      situationId: frameLike.situationId || 0,
      actionImageId: frameLike.actionImageId != null ? frameLike.actionImageId : null,
      effect: frameLike.effect != null ? frameLike.effect : null,
      responseStimulusImageId: frameLike.responseStimulusImageId != null ? frameLike.responseStimulusImageId : null
    });
  }

  /**
   * One passive-mode iteration step for this cycle.
   *
   * Return true if the chain was advanced (including insight branch without motor).
   * false — no anchor stimulus, no EP frames, or missing memory APIs.
   *
   * @param {Object} cycle — active consciousness cycle (status === 'running')
   * @returns {boolean}
   */
  function info_fantasizming(cycle) {
    if (!cycle || cycle.status !== 'running') return false;
    if (cycle.thinkingMode !== 'passive') return false;

    var inf = global.InfoPicture;
    var isMain = cycle.isMainCycle === true;

    var plot = ensureFantazmingPlot(cycle);
    // --- Step 1: anchor stimulus (FinalImageId) for teacher-frame lookup by responseStimulusImageId.
    // Priority: chain continuation (last step’s action image as new “response” id) → cycle creation context
    // → current goal in info picture (often 0 in passive).
    var currentStimulusId = 0;
    if (plot.lastGeneratedActionId) {
      currentStimulusId = parseInt(plot.lastGeneratedActionId, 10) || 0;
    }
    if (!currentStimulusId) {
      var cx = cycle.context || {};
      if (cx.actual_stimul_ID != null) currentStimulusId = parseInt(cx.actual_stimul_ID, 10) || 0;
    }
    if (!currentStimulusId && isMain && inf && typeof inf.currentGoalId === 'number' && inf.currentGoalId > 0) {
      currentStimulusId = inf.currentGoalId;
    }
    if (!currentStimulusId) {
      appendCycleLog(cycle, 'Fantasy: no anchor stimulus (currentStimulusId) — step skipped.');
      return false;
    }

    // --- Step 2: all EP frames where operator response matched currentStimulusId; best by |effect|.
    var getFrames = global.EpisodicMemory_getFramesByResponseStimulus;
    var pickBest = global.EpisodicMemory_pickBestFrameByAbsEffect;
    if (typeof getFrames !== 'function' || typeof pickBest !== 'function') {
      appendCycleLog(cycle, 'Fantasy: missing EpisodicMemory_getFramesByResponseStimulus / pickBestFrameByAbsEffect — plot not updated.');
      return false;
    }

    var candidates = getFrames(currentStimulusId);
    var bestFrame = pickBest(candidates);
    if (!bestFrame || !bestFrame.actionImageId) {
      appendCycleLog(cycle, 'Fantasy: no frame with responseStimulusImageId=' + currentStimulusId + ' — chain broken.');
      return false;
    }

    var actionId = parseInt(bestFrame.actionImageId, 10) || 0;
    if (!actionId) {
      appendCycleLog(cycle, 'Fantasy: EP frame has no valid actionImageId — plot not updated.');
      return false;
    }

    var eff = typeof bestFrame.effect === 'number' ? bestFrame.effect : 0;
    var threshold = typeof global.FANTASMI_INSITE_COMPARE === 'number' ? global.FANTASMI_INSITE_COMPARE : DEFAULT_INSITE_COMPARE;

    // --- Step 3: record link; lastGeneratedActionId = action image — next pulse searches
    // as if operator “answered” with that action image (match responseStimulusImageId in data).
    plot.chain.push({
      fromStimulusId: currentStimulusId,
      actionImageId: actionId,
      episodeIndex: bestFrame._episodeIndex != null ? bestFrame._episodeIndex : null,
      effect: eff
    });
    plot.lastGeneratedActionId = actionId;
    cycle.currentFantazmingStimulus = actionId;

    syncFantasizmArr(cycle, bestFrame);
    if (isMain) {
      appendFantasmSnapshotToInfoPicture(bestFrame);
    }

    // Each successful plot update — log line.
    var storyLog = 'Fantasy [plot]: response stimulus=' + currentStimulusId + ' → action image=' + actionId +
      ', effect=' + eff + ', episode #' + (bestFrame._episodeIndex != null ? bestFrame._episodeIndex : '—') +
      (isMain ? ', fantasy plot cell updated.' : ', context in fantasizmArr / fantazmingPlot.');
    appendCycleLog(cycle, storyLog);

    // --- Step 4a: extreme effect → insight: target mode, “meaning” goal.
    // Intentionally no runActionImage: semantic shift matters more than motor imitation this tick.
    if (Math.abs(eff) >= threshold && typeof global.info_insight === 'function') {
      global.info_insight(cycle, { fantasyInsight: true, effect: eff });
      if (isMain && global.InfoPicture) {
        global.InfoPicture.thinkingSource = 'fantasy';
      }
      if (isMain && typeof global.Info_incrementStep === 'function') {
        global.Info_incrementStep();
      }
      appendCycleLog(cycle, 'Fantasy: insight |effect|≥' + String(threshold) + ' — meaning goal, switch to target mode.', { force: true });
      return true;
    }

    // --- Step 4b: main cycle — simulate response and update global info; background — cycle context only.
    if (isMain) {
      if (typeof global.runActionImage === 'function') {
        global.runActionImage(actionId);
      }
      if (typeof global.Info_updateFromStimulus === 'function') {
        var showStim = bestFrame.stimulusImageId || actionId;
        global.Info_updateFromStimulus(showStim, 'imagination');
      }
      if (global.InfoPicture) {
        global.InfoPicture.thinkingSource = 'fantasy';
      }
      if (typeof global.Info_incrementStep === 'function') {
        global.Info_incrementStep();
      }
    }

    return true;
  }

  global.info_fantasizming = info_fantasizming;
  /** Global fantasy-insight threshold; may override before first step. */
  global.FANTASMI_INSITE_COMPARE = DEFAULT_INSITE_COMPARE;
})(window);
