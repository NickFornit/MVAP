(function (global) {
  'use strict';

  /**
   * Situation tree: three-level structure
   *  Level 1: comprehension mode (mode: 0 — passive, 1 — target)
   *  Level 2: Theme image (ThemeImage: id, mode, componentIds[], count, ready)
   *  Level 3: Situation image (SituationImage: id, mode, componentIds[], count, ready)
   *
   * Theme and Situation images are formed from info-picture fields:
   *  - Theme: from perception tree levels (BaseID, EmotionID, ActivityID)
   *  - Situation: from detector variables on the info picture (criticalVital, badState, ...).
   *
   * A new image becomes “ready” (ready = true) when count > 3.
   * Tree activation attempt — on each perception tree activation:
   *  - snapshot from current info (mode, themeComponents, situationComponents),
   *  - image counters increase,
   *  - if count > 3 — image marked ready,
   *  - the Theme/Situation whose ready images best match current components is activated.
   *
   * Activation result:
   *  - InfoDet_updateCurrentTheme(themeId)
   *  - InfoDet_updateCurrentSituation(situationId)
   *
   * Info-picture field detectors (vitals, effects, responses, etc.) — in info_detectors.js.
   */

  var ThemeImages = [];      // { id, mode, componentIds, count, ready }
  var SituationImages = [];  // { id, mode, componentIds, count, ready }
  var nextThemeId = 1;
  var nextSituationId = 1;
  var treeDirty = false;
  var lastSavedSig = '';

  // Fixed mapping of info-picture detector fields to component IDs for situations.
  // Gives stable numeric components for situation images.
  var DETECTOR_COMPONENT_IDS = {
    // InfoPicture mapping: when detector value is non-zero, this numeric id joins situation components.
    criticalVital: 1,              // critical vital active (>0 — vital id)
    shockState: 2,                 // shock state
    suddenChange: 3,               // sharp state change recorded
    playMode: 4,                   // Play mode
    learningMode: 5,               // learning mode
    negativeMotorEffect: 6,        // negative motor automatism effect
    negativeMentalEffect: 7,       // negative mental automatism effect
    badState: 8,                   // Bad state
    consoleStimulus: 9,            // active console stimulus
    searchInterest: 10,            // search interest
    teacherLearning: 11,           // learning with teacher
    operatorIgnoring: 12,          // operator ignoring
    dissatisfaction: 13,           // dissatisfaction with existing
    misunderstanding: 14,          // misunderstanding
    doubtInDefaultAutomatism: 16,  // doubt in default automatism
    defense: 17,                   // defense mode
    fear: 18,                      // Fear
    aggression: 19,                // Aggression
    highImportanceObject: 20,      // high-importance object present
    moodImproving: 21,             // mood improvement recorded
    imageNovelty: 22,              // high image novelty
    highSemanticImportance: 23,    // high semantic importance
    conflictingSemantics: 24,        // conflicting semantics
    hardProblem: 25,               // hard problem
    positiveActionEffect: 26,      // positive last-action effect
    negativeActionEffect: 27,      // negative last-action effect
    noReactionToStimulus: 28,      // no reaction to stimulus
    operatorAnswerReceived: 29,    // operator answer received
    activeWaitingAnswer: 30,       // active answer wait
    seriesWithoutEffect: 31,       // episode series without effect
    lowAutomatismUsefulness: 32,   // low automatism usefulness
    foundSuitableAutomatism: 33,    // suitable automatism found
    notFoundSuitableAutomatism: 34, // suitable automatism NOT found
    usedRule: 35,                   // reacting by rule
    /**
     * Synthetic “all calm” marker: not an InfoPicture field — injected in
     * extractSituationComponentsFromInfo when no non-zero detectors, but
     * BadNormWell is Norm/Good, basic context Rest (id 14) active, no critical vital.
     * Otherwise the “Situation” cell and situation images would not accumulate in a typical calm phase.
     */
    peaceNormBaseline: 36
  };

  function cloneSortedComponents(arr) {
    if (!Array.isArray(arr)) return [];
    var filtered = [];
    for (var i = 0; i < arr.length; i++) {
      var v = parseInt(arr[i], 10);
      if (!isNaN(v) && v !== 0 && filtered.indexOf(v) === -1) {
        filtered.push(v);
      }
    }
    filtered.sort(function (a, b) { return a - b; });
    return filtered;
  }

  function componentsEqual(a, b) {
    if (!Array.isArray(a) || !Array.isArray(b)) return false;
    if (a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (a[i] !== b[i]) return false;
    }
    return true;
  }

  // Simple match measure: count of shared components.
  function overlapScore(a, b) {
    if (!Array.isArray(a) || !Array.isArray(b) || !a.length || !b.length) return 0;
    var score = 0;
    for (var i = 0; i < a.length; i++) {
      if (b.indexOf(a[i]) !== -1) score++;
    }
    return score;
  }

  function findOrCreateThemeImage(mode, componentIds) {
    var comps = cloneSortedComponents(componentIds);
    if (!comps.length) return null;
    for (var i = 0; i < ThemeImages.length; i++) {
      var t = ThemeImages[i];
      if (t.mode === mode && componentsEqual(t.componentIds, comps)) {
        t.count++;
        if (!t.ready && t.count > 3) {
          t.ready = true;
        }
        return t;
      }
    }
    // New theme image
    var theme = {
      id: nextThemeId++,
      mode: mode,
      componentIds: comps,
      count: 1,
      ready: false
    };
    ThemeImages.push(theme);
    treeDirty = true;
    return theme;
  }

  function findOrCreateSituationImage(mode, componentIds) {
    var comps = cloneSortedComponents(componentIds);
    if (!comps.length) return null;
    for (var i = 0; i < SituationImages.length; i++) {
      var s = SituationImages[i];
      if (s.mode === mode && componentsEqual(s.componentIds, comps)) {
        s.count++;
        if (!s.ready && s.count > 3) {
          s.ready = true;
        }
        return s;
      }
    }
    // New situation image
    var sit = {
      id: nextSituationId++,
      mode: mode,
      componentIds: comps,
      count: 1,
      ready: false
    };
    SituationImages.push(sit);
    treeDirty = true;
    return sit;
  }

  // -------------------- Save/restore (file + IndexedDB) --------------------

  function serializeState() {
    return {
      nextThemeId: nextThemeId,
      nextSituationId: nextSituationId,
      themeImages: ThemeImages.slice(0),
      situationImages: SituationImages.slice(0)
    };
  }

  function applyState(state) {
    state = state || {};
    nextThemeId = parseInt(state.nextThemeId, 10);
    if (isNaN(nextThemeId) || nextThemeId < 1) nextThemeId = 1;
    nextSituationId = parseInt(state.nextSituationId, 10);
    if (isNaN(nextSituationId) || nextSituationId < 1) nextSituationId = 1;

    ThemeImages = Array.isArray(state.themeImages) ? state.themeImages.slice(0) : [];
    SituationImages = Array.isArray(state.situationImages) ? state.situationImages.slice(0) : [];

    // Recompute nextId defensively (load conflict guard)
    for (var i = 0; i < ThemeImages.length; i++) {
      var t = ThemeImages[i];
      if (t && typeof t.id === 'number' && t.id >= nextThemeId) nextThemeId = t.id + 1;
    }
    for (var j = 0; j < SituationImages.length; j++) {
      var s = SituationImages[j];
      if (s && typeof s.id === 'number' && s.id >= nextSituationId) nextSituationId = s.id + 1;
    }

    treeDirty = false;
    try {
      lastSavedSig = JSON.stringify(serializeState());
    } catch (e) {
      lastSavedSig = '';
    }
  }

  var DB_NAME = 'BEAST_SituationsTree_DB';
  // Bumping version forces onupgradeneeded and creates store
  // if DB was created without it (IndexedDB wrapper changes).
  var DB_VERSION = 2;
  var STORE = 'situations_tree_state';
  var KEY = 'situations_tree_singleton';

  function openDb() {
    if (!global.IndexedDBModule || typeof global.IndexedDBModule.openDB !== 'function') {
      return Promise.reject(new Error('IndexedDBModule not available'));
    }
    return global.IndexedDBModule.openDB({
      dbName: DB_NAME,
      version: DB_VERSION,
      storeName: STORE,
      keyPath: 'id'
    });
  }

  function loadFromIndexedDB() {
    openDb()
      .then(function (d) {
        return global.IndexedDBModule.get({ db: d, storeName: STORE, key: KEY });
      })
      .then(function (record) {
        if (record && record.state) {
          applyState(record.state);
        }
      })
      .catch(function (e) {
        if (global.console && typeof global.console.error === 'function') {
          global.console.error('SituationsTree IndexedDB load error:', e);
        }
      });
  }

  loadFromIndexedDB();

  if (typeof global.registerIndexedDBSaver === 'function') {
    global.registerIndexedDBSaver(function () {
      if (!treeDirty) return;
      treeDirty = false;
      var state = serializeState();
      var sig = '';
      try { sig = JSON.stringify(state); } catch (e) { sig = ''; }
      if (sig && sig === lastSavedSig) return;
      lastSavedSig = sig;
      openDb()
        .then(function (db) {
          return global.IndexedDBModule.put({
            db: db,
            storeName: STORE,
            value: { id: KEY, state: state, ts: Date.now() }
          });
        })
        .catch(function (e) {
          if (global.console && typeof global.console.error === 'function') {
            global.console.error('SituationsTree IndexedDB save error:', e);
          }
        });
    });
  }

  function findBestReadyTheme(mode, componentIds) {
    var comps = cloneSortedComponents(componentIds);
    if (!comps.length) return 0;
    var bestId = 0;
    var bestScore = 0;
    for (var i = 0; i < ThemeImages.length; i++) {
      var t = ThemeImages[i];
      if (!t.ready || t.mode !== mode) continue;
      var s = overlapScore(comps, t.componentIds);
      if (s > bestScore) {
        bestScore = s;
        bestId = t.id;
      }
    }
    return bestId;
  }

  function findBestReadySituation(mode, componentIds) {
    var comps = cloneSortedComponents(componentIds);
    if (!comps.length) return 0;
    var bestId = 0;
    var bestScore = 0;
    for (var i = 0; i < SituationImages.length; i++) {
      var sIt = SituationImages[i];
      if (!sIt.ready || sIt.mode !== mode) continue;
      var s = overlapScore(comps, sIt.componentIds);
      if (s > bestScore) {
        bestScore = s;
        bestId = sIt.id;
      }
    }
    return bestId;
  }

  // ---------- Public helpers for drill-down ----------

  function SituationsTree_getThemeImage(id) {
    for (var i = 0; i < ThemeImages.length; i++) {
      if (ThemeImages[i].id === id) return ThemeImages[i];
    }
    return null;
  }

  function SituationsTree_getAllThemeImages() {
    return ThemeImages.slice(0);
  }

  function SituationsTree_getSituationImage(id) {
    for (var i = 0; i < SituationImages.length; i++) {
      if (SituationImages[i].id === id) return SituationImages[i];
    }
    return null;
  }

  function SituationsTree_getAllSituationImages() {
    return SituationImages.slice(0);
  }

  function SituationsTree_getSituationComponentName(componentId) {
    for (var key in DETECTOR_COMPONENT_IDS) {
      if (!Object.prototype.hasOwnProperty.call(DETECTOR_COMPONENT_IDS, key)) continue;
      if (DETECTOR_COMPONENT_IDS[key] === componentId) {
        return key;
      }
    }
    return '';
  }

  /**
   * Extract Theme image components from current info picture:
   * for now: [BaseID, EmotionID, ActivityID] (non-zero).
   */
  function extractThemeComponentsFromInfo(info) {
    var comps = [];
    if (!info || !info.tree) return comps;
    if (info.tree.baseID) comps.push(info.tree.baseID);
    if (info.tree.emotionID) comps.push(info.tree.emotionID);
    if (info.tree.activityID) comps.push(info.tree.activityID);
    return comps;
  }

  /**
   * Extract Situation image components from current info picture:
   * by detector variables (each non-zero flag adds a component).
   * If set empty (typical under vital Norm and Rest, without alarm detectors),
   * peaceNormBaseline component (36) is injected so a calm-norm situation image
   * accumulates and activates — see DETECTOR_COMPONENT_IDS.peaceNormBaseline.
   */
  function extractSituationComponentsFromInfo(info) {
    var comps = [];
    if (!info) return comps;
    var k;
    for (k in DETECTOR_COMPONENT_IDS) {
      if (!Object.prototype.hasOwnProperty.call(DETECTOR_COMPONENT_IDS, k)) continue;
      if (k === 'peaceNormBaseline') continue;
      var cid = DETECTOR_COMPONENT_IDS[k];
      var v = info[k];
      if (typeof v === 'number' && v !== 0) {
        if (comps.indexOf(cid) === -1) comps.push(cid);
      }
    }
    if (!comps.length) {
      var bnw = typeof global.BadNormWell === 'number' ? global.BadNormWell : 0;
      var wellBenign = (bnw === 2 || bnw === 3);
      var act = global.BasicContextsActived;
      var peace = Array.isArray(act) && act.indexOf(14) !== -1;
      var crit = typeof info.criticalVital === 'number' ? info.criticalVital : 0;
      if (wellBenign && peace && !crit) {
        var baselineCid = DETECTOR_COMPONENT_IDS.peaceNormBaseline;
        if (baselineCid != null) comps.push(baselineCid);
      }
    }
    return comps;
  }

  /**
   * Main entry: called on each perception tree activation
   * (after info picture updated from PerceptionTree).
   *
   * 1) Extract mode (main cycle thinking mode), themeComponents, situationComponents from InfoPicture.
   * 2) Update/create Theme and Situation images (counters, ready when count>3).
   * 3) Find best ready Theme/Situation for mode and update
   *    current themeId / situationId via info detectors.
   */
  function SituationsTree_onPerceptionTreeActivated() {
    if (typeof global.Info_initIfNeeded !== 'function') return;
    var info = global.Info_initIfNeeded();
    if (!info) return;

    var mainTm = (typeof global.Consciousness_getMainCycleThinkingMode === 'function')
      ? global.Consciousness_getMainCycleThinkingMode()
      : 'target';
    var mode = (mainTm === 'target') ? 1 : 0;
    var themeComps = extractThemeComponentsFromInfo(info);
    var situationComps = extractSituationComponentsFromInfo(info);

    // Register / strengthen images (counters and ready).
    if (themeComps.length) {
      findOrCreateThemeImage(mode, themeComps);
    }
    if (situationComps.length) {
      findOrCreateSituationImage(mode, situationComps);
    }

    // Activate ready images — best matching THEME and SITUATION.
    var activeThemeId = findBestReadyTheme(mode, themeComps);
    var activeSituationId = findBestReadySituation(mode, situationComps);

    if (typeof global.InfoDet_updateCurrentTheme === 'function') {
      global.InfoDet_updateCurrentTheme(activeThemeId);
    }
    if (typeof global.InfoDet_updateCurrentSituation === 'function') {
      global.InfoDet_updateCurrentSituation(activeSituationId);
    }
  }

  /**
   * Stub: consider new situation images for the future during semantic processing of understanding models.
   * Called from PassiveMode_processUnderstandingModels (goals.js) when passive mode runs
   * semantic processing of understanding models; during that work future situation images may arise.
   * Full implementation: from understanding-model data (semantics, images) create or strengthen
   * SituationImages with matching componentIds (mode 0 — passive).
   */
  function SituationsTree_considerNewSituationFromUnderstanding() {
    // Stub: on semantic processing — form/update future situation images.
  }

  /** Clear all situation images (SituationImages); themes untouched. State persists via treeDirty. */
  function SituationsTree_clearAllSituationImages() {
    SituationImages = [];
    nextSituationId = 1;
    treeDirty = true;
    if (typeof global.InfoDet_updateCurrentSituation === 'function') {
      global.InfoDet_updateCurrentSituation(0);
    } else if (global.InfoPicture) {
      global.InfoPicture.situationId = 0;
    }
    if (typeof global.Info_updateView === 'function') global.Info_updateView();
  }

  global.SituationsTree_onPerceptionTreeActivated = SituationsTree_onPerceptionTreeActivated;
  global.SituationsTree_getThemeImage = SituationsTree_getThemeImage;
  global.SituationsTree_getAllThemeImages = SituationsTree_getAllThemeImages;
  global.SituationsTree_getSituationImage = SituationsTree_getSituationImage;
  global.SituationsTree_getAllSituationImages = SituationsTree_getAllSituationImages;
  global.SituationsTree_getSituationComponentName = SituationsTree_getSituationComponentName;
  global.SituationsTree_considerNewSituationFromUnderstanding = SituationsTree_considerNewSituationFromUnderstanding;
  global.SituationsTree_serializeState = serializeState;
  global.SituationsTree_applyState = applyState;
  global.SituationsTree_clearAllSituationImages = SituationsTree_clearAllSituationImages;

})(window);
