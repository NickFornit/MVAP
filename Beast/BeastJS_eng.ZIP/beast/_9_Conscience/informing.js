(function (global) {
  'use strict';

  /**
   * Information picture (InfoPicture) — working comprehension context.
   * Not persisted across sessions; on reload rebuilt from current activity.
   */
  function ensureInfoPicture() {
    if (!global.InfoPicture) {
      global.InfoPicture = {
        themeId: 0,
        situationId: 0,
        problemFinalImageId: 0,   // linked to unsolved_problem
        step: 0,
        tree: {
          baseID: 0,
          emotionID: 0,
          activityID: 0,
          toneMoodID: 0,
          simbolID: 0,
          phraseID: 0
        },
        stimulus: {
          source: 'external',     // 'external' | 'imagination'
          finalImageId: 0
        },
        // Info-picture detector fields (integers, default 0):
        // criticalVital: 0 — none, >0 — critical vital ID.
        criticalVital: 0,
        // shockState: 0 — none, 1 — shock state active.
        shockState: 0,
        // suddenChange: 0 — none, |value| — magnitude of sharp state change (normalized).
        suddenChange: 0,
        // playMode: 0 — none, 1 — Play mode active.
        playMode: 0,
        // learningMode: 0 — none, 1 — learning mode active.
        learningMode: 0,
        // isPlayMode / isLearningMode — duplicate for L3 (sync with playMode / learningMode on L2).
        isPlayMode: 0,
        isLearningMode: 0,
        // negativeMotorEffect: 0 — none, <0 — sum/level of negative motor automatism effect.
        negativeMotorEffect: 0,
        // negativeMentalEffect: 0 — none, <0 — sum/level of negative mental automatism effect.
        negativeMentalEffect: 0,
        // badState: 0 — not Bad, 1 — Bad state active.
        badState: 0,
        // consoleStimulus: 0 — none, >0 — last console stimulus ID.
        consoleStimulus: 0,
        // searchInterest: 0 — none, 1 — search interest active.
        searchInterest: 0,
        // teacherLearning: 0 — none, 1 — learning with teacher in progress.
        teacherLearning: 0,
        // operatorIgnoring: 0 — none, 1 — operator ignoring.
        operatorIgnoring: 0,
        // dissatisfaction: 0 — none, 1 — dissatisfaction with existing.
        dissatisfaction: 0,
        // isDissatisfaction: 0 — none, 1 — dissatisfaction-with-existing active (L3 trigger).
        isDissatisfaction: 0,
        // misunderstanding: 0 — none, 1 — misunderstanding state.
        misunderstanding: 0,
        // doubtInDefaultAutomatism: 0 — none, 1 — doubt in default automatism.
        doubtInDefaultAutomatism: 0,
        // defense: 0 — none, 1 — defense mode active.
        defense: 0,
        // fear: 0 — none, 1 — Fear active.
        fear: 0,
        // aggression: 0 — none, 1 — Aggression active.
        aggression: 0,
        // highImportanceObject: 0 — none, >0 — high-importance object ID.
        highImportanceObject: 0,
        // moodImproving: 0 — none, >0 — mood improvement magnitude.
        moodImproving: 0,
        // imageNovelty: 0 — none, >0 — image novelty level.
        imageNovelty: 0,
        // highSemanticImportance: 0 — none, >0 — high semantic importance magnitude.
        highSemanticImportance: 0,
        // conflictingSemantics: 0 — none, 1 — conflicting semantics detected.
        conflictingSemantics: 0,
        // hardProblem: 0 — none, >0 — attempt counter / problem difficulty level.
        hardProblem: 0,
        // positiveActionEffect: 0 — none, >0 — last positive effect magnitude.
        positiveActionEffect: 0,
        // negativeActionEffect: 0 — none, <0 — last negative effect magnitude.
        negativeActionEffect: 0,
        // noReactionToStimulus: 0 — none, 1 — no reaction recorded.
        noReactionToStimulus: 0,
        // operatorAnswerReceived: 0 — none, 1 — operator answer received.
        operatorAnswerReceived: 0,
        // isOperatorAnswerReceived: 0 — none, 1 — answer to reaction after consciousness automatism (incl. L2).
        isOperatorAnswerReceived: 0,
        // activeWaitingAnswer: 0 — none, 1 — active answer wait.
        activeWaitingAnswer: 0,
        // seriesWithoutEffect: 0 — none, >0 — length of last episode series without effect.
        seriesWithoutEffect: 0,
        // lowAutomatismUsefulness: 0 — none, <0 — low automatism usefulness level.
        lowAutomatismUsefulness: 0,
        // foundSuitableAutomatism: 0 — none, >0 — ID/flag of found suitable automatism.
        foundSuitableAutomatism: 0,
        // ImportantProblem: 0 — none, 1 — important problem (critical vitals); attention hysteresis to stimuli, at 0 — lighter OR/consciousness.
        ImportantProblem: 0,
        // usedRule: 0 — not by remembered rule; ≠0 — reacting by rule (flag or rule id per caller convention).
        usedRule: 0,
        // Fantasy plot: growing array of EP frame snapshots (UI cell); filled on target→passive and each info_fantasizming step.
        fantasmPlotRules: [],
        // What drives displayed thought: external — real stimulus; imagination — Info_updateFromStimulus(..., 'imagination'); fantasy — info_fantasizming step (passive chain).
        thinkingSource: 'external'
      };
      // Current goal (set on second comprehension level).
      global.InfoPicture.currentGoalType = null;   // 'base' | 'life' | 'voluntary' | 'meaning' | null
      global.InfoPicture.currentGoalId = 0;       // goal image id (life/voluntary)
      global.InfoPicture.currentGoalVitalId = 0;  // for base goal — vital ID
    } else {
      var pic = global.InfoPicture;
      if (pic.currentGoalType === undefined) pic.currentGoalType = null;
      if (pic.currentGoalId === undefined) pic.currentGoalId = 0;
      if (pic.currentGoalVitalId === undefined) pic.currentGoalVitalId = 0;
      if (pic.isDissatisfaction === undefined) pic.isDissatisfaction = 0;
      if (pic.ImportantProblem === undefined) pic.ImportantProblem = 0;
      if (pic.usedRule === undefined) pic.usedRule = 0;
      if (pic.isOperatorAnswerReceived === undefined) pic.isOperatorAnswerReceived = 0;
      if (pic.isPlayMode === undefined) pic.isPlayMode = 0;
      if (pic.isLearningMode === undefined) pic.isLearningMode = 0;
      if (pic.fantasmPlotRules === undefined || !Array.isArray(pic.fantasmPlotRules)) pic.fantasmPlotRules = [];
      if (pic.thinkingSource === undefined) pic.thinkingSource = 'external';
      if (pic.mode !== undefined) delete pic.mode;
    }
    return global.InfoPicture;
  }

  /** EP frame snapshots as “rules” for fantasy plot / fantasizmArr (stub until final algorithm). */
  function snapshotEpisodicRulesForFantasm(maxN) {
    maxN = typeof maxN === 'number' && maxN > 0 ? maxN : 8;
    var out = [];
    var ep = global.Episodes;
    if (!Array.isArray(ep) || !ep.length) return out;
    for (var i = ep.length - 1; i >= 0 && out.length < maxN; i--) {
      var f = ep[i];
      if (!f) continue;
      out.push({
        perceptionNodeId: f.perceptionNodeId || 0,
        stimulusImageId: f.stimulusImageId || 0,
        situationId: f.situationId || 0,
        actionImageId: f.actionImageId != null ? f.actionImageId : null,
        effect: f.effect != null ? f.effect : null,
        responseStimulusImageId: f.responseStimulusImageId != null ? f.responseStimulusImageId : null
      });
    }
    return out;
  }

  /**
   * When info picture goes passive (target → passive): fill fantasy plot.
   * TODO: replace with proper EP rule selection algorithm.
   */
  function Info_fillFantasmPlotOnPassiveMain() {
    var info = ensureInfoPicture();
    info.fantasmPlotRules = snapshotEpisodicRulesForFantasm(12);
  }

  /**
   * First step of background cycle in global passive mode: fill cycle fantasizmArr.
   * TODO: replace with proper algorithm.
   */
  function Info_fillFantasmPlotOnPassiveBackground(cycle) {
    if (!cycle) return;
    cycle.fantasizmArr = snapshotEpisodicRulesForFantasm(8);
  }

  function setByPath(obj, path, value) {
    if (!obj || !path) return;
    var parts = path.split('.');
    var cur = obj;
    for (var i = 0; i < parts.length - 1; i++) {
      var k = parts[i];
      if (!cur[k] || typeof cur[k] !== 'object') {
        cur[k] = {};
      }
      cur = cur[k];
    }
    cur[parts[parts.length - 1]] = value;
  }

  function getCell(id) {
    return global.document && global.document.getElementById(id);
  }

  /** show_alert link: click reloads dialog with detail for that ID. */
  function infoAlertIdLink(handlerName, id) {
    var n = parseInt(id, 10);
    if (isNaN(n)) n = 0;
    return '<span style="cursor:pointer;color:#1976d2;text-decoration:underline" onclick="' + handlerName + '(' + n + ')">' + String(n) + '</span>';
  }

  /** Abstractions object fields: detail handler by key name (for per-field ID drill-down). */
  var INFO_ABSTRACTION_FIELD_LINK = {
    perceptionNodeId: 'Info_showPerceptionNodeDetail',
    stimulusImageId: 'Info_showFinalImageStimulusDetail',
    actionImageId: 'Info_showActionImageDetail',
    sourceActionImageId: 'Info_showActionImageDetail',
    abstractPerceptionId: 'Info_showAbstractPerceptionImageDetail',
    abstractActionId: 'Info_showAbstractActionImageDetail',
    abstractionId: 'Info_showAbstractionDetail',
    mentalActionImageId: 'Info_showMentalActionImageDetail',
    themeId: 'Info_showThemeImageDetail',
    situationId: 'Info_showSituationImageDetail'
  };

  var INFO_ABSTRACTION_FIELD_LABEL = {
    perceptionNodeId: 'Perception branch node',
    stimulusImageId: 'Pinned stimulus (clone source)',
    actionImageId: 'Pinned action image (AI)',
    sourceActionImageId: 'Source action image',
    abstractPerceptionId: 'Perception clone (AbstractPerceptionImages)',
    abstractActionId: 'Action clone (AbstractActionImages)',
    abstractionId: 'Abstractions symbol',
    mentalActionImageId: 'Mental action image',
    themeId: 'Theme image',
    situationId: 'Situation image',
    meanImportance: 'Mean importance (avg.)',
    meanEffect: 'Mean effect',
    count: 'Averaging count',
    createdAt: 'Created',
    lastUsedAt: 'Last used',
    semanticStructure: 'Semantic structure'
  };

  /** Abstraction semanticStructure: condition frames (branch + situation) and EP / teacher rule. */
  function infoFormatAbstractSemanticStructureHtml(sem) {
    if (!sem || typeof sem !== 'object') return '<br><i>semanticStructure:</i> —';
    var frames = sem.frames;
    if (!Array.isArray(frames) || !frames.length) {
      return '<br><i>semanticStructure:</i> no frames (0 conditions)';
    }
    var parts = ['<br><b>semanticStructure</b> — by conditions (perception node + situation), ' + frames.length + ' frame(s):'];
    for (var si = 0; si < frames.length; si++) {
      var fr = frames[si];
      if (!fr) continue;
      var rk = fr.ruleKind || '—';
      parts.push('<br>— <b>' + rk + '</b>: node ' + (fr.perceptionNodeId || 0) + ', situation ' + (fr.situationId || 0));
      parts.push('<br> &nbsp; stimulus FinalImageId=' + (fr.stimulusImageId || 0) + ', AI=' + (fr.actionImageId != null ? fr.actionImageId : '—'));
      if (rk === 'teacher' || (fr.responseStimulusImageId != null && fr.responseStimulusImageId > 0)) {
        parts.push(', operator answer FinalImageId=' + (fr.responseStimulusImageId || 0));
      }
      if (typeof fr.effect === 'number') {
        parts.push(', effect=' + fr.effect);
      }
    }
    return parts.join('');
  }

  function infoFormatAbstractionFieldValue(key, val) {
    if (key === 'abstractActionIds' && Array.isArray(val)) {
      if (!val.length) return '—';
      var parts = [];
      for (var ai = 0; ai < val.length; ai++) {
        if (ai) parts.push(', ');
        var ab = parseInt(val[ai], 10) || 0;
        parts.push(ab ? infoAlertIdLink('Info_showAbstractionDetail', ab) : '0');
      }
      return parts.join('');
    }
    if (val != null && typeof val === 'object') {
      try {
        return JSON.stringify(val);
      } catch (e) {
        return String(val);
      }
    }
    var handler = INFO_ABSTRACTION_FIELD_LINK[key];
    var n = typeof val === 'number' ? val : parseInt(val, 10);
    if (handler && !isNaN(n) && n > 0) {
      return infoAlertIdLink(handler, n);
    }
    if ((key === 'createdAt' || key === 'lastUsedAt') && typeof val === 'number' && val > 0) {
      try {
        return new Date(val).toLocaleString();
      } catch (e2) {
        return String(val);
      }
    }
    return String(val);
  }

  /**
   * Situation image link: ready images get a blue border in detail lists.
   * @param {{id:number, ready?:boolean}|null} sv
   */
  function infoSituationImageLinkFromRecord(sv) {
    if (!sv || typeof sv.id !== 'number') return '';
    var n = sv.id;
    var ready = sv.ready === true;
    var base = 'cursor:pointer;color:#1976d2;text-decoration:underline;';
    var box = ready
      ? 'border:2px solid #1976d2;border-radius:4px;padding:1px 5px;display:inline-block;margin:0 1px;vertical-align:baseline;'
      : '';
    return '<span style="' + base + box + '" onclick="Info_showSituationImageDetail(' + n + ')">' + String(n) + '</span>';
  }

  function infoSituationImageLinkById(sitId) {
    var n = parseInt(sitId, 10) || 0;
    if (!n) return '0';
    var sv = typeof global.SituationsTree_getSituationImage === 'function'
      ? global.SituationsTree_getSituationImage(n) : null;
    if (sv) return infoSituationImageLinkFromRecord(sv);
    return infoAlertIdLink('Info_showSituationImageDetail', n);
  }

  function Info_showFinalImageStimulusDetail(finalImageId) {
    if (typeof global.show_alert !== 'function') return;
    finalImageId = parseInt(finalImageId, 10) || 0;
    if (!finalImageId) {
      global.show_alert('FinalImageId = 0.', 0);
      return;
    }
    var names = '';
    if (typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function') {
      names = global.PerceptionTree_getStimulusNamesForFinalImageId(finalImageId) || '';
    }
    var html = '<b>Final image FinalImageId:</b> ' + infoAlertIdLink('Info_showFinalImageStimulusDetail', finalImageId) +
      '<br><b>Stimuli:</b> ' + (names && names !== '—' ? names : '—');
    if (typeof global.getSemanticObjectFast === 'function') {
      var well = global.BadNormWell || 0;
      var emotionId = 0;
      if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
        emotionId = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
      }
      var semObj = (well && emotionId) ? global.getSemanticObjectFast(well, emotionId, finalImageId) : null;
      if (semObj) {
        html += '<br><br><b>Semantics (current well/emotion):</b> z ≈ ' +
          (Math.round(semObj.meanImportance * 100) / 100) + ', trainings: ' + semObj.samplesCount;
      }
    }
    global.show_alert(html, 0);
  }

  function Info_showPerceptionNodeDetail(nodeId) {
    if (typeof global.show_alert !== 'function') return;
    nodeId = parseInt(nodeId, 10) || 0;
    if (!nodeId || typeof global.PerceptionTree_getNode !== 'function') {
      global.show_alert('Branch node #' + nodeId + ' not found.', 0);
      return;
    }
    var node = global.PerceptionTree_getNode(nodeId);
    if (!node) {
      global.show_alert('Branch node #' + nodeId + ' not found in perception tree.', 0);
      return;
    }
    var actId = node.activityID || 0;
    var actDetail = '';
    if (actId && typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function') {
      actDetail = global.PerceptionTree_getStimulusNamesForFinalImageId(actId) || '';
    }
    var html = '<b>Branch node (branchId) ' + infoAlertIdLink('Info_showPerceptionNodeDetail', nodeId) + '</b>' +
      '<br>BaseID: ' + (node.baseID || 0) +
      '<br>EmotionID: ' + (node.emotionID || 0) +
      '<br>ActivityID: ' + (actId ? infoAlertIdLink('Info_showFinalImageStimulusDetail', actId) : '0') +
      (actDetail && actDetail !== '—' ? '<br><i>Current image:</i> ' + actDetail : '') +
      '<br>ToneMoodID: ' + (node.toneMoodID || 0) +
      '<br>SimbolID: ' + (node.simbolID || 0) +
      '<br>PhraseID: ' + (node.phraseID || 0) +
      '<br>parentId: ' + (node.parentId != null ? node.parentId : '—');
    global.show_alert(html, 0);
  }

  function Info_showEmotionRecordDetail(emotionId) {
    if (typeof global.show_alert !== 'function') return;
    emotionId = parseInt(emotionId, 10) || 0;
    if (!emotionId) {
      global.show_alert('emotionId = 0.', 0);
      return;
    }
    var em = null;
    if (Array.isArray(global.Emotions)) {
      for (var ei = 0; ei < global.Emotions.length; ei++) {
        if (global.Emotions[ei] && global.Emotions[ei].id === emotionId) {
          em = global.Emotions[ei];
          break;
        }
      }
    }
    if (!em) {
      global.show_alert('Emotion record #' + emotionId + ' not found.', 0);
      return;
    }
    var parts = ['<b>Emotion (emotionId) ' + infoAlertIdLink('Info_showEmotionRecordDetail', emotionId) + '</b>'];
    var emotionContexts = em.contextIds || [];
    if (emotionContexts.length && Array.isArray(global.BasicContexts)) {
      var names = [];
      for (var ci = 0; ci < emotionContexts.length; ci++) {
        var cid = emotionContexts[ci];
        var found = false;
        for (var bj = 0; bj < global.BasicContexts.length; bj++) {
          if (global.BasicContexts[bj] && global.BasicContexts[bj].id === cid) {
            names.push(global.BasicContexts[bj].name || ('Context ' + cid));
            found = true;
            break;
          }
        }
        if (!found) names.push('id ' + cid);
      }
      parts.push('<br><b>Basic contexts:</b> ' + names.join(', '));
    } else {
      parts.push('<br>Contexts: —');
    }
    global.show_alert(parts.join(''), 0);
  }

  function Info_showCycleDetailById(cycleId) {
    if (typeof global.show_alert !== 'function') return;
    cycleId = parseInt(cycleId, 10);
    if (isNaN(cycleId) || cycleId <= 0) return;
    var getCycle = global.Consciousness_getCycle;
    var cycle = typeof getCycle === 'function' ? getCycle(cycleId) : null;
    if (!cycle) {
      global.show_alert('Cycle with ID ' + String(cycleId) + ' not found in registry.', 0);
      return;
    }
    var mainId = typeof global.ConsciousnessCurrentProcessId === 'number' ? global.ConsciousnessCurrentProcessId : 0;
    var prefix = (cycleId === mainId && mainId) ? 'Main cycle' : ('Cycle #' + String(cycleId));
    global.show_alert(formatCycleOrStackInfo(cycle, prefix), 0);
  }

  var thinkingTimer = null;

  /**
   * Brief “orienting effect” indicator for comprehension:
   * lights the blue lamp next to the “Information picture” title for 0.5 s.
   */
  function Info_thinkingFlash() {
    if (!global.document) return;
    var el = getCell('infoThinkingIndicator');
    if (!el) return;
    el.classList.add('on');
    if (thinkingTimer !== null) {
      global.clearTimeout(thinkingTimer);
    }
    thinkingTimer = global.setTimeout(function () {
      el.classList.remove('on');
      thinkingTimer = null;
    }, 500);
  }

  /**
   * Refresh info-picture indicators on the main page.
   * Called automatically whenever InfoPicture changes.
   */
  function Info_updateView() {
    var info = ensureInfoPicture();
    if (!global.document) return;

    var mainThinking = (typeof global.Consciousness_getMainCycleThinkingMode === 'function')
      ? global.Consciousness_getMainCycleThinkingMode()
      : 'target';
    if (info._fantasmPrevMainThinkingMode === undefined) {
      info._fantasmPrevMainThinkingMode = mainThinking;
    } else {
      if (mainThinking === 'passive' && info._fantasmPrevMainThinkingMode === 'target') {
        Info_fillFantasmPlotOnPassiveMain();
      }
      info._fantasmPrevMainThinkingMode = mainThinking;
    }

    var modeCell = getCell('infoModeCell');
    var themeCell = getCell('infoThemeCell');
    var situationCell = getCell('infoSituationCell');
    var problemCell = getCell('infoProblemCell');
    var stepCell = getCell('infoStepCell');
    var stimCell = getCell('infoStimulusCell');
    var baseCell = getCell('infoBaseCell');
    var emoCell = getCell('infoEmotionCell');
    var actCell = getCell('infoActivityCell');
    // Detector cells
    var detCriticalVital = getCell('infoDetCriticalVital');
    var detImportantProblem = getCell('infoDetImportantProblem');
    var detUsedRule = getCell('infoDetUsedRule');
    var detShockState = getCell('infoDetShockState');
    var detSuddenChange = getCell('infoDetSuddenChange');
    var detPlayMode = getCell('infoDetPlayMode');
    var detLearningMode = getCell('infoDetLearningMode');
    var detNegativeMotor = getCell('infoDetNegativeMotor');
    var detNegativeMental = getCell('infoDetNegativeMental');
    var detBadState = getCell('infoDetBadState');
    var detConsoleStimulus = getCell('infoDetConsoleStimulus');
    var detSearchInterest = getCell('infoDetSearchInterest');
    var detTeacherLearning = getCell('infoDetTeacherLearning');
    var detOperatorIgnoring = getCell('infoDetOperatorIgnoring');
    var detDissatisfaction = getCell('infoDetDissatisfaction');
    var detMisunderstanding = getCell('infoDetMisunderstanding');
    var detDoubtAuto = getCell('infoDetDoubtAuto');
    var detDefense = getCell('infoDetDefense');
    var detFear = getCell('infoDetFear');
    var detAggression = getCell('infoDetAggression');
    var detHighObj = getCell('infoDetHighObj');
    var detMoodImproving = getCell('infoDetMoodImproving');
    var detImageNovelty = getCell('infoDetImageNovelty');
    var detHighSem = getCell('infoDetHighSem');
    var detConfSem = getCell('infoDetConfSem');
    var detHardProblem = getCell('infoDetHardProblem');
    var detPosEffect = getCell('infoDetPosEffect');
    var detNegEffect = getCell('infoDetNegEffect');
    var detNoReaction = getCell('infoDetNoReaction');
    var detAnswer = getCell('infoDetAnswer');
    var detActiveWait = getCell('infoDetActiveWait');
    var detSeriesNoEffect = getCell('infoDetSeriesNoEffect');
    var detLowAutoUse = getCell('infoDetLowAutoUse');
    var detFoundAuto = getCell('infoDetFoundAuto');
    var bgCountLabel = getCell('infoBackgroundCountLabel');
    var interruptQueueLabel = getCell('infoInterruptQueueLabel');
    var bgStackIndicator = getCell('infoBackgroundStackIndicator');
    var motorAutoInd = getCell('infoMotorAutomatizmsIndicator');
    var mentalAutoInd = getCell('infoMentalAutomatizmsIndicator');
    var abstrInd = getCell('infoAbstractionsIndicator');
    var lifeGoalsInd = getCell('infoLifeGoalsIndicator');
    var situationImagesInd = getCell('infoSituationImagesIndicator');
    var mainProcessLabel = getCell('infoMainProcessLabel');

    if (modeCell) {
      var mt = (typeof global.Consciousness_getMainCycleThinkingMode === 'function')
        ? global.Consciousness_getMainCycleThinkingMode()
        : 'target';
      var modeTitle = (mt === 'target' ? 'Target (active)' : 'Passive') + ' thinking mode (main cycle)';
      modeCell.title = modeTitle;
      modeCell.classList.toggle('info-cell-active', true);
    }
    if (themeCell) {
      themeCell.title = info.themeId ? ('Theme #' + info.themeId) : 'Theme not active';
      themeCell.classList.toggle('info-cell-active', !!info.themeId);
    }
    if (situationCell) {
      situationCell.title = info.situationId ? ('Situation #' + info.situationId) : 'Situation not active';
      situationCell.classList.toggle('info-cell-active', !!info.situationId);
    }
    if (problemCell) {
      problemCell.title = info.problemFinalImageId
        ? ('Open problem: FinalImageId=' + info.problemFinalImageId)
        : 'No open problem';
      problemCell.classList.toggle('info-cell-active', !!info.problemFinalImageId);
    }
    if (stepCell) {
      stepCell.title = 'Comprehension step: ' + String(info.step || 0);
      stepCell.classList.toggle('info-cell-active', info.step > 0);
    }
    if (stimCell) {
      stimCell.title = info.stimulus.finalImageId
        ? ('Current stimulus: FinalImageId=' + info.stimulus.finalImageId)
        : 'No current stimulus';
      stimCell.classList.toggle('info-cell-active', !!info.stimulus.finalImageId);
    }
    if (baseCell || emoCell || actCell) {
      var treeTitle = 'Perception tree branch:\n' +
        'BaseID=' + (info.tree.baseID || 0) +
        ' → EmotionID=' + (info.tree.emotionID || 0) +
        ' → ActivityID=' + (info.tree.activityID || 0) +
        ' → ToneMoodID=' + (info.tree.toneMoodID || 0) +
        ' → SimbolID=' + (info.tree.simbolID || 0) +
        ' → PhraseID=' + (info.tree.phraseID || 0);
      if (baseCell) {
        baseCell.title = treeTitle;
        baseCell.classList.toggle('info-cell-active', !!info.tree.baseID);
      }
      if (emoCell) {
        emoCell.title = 'EmotionID=' + (info.tree.emotionID || 0) + '\n(click — basic context mix)\n\n' + treeTitle;
        emoCell.classList.toggle('info-cell-active', !!info.tree.emotionID);
      }
      if (actCell) {
        var aId = info.tree.activityID || 0;
        var aNames = '';
        if (aId && typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function') {
          aNames = global.PerceptionTree_getStimulusNamesForFinalImageId(aId) || '';
        }
        actCell.title = 'ActivityID=' + aId + (aNames ? ('\n' + aNames) : '') + '\n(click — activity detail)\n\n' + treeTitle;
        actCell.classList.toggle('info-cell-active', !!info.tree.activityID);
      }
    }

    // Background process and interrupt-queue indicators.
    var bgCount = typeof global.Consciousness_getBackgroundCyclesCount === 'function'
      ? global.Consciousness_getBackgroundCyclesCount() : 0;
    var interruptQueueLen = Array.isArray(global.ConsciousnessBackgroundStack) ? global.ConsciousnessBackgroundStack.length : 0;
    if (bgCountLabel) {
      bgCountLabel.textContent = 'Pure-background processes: ' + String(bgCount);
    }
    if (interruptQueueLabel) {
      interruptQueueLabel.textContent = 'interrupt queue: ' + String(interruptQueueLen);
      interruptQueueLabel.title = 'Interrupted main cycles queued for return (LIFO): ' + String(interruptQueueLen);
    }
    if (bgStackIndicator) {
      bgStackIndicator.textContent = 'bg: ' + String(bgCount);
      var title = 'Background comprehension cycles (' + bgCount + '), click for detail:';
      if (typeof global.Consciousness_getBackgroundCyclesList === 'function') {
        var list = global.Consciousness_getBackgroundCyclesList();
        for (var si = 0; si < list.length; si++) {
          var item = list[si];
          var ctx = item && item.context ? item.context : null;
          var stimId = ctx && typeof ctx.actual_stimul_ID === 'number' ? ctx.actual_stimul_ID : 0;
          title += '\nID ' + String(item && item.id != null ? item.id : '—') +
            ' — stimulus FinalImageId=' + String(stimId) + ', weight=' + String(item && typeof item.weight === 'number' ? item.weight : 0) +
            (item && item.expired ? ', expired' : '');
        }
      }
      bgStackIndicator.title = title;
    }

    var motorN = Array.isArray(global.Automatizms) ? global.Automatizms.length : 0;
    var mentalN = Array.isArray(global.MentalAutomatizms) ? global.MentalAutomatizms.length : 0;
    // “Clones” from EP (abstract_images.js) — not the Abstractions array (mental_automatism.js symbols).
    var apClones = Array.isArray(global.AbstractPerceptionImages) ? global.AbstractPerceptionImages.length : 0;
    var aaClones = Array.isArray(global.AbstractActionImages) ? global.AbstractActionImages.length : 0;
    var cloneAbstrN = apClones + aaClones;
    var mentalSymN = Array.isArray(global.Abstractions) ? global.Abstractions.length : 0;
    if (motorAutoInd) {
      motorAutoInd.textContent = 'auto: ' + String(motorN);
      motorAutoInd.title = 'Motor automatisms (' + motorN + '), click — ID list';
    }
    if (mentalAutoInd) {
      mentalAutoInd.textContent = 'm-auto: ' + String(mentalN);
      mentalAutoInd.title = 'Mental automatisms (' + mentalN + '), click — ID list';
    }
    if (abstrInd) {
      var abstrLabel = String(cloneAbstrN);
      if (mentalSymN > 0) abstrLabel += '+' + String(mentalSymN);
      abstrInd.textContent = 'abstr: ' + abstrLabel;
      abstrInd.title = 'Three kinds: perception clones ' + apClones + ', action clones ' + aaClones
        + ' (abstract_images.js); Abstractions symbols: ' + mentalSymN + ' (mental_automatism.js).'
        + ' Click — summary; each ID in the list opens its detail.';
    }
    var lifeGoalsArr = Array.isArray(global.GoalImagesLife) ? global.GoalImagesLife : [];
    var lifeGoalsN = 0;
    for (var gi = 0; gi < lifeGoalsArr.length; gi++) {
      if (lifeGoalsArr[gi] && typeof lifeGoalsArr[gi].id === 'number') lifeGoalsN += 1;
    }
    if (lifeGoalsInd) {
      lifeGoalsInd.textContent = 'goals: ' + String(lifeGoalsN);
      lifeGoalsInd.title = 'Life-experience goal images (GoalImagesLife), ' + lifeGoalsN + ' items; click — ID list';
    }
    var sitImgN = 0;
    if (typeof global.SituationsTree_getAllSituationImages === 'function') {
      var sitArr = global.SituationsTree_getAllSituationImages() || [];
      sitImgN = sitArr.length;
    }
    if (situationImagesInd) {
      situationImagesInd.textContent = 'situations: ' + String(sitImgN);
      situationImagesInd.title = 'Situation images (SituationImages), ' + sitImgN + ' items; click — ID list';
    }

    var gestaltInd = getCell('infoGestaltsIndicator');
    if (gestaltInd) {
      var gArr = Array.isArray(global.GestaltArr) ? global.GestaltArr : [];
      var gN = gArr.length;
      var rBuf = Array.isArray(global.GestaltResonanceBuffer) ? global.GestaltResonanceBuffer.length : 0;
      gestaltInd.textContent = 'gest: ' + String(gN);
      gestaltInd.title = 'Gestalts (dominants), records: ' + gN
        + ', resonance buffer (EP signatures): ' + rBuf + '. Click — ID list. See beast/_9_Conscience/gestalt.js';
    }
    var fantasmInd = getCell('infoFantasmPlotIndicator');
    if (fantasmInd) {
      var fp = Array.isArray(info.fantasmPlotRules) ? info.fantasmPlotRules : [];
      var fpN = fp.length;
      fantasmInd.textContent = 'fant: ' + String(fpN);
      fantasmInd.title = 'Fantasy plot: EP rules in plot ' + fpN
        + '. Filled when switching to passive (target→passive). Click — detail.';
    }
    var fantasmCell = getCell('infoFantasmPlotCell');
    if (fantasmCell) {
      var fp2 = Array.isArray(info.fantasmPlotRules) ? info.fantasmPlotRules : [];
      fantasmCell.title = 'Fantasy plot: ' + fp2.length + ' EP snapshot rule(s). Click — list.';
      fantasmCell.classList.toggle('info-cell-active', fp2.length > 0);
    }

    // Current main comprehension cycle indicator (click — cycle detail).
    if (mainProcessLabel) {
      var mainId = typeof global.ConsciousnessCurrentProcessId === 'number'
        ? global.ConsciousnessCurrentProcessId
        : 0;
      var mainCyc = mainId && typeof global.Consciousness_getCycle === 'function'
        ? global.Consciousness_getCycle(mainId) : null;
      var mainExpired = !!(mainCyc && mainCyc.expired);
      mainProcessLabel.textContent = 'Main cycle ID: ' + String(mainId) +
        (mainExpired ? ' · expired' : '');
      mainProcessLabel.title = 'Click for cycle detail' +
        (mainExpired ? '. Cycle marked expired (finished).' : '');
      mainProcessLabel.style.cursor = 'pointer';
      mainProcessLabel.onclick = function () {
        if (typeof global.Info_showMainCycleDetail === 'function') global.Info_showMainCycleDetail();
      };
    }

    // Detector indicators (yellow highlight when active)
    if (detCriticalVital) detCriticalVital.classList.toggle('info-cell-active', !!info.criticalVital);
    if (detImportantProblem) detImportantProblem.classList.toggle('info-cell-active', !!info.ImportantProblem);
    if (detUsedRule) {
      var urVal = typeof info.usedRule === 'number' ? info.usedRule : 0;
      var stArr = Array.isArray(global.Target_rule_stack) ? global.Target_rule_stack : [];
      var stTxt = stArr.length
        ? ('bottom→top: ' + stArr.map(function (x) { return String(x); }).join(', '))
        : 'stack empty';
      detUsedRule.title = 'Reacting by rule (usedRule): ' + (urVal ? ('yes (' + urVal + ')') : 'no') +
        '\nTarget_rule_stack (up to 3 goal IDs): ' + stTxt;
      detUsedRule.classList.toggle('info-cell-active', !!urVal);
    }
    if (detShockState) detShockState.classList.toggle('info-cell-active', !!info.shockState);
    if (detSuddenChange) detSuddenChange.classList.toggle('info-cell-active', !!info.suddenChange);
    if (detPlayMode) detPlayMode.classList.toggle('info-cell-active', !!info.playMode);
    if (detLearningMode) detLearningMode.classList.toggle('info-cell-active', !!info.learningMode);
    if (detNegativeMotor) detNegativeMotor.classList.toggle('info-cell-active', !!info.negativeMotorEffect);
    if (detNegativeMental) detNegativeMental.classList.toggle('info-cell-active', !!info.negativeMentalEffect);
    if (detBadState) detBadState.classList.toggle('info-cell-active', !!info.badState);
    if (detConsoleStimulus) detConsoleStimulus.classList.toggle('info-cell-active', !!info.consoleStimulus);
    if (detSearchInterest) detSearchInterest.classList.toggle('info-cell-active', !!info.searchInterest);
    if (detTeacherLearning) detTeacherLearning.classList.toggle('info-cell-active', !!info.teacherLearning);
    if (detOperatorIgnoring) detOperatorIgnoring.classList.toggle('info-cell-active', !!info.operatorIgnoring);
    if (detDissatisfaction) detDissatisfaction.classList.toggle('info-cell-active', !!info.dissatisfaction);
    if (detMisunderstanding) detMisunderstanding.classList.toggle('info-cell-active', !!info.misunderstanding);
    if (detDoubtAuto) detDoubtAuto.classList.toggle('info-cell-active', !!info.doubtInDefaultAutomatism);
    if (detDefense) detDefense.classList.toggle('info-cell-active', !!info.defense);
    if (detFear) detFear.classList.toggle('info-cell-active', !!info.fear);
    if (detAggression) detAggression.classList.toggle('info-cell-active', !!info.aggression);
    if (detHighObj) detHighObj.classList.toggle('info-cell-active', !!info.highImportanceObject);
    if (detMoodImproving) detMoodImproving.classList.toggle('info-cell-active', !!info.moodImproving);
    if (detImageNovelty) detImageNovelty.classList.toggle('info-cell-active', !!info.imageNovelty);
    if (detHighSem) detHighSem.classList.toggle('info-cell-active', !!info.highSemanticImportance);
    if (detConfSem) detConfSem.classList.toggle('info-cell-active', !!info.conflictingSemantics);
    if (detHardProblem) detHardProblem.classList.toggle('info-cell-active', !!info.hardProblem);
    if (detPosEffect) detPosEffect.classList.toggle('info-cell-active', !!info.positiveActionEffect);
    if (detNegEffect) detNegEffect.classList.toggle('info-cell-active', !!info.negativeActionEffect);
    if (detNoReaction) detNoReaction.classList.toggle('info-cell-active', !!info.noReactionToStimulus);
    if (detAnswer) {
      detAnswer.classList.toggle('info-cell-active',
        !!(info.operatorAnswerReceived || info.isOperatorAnswerReceived));
    }
    if (detActiveWait) detActiveWait.classList.toggle('info-cell-active', !!info.activeWaitingAnswer);
    if (detSeriesNoEffect) detSeriesNoEffect.classList.toggle('info-cell-active', !!info.seriesWithoutEffect);
    if (detLowAutoUse) detLowAutoUse.classList.toggle('info-cell-active', !!info.lowAutomatismUsefulness);
    if (detFoundAuto) detFoundAuto.classList.toggle('info-cell-active', !!info.foundSuitableAutomatism);
  }

  function Info_setField(path, value) {
    var info = ensureInfoPicture();
    setByPath(info, path, value);
    Info_updateView();
  }

  /**
   * Thinking mode is set only on the main consciousness cycle (thinkingMode), not on the info picture object.
   */
  function Info_setMode(mode) {
    var passive = !(mode === 'target');
    if (typeof global.Consciousness_getMainCycle === 'function') {
      var mc = global.Consciousness_getMainCycle();
      if (mc) {
        mc.thinkingMode = passive ? 'passive' : 'target';
      }
    }
    if (typeof global.Info_updateView === 'function') {
      global.Info_updateView();
    }
  }

  var lastActiveBranchIdForSituations = null;

  function Info_updateFromPerceptionTree() {
    if (typeof global.PerceptionTree_getActiveTerminalNodeId !== 'function' ||
        typeof global.PerceptionTree_getPathByNodeId !== 'function') {
      return;
    }
    var nodeId = global.PerceptionTree_getActiveTerminalNodeId();
    if (!nodeId) return;
    var path = global.PerceptionTree_getPathByNodeId(nodeId);
    if (!Array.isArray(path) || path.length < 3) return;
    var info = ensureInfoPicture();
    info.tree.baseID = path[0] || 0;
    info.tree.emotionID = path[1] || 0;
    info.tree.activityID = path[2] || 0;
    info.tree.toneMoodID = path[3] || 0;
    info.tree.simbolID = path[4] || 0;
    info.tree.phraseID = path[5] || 0;
    Info_updateView();
    // Update theme and situation only when active perception branch ID changes, not every pulse.
    if (nodeId !== lastActiveBranchIdForSituations) {
      lastActiveBranchIdForSituations = nodeId;
      if (typeof global.SituationsTree_onPerceptionTreeActivated === 'function') {
        global.SituationsTree_onPerceptionTreeActivated();
      }
    }
  }

  function Info_updateFromStimulus(finalImageId, source) {
    var info = ensureInfoPicture();
    info.stimulus.finalImageId = finalImageId || 0;
    info.stimulus.source = source || 'external';
    Info_updateView();
  }

  function Info_setProblemFromUnsolved(finalImageId) {
    Info_setField('problemFinalImageId', finalImageId || 0);
  }

  function Info_incrementStep() {
    var info = ensureInfoPicture();
    info.step = (info.step || 0) + 1;
    Info_updateView();
  }

  /** English labels for situation detectors (keys match SituationsTree_getSituationComponentName). */
  var SITUATION_DETECTOR_LABELS = {
    criticalVital: 'critical vital',
    shockState: 'shock state',
    suddenChange: 'sudden state change',
    playMode: 'Play mode',
    learningMode: 'learning mode',
    negativeMotorEffect: 'negative motor automatism effect',
    negativeMentalEffect: 'negative mental automatism effect',
    badState: 'Bad state',
    consoleStimulus: 'console stimulus',
    searchInterest: 'search interest',
    teacherLearning: 'learning with teacher',
    operatorIgnoring: 'operator ignoring',
    dissatisfaction: 'dissatisfaction',
    misunderstanding: 'misunderstanding',
    doubtInDefaultAutomatism: 'doubt in default automatism',
    defense: 'defense',
    fear: 'Fear',
    aggression: 'Aggression',
    highImportanceObject: 'high-importance object',
    moodImproving: 'mood improving',
    imageNovelty: 'image novelty',
    highSemanticImportance: 'high semantic importance',
    conflictingSemantics: 'conflicting semantics',
    hardProblem: 'hard problem',
    positiveActionEffect: 'positive action effect',
    negativeActionEffect: 'negative action effect',
    noReactionToStimulus: 'no reaction to stimulus',
    operatorAnswerReceived: 'operator answer received',
    activeWaitingAnswer: 'active answer wait',
    seriesWithoutEffect: 'episode series without effect',
    lowAutomatismUsefulness: 'low automatism usefulness',
    foundSuitableAutomatism: 'suitable automatism found',
    notFoundSuitableAutomatism: 'no suitable automatism found',
    usedRule: 'reacting by rule',
    peaceNormBaseline: 'vitals norm and calm'
  };

  function Info_formatSituationDetectorNames(sImg) {
    if (!sImg || !Array.isArray(sImg.componentIds) || !sImg.componentIds.length) {
      return '—';
    }
    var parts = [];
    for (var di = 0; di < sImg.componentIds.length; di++) {
      var cid = sImg.componentIds[di];
      var key = (typeof global.SituationsTree_getSituationComponentName === 'function')
        ? global.SituationsTree_getSituationComponentName(cid) : '';
      var label = (key && SITUATION_DETECTOR_LABELS[key]) || key || ('id ' + String(cid));
      parts.push(label);
    }
    return parts.join(', ');
  }

  function Info_showDetail(key) {
    if (typeof global.show_alert !== 'function') return;
    var info = ensureInfoPicture();
    var html = '';
    if (key === 'mode') {
      var mtm = (typeof global.Consciousness_getMainCycleThinkingMode === 'function')
        ? global.Consciousness_getMainCycleThinkingMode()
        : 'target';
      html = '<b>Thinking mode (main consciousness cycle):</b> ' + (mtm === 'target' ? 'Target' : 'Passive');
    } else if (key === 'fantasmPlot') {
      var rules = Array.isArray(info.fantasmPlotRules) ? info.fantasmPlotRules : [];
      html = '<b>Fantasy plot</b> — growing array of episodic-memory rules (frame snapshots).';
      html += '<br><small>On target → passive transition it is filled (final algorithm TBD; currently last Episodes frames).</small>';
      html += '<br><br><b>Rules in plot:</b> ' + rules.length;
      for (var fpi = 0; fpi < rules.length; fpi++) {
        var rr = rules[fpi];
        if (!rr) continue;
        html += '<br>— node ' + (rr.perceptionNodeId || 0) + ', situation ' + (rr.situationId || 0) +
          ', stimulus ' + (rr.stimulusImageId || 0) + ', AI=' + (rr.actionImageId != null ? rr.actionImageId : '—') +
          ', effect=' + (rr.effect != null ? rr.effect : '—');
      }
      if (!rules.length) html += '<br><i>empty for now</i>';
    } else if (key === 'theme') {
      var thId = info.themeId || 0;
      html = '<b>Theme:</b> ' + (thId || 'none');
      if (thId && typeof global.SituationsTree_getThemeImage === 'function') {
        var tImg = global.SituationsTree_getThemeImage(thId);
        if (tImg) {
          html += '<br><br><b>Theme image detail:</b>' +
            '<br>Theme ID: ' + tImg.id +
            '<br>Mode: ' + (tImg.mode === 1 ? 'target' : 'passive') +
            '<br>Components (BaseID, EmotionID, ActivityID): ' +
            (tImg.componentIds && tImg.componentIds.length ? tImg.componentIds.join(', ') : 'none') +
            '<br>Averaging count: ' + tImg.count +
            '<br>Ready image: ' + (tImg.ready ? 'yes' : 'no');
        }
      }
      if (typeof global.SituationsTree_getAllThemeImages === 'function') {
        var allT = global.SituationsTree_getAllThemeImages() || [];
        html += '<br><br><b>Total themes:</b> ' + allT.length;
        if (allT.length) {
          html += '<br>Theme IDs (click — detail): ';
          for (var ti = 0; ti < allT.length; ti++) {
            if (ti > 0) html += ', ';
            html += infoAlertIdLink('Info_showThemeImageDetail', allT[ti].id);
          }
        }
      }
    } else if (key === 'situation') {
      var stId = info.situationId || 0;
      html = '<b>Situations</b> (images from situation tree)';
      html += '<br><b>Active now:</b> ';
      if (stId && typeof global.SituationsTree_getSituationImage === 'function' &&
          global.SituationsTree_getSituationImage(stId)) {
        var actSit = global.SituationsTree_getSituationImage(stId);
        html += infoSituationImageLinkFromRecord(actSit);
        html += '<br><i>Detectors:</i> ' + Info_formatSituationDetectorNames(actSit);
      } else {
        html += (stId ? ('ID ' + String(stId) + ' (image not found)') : 'none');
      }
      if (typeof global.SituationsTree_getAllSituationImages !== 'function') {
        html += '<br><br>Situation lists unavailable (SituationsTree).';
      } else {
        var allS = global.SituationsTree_getAllSituationImages() || [];
        var realized = [];
        var unrealized = [];
        for (var sx = 0; sx < allS.length; sx++) {
          var sv = allS[sx];
          if (!sv || typeof sv.id !== 'number') continue;
          if (sv.ready === true) {
            realized.push(sv);
          } else {
            unrealized.push(sv);
          }
        }
        realized.sort(function (a, b) { return (a.id || 0) - (b.id || 0); });
        unrealized.sort(function (a, b) {
          var ca = typeof a.count === 'number' ? a.count : 0;
          var cb = typeof b.count === 'number' ? b.count : 0;
          if (ca !== cb) return ca - cb;
          return (a.id || 0) - (b.id || 0);
        });
        html += '<br><br><b>Realized</b> (ready image): ' + realized.length;
        html += '<br><small>Click ID — full detail</small>';
        if (realized.length) {
          for (var ri = 0; ri < realized.length; ri++) {
            html += '<br>• ' + infoSituationImageLinkFromRecord(realized[ri]) +
              ' — <i>' + Info_formatSituationDetectorNames(realized[ri]) + '</i>';
          }
        } else {
          html += '<br><i>none yet</i>';
        }
        html += '<br><br><b>Unrealized</b> (still averaging, not ready): ' + unrealized.length;
        html += '<br><small>count — averaging count</small>';
        if (unrealized.length) {
          for (var ui = 0; ui < unrealized.length; ui++) {
            var uc = typeof unrealized[ui].count === 'number' ? unrealized[ui].count : 0;
            html += '<br>• ' + infoSituationImageLinkFromRecord(unrealized[ui]) +
              ' <small>(' + String(uc) + ')</small> — <i>' + Info_formatSituationDetectorNames(unrealized[ui]) + '</i>';
          }
        } else {
          html += '<br><i>none yet</i>';
        }
        html += '<br><br><small>Total situation records: ' + String(allS.length) + '</small>';
      }
    } else if (key === 'problem') {
      html = '<b>Open problem:</b> FinalImageId=' + (info.problemFinalImageId || 'none');
    } else if (key === 'step') {
      html = '<b>Comprehension step:</b> ' + (info.step || 0);
    } else if (key === 'stimulus') {
      var fid = info.stimulus.finalImageId || 0;
      var stimDetail = '';
      if (fid && typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function') {
        stimDetail = global.PerceptionTree_getStimulusNamesForFinalImageId(fid) || '';
      }
      html = '<b>Stimulus:</b> ' + (stimDetail || ('FinalImageId=' + (fid || 'none'))) +
        '<br><b>Source:</b> ' + (info.stimulus.source === 'imagination' ? 'imagination' : 'external stimulus');
      // Compare with last console stimulus.
      var cId2 = info.consoleStimulus || 0;
      if (cId2) {
        html += '<br><b>Console stimulus (last):</b> ' +
          infoAlertIdLink('Info_showFinalImageStimulusDetail', cId2) +
          (cId2 === fid ? ' (match)' : ' (no match)');
      } else {
        html += '<br><b>Console stimulus (last):</b> 0';
      }
      // Semantics for this stimulus (if current well/emotion).
      if (fid && typeof global.getSemanticObjectFast === 'function') {
        var well = global.BadNormWell || 0;
        var emotionId = 0;
        if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
          emotionId = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
        }
        var semObj = (well && emotionId) ? global.getSemanticObjectFast(well, emotionId, fid) : null;
        if (semObj) {
          html += '<br><br><b>Semantics (current conditions):</b>' +
            '<br>Mean importance z ≈ ' + (Math.round(semObj.meanImportance * 100) / 100) +
            '<br>Training samples: ' + semObj.samplesCount;
        }
      }
    } else if (key === 'emotion') {
      var eId = info.tree.emotionID || 0;
      html = '<b>EmotionID:</b> ' + String(eId || 0);
      if (eId && Array.isArray(global.Emotions)) {
        var em = null;
        for (var eii = 0; eii < global.Emotions.length; eii++) {
          if (global.Emotions[eii] && global.Emotions[eii].id === eId) { em = global.Emotions[eii]; break; }
        }
        if (em) {
          var emotionContexts = em.contextIds || [];
          if (emotionContexts.length && Array.isArray(global.BasicContexts)) {
            var names = [];
            for (var ci = 0; ci < emotionContexts.length; ci++) {
              var cid = emotionContexts[ci];
              var found = false;
              for (var bj = 0; bj < global.BasicContexts.length; bj++) {
                if (global.BasicContexts[bj] && global.BasicContexts[bj].id === cid) {
                  names.push(global.BasicContexts[bj].name || ('Context ' + cid));
                  found = true;
                  break;
                }
              }
              if (!found) names.push('id ' + cid);
            }
            html += '<br><b>Basic contexts:</b> ' + names.join(', ');
          } else {
            html += '<br><b>Basic contexts:</b> —';
          }
        }
      }
      html += '<br><br><b>Full branch:</b><br>' +
        'BaseID=' + (info.tree.baseID || 0) +
        ' → EmotionID=' + (info.tree.emotionID || 0) +
        ' → ActivityID=' + (info.tree.activityID || 0);
    } else if (key === 'activity') {
      var actId2 = info.tree.activityID || 0;
      var actNames = '';
      if (actId2 && typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function') {
        actNames = global.PerceptionTree_getStimulusNamesForFinalImageId(actId2) || '';
      }
      html = '<b>ActivityID:</b> ' + (actId2 ? infoAlertIdLink('Info_showFinalImageStimulusDetail', actId2) : '0');
      html += '<br><b>Current stimulus image:</b> ' + (actNames && actNames !== '—' ? actNames : '—');
      if (actId2 && typeof global.getSemanticObjectFast === 'function') {
        var wellA = global.BadNormWell || 0;
        var emoA = info.tree.emotionID || 0;
        var semA = (wellA && emoA) ? global.getSemanticObjectFast(wellA, emoA, actId2) : null;
        if (semA) {
          html += '<br><br><b>Semantics (well=' + String(wellA) + ', emotionId=' + String(emoA) + '):</b>' +
            '<br>z ≈ ' + (Math.round(semA.meanImportance * 100) / 100) +
            '<br>trainings: ' + semA.samplesCount;
        }
      }
      html += '<br><br><b>Full branch:</b><br>' +
        'BaseID=' + (info.tree.baseID || 0) +
        ' → EmotionID=' + (info.tree.emotionID || 0) +
        ' → ActivityID=' + (info.tree.activityID || 0);
    } else if (key === 'tree') {
      // Base: Bad / Norm / Good
      var baseName = 'undefined';
      if (info.tree.baseID === 1) baseName = 'Bad';
      else if (info.tree.baseID === 2) baseName = 'Norm';
      else if (info.tree.baseID === 3) baseName = 'Good';

      // Emotion: basic context mix
      var emotionName = 'none';
      var emotionContexts = [];
      if (info.tree.emotionID && Array.isArray(global.Emotions)) {
        for (var ei = 0; ei < global.Emotions.length; ei++) {
          if (global.Emotions[ei] && global.Emotions[ei].id === info.tree.emotionID) {
            emotionContexts = global.Emotions[ei].contextIds || [];
            break;
          }
        }
      }
      if (emotionContexts.length && Array.isArray(global.BasicContexts)) {
        var parts = [];
        for (var ci = 0; ci < emotionContexts.length; ci++) {
          var cid = emotionContexts[ci];
          for (var bj = 0; bj < global.BasicContexts.length; bj++) {
            if (global.BasicContexts[bj] && global.BasicContexts[bj].id === cid) {
              parts.push(global.BasicContexts[bj].name || ('Context ' + cid));
              break;
            }
          }
        }
        if (parts.length) {
          emotionName = parts.join(', ');
        }
      }

      // Activity: current stimulus image + semantics
      var actId = info.tree.activityID || 0;
      var actDetail = '';
      if (actId && typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function') {
        actDetail = global.PerceptionTree_getStimulusNamesForFinalImageId(actId) || '';
      }
      var actSem = '';
      if (actId && typeof global.getSemanticObjectFast === 'function') {
        var wellT = global.BadNormWell || 0;
        var emotionIdT = info.tree.emotionID || 0;
        var semObjT = (wellT && emotionIdT) ? global.getSemanticObjectFast(wellT, emotionIdT, actId) : null;
        if (semObjT) {
          actSem = 'Mean importance z ≈ ' + (Math.round(semObjT.meanImportance * 100) / 100) +
            ', training samples: ' + semObjT.samplesCount;
        }
      }

      html = '<b>Base:</b> ' + baseName +
        '<br><b>EmotionID:</b> ' + (info.tree.emotionID || 0) +
        '<br><b>Emotion (basic context mix):</b> ' + emotionName +
        '<br><br><b>ActivityID:</b> ' + (actId || 0) +
        '<br><b>Current stimulus image:</b> ' + (actDetail || 'none') +
        (actSem ? ('<br>' + actSem) : '') +
        '<br><br><b>Full tree branch:</b><br>' +
        'BaseID=' + (info.tree.baseID || 0) +
        ' → EmotionID=' + (info.tree.emotionID || 0) +
        ' → ActivityID=' + (info.tree.activityID || 0) +
        ' → ToneMoodID=' + (info.tree.toneMoodID || 0) +
        ' → SimbolID=' + (info.tree.simbolID || 0) +
        ' → PhraseID=' + (info.tree.phraseID || 0);
    } else if (key === 'criticalVital') {
      html = '<b>Critical vital:</b> ' + (info.criticalVital ? 'active' : 'no');
    } else if (key === 'ImportantProblem') {
      html = '<b>Important problem:</b> ' + (info.ImportantProblem ? 'yes (attention hysteresis to stimuli)' : 'no (lighter OR/consciousness)');
    } else if (key === 'usedRule') {
      var ur = typeof info.usedRule === 'number' ? info.usedRule : 0;
      var stk = Array.isArray(global.Target_rule_stack) ? global.Target_rule_stack.slice() : [];
      html = '<b>Reacting by rule</b> (usedRule): ' + (ur ? ('yes, value ' + ur) : 'no (0)') +
        '<br><br><b>Goal stack Target_rule_stack</b> (LIFO, max 3 FinalImageId): ';
      if (!stk.length) {
        html += 'empty.';
      } else {
        html += 'bottom → top (last pushed on the right):<br>';
        for (var si = 0; si < stk.length; si++) {
          if (si > 0) html += ' → ';
          html += infoAlertIdLink('Info_showFinalImageStimulusDetail', stk[si]);
        }
      }
    } else if (key === 'shockState') {
      html = '<b>Shock state:</b> ' + (info.shockState ? 'active' : 'no');
    } else if (key === 'suddenChange') {
      html = '<b>Sharp worsening (transition to Bad):</b> ' + (info.suddenChange ? 'yes' : 'no');
    } else if (key === 'playMode') {
      html = '<b>Play mode:</b> ' + (info.playMode ? 'active' : 'no');
    } else if (key === 'learningMode') {
      html = '<b>Learning mode:</b> ' + (info.learningMode ? 'active' : 'no');
    } else if (key === 'negativeMotorEffect') {
      html = '<b>Negative motor automatism effect:</b> ' + (info.negativeMotorEffect ? 'yes' : 'no');
    } else if (key === 'negativeMentalEffect') {
      html = '<b>Negative mental automatism effect:</b> ' + (info.negativeMentalEffect ? 'yes' : 'no');
    } else if (key === 'badState') {
      html = '<b>Bad state:</b> ' + (info.badState ? 'yes' : 'no');
    } else if (key === 'consoleStimulus') {
      var cId = info.consoleStimulus || 0;
      var curId = info.stimulus && typeof info.stimulus.finalImageId === 'number' ? info.stimulus.finalImageId : 0;
      var cNames = '';
      if (cId && typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function') {
        cNames = global.PerceptionTree_getStimulusNamesForFinalImageId(cId) || '';
      }
      html = '<b>Console stimulus</b> (consoleStimulus): ' + (cId ? infoAlertIdLink('Info_showFinalImageStimulusDetail', cId) : '0') +
        '<br><i>Meaning:</i> FinalImageId of the last stimulus from the operator (console).' +
        '<br>It may <b>not match</b> the current comprehension stimulus.' +
        (cId ? ('<br><b>Stimulus names:</b> ' + (cNames && cNames !== '—' ? cNames : '—')) : '') +
        '<br><br><b>Current comprehension stimulus:</b> ' +
        (curId ? infoAlertIdLink('Info_showFinalImageStimulusDetail', curId) : '0') +
        (curId && info.stimulus && info.stimulus.source ? (' (' + (info.stimulus.source === 'imagination' ? 'imagination' : 'external') + ')') : '') +
        '<br><b>Match?</b> ' + ((cId && curId && cId === curId) ? 'yes' : 'no');
    } else if (key === 'searchInterest') {
      html = '<b>Search interest:</b> ' + (info.searchInterest ? 'active' : 'no');
    } else if (key === 'teacherLearning') {
      html = '<b>Learning with teacher:</b> ' + (info.teacherLearning ? 'in progress' : 'no');
    } else if (key === 'operatorIgnoring') {
      html = '<b>Operator ignoring:</b> ' + (info.operatorIgnoring ? 'detected' : 'no');
    } else if (key === 'dissatisfaction') {
      html = '<b>Dissatisfaction with existing:</b> ' + (info.dissatisfaction ? 'yes' : 'no');
    } else if (key === 'misunderstanding') {
      html = '<b>Misunderstanding:</b> ' + (info.misunderstanding ? 'yes' : 'no');
    } else if (key === 'doubtInDefaultAutomatism') {
      html = '<b>Doubt in default automatism:</b> ' + (info.doubtInDefaultAutomatism ? 'yes' : 'no');
    } else if (key === 'defense') {
      html = '<b>Defense:</b> ' + (info.defense ? 'active' : 'no');
    } else if (key === 'fear') {
      html = '<b>Fear:</b> ' + (info.fear ? 'active' : 'no');
    } else if (key === 'aggression') {
      html = '<b>Aggression:</b> ' + (info.aggression ? 'active' : 'no');
    } else if (key === 'highImportanceObject') {
      var ho = typeof info.highImportanceObject === 'number' ? info.highImportanceObject : 0;
      var curStim = info.stimulus && typeof info.stimulus.finalImageId === 'number' ? info.stimulus.finalImageId : 0;
      html = '<b>Important object</b> (highImportanceObject): ' + String(ho || 0) +
        '<br><i>Meaning:</i> <b>ID of a specific object</b> (or level) that external code marked as especially significant' +
        ' in the current situation and passed here.' +
        '<br>Not “semantic level in general”, but <b>a pointer to a found object</b>.' +
        (ho ? '<br><br><b>Hint:</b> if this is a FinalImageId, open: ' + infoAlertIdLink('Info_showFinalImageStimulusDetail', ho) : '') +
        '<br><br><b>Current comprehension stimulus:</b> ' + (curStim ? infoAlertIdLink('Info_showFinalImageStimulusDetail', curStim) : '0') +
        '<br><b>Matches current stimulus?</b> ' + ((ho && curStim && ho === curStim) ? 'yes' : 'no');
    } else if (key === 'moodImproving') {
      html = '<b>Mood improving:</b> ' + (info.moodImproving ? 'recorded' : 'no');
    } else if (key === 'imageNovelty') {
      html = '<b>Image novelty:</b> ' + (info.imageNovelty ? 'high' : 'no');
    } else if (key === 'highSemanticImportance') {
      var hs = typeof info.highSemanticImportance === 'number' ? info.highSemanticImportance : 0;
      var fidHs = info.stimulus && typeof info.stimulus.finalImageId === 'number' ? info.stimulus.finalImageId : 0;
      html = '<b>High semantics</b> (highSemanticImportance): ' + String(hs || 0) +
        '<br><i>Meaning:</i> <b>numeric semantic importance</b> of the current image in these conditions (usually meanImportance).' +
        '<br>How significant the stimulus is semantically, not which object matters.' +
        '<br><br><b>For current stimulus:</b> ' + (fidHs ? infoAlertIdLink('Info_showFinalImageStimulusDetail', fidHs) : '0');
    } else if (key === 'conflictingSemantics') {
      html = '<b>Conflicting semantics:</b> ' + (info.conflictingSemantics ? 'yes' : 'no');
    } else if (key === 'hardProblem') {
      html = '<b>Hard problem:</b> ' + (info.hardProblem ? 'active' : 'no');
    } else if (key === 'positiveActionEffect') {
      html = '<b>Positive action effect:</b> ' + (info.positiveActionEffect ? 'yes' : 'no');
    } else if (key === 'negativeActionEffect') {
      html = '<b>Negative action effect:</b> ' + (info.negativeActionEffect ? 'yes' : 'no');
    } else if (key === 'noReactionToStimulus') {
      html = '<b>No reaction to stimulus:</b> ' + (info.noReactionToStimulus ? 'recorded' : 'no');
    } else if (key === 'operatorAnswerReceived') {
      html = '<b>Operator answer received</b> (operatorAnswerReceived): ' +
        (info.operatorAnswerReceived ? 'yes' : 'no') +
        '<br><b>Answer to consciousness automatism</b> (isOperatorAnswerReceived): ' +
        (info.isOperatorAnswerReceived ? 'yes (handled on L2 if needed)' : 'no');
    } else if (key === 'activeWaitingAnswer') {
      html = '<b>Active answer wait:</b> ' + (info.activeWaitingAnswer ? 'in progress' : 'no');
    } else if (key === 'seriesWithoutEffect') {
      html = '<b>Episode series without effect:</b> ' + (info.seriesWithoutEffect ? 'yes' : 'no');
    } else if (key === 'lowAutomatismUsefulness') {
      html = '<b>Low automatism usefulness:</b> ' + (info.lowAutomatismUsefulness ? 'detected' : 'no');
    } else if (key === 'foundSuitableAutomatism') {
      html = '<b>Suitable automatism found (for now):</b> ' + (info.foundSuitableAutomatism ? 'yes' : 'no');
    }
    if (html) {
      global.show_alert(html, 0);
    }
  }

  global.Info_initIfNeeded = ensureInfoPicture;

  /** Cycle birth pulse: explicit field or first log entry (for old cycles without birthPuls). */
  function resolveCycleBirthPuls(cycleOrItem, pulsNow) {
    if (cycleOrItem && typeof cycleOrItem.birthPuls === 'number') return cycleOrItem.birthPuls;
    var dl = cycleOrItem && cycleOrItem.debugLog;
    if (Array.isArray(dl) && dl.length && typeof dl[0].atPuls === 'number') return dl[0].atPuls;
    return pulsNow;
  }

  /**
   * Formats cycle or background-stack item info as HTML for show_alert.
   * @param {Object} cycleOrItem - cycle object (from registry) or stack item { id, context, importance }
   * @param {string} prefix - block label (e.g. "Cycle" or "Background #N")
   * @returns {string}
   */
  function formatCycleOrStackInfo(cycleOrItem, prefix) {
    if (!cycleOrItem) return '';
    var ctx = cycleOrItem.context || {};
    var actualId = ctx.actual_stimul_ID != null ? ctx.actual_stimul_ID : 0;
    var branchId = ctx.branchId != null ? ctx.branchId : 0;
    var well = ctx.well != null ? ctx.well : 0;
    var emotionId = ctx.emotionId != null ? ctx.emotionId : 0;
    var activityID = ctx.activityID != null ? ctx.activityID : actualId;
    var weight = cycleOrItem.weight != null ? cycleOrItem.weight : (cycleOrItem.importance != null ? cycleOrItem.importance : 0);
    var stimNames = '';
    if (typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function' && actualId) {
      var names = global.PerceptionTree_getStimulusNamesForFinalImageId(actualId);
      if (names && names.length) stimNames = ' — ' + names;
    }
    var cycId = cycleOrItem.id != null ? cycleOrItem.id : 0;
    var idLine = 'ID: ' + (cycId ? infoAlertIdLink('Info_showCycleDetailById', cycId) : '—');
    var themeId = typeof cycleOrItem.createdThemeId === 'number' ? cycleOrItem.createdThemeId : 0;
    var themeLine = 'Theme at creation (createdThemeId): ' +
      (themeId ? infoAlertIdLink('Info_showThemeImageDetail', themeId) : '0');
    var sitId = typeof cycleOrItem.createdSituationId === 'number' ? cycleOrItem.createdSituationId : 0;
    var sitLine = 'Situation at creation (createdSituationId): ' +
      (sitId ? infoSituationImageLinkById(sitId) : '0');
    var goalImgId = typeof cycleOrItem.goalImageId === 'number' ? cycleOrItem.goalImageId : 0;
    var goalLine = 'Goal image (goalImageId): ' + String(goalImgId || 0) +
      (goalImgId ? ' <small>(life experience, record id)</small>' : ' <small>(passive mode or base goal without image)</small>');
    var waitAutoId = typeof cycleOrItem.waitingFeedbackAutomatizmId === 'number' ? cycleOrItem.waitingFeedbackAutomatizmId : 0;
    var waitAutoLine = 'Awaiting automatism feedback (waitingFeedbackAutomatizmId): ' + String(waitAutoId || 0);
    var waitCycLine = 'Post-automatism wait: awaiting=' +
      (cycleOrItem.awaitingAutomatismEpisodeFeedback ? 'yes' : 'no') +
      ', answer by stimulus=' + (cycleOrItem.automatismOperatorAnswerReceived ? 'yes' : 'no') +
      ', frame effect=' + (typeof cycleOrItem.lastAutomatismEpisodeEffect === 'number'
        ? String(cycleOrItem.lastAutomatismEpisodeEffect) : '—');
    var stimLine = 'Stimulus FinalImageId: ' +
      (actualId ? infoAlertIdLink('Info_showFinalImageStimulusDetail', actualId) : '0') + stimNames;
    var branchLine = 'Branch (branchId): ' +
      (branchId ? infoAlertIdLink('Info_showPerceptionNodeDetail', branchId) : '0');
    var emoLine = 'Emotion (emotionId): ' +
      (emotionId ? infoAlertIdLink('Info_showEmotionRecordDetail', emotionId) : '0');
    var actLine = 'ActivityID: ' +
      (activityID ? infoAlertIdLink('Info_showFinalImageStimulusDetail', activityID) : '0');
    if (activityID && activityID === actualId) {
      actLine += ' (same as stimulus)';
    }
    var effectiveState = (cycleOrItem && cycleOrItem.expired === true) ? 'expired' : 'running';
    var parts = [
      '<b>' + (prefix || 'Cycle') + '</b>',
      idLine,
      themeLine,
      sitLine,
      goalLine,
      waitAutoLine,
      waitCycLine,
      stimLine,
      branchLine,
      'Base state (well): ' + String(well) + (well === 1 ? ' (Bad)' : well === 2 ? ' (Norm)' : well === 3 ? ' (Good)' : ''),
      emoLine,
      actLine,
      'Weight: ' + String(weight),
      'Cycle state: ' + effectiveState,
      'expired: ' + (cycleOrItem.expired === true
        ? 'yes (finished, kept in registry)'
        : 'no')
    ];
    if (cycleOrItem.passiveWorkAfterGestaltExpire === true) {
      parts.push('After expired (stagnation right after gestalt tick): info picture switched to <b>passive work mode</b>.');
    }
    if (typeof cycleOrItem.lastGestaltConsciencePuls === 'number' && cycleOrItem.lastGestaltConsciencePuls > 0) {
      parts.push('Last L4/gestalt tick (pulse): ' + String(cycleOrItem.lastGestaltConsciencePuls));
    }
    if (cycleOrItem.status != null) {
      parts.push('Status: ' + String(cycleOrItem.status));
    }
    if (typeof cycleOrItem.step === 'number') {
      parts.push('Step (consciousness level): ' + String(cycleOrItem.step));
    }
    var pulsNow = typeof global.cpuls === 'number' ? global.cpuls : 0;
    var birthPuls = resolveCycleBirthPuls(cycleOrItem, pulsNow);
    parts.push('Birth pulse: ' + String(birthPuls));
    parts.push('Cycle age (pulses since creation): ' + String(Math.max(0, pulsNow - birthPuls)));
    if (typeof cycleOrItem.count === 'number') {
      parts.push(
        'Dispatcher steps (runOneStep): ' + String(cycleOrItem.count) +
          ' — dispetchConsciousnessThinking ticks, not stop limit; background cycle steps less often (~ every 5 pulses).'
      );
    }
    if (typeof cycleOrItem.order === 'number') {
      parts.push('Creation order: ' + String(cycleOrItem.order));
    }
    if (Array.isArray(cycleOrItem.fantasizmArr)) {
      parts.push('fantasizmArr (EP rules, background cycle plot): ' + String(cycleOrItem.fantasizmArr.length) + ' item(s).');
    }
    if (cycleOrItem.fantasizmPassiveFillStarted === true) {
      parts.push('fantasizmArr passive-mode fill: started.');
    }
    // Cycle log (if any)
    if (Array.isArray(cycleOrItem.debugLog) && cycleOrItem.debugLog.length) {
      var from = Math.max(0, cycleOrItem.debugLog.length - 30);
      var lines = [];
      for (var i = from; i < cycleOrItem.debugLog.length; i++) {
        var e = cycleOrItem.debugLog[i];
        var p = (e && typeof e.atPuls === 'number') ? e.atPuls : 0;
        var t = e && e.text != null ? String(e.text) : '';
        lines.push('[' + String(p) + '] ' + t);
      }
      parts.push('<details style="margin-top:6px"><summary><b>Cycle log</b> (last ' + String(lines.length) + ')</summary>' +
        '<pre style="white-space:pre-wrap;margin:6px 0 0 0;font-size:10pt">' +
        lines.join('\n').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') +
        '</pre></details>');
    }
    return parts.join('<br>');
  }

  /**
   * Show details for the current main comprehension cycle.
   * Invoked by click on “Main cycle ID: N”.
   */
  function Info_showMainCycleDetail() {
    if (typeof global.show_alert !== 'function') return;
    var mainId = typeof global.ConsciousnessCurrentProcessId === 'number' ? global.ConsciousnessCurrentProcessId : 0;
    if (!mainId) {
      global.show_alert('No active main cycle (ID = 0).', 0);
      return;
    }
    var getCycle = global.Consciousness_getCycle;
    var cycle = typeof getCycle === 'function' ? getCycle(mainId) : null;
    if (!cycle) {
      global.show_alert('Cycle with ID ' + String(mainId) + ' not in registry (finished or removed).', 0);
      return;
    }
    var html = formatCycleOrStackInfo(cycle, 'Main cycle');
    global.show_alert(html, 0);
  }

  /**
   * Show background comprehension cycles (from registry, isMainCycle=false, status=running).
   * Invoked by click on the “bg: N” indicator. Each cycle uses the same detail layout as the main cycle.
   */
  function Info_showBackgroundStack() {
    if (typeof global.show_alert !== 'function') return;
    var list = typeof global.Consciousness_getBackgroundCyclesList === 'function'
      ? global.Consciousness_getBackgroundCyclesList() : [];
    if (!list.length) {
      global.show_alert('No background comprehension cycles.', 0);
      return;
    }
    var blocks = ['<b>Background comprehension cycles</b> (by decreasing weight). Click ID — full detail:'];
    for (var i = 0; i < list.length; i++) {
      var item = list[i];
      var cid = item && item.id != null ? item.id : 0;
      var w = item && typeof item.weight === 'number' ? item.weight : 0;
      var ctx = item && item.context ? item.context : {};
      var stim = ctx && typeof ctx.actual_stimul_ID === 'number' ? ctx.actual_stimul_ID : 0;
      blocks.push('<br>');
      blocks.push(cid ? infoAlertIdLink('Info_showBackgroundCycleDetail', cid) : '—');
      blocks.push(' — weight ' + String(w) + ', stimulus FinalImageId=');
      blocks.push(stim ? infoAlertIdLink('Info_showFinalImageStimulusDetail', stim) : '0');
      if (item && item.expired === true) {
        blocks.push(', <b>expired</b>');
      }
    }
    global.show_alert(blocks.join(''), 0);
  }

  function Info_showBackgroundCycleDetail(cycleId) {
    if (typeof global.show_alert !== 'function') return;
    cycleId = parseInt(cycleId, 10);
    if (isNaN(cycleId) || cycleId <= 0) return;
    var getCycle = global.Consciousness_getCycle;
    var cycle = typeof getCycle === 'function' ? getCycle(cycleId) : null;
    if (!cycle) {
      global.show_alert('Cycle with ID ' + String(cycleId) + ' not found in registry.', 0);
      return;
    }
    global.show_alert(formatCycleOrStackInfo(cycle, 'Background cycle'), 0);
  }

  function Info_showThemeImageDetail(themeId) {
    if (typeof global.show_alert !== 'function') return;
    themeId = parseInt(themeId, 10) || 0;
    if (!themeId || typeof global.SituationsTree_getThemeImage !== 'function') {
      global.show_alert('Theme #' + themeId + ' not found.', 0);
      return;
    }
    var tImg = global.SituationsTree_getThemeImage(themeId);
    if (!tImg) {
      global.show_alert('Theme #' + themeId + ' not found.', 0);
      return;
    }
    var html = '<b>Theme image #' + tImg.id + '</b>' +
      '<br>Mode: ' + (tImg.mode === 1 ? 'target' : 'passive') +
      '<br>Components (BaseID, EmotionID, ActivityID): ' +
      (tImg.componentIds && tImg.componentIds.length ? tImg.componentIds.join(', ') : 'none') +
      '<br>Averaging count: ' + tImg.count +
      '<br>Ready image: ' + (tImg.ready ? 'yes' : 'no');
    global.show_alert(html, 0);
  }

  function Info_showSituationImageDetail(situationId) {
    if (typeof global.show_alert !== 'function') return;
    situationId = parseInt(situationId, 10) || 0;
    if (!situationId || typeof global.SituationsTree_getSituationImage !== 'function') {
      global.show_alert('Situation #' + situationId + ' not found.', 0);
      return;
    }
    var sImg = global.SituationsTree_getSituationImage(situationId);
    if (!sImg) {
      global.show_alert('Situation #' + situationId + ' not found.', 0);
      return;
    }
    var comp = '';
    if (sImg.componentIds && sImg.componentIds.length) {
      var partsS = [];
      for (var si = 0; si < sImg.componentIds.length; si++) {
        var cid = sImg.componentIds[si];
        var name = (typeof global.SituationsTree_getSituationComponentName === 'function')
          ? global.SituationsTree_getSituationComponentName(cid) : '';
        partsS.push(cid + (name ? ' (' + name + ')' : ''));
      }
      comp = partsS.join(', ');
    } else {
      comp = 'none';
    }
    var inner = '<b>Situation image #' + sImg.id + '</b>' +
      '<br><b>Detectors (composition):</b> ' + Info_formatSituationDetectorNames(sImg) +
      '<br>Mode: ' + (sImg.mode === 1 ? 'target' : 'passive') +
      '<br>Components (id, key): ' + comp +
      '<br>Averaging count: ' + sImg.count +
      '<br>Ready image: ' + (sImg.ready ? 'yes' : 'no');
    var html = sImg.ready === true
      ? ('<div style="border:2px solid #1976d2;padding:10px 12px;border-radius:8px;box-sizing:border-box">' + inner + '</div>')
      : inner;
    global.show_alert(html, 0);
  }

  /**
   * Human-readable action image: stimulus chain of final image (as in perception branch),
   * or action names if absent.
   */
  function Info_formatActionImageReadableBlock(od) {
    if (!od) return '<b>Action image:</b><br>—';
    var stim = '';
    if (od.finalImageId && typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function') {
      stim = global.PerceptionTree_getStimulusNamesForFinalImageId(od.finalImageId) || '';
    }
    if (stim === '—') stim = '';
    var actions = '';
    if (typeof global.PerceptionTree_getActionNamesForActionImage === 'function') {
      actions = global.PerceptionTree_getActionNamesForActionImage(od.id) || '';
    }
    if (actions === '—') actions = '';
    var body = stim || actions || '—';
    var extra = '';
    if (stim && actions) {
      extra = '<br><i>Actions:</i> ' + actions;
    }
    return '<b>Action image:</b><br>' + body + extra;
  }

  function Info_showActionImageDetail(odId) {
    if (typeof global.show_alert !== 'function') return;
    odId = parseInt(odId, 10) || 0;
    if (!odId || typeof global.ActionImages_getActionImage !== 'function') {
      global.show_alert('Action image #' + odId + ' not found.', 0);
      return;
    }
    var od = global.ActionImages_getActionImage(odId);
    if (!od) {
      global.show_alert('Action image #' + odId + ' not found.', 0);
      return;
    }
    var html = '<b>Action image #' + od.id + '</b><br>' +
      Info_formatActionImageReadableBlock(od) +
      '<br><br><b>Action image fields:</b>' +
      '<br>finalImageId: ' + (od.finalImageId || 0) +
      '<br>actionIds: ' + (Array.isArray(od.actionIds) && od.actionIds.length ? od.actionIds.join(', ') : '—') +
      '<br>odSequence: ' + (od.odSequence || '—');
    global.show_alert(html, 0);
  }

  function Info_showMentalActionImageDetail(maiId) {
    if (typeof global.show_alert !== 'function') return;
    maiId = parseInt(maiId, 10) || 0;
    if (!maiId || typeof global.MentalActionImages_get !== 'function') {
      global.show_alert('Mental action image #' + maiId + ' not found.', 0);
      return;
    }
    var m = global.MentalActionImages_get(maiId);
    if (!m) {
      global.show_alert('Mental action image #' + maiId + ' not found.', 0);
      return;
    }
    var ids = Array.isArray(m.abstractActionIds) ? m.abstractActionIds : [];
    var absParts = [];
    for (var i = 0; i < ids.length; i++) {
      if (i > 0) absParts.push(', ');
      absParts.push(infoAlertIdLink('Info_showAbstractionDetail', ids[i]));
    }
    var srcLink = (m.sourceActionImageId || 0)
      ? infoAlertIdLink('Info_showActionImageDetail', m.sourceActionImageId)
      : '0';
    var html = '<b>Mental action image #' + m.id + '</b>' +
      '<br>Source action image (motor): ' + srcLink +
      '<br>Abstract actions (Abstractions symbols, click — detail): ' +
      (absParts.length ? absParts.join('') : '—') +
      '<br>maSequence: ' + (m.maSequence || '—');
    global.show_alert(html, 0);
  }

  function Info_findAbstractPerceptionImage(id) {
    id = parseInt(id, 10) || 0;
    if (!id) return null;
    var ap = Array.isArray(global.AbstractPerceptionImages) ? global.AbstractPerceptionImages : [];
    for (var i = 0; i < ap.length; i++) {
      if (ap[i] && ap[i].id === id) return ap[i];
    }
    return null;
  }

  function Info_findAbstractActionImage(id) {
    id = parseInt(id, 10) || 0;
    if (!id) return null;
    var aa = Array.isArray(global.AbstractActionImages) ? global.AbstractActionImages : [];
    for (var j = 0; j < aa.length; j++) {
      if (aa[j] && aa[j].id === id) return aa[j];
    }
    return null;
  }

  function Info_showAbstractPerceptionImageDetail(recId) {
    if (typeof global.show_alert !== 'function') return;
    var o = Info_findAbstractPerceptionImage(recId);
    if (!o) {
      global.show_alert('Abstract perception clone #' + (parseInt(recId, 10) || 0) + ' not found (AbstractPerceptionImages).', 0);
      return;
    }
    var stimNames = '';
    if (o.stimulusImageId && typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function') {
      stimNames = global.PerceptionTree_getStimulusNamesForFinalImageId(o.stimulusImageId) || '';
    }
    var html = '<b>Perception clone #' + o.id + '</b> <small>(episode → abstract_images.js)</small>' +
      '<br>Branch node: ' + (o.perceptionNodeId ? infoAlertIdLink('Info_showPerceptionNodeDetail', o.perceptionNodeId) : '0') +
      '<br>Pinned stimulus (FinalImageId): ' + (o.stimulusImageId ? infoAlertIdLink('Info_showFinalImageStimulusDetail', o.stimulusImageId) : '0') +
      (stimNames && stimNames !== '—' ? '<br><i>Stimulus:</i> ' + stimNames : '') +
      '<br>Mean importance: ' + (typeof o.meanImportance === 'number' ? o.meanImportance : 0) +
      '<br>Averaging count: ' + (typeof o.count === 'number' ? o.count : 0) +
      '<br>Created: ' + infoFormatAbstractionFieldValue('createdAt', o.createdAt) +
      '<br>Last used: ' + infoFormatAbstractionFieldValue('lastUsedAt', o.lastUsedAt) +
      infoFormatAbstractSemanticStructureHtml(o.semanticStructure);
    global.show_alert(html, 0);
  }

  function Info_showAbstractActionImageDetail(recId) {
    if (typeof global.show_alert !== 'function') return;
    var o = Info_findAbstractActionImage(recId);
    if (!o) {
      global.show_alert('Abstract action clone #' + (parseInt(recId, 10) || 0) + ' not found (AbstractActionImages).', 0);
      return;
    }
    var odBlock = '';
    if (o.actionImageId && typeof global.ActionImages_getActionImage === 'function') {
      var od = global.ActionImages_getActionImage(o.actionImageId);
      if (od) odBlock = '<br>' + Info_formatActionImageReadableBlock(od);
    }
    var html = '<b>Action clone #' + o.id + '</b> <small>(episode → abstract_images.js)</small>' +
      '<br>Branch node: ' + (o.perceptionNodeId ? infoAlertIdLink('Info_showPerceptionNodeDetail', o.perceptionNodeId) : '0') +
      '<br>Pinned action image: ' + (o.actionImageId ? infoAlertIdLink('Info_showActionImageDetail', o.actionImageId) : '0') +
      (odBlock || '') +
      '<br>Mean importance: ' + (typeof o.meanImportance === 'number' ? o.meanImportance : 0) +
      '<br>Averaging count: ' + (typeof o.count === 'number' ? o.count : 0) +
      '<br>Created: ' + infoFormatAbstractionFieldValue('createdAt', o.createdAt) +
      '<br>Last used: ' + infoFormatAbstractionFieldValue('lastUsedAt', o.lastUsedAt) +
      infoFormatAbstractSemanticStructureHtml(o.semanticStructure);
    global.show_alert(html, 0);
  }

  function Info_showMotorAutomatizmsList() {
    if (typeof global.show_alert !== 'function') return;
    var arr = Array.isArray(global.Automatizms) ? global.Automatizms : [];
    if (!arr.length) {
      global.show_alert('No motor automatisms.', 0);
      return;
    }
    var ids = [];
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && typeof arr[i].id === 'number') ids.push(arr[i].id);
    }
    ids.sort(function (a, b) { return a - b; });
    var parts = ['<b>Motor automatisms</b> (' + ids.length + '). Click ID — detail:<br><br>'];
    for (var j = 0; j < ids.length; j++) {
      if (j > 0) parts.push(' &nbsp; ');
      parts.push(infoAlertIdLink('Info_showMotorAutomatizmDetail', ids[j]));
    }
    global.show_alert(parts.join(''), 0);
  }

  function Info_showMotorAutomatizmDetail(id) {
    if (typeof global.show_alert !== 'function') return;
    id = parseInt(id, 10) || 0;
    var arr = Array.isArray(global.Automatizms) ? global.Automatizms : [];
    var a = null;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && arr[i].id === id) { a = arr[i]; break; }
    }
    if (!a) {
      global.show_alert('Motor automatism #' + id + ' not found.', 0);
      return;
    }
    var odBlock = '';
    if (a.actionsImageId && typeof global.ActionImages_getActionImage === 'function') {
      var od = global.ActionImages_getActionImage(a.actionsImageId);
      if (od) {
        odBlock = '<br>' + Info_formatActionImageReadableBlock(od) +
          '<br><small>AI ' + infoAlertIdLink('Info_showActionImageDetail', a.actionsImageId) +
          ' — all action image fields</small>';
      }
    }
    if (!odBlock) {
      odBlock = '<br><b>Action image:</b><br>—<br><small>No action image</small>';
    }
    var html = '<b>Motor automatism #' + a.id + '</b>' +
      '<br>branchId: ' + (a.branchId || 0) +
      odBlock +
      '<br>usefulness: ' + (typeof a.usefulness === 'number' ? a.usefulness : 0) +
      '<br>count: ' + (typeof a.count === 'number' ? a.count : 0) +
      '<br>default (isDefault): ' + (a.isDefault ? 'yes' : 'no');
    global.show_alert(html, 0);
  }

  function Info_showMentalAutomatizmsList() {
    if (typeof global.show_alert !== 'function') return;
    var arr = Array.isArray(global.MentalAutomatizms) ? global.MentalAutomatizms : [];
    if (!arr.length) {
      global.show_alert('No mental automatisms.', 0);
      return;
    }
    var ids = [];
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && typeof arr[i].id === 'number') ids.push(arr[i].id);
    }
    ids.sort(function (a, b) { return a - b; });
    var parts = ['<b>Mental automatisms</b> (' + ids.length + '). Click ID — detail:<br><br>'];
    for (var j = 0; j < ids.length; j++) {
      if (j > 0) parts.push(' &nbsp; ');
      parts.push(infoAlertIdLink('Info_showMentalAutomatizmDetail', ids[j]));
    }
    global.show_alert(parts.join(''), 0);
  }

  function Info_showMentalAutomatizmDetail(id) {
    if (typeof global.show_alert !== 'function') return;
    id = parseInt(id, 10) || 0;
    var arr = Array.isArray(global.MentalAutomatizms) ? global.MentalAutomatizms : [];
    var a = null;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && arr[i].id === id) { a = arr[i]; break; }
    }
    if (!a) {
      global.show_alert('Mental automatism #' + id + ' not found.', 0);
      return;
    }
    var maiLink = (a.mentalActionImageId || 0)
      ? infoAlertIdLink('Info_showMentalActionImageDetail', a.mentalActionImageId)
      : '0';
    var html = '<b>Mental automatism #' + a.id + '</b>' +
      '<br>themeId: ' + (a.themeId || 0) +
      '<br>situationId: ' + (a.situationId || 0) +
      '<br>branchId: ' + (a.branchId || 0) +
      '<br>Mental action image: ' + maiLink +
      '<br>usefulness: ' + (typeof a.usefulness === 'number' ? a.usefulness : 0) +
      '<br>count: ' + (typeof a.count === 'number' ? a.count : 0) +
      '<br>default (isDefault): ' + (a.isDefault ? 'yes' : 'no');
    global.show_alert(html, 0);
  }

  function Info_showAbstractionsList() {
    if (typeof global.show_alert !== 'function') return;
    var ap = Array.isArray(global.AbstractPerceptionImages) ? global.AbstractPerceptionImages : [];
    var aa = Array.isArray(global.AbstractActionImages) ? global.AbstractActionImages : [];
    var arr = Array.isArray(global.Abstractions) ? global.Abstractions : [];
    var blocks = [];
    blocks.push('<b>Abstractions: three separate stores</b> — each has its own ID type; click opens <i>its</i> detail.');
    blocks.push('<br><br><b>1. Perception clones</b> (AbstractPerceptionImages, abstract_images.js), total ' + ap.length + ':');
    if (ap.length) {
      var apIds = [];
      for (var pi = 0; pi < ap.length; pi++) {
        if (ap[pi] && typeof ap[pi].id === 'number') apIds.push(ap[pi].id);
      }
      apIds.sort(function (a, b) { return a - b; });
      blocks.push('<br>');
      for (var pj = 0; pj < apIds.length; pj++) {
        if (pj > 0) blocks.push(' &nbsp; ');
        blocks.push(infoAlertIdLink('Info_showAbstractPerceptionImageDetail', apIds[pj]));
      }
    } else {
      blocks.push('<br><i>None. Created when an <b>EP</b> frame <b>closes</b>.</i>');
    }
    blocks.push('<br><br><b>2. Action clones</b> (AbstractActionImages), total ' + aa.length + ':');
    if (aa.length) {
      var aaIds = [];
      for (var ai = 0; ai < aa.length; ai++) {
        if (aa[ai] && typeof aa[ai].id === 'number') aaIds.push(aa[ai].id);
      }
      aaIds.sort(function (a, b) { return a - b; });
      blocks.push('<br>');
      for (var aj = 0; aj < aaIds.length; aj++) {
        if (aj > 0) blocks.push(' &nbsp; ');
        blocks.push(infoAlertIdLink('Info_showAbstractActionImageDetail', aaIds[aj]));
      }
    } else {
      blocks.push('<br><i>None (or perception only — no action image in the frame).</i>');
    }
    blocks.push('<br><br><b>3. Top-level symbols</b> (Abstractions, mental_automatism.js), total ' + arr.length + ':');
    if (!arr.length) {
      blocks.push('<br><i>None yet.</i>');
    } else {
      blocks.push('<br>');
      var ids = [];
      for (var i = 0; i < arr.length; i++) {
        if (arr[i] && typeof arr[i].id === 'number') ids.push(arr[i].id);
      }
      ids.sort(function (a, b) { return a - b; });
      for (var j = 0; j < ids.length; j++) {
        if (j > 0) blocks.push(' &nbsp; ');
        blocks.push(infoAlertIdLink('Info_showAbstractionDetail', ids[j]));
      }
    }
    global.show_alert(blocks.join(''), 0);
  }

  /** Human-readable gestalt status (gestalt.js, GESTALT_STATUS). */
  function gestaltStatusLabel(st) {
    var n = parseInt(st, 10);
    if (isNaN(n)) return String(st);
    switch (n) {
      case 0: return '0 — new';
      case 1: return '1 — started';
      case 2: return '2 — partial';
      case 3: return '3 — closed (success)';
      case 4: return '4 — archive';
      default: return String(n);
    }
  }

  /**
   * GestaltArr records; click ID → Info_showGestaltDetail.
   * Data lives in gestalt.js (loaded after informing.js; available on click).
   */
  function Info_showGestaltsList() {
    if (typeof global.show_alert !== 'function') return;
    var arr = Array.isArray(global.GestaltArr) ? global.GestaltArr : [];
    var buf = Array.isArray(global.GestaltResonanceBuffer) ? global.GestaltResonanceBuffer : [];
    var head = '<b>Gestalts (dominants of open problems)</b><br><small>Records: ' + arr.length
      + '. Resonance buffer (FIFO EP signatures): ' + buf.length
      + '. Statuses: 0 new, 1 started, 2 partial, 3 closed, 4 archive.</small><br><br>';
    if (!arr.length) {
      global.show_alert(head + '<i>No gestalt records yet.</i>', 0);
      return;
    }
    var ids = [];
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && typeof arr[i].id === 'number') ids.push(arr[i].id);
    }
    ids.sort(function (a, b) { return a - b; });
    var parts = [head, 'ID: '];
    for (var j = 0; j < ids.length; j++) {
      if (j > 0) parts.push(' &nbsp; ');
      parts.push(infoAlertIdLink('Info_showGestaltDetail', ids[j]));
    }
    global.show_alert(parts.join(''), 0);
  }

  function Info_showGestaltDetail(id) {
    if (typeof global.show_alert !== 'function') return;
    id = parseInt(id, 10) || 0;
    var arr = Array.isArray(global.GestaltArr) ? global.GestaltArr : [];
    var g = null;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && arr[i].id === id) {
        g = arr[i];
        break;
      }
    }
    if (!g) {
      global.show_alert('Gestalt #' + id + ' not found.', 0);
      return;
    }
    var activeId = typeof global.Gestalt_activeGestaltId === 'number' ? global.Gestalt_activeGestaltId : 0;
    var masterCyc = typeof global.Gestalt_activeMasterCycleId === 'number' ? global.Gestalt_activeMasterCycleId : 0;
    var goalPart = g.goalImageId
      ? ('goalImageId: ' + infoAlertIdLink('Info_showLifeGoalDetail', g.goalImageId))
      : 'goalImageId: 0';
    var branchPart = g.problemTreeId
      ? ('branch (problemTreeId): ' + infoAlertIdLink('Info_showPerceptionNodeDetail', g.problemTreeId))
      : ('branch (problemTreeId): 0');
    var sitPart = g.situationId
      ? ('situation: ' + infoAlertIdLink('Info_showSituationImageDetail', g.situationId))
      : 'situation: 0';
    var autoIds = Array.isArray(g.automatismIds) ? g.automatismIds : [];
    var autoLine = 'tried automatisms: ';
    if (!autoIds.length) {
      autoLine += '—';
    } else {
      var bits = [];
      for (var a = 0; a < autoIds.length; a++) {
        bits.push(infoAlertIdLink('Info_showMotorAutomatizmDetail', autoIds[a]));
      }
      autoLine += bits.join(', ');
    }
    var pool = Array.isArray(g.analogyPool) ? g.analogyPool : [];
    var poolStr = pool.length ? ('<pre style="white-space:pre-wrap;font-size:9pt;margin:6px 0">' +
      String(JSON.stringify(pool, null, 2)) + '</pre>') : '<i>empty</i>';
    var lines = [
      '<b>Gestalt #' + id + '</b>',
      '<br>' + goalPart,
      '<br>' + branchPart,
      '<br>' + sitPart,
      '<br>status: ' + gestaltStatusLabel(g.status),
      '<br>' + autoLine,
      '<br>lastInsightKind: ' + String(g.lastInsightKind || '—') + ', lastInsightPuls: ' + String(g.lastInsightPuls || 0)
        + ', insightChainCount: ' + String(g.insightChainCount || 0),
      '<br>leading now: ' + (activeId === id ? 'yes' : 'no') + ' (Gestalt_activeGestaltId=' + activeId + ', master cycle=' + masterCyc + ')',
      '<br><b>analogyPool</b> (analogy tail):',
      poolStr
    ];
    global.show_alert(lines.join(''), 0);
  }

  function Info_showLifeGoalsList() {
    if (typeof global.show_alert !== 'function') return;
    var arr = Array.isArray(global.GoalImagesLife) ? global.GoalImagesLife : [];
    if (!arr.length) {
      global.show_alert('No life-experience goal images (GoalImagesLife) yet.', 0);
      return;
    }
    var ids = [];
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && typeof arr[i].id === 'number') ids.push(arr[i].id);
    }
    ids.sort(function (a, b) { return a - b; });
    var parts = ['<b>Goal images (life experience)</b> (' + ids.length + '). Click ID — detail:<br><br>'];
    for (var j = 0; j < ids.length; j++) {
      if (j > 0) parts.push(' &nbsp; ');
      parts.push(infoAlertIdLink('Info_showLifeGoalDetail', ids[j]));
    }
    global.show_alert(parts.join(''), 0);
  }

  function Info_showSituationImagesList() {
    if (typeof global.show_alert !== 'function') return;
    if (typeof global.SituationsTree_getAllSituationImages !== 'function') {
      global.show_alert('SituationsTree unavailable.', 0);
      return;
    }
    var arr = global.SituationsTree_getAllSituationImages() || [];
    if (!arr.length) {
      global.show_alert('No situation images (SituationImages) yet.', 0);
      return;
    }
    var ids = [];
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && typeof arr[i].id === 'number') ids.push(arr[i].id);
    }
    ids.sort(function (a, b) { return a - b; });
    var bySitId = {};
    for (var si = 0; si < arr.length; si++) {
      if (arr[si] && typeof arr[si].id === 'number') bySitId[arr[si].id] = arr[si];
    }
    var parts = ['<b>Situation images (SituationImages)</b> (' + ids.length + '). Click ID — detail.<br><small>Ready — blue border.</small><br><br>'];
    for (var j = 0; j < ids.length; j++) {
      if (j > 0) parts.push(' &nbsp; ');
      var rec = bySitId[ids[j]];
      parts.push(rec ? infoSituationImageLinkFromRecord(rec) : infoAlertIdLink('Info_showSituationImageDetail', ids[j]));
    }
    global.show_alert(parts.join(''), 0);
  }

  function Info_showLifeGoalDetail(id) {
    if (typeof global.show_alert !== 'function') return;
    id = parseInt(id, 10) || 0;
    var g = typeof global.Goals_getGoalById === 'function' ? global.Goals_getGoalById(id) : null;
    if (!g) {
      global.show_alert('Goal image #' + id + ' not found.', 0);
      return;
    }
    var odLink = (g.actionImageId || 0)
      ? infoAlertIdLink('Info_showActionImageDetail', g.actionImageId)
      : '0';
    var lines = [
      '<b>Goal image (life experience) #' + id + '</b>',
      '<br>perceptionNodeId: ' + (g.perceptionNodeId || 0),
      '<br>situationId: ' + (g.situationId || 0),
      '<br>stimulusImageId: ' + (g.stimulusImageId || 0),
      '<br>action (AI): ' + odLink,
      '<br>effect (avg.): ' + (typeof g.effect === 'number' ? g.effect : 0),
      '<br>count: ' + (typeof g.count === 'number' ? g.count : 0),
      '<br>usefulness: ' + (typeof g.usefulness === 'number' ? g.usefulness : 0),
      '<br>usefulnessCount: ' + (typeof g.usefulnessCount === 'number' ? g.usefulnessCount : 0)
    ];
    global.show_alert(lines.join(''), 0);
  }

  function Info_showAbstractionDetail(id) {
    if (typeof global.show_alert !== 'function') return;
    id = parseInt(id, 10) || 0;
    var arr = Array.isArray(global.Abstractions) ? global.Abstractions : [];
    var obj = null;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && arr[i].id === id) { obj = arr[i]; break; }
    }
    if (!obj) {
      global.show_alert('Abstractions symbol #' + id + ' not found.', 0);
      return;
    }
    var lines = [
      '<b>Abstractions symbol #' + id + '</b>',
      '<small>mental_automatism.js — click a number below to open linked entity detail.</small>'
    ];
    var keys = Object.keys(obj).sort();
    for (var k = 0; k < keys.length; k++) {
      var key = keys[k];
      if (key === 'id') continue;
      var val = obj[key];
      var label = INFO_ABSTRACTION_FIELD_LABEL[key] || key;
      lines.push('<br><b>' + label + '</b> (' + key + '): ' + infoFormatAbstractionFieldValue(key, val));
    }
    global.show_alert(lines.join(''), 0);
  }

  function infoConfirmThenClear(ev, onOk) {
    if (ev && ev.stopPropagation) ev.stopPropagation();
    if (ev && ev.preventDefault) ev.preventDefault();
    var msg = 'Delete for sure?';
    if (typeof global.show_confirm === 'function') {
      global.show_confirm(msg, function (result) {
        if (result === 'OK') onOk();
      });
    } else if (typeof global.confirm === 'function' && global.confirm(msg)) {
      onOk();
    }
  }

  function Info_clearMotorAutomatizms(ev) {
    infoConfirmThenClear(ev, function () {
      if (typeof global.Automatizms_clearAll === 'function') global.Automatizms_clearAll();
    });
  }

  function Info_clearMentalAutomatizms(ev) {
    infoConfirmThenClear(ev, function () {
      if (typeof global.MentalAutomatizms_clearAll === 'function') global.MentalAutomatizms_clearAll();
    });
  }

  function Info_clearAbstractions(ev) {
    infoConfirmThenClear(ev, function () {
      if (typeof global.Abstractions_clearAll === 'function') global.Abstractions_clearAll();
    });
  }

  function Info_clearLifeGoals(ev) {
    infoConfirmThenClear(ev, function () {
      if (typeof global.Goals_clearAllLifeGoals === 'function') global.Goals_clearAllLifeGoals();
    });
  }

  function Info_clearSituationImages(ev) {
    infoConfirmThenClear(ev, function () {
      if (typeof global.SituationsTree_clearAllSituationImages === 'function') {
        global.SituationsTree_clearAllSituationImages();
      }
    });
  }

  global.Info_setField = Info_setField;
  global.Info_setMode = Info_setMode;
  global.Info_updateFromPerceptionTree = Info_updateFromPerceptionTree;
  global.Info_updateFromStimulus = Info_updateFromStimulus;
  global.Info_setProblemFromUnsolved = Info_setProblemFromUnsolved;
  global.Info_incrementStep = Info_incrementStep;
  global.Info_updateView = Info_updateView;
  global.Info_showBackgroundStack = Info_showBackgroundStack;
  global.Info_showBackgroundCycleDetail = Info_showBackgroundCycleDetail;
  global.Info_showCycleDetailById = Info_showCycleDetailById;
  global.Info_showFinalImageStimulusDetail = Info_showFinalImageStimulusDetail;
  global.Info_showPerceptionNodeDetail = Info_showPerceptionNodeDetail;
  global.Info_showEmotionRecordDetail = Info_showEmotionRecordDetail;
  global.Info_showThemeImageDetail = Info_showThemeImageDetail;
  global.Info_showSituationImageDetail = Info_showSituationImageDetail;
  global.Info_showActionImageDetail = Info_showActionImageDetail;
  global.Info_showMentalActionImageDetail = Info_showMentalActionImageDetail;
  global.Info_showMotorAutomatizmsList = Info_showMotorAutomatizmsList;
  global.Info_showMotorAutomatizmDetail = Info_showMotorAutomatizmDetail;
  global.Info_showMentalAutomatizmsList = Info_showMentalAutomatizmsList;
  global.Info_showMentalAutomatizmDetail = Info_showMentalAutomatizmDetail;
  global.Info_showAbstractionsList = Info_showAbstractionsList;
  global.Info_showAbstractionDetail = Info_showAbstractionDetail;
  global.Info_showAbstractPerceptionImageDetail = Info_showAbstractPerceptionImageDetail;
  global.Info_showAbstractActionImageDetail = Info_showAbstractActionImageDetail;
  global.Info_showLifeGoalsList = Info_showLifeGoalsList;
  global.Info_showLifeGoalDetail = Info_showLifeGoalDetail;
  global.Info_showGestaltsList = Info_showGestaltsList;
  global.Info_showGestaltDetail = Info_showGestaltDetail;
  global.Info_showMainCycleDetail = Info_showMainCycleDetail;
  global.Info_showDetail = Info_showDetail;
  global.Info_thinkingFlash = Info_thinkingFlash;
  global.Info_clearMotorAutomatizms = Info_clearMotorAutomatizms;
  global.Info_clearMentalAutomatizms = Info_clearMentalAutomatizms;
  global.Info_clearAbstractions = Info_clearAbstractions;
  global.Info_clearLifeGoals = Info_clearLifeGoals;
  global.Info_showSituationImagesList = Info_showSituationImagesList;
  global.Info_clearSituationImages = Info_clearSituationImages;
  global.Info_fillFantasmPlotOnPassiveMain = Info_fillFantasmPlotOnPassiveMain;
  global.Info_fillFantasmPlotOnPassiveBackground = Info_fillFantasmPlotOnPassiveBackground;

  function Info_showFantasmPlotDetail() {
    Info_showDetail('fantasmPlot');
  }
  global.Info_showFantasmPlotDetail = Info_showFantasmPlotDetail;

})(window);

