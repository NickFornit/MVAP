# Conscious attention channel (_9_Conscience)

## Purpose

The module implements **conscious processing of a stimulus** after the orientation reflex: **stimuls_consciousness(context)** is called from OR. The context carries full novelty detail (**actual_stimul_ID**, **branchId**, **novelty**, **significance**, **samplesCount**, **pathArr**, **well**, **emotionId**, **activityID**, **isResponseStimulus**, **orientationReflexWinner**) for situation analysis. If **orientationReflexWinner** is true, the “thought silence” threshold (vs main cycle importance) **does not block** starting a new consciousness cycle — OR competition already picked the winner.

**Thought silence** (lower effective importance for competing stimulus: theme/situation mismatch with main cycle, penalty for `ImportantProblem`, threshold `INTERRUPT_THRESHOLD_ATTENTION_RATIO`) applies **only while a main consciousness cycle exists and is not yet `expired`**. For **EP chain priority** stimuli, separate rules — `about_episodic_memory_rules.md`, §7. The code checks for a default automatism on the active tree node (branchId); if present, the action image runs (runActionImage). On automatism start, removeDelayedReflexesForBranch(branchId) clears all delayed reflex entries for that branch (no action comparison). There is room to evaluate whether starting the ActionsImageID is acceptable for current novelty.

**Automatism independence from reflex:** the initial automatism in consciousness may be arbitrarily changed (different AID). No assumed link between primary reflex and secondary automatism: automatism is its own branch rule; its action image may differ from what the reflex first recorded.

## Consciousness cycle dispatcher

Consciousness cycles run **per pulse iteratively**, without recursive consciousness calls (pattern from OLD_CODE/Go: understanding.go, understanding_cycle.go).

- **consciousness_dispatcher.js** — cycle registry (ConsciousnessCycles), create/cancel/delete, set main (Consciousness_setMainCycle). Each pulse **dispetchConsciousnessThinking(pulsCount)**: main gets one step (Consciousness_runOneStep), background every **5** pulses (see `consciousness_dispatcher.js`); if no main, promote from ConsciousnessBackgroundStack (**promoteFromBackgroundCycle** / interrupt stack). Without the dispatcher, reliable “thinking” is hard. **Stagnation:** if after a step main is **expired** (three iterations without info-picture change) and level-4/gestalt tick already ran this pulse (`lastGestaltConsciencePuls`), info picture switches to **passive**, cycle flag `passiveWorkAfterGestaltExpire` (cycle detail in `informing.js`, `formatCycleOrStackInfo`).
- **conscious_attention_channel.js** — **stimuls_consciousness(context)** entry. On a more salient call, current main is pushed to stack and cancelled; new cycle is created and elementary pass runs (Consciousness_runElementary). No recursion: dispatcher continues and resumes interrupted context.

## Current implementation

- **conscious_attention_channel.js** — stimuls_consciousness creates cycle, runs levels 1 and 2 (EP lookup, default automatism, else conscience_level_2). Consciousness_runElementary and Consciousness_runOneStep exported for dispatcher; levels 3–4 in runOneStep delegate to **conscience_level_3_runFromChannel** / **conscience_level_4_runFromChannel**.
- Call from `orientation_reflex.js` on **full** OR (including **second** pass after response during wait); on 3rd pulse — initial cycle without stimulus (`actualId: 0`, no `orientationReflexWinner`).
- **puls.js** — each pulse calls dispetchConsciousnessThinking(global.cpuls).

## Files

- **consciousness_dispatcher.js** — registry, dispatcher, promoteFromBackgroundStack.
- **infofunctions.js** — `info_automatismWithEpisodeFeedbackAndExpireCycle`; `info_bestEpisodicRule` (best EP rule with options: stimulus filter as level 3, stimulus fallback as level 2 survival); `info_bestEpisodicRuleForStimulus` — wrapper.
- **conscious_attention_channel.js** — stimuls_consciousness, Consciousness_runElementary, Consciousness_runOneStep.
- **conscience_level_3.js** — third level (from `conscience_level_3_runFromChannel` per channel tick). **Order:** ready default mental automatism (if `semanticStructure` frame aligns with MAI) → shortcut `AbstractImages_findRuleFrameMatchingContext` → stimulus semantics + `info_bestEpisodicRule` (same stimulus, positive effect) → teacher fallback (`info_teacherEpisodicRuleForAction`, mirrors 88/89). All successful branches run motor via `conscience_level_3_startAutomatismFromEpisodicRule` → `info_automatismWithEpisodeFeedbackAndExpireCycle`. **Stability:** while cycle waits for EP after automatism (`awaitingAutomatismEpisodeFeedback` without operator answer), full pipeline is skipped; multiple triggers in one tick log via `Consciousness_cycleAppendLog`, often `{ force: true }` due to `expired`. **Significance before motor:** shortcut and mental paths only if `semanticStructure` frame is “positive” (`conscience_level_3_semanticStructureFrameAllowsMotor`: teacher or episodic with numeric `effect > 0`); EP path also blocked if best semantic frame for stimulus has `meanImportance < 0`; teacher path blocked if chosen frame has numeric `effect ≤ 0`.
- **conscience_level_4.js** — fourth level: channel tick calls **`Gestalt_onConsciousnessTick`** (`gestalt.js`) — leading gestalt to main cycle goal, **resonance buffer** (signatures of closed EP frames), context refresh. Details: **`about_gestalt.md`**.
- **gestalt.js** — **gestalt** records (dominants by `goalImageId`), **GestaltResonanceBuffer**, calls from level 3 (**`Gestalt_prepareContextForCycle`** → `GestaltContextForLevel3`) and **`closeLastFrame`** (**`Gestalt_onEpisodeFeedbackClosed`**). IndexedDB `BEAST_Gestalt_DB`. Main page info row: **“gest: N”** and `Info_showGestaltsList` / `Info_showGestaltDetail` (`informing.js`).

## See also

- **`about_adaptivity_levels_2_4.md`** — how levels 2 and 4 tie to semantics, EP, passive fantasy, and implementation limits.
- **`../_12_Sleep/about_sleep.md`** — sleep and dreams (main passive cycle, `Consciousness_deleteAllBackgroundCycles` after `SleepMode_exit(true)`).
