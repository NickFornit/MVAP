/* GOAL IMAGES — theory & implementation notes (condensed).
Goal images: generalized desired-state models from episodic memory (situation → action → outcome), reorganized by frontal systems for planning.
Hippocampus builds predictive transition maps; PFC/episodic RL analogs combine past episodes for novel situations; value networks arbitrate competing goals.
Implementation: base homeostatic goal (vital to normalize); life-experience goals in GoalImagesLife (EP-derived rules, branch generalization via parents); voluntary chains (planned); allostatic overload blocks voluntary goals; in Norm without a chosen goal, thinkingMode becomes passive.
Integration: conscience_level_2 calls Goals_determineGoalInSituation; new goals form when L2 scans Episodes, not in EP closeLastFrame alone.
See inline structure comments below for GoalImagesLife / voluntary design.
*/


(function (global) {
  'use strict';

  /** Default meaning goal key (perceptionNodeId=0, situationId=0, actionImageId=-1). */
  var GOAL_KIND_MEANING_DEFAULT = 'meaning_default';
  var GOALS_DEFAULT_MEANING_LABEL = 'What does this mean to me?';

  /** Default cry goal: perceptionNodeId=0, situationId=0, action image with BasicActions Id=1 (Cries). */
  var GOAL_KIND_CRY_DEFAULT = 'cry_default';
  var GOALS_DEFAULT_CRY_LABEL = 'Cry';

  if (!Array.isArray(global.GoalImagesLife)) {
    global.GoalImagesLife = [];
  }

  var nextId = 1;
  /** Index: perceptionNodeId -> goal images for that branch (fast lookup). */
  var byPerceptionNodeId = Object.create(null);
  /** Uniqueness by (perceptionNodeId, stimulusImageId, actionImageId) -> goal object. */
  var byKey = Object.create(null);
  var goalsDirty = false;
  var lastGoalsSavedSig = '';

  function lifeGoalKey(perceptionNodeId, stimulusImageId, actionImageId, situationId) {
    return (perceptionNodeId || 0) + '|' + (stimulusImageId || 0) + '|' + (actionImageId || 0) +
      '|' + (situationId || 0);
  }

  function normalizeLifeGoalRecord(g) {
    if (!g) return g;
    var pn = g.perceptionNodeId != null ? g.perceptionNodeId : (g.perceptionBranchId || 0);
    g.perceptionNodeId = pn;
    g.perceptionBranchId = pn;
    if (g.situationId == null) g.situationId = 0;
    if (g.usefulness == null) g.usefulness = 0;
    if (g.usefulnessCount == null) g.usefulnessCount = 0;
    if (g.episodicRule !== null && g.episodicRule !== undefined && typeof g.episodicRule !== 'object') {
      g.episodicRule = null;
    }
    if (!Array.isArray(g.episodicRuleChain)) g.episodicRuleChain = [];
    if (g.goalKind == null) g.goalKind = '';
    if (g.goalLabel == null) g.goalLabel = '';
    return g;
  }

  /**
   * One rule snapshot from an EP frame: conditions + action + frame outcome (+ operator response if any).
   * Omits frame housekeeping fields (_goalsProcessed, etc.).
   * @param {Object} frame
   * @param {number} [episodeIndex] — index in global.Episodes for consecutive-frame chain assembly
   * @returns {Object|null}
   */
  function episodicRuleFromFrame(frame, episodeIndex) {
    if (!frame) return null;
    var r = {
      perceptionNodeId: frame.perceptionNodeId != null ? frame.perceptionNodeId : 0,
      stimulusImageId: frame.stimulusImageId != null ? frame.stimulusImageId : 0,
      situationId: frame.situationId != null ? frame.situationId : 0,
      actionImageId: frame.actionImageId != null ? frame.actionImageId : 0,
      effect: typeof frame.effect === 'number' && !isNaN(frame.effect) ? frame.effect : null,
      responseStimulusImageId: frame.responseStimulusImageId != null ? frame.responseStimulusImageId : 0
    };
    if (episodeIndex != null && typeof episodeIndex === 'number' && !isNaN(episodeIndex)) {
      r.episodeIndex = episodeIndex;
    }
    return r;
  }

  function cloneEpisodicRule(rule) {
    if (!rule || typeof rule !== 'object') return null;
    try {
      return JSON.parse(JSON.stringify(rule));
    } catch (e) {
      return episodicRuleFromFrame(rule, rule.episodeIndex);
    }
  }

  /**
   * Update rule snapshot and chain when possible: append only if episodeIndex is last link index + 1
   * (consecutive frames in Episodes).
   * Empty chain (old saves): first update adds current snapshot as first link.
   */
  function mergeEpisodicRuleChainOnUpdate(goal, frame, meta) {
    if (!goal || !frame) return;
    var snap = episodicRuleFromFrame(frame, meta && typeof meta.episodeIndex === 'number' ? meta.episodeIndex : undefined);
    if (!snap) return;
    goal.episodicRule = snap;
    if (!Array.isArray(goal.episodicRuleChain)) goal.episodicRuleChain = [];
    if (goal.episodicRuleChain.length === 0) {
      goal.episodicRuleChain.push(cloneEpisodicRule(snap));
      return;
    }
    var idx = meta && typeof meta.episodeIndex === 'number' ? meta.episodeIndex : null;
    var last = goal.episodicRuleChain[goal.episodicRuleChain.length - 1];
    if (idx == null || typeof last !== 'object' || last == null || typeof last.episodeIndex !== 'number') {
      return;
    }
    if (idx === last.episodeIndex + 1) {
      goal.episodicRuleChain.push(cloneEpisodicRule(snap));
    }
  }

  /** Add a usefulness sample into the goal’s running average. */
  function mergeUsefulnessSample(goal, sample) {
    if (!goal || typeof sample !== 'number' || isNaN(sample)) return;
    var oc = goal.usefulnessCount || 0;
    var n = oc + 1;
    goal.usefulness = ((goal.usefulness || 0) * oc + sample) / n;
    goal.usefulnessCount = n;
  }

  function rebuildIndex() {
    byPerceptionNodeId = Object.create(null);
    byKey = Object.create(null);
    var arr = global.GoalImagesLife;
    if (!Array.isArray(arr)) return;
    for (var i = 0; i < arr.length; i++) {
      var g = arr[i];
      if (!g || g.perceptionNodeId == null) continue;
      var key = String(g.perceptionNodeId);
      if (!byPerceptionNodeId[key]) byPerceptionNodeId[key] = [];
      byPerceptionNodeId[key].push(g);
      normalizeLifeGoalRecord(g);
      var k = lifeGoalKey(g.perceptionNodeId, g.stimulusImageId, g.actionImageId, g.situationId);
      byKey[k] = g;
    }
  }

  function getNextId() {
    var max = 0;
    var arr = global.GoalImagesLife;
    for (var i = 0; i < (arr && arr.length) || 0; i++) {
      if (arr[i] && arr[i].id > max) max = arr[i].id;
    }
    return max + 1;
  }

  /**
   * Add or update a life-experience goal image from an episode frame (effect > 0).
   * Unique by (perceptionNodeId, stimulusImageId, actionImageId, situationId). effect averaged by count.
   * Stores episodicRule (last frame snapshot) and extends episodicRuleChain when episode indices are known.
   * @param {Object} frame — EP frame
   * @param {Object} [meta] — { episodeIndex: number } index in global.Episodes for consecutive-rule chain
   * @returns {number} goal image id (existing or new)
   */
  function addOrUpdateLifeGoalFromFrame(frame, meta) {
    if (!frame || typeof frame.effect !== 'number' || frame.effect <= 0) return 0;
    var perceptionNodeId = frame.perceptionNodeId != null ? frame.perceptionNodeId : 0;
    var stimulusImageId = frame.stimulusImageId != null ? frame.stimulusImageId : 0;
    var actionImageId = frame.actionImageId != null ? frame.actionImageId : 0;
    var situationId = frame.situationId != null ? frame.situationId : 0;
    if (!perceptionNodeId || !actionImageId) return 0;

    var k = lifeGoalKey(perceptionNodeId, stimulusImageId, actionImageId, situationId);
    var existing = byKey[k];
    if (existing) {
      var n = (existing.count || 0) + 1;
      existing.effect = ((existing.effect || 0) * (existing.count || 0) + frame.effect) / n;
      existing.count = n;
      mergeUsefulnessSample(existing, frame.usefulness);
      existing.lastUsedAt = Date.now();
      normalizeLifeGoalRecord(existing);
      mergeEpisodicRuleChainOnUpdate(existing, frame, meta || {});
      goalsDirty = true;
      return existing.id;
    }

    var id = getNextId();
    var snap = episodicRuleFromFrame(frame, meta && typeof meta.episodeIndex === 'number' ? meta.episodeIndex : undefined);
    var goal = {
      id: id,
      perceptionNodeId: perceptionNodeId,
      perceptionBranchId: perceptionNodeId,
      situationId: situationId,
      stimulusImageId: stimulusImageId,
      actionImageId: actionImageId,
      effect: frame.effect,
      count: 1,
      usefulness: 0,
      usefulnessCount: 0,
      lastUsedAt: Date.now(),
      episodicRule: snap,
      episodicRuleChain: snap ? [cloneEpisodicRule(snap)] : []
    };
    normalizeLifeGoalRecord(goal);
    mergeUsefulnessSample(goal, frame.usefulness);
    global.GoalImagesLife.push(goal);
    rebuildIndex();
    goalsDirty = true;
    return id;
  }

  /**
   * Append another rule snapshot to the goal’s chain (order defined by caller).
   * Sets episodicRule to this snapshot.
   * @param {number} goalId
   * @param {Object} frame — EP frame or fields like episodicRuleFromFrame
   * @param {number} [episodeIndex]
   * @returns {boolean}
   */
  function appendLifeGoalEpisodicRuleLink(goalId, frame, episodeIndex) {
    var g = getGoalById(goalId);
    if (!g || !frame) return false;
    var snap = episodicRuleFromFrame(frame, episodeIndex);
    if (!snap) return false;
    normalizeLifeGoalRecord(g);
    g.episodicRule = snap;
    g.episodicRuleChain.push(cloneEpisodicRule(snap));
    goalsDirty = true;
    return true;
  }

  /**
   * Merge one usefulness sample into a GoalImagesLife record.
   * @param {number} goalId
   * @param {number} sample
   */
  function mergeUsefulnessSampleForGoalId(goalId, sample) {
    var g = getGoalById(goalId);
    if (!g || typeof sample !== 'number' || isNaN(sample)) return;
    mergeUsefulnessSample(g, sample);
    goalsDirty = true;
  }

  /**
   * Adjust usefulness after the waiting-period frame closes (operator response effect).
   * If count === 1, usefulness = effect (no blend with past).
   * If count &gt; 1 — mergeUsefulnessSample (running mean).
   * Not called on wait timeout without response (L2 pipeline does not run).
   * @param {number} goalId
   * @param {number} episodeEffect
   */
  function applyWaitingPeriodEffectToGoalUsefulness(goalId, episodeEffect) {
    var g = getGoalById(goalId);
    if (!g || typeof episodeEffect !== 'number' || isNaN(episodeEffect)) return;
    if ((g.count || 0) === 1) {
      g.usefulness = episodeEffect;
      g.usefulnessCount = 1;
    } else {
      mergeUsefulnessSample(g, episodeEffect);
    }
    goalsDirty = true;
  }

  /**
   * Get life-experience goal image by id.
   * @param {number} id
   * @returns {Object|null}
   */
  function getGoalById(id) {
    if (id == null || id === 0) return null;
    var arr = global.GoalImagesLife;
    if (!Array.isArray(arr)) return null;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && arr[i].id === id) return arr[i];
    }
    return null;
  }

  function lifeGoalMatchesSituationFilter(g, situationFilter) {
    if (situationFilter == null || situationFilter === 0) return true;
    return (g.situationId || 0) === situationFilter;
  }

  /**
   * Best life-experience goal for a branch: exact match first, then parent chain.
   * Returns goal with max effect (count >= minCount).
   * @param {number} branchId — current terminal perception-tree node
   * @param {number} [minCount=1] — minimum experiences to consider
   * @param {number} [situationId=0] — 0 = no situation filter; else only this situationId
   * @returns {Object|null}
   */
  function getBestLifeGoalForBranch(branchId, minCount, situationId) {
    if (branchId == null || branchId === 0) return null;
    minCount = minCount != null ? minCount : 1;
    var situationFilter = situationId != null ? situationId : 0;
    var getNode = global.PerceptionTree_getNode;
    if (typeof getNode !== 'function') return null;

    var nodeId = branchId;
    var best = null;
    var bestEffect = -Infinity;

    while (nodeId) {
      var list = byPerceptionNodeId[String(nodeId)];
      if (Array.isArray(list)) {
        for (var i = 0; i < list.length; i++) {
          var g = list[i];
          if (!g || (g.count || 0) < minCount || typeof g.effect !== 'number') continue;
          if (!lifeGoalMatchesSituationFilter(g, situationFilter)) continue;
          if (g.effect > bestEffect) {
            bestEffect = g.effect;
            best = g;
          }
        }
        if (best) return best;
      }
      var node = getNode(nodeId);
      nodeId = node && typeof node.parentId === 'number' && node.parentId !== 0 ? node.parentId : null;
    }
    return null;
  }

  /**
   * Find life-experience goal by perception branch and optional situation image.
   * If situationId === 0, no situation filter (any situationId on records).
   * If nonzero, only goals with that situationId.
   * Among matches, pick max effect (tie: first in array order).
   * @param {number} perceptionNodeId
   * @param {number} situationId
   * @returns {Object|null}
   */
  function findLifeGoalByPerceptionAndSituation(perceptionNodeId, situationId) {
    perceptionNodeId = parseInt(perceptionNodeId, 10) || 0;
    situationId = parseInt(situationId, 10) || 0;
    if (!perceptionNodeId) return null;
    var arr = global.GoalImagesLife;
    if (!Array.isArray(arr) || !arr.length) return null;
    var best = null;
    var bestEffect = -Infinity;
    for (var i = 0; i < arr.length; i++) {
      var g = arr[i];
      if (!g) continue;
      var pn = g.perceptionNodeId != null ? g.perceptionNodeId : (g.perceptionBranchId || 0);
      if (pn !== perceptionNodeId) continue;
      if (situationId !== 0 && (g.situationId || 0) !== situationId) continue;
      if (typeof g.effect !== 'number') continue;
      if (g.effect > bestEffect) {
        bestEffect = g.effect;
        best = g;
      }
    }
    return best;
  }

  function goalUsefulnessPositive(g) {
    return g && typeof g.usefulness === 'number' && !isNaN(g.usefulness) && g.usefulness > 0;
  }

  /**
   * Life-experience goal with positive usefulness (survival mode, L2).
   * 1) Try perceptionNodeId + situationId (if situationId === 0, only goals with situationId 0).
   * 2) Else any goal with same perceptionNodeId.
   * Pick max usefulness (tie: higher effect).
   */
  function findBestLifeGoalPositiveUsefulness(perceptionNodeId, situationId) {
    perceptionNodeId = parseInt(perceptionNodeId, 10) || 0;
    situationId = parseInt(situationId, 10) || 0;
    if (!perceptionNodeId) return null;
    var arr = global.GoalImagesLife;
    if (!Array.isArray(arr) || !arr.length) return null;
    function pickBest(filterSit) {
      var best = null;
      var bestU = -Infinity;
      for (var i = 0; i < arr.length; i++) {
        var g = arr[i];
        if (!g || !goalUsefulnessPositive(g)) continue;
        var pn = g.perceptionNodeId != null ? g.perceptionNodeId : (g.perceptionBranchId || 0);
        if (pn !== perceptionNodeId) continue;
        var gs = g.situationId != null ? g.situationId : 0;
        if (!filterSit(gs)) continue;
        var u = g.usefulness;
        var eff = typeof g.effect === 'number' ? g.effect : 0;
        var bestEff = best && typeof best.effect === 'number' ? best.effect : 0;
        if (u > bestU || (u === bestU && eff > bestEff)) {
          bestU = u;
          best = g;
        }
      }
      return best;
    }
    var tier1 = pickBest(function (gs) {
      return situationId === 0 ? gs === 0 : gs === situationId;
    });
    if (tier1) return tier1;
    return pickBest(function () { return true; });
  }

  /**
   * Base homeostatic goal: vital id to return to norm.
   * Only when BadNormWell === 1 (Bad); Norm/Well returns 0.
   * @returns {number} vitalId with max BadVitalsValue or 0
   */
  function getActiveBaseGoalVitalId() {
    if (global.BadNormWell !== 1) return 0;
    var badVitals = global.BadVitalsValue;
    if (!badVitals || typeof badVitals !== 'object') return 0;
    var vitalsArr = global.VitalsArr;
    if (!Array.isArray(vitalsArr) || !vitalsArr.length) return 0;
    var maxK = 0;
    var vitalId = 0;
    for (var v = 0; v < vitalsArr.length; v++) {
      var vid = vitalsArr[v].Id;
      var k = badVitals[vid] || badVitals[String(vid)] || 0;
      if (k > maxK) {
        maxK = k;
        vitalId = vid;
      }
    }
    return vitalId;
  }

  function contextSignificance(ctx) {
    if (!ctx) return 0;
    if (typeof ctx.significance === 'number' && !isNaN(ctx.significance)) return Math.abs(ctx.significance);
    var sc = ctx.sourceContext || (ctx.sourceCycle && ctx.sourceCycle.context);
    if (sc && typeof sc.significance === 'number' && !isNaN(sc.significance)) return Math.abs(sc.significance);
    return 0;
  }

  function actualStimulusIdFromContext(ctx) {
    if (!ctx) return 0;
    var a = ctx.actualId != null ? ctx.actualId : ctx.actual_stimul_ID;
    if (a != null) {
      var n = parseInt(a, 10);
      return isNaN(n) ? 0 : n;
    }
    var sc = ctx.sourceContext || (ctx.sourceCycle && ctx.sourceCycle.context);
    if (sc && sc.actual_stimul_ID != null) {
      var n2 = parseInt(sc.actual_stimul_ID, 10);
      return isNaN(n2) ? 0 : n2;
    }
    return 0;
  }

  /**
   * Ensure default “what does this mean to me?” goal exists.
   * Key: perceptionNodeId=0, situationId=0, actionImageId=-1, stimulusImageId=0.
   */
  function findDefaultMeaningGoal() {
    var arr = global.GoalImagesLife;
    if (!Array.isArray(arr)) return null;
    for (var i = 0; i < arr.length; i++) {
      var g = arr[i];
      if (!g) continue;
      if (g.goalKind === GOAL_KIND_MEANING_DEFAULT) return normalizeLifeGoalRecord(g);
      var pn = g.perceptionNodeId != null ? g.perceptionNodeId : 0;
      var sn = g.situationId != null ? g.situationId : 0;
      var ai = g.actionImageId != null ? g.actionImageId : 0;
      if (pn === 0 && sn === 0 && ai === -1) return normalizeLifeGoalRecord(g);
    }
    return null;
  }

  function ensureDefaultMeaningGoal() {
    if (findDefaultMeaningGoal()) return;
    var id = getNextId();
    var goal = {
      id: id,
      perceptionNodeId: 0,
      perceptionBranchId: 0,
      situationId: 0,
      stimulusImageId: 0,
      actionImageId: -1,
      effect: 0,
      count: 1,
      usefulness: 0,
      usefulnessCount: 0,
      goalKind: GOAL_KIND_MEANING_DEFAULT,
      goalLabel: GOALS_DEFAULT_MEANING_LABEL,
      episodicRule: null,
      episodicRuleChain: []
    };
    normalizeLifeGoalRecord(goal);
    global.GoalImagesLife.push(goal);
    rebuildIndex();
    goalsDirty = true;
  }

  function findDefaultCryGoal() {
    var arr = global.GoalImagesLife;
    if (!Array.isArray(arr)) return null;
    for (var i = 0; i < arr.length; i++) {
      var g = arr[i];
      if (!g) continue;
      if (g.goalKind === GOAL_KIND_CRY_DEFAULT) return normalizeLifeGoalRecord(g);
    }
    return null;
  }

  /**
   * Default cry goal if missing: action image for finalImageId=0 and actionIds=[1] (BasicActions “Cries”).
   * Requires actions_image.js (ActionImages_getOrCreateActionImageId).
   */
  function ensureDefaultCryGoal() {
    if (typeof global.ActionImages_getOrCreateActionImageId !== 'function') return;
    var cryOd = global.ActionImages_getOrCreateActionImageId(0, [1], '');
    if (!cryOd) return;
    var existing = findDefaultCryGoal();
    if (existing) {
      if (existing.actionImageId !== cryOd) {
        existing.actionImageId = cryOd;
        rebuildIndex();
        goalsDirty = true;
      }
      return;
    }
    var id = getNextId();
    var goal = {
      id: id,
      perceptionNodeId: 0,
      perceptionBranchId: 0,
      situationId: 0,
      stimulusImageId: 0,
      actionImageId: cryOd,
      effect: 0,
      count: 1,
      usefulness: 0,
      usefulnessCount: 0,
      goalKind: GOAL_KIND_CRY_DEFAULT,
      goalLabel: GOALS_DEFAULT_CRY_LABEL,
      episodicRule: null,
      episodicRuleChain: []
    };
    normalizeLifeGoalRecord(goal);
    global.GoalImagesLife.push(goal);
    rebuildIndex();
    goalsDirty = true;
  }

  function getDefaultCryGoalId() {
    var g = findDefaultCryGoal();
    return g && g.id ? g.id : 0;
  }

  function isDefaultCryGoalId(goalId) {
    if (goalId == null || goalId === 0) return false;
    var g = getGoalById(goalId);
    if (!g) return false;
    return g.goalKind === GOAL_KIND_CRY_DEFAULT;
  }

  function isDefaultMeaningGoalId(id) {
    if (id == null || id === 0) return false;
    var g = getGoalById(id);
    if (!g) return false;
    if (g.goalKind === GOAL_KIND_MEANING_DEFAULT) return true;
    var pn = g.perceptionNodeId != null ? g.perceptionNodeId : 0;
    var sn = g.situationId != null ? g.situationId : 0;
    return pn === 0 && sn === 0 && g.actionImageId === -1;
  }

  function getDefaultMeaningGoalId() {
    var g = findDefaultMeaningGoal();
    return g && g.id ? g.id : 0;
  }

  /**
   * Set current goal on the info picture (currentGoalType, currentGoalId, currentGoalVitalId).
   */
  function setCurrentGoalInInfoPicture(goalType, goalId, vitalId) {
    var info = global.InfoPicture;
    if (!info) return;
    info.currentGoalType = goalType || null;
    info.currentGoalId = goalId != null ? goalId : 0;
    info.currentGoalVitalId = vitalId != null ? vitalId : 0;
    if (typeof global.Info_updateView === 'function') {
      global.Info_updateView();
    }
  }

  /**
   * Resolve goal for the situation (first step of L2 in target mode).
   * Priority: 1) base (vital when Bad); 2) life-experience goal on branch/parents;
   * 3) if stimulus significance &gt; 3 and actual stimulus — default “meaning” goal;
   * 4) else clear.
   */
  function Goals_determineGoalInSituation(context) {
    if (!context) return;

    var baseVitalId = getActiveBaseGoalVitalId();
    if (baseVitalId) {
      setCurrentGoalInInfoPicture('base', 0, baseVitalId);
      return;
    }

    var branchId = context.branchId != null ? context.branchId : 0;
    var sitId = 0;
    if (global.InfoPicture && typeof global.InfoPicture.situationId === 'number') {
      sitId = global.InfoPicture.situationId || 0;
    }
    var lifeGoal = getBestLifeGoalForBranch(branchId, 1, sitId);
    if (lifeGoal && lifeGoal.id) {
      setCurrentGoalInInfoPicture('life', lifeGoal.id, 0);
      return;
    }

    ensureDefaultMeaningGoal();
    var stim = actualStimulusIdFromContext(context);
    var sig = contextSignificance(context);
    var meaningG = findDefaultMeaningGoal();
    if (meaningG && meaningG.id && stim > 0 && sig > 3) {
      setCurrentGoalInInfoPicture('meaning', meaningG.id, 0);
      return;
    }

    setCurrentGoalInInfoPicture(null, 0, 0);
  }

  /**
   * Search episodic memory: scan frames, call Goals_considerNewGoalFromEpisode.
   */
  function Goals_runEpisodicSearch(context) {
    if (!context) return;
    var episodes = global.Episodes;
    if (!Array.isArray(episodes) || !episodes.length) return;
    var limit = Math.min(50, episodes.length);
    for (var i = episodes.length - 1; i >= 0 && episodes.length - i <= limit; i--) {
      var frame = episodes[i];
      if (frame) Goals_considerNewGoalFromEpisode(frame, context, i);
    }
  }

  /**
   * Consider an episode frame: if effect > 0 and fields present — create/update GoalImagesLife.
   * Each frame counted once (_goalsProcessed) so goals are not saved every pulse.
   * @param {number} [episodeIndex] — Episodes[] index for episodicRuleChain (consecutive frames).
   */
  function Goals_considerNewGoalFromEpisode(frame, context, episodeIndex) {
    if (!frame) return;
    if (frame._goalsProcessed) return;
    addOrUpdateLifeGoalFromFrame(frame, episodeIndex != null && typeof episodeIndex === 'number'
      ? { episodeIndex: episodeIndex }
      : null);
    frame._goalsProcessed = true;
  }

  /**
   * Passive mode: semantic processing of understanding models; new situation images — situatioms_tree.
   */
  function PassiveMode_processUnderstandingModels() {
    if (typeof global.Consciousness_getMainCycleThinkingMode !== 'function' ||
        global.Consciousness_getMainCycleThinkingMode() !== 'passive') return;
    if (typeof global.SituationsTree_considerNewSituationFromUnderstanding === 'function') {
      global.SituationsTree_considerNewSituationFromUnderstanding();
    }
  }

  /**
   * Call when passive scenarios are exhausted: decays background FO cycle weights by 50%
   * (operative memory of prior thought).
   */
  function PassiveMode_notifyScenariosExhausted() {
    if (typeof global.Consciousness_decayBackgroundOperativeMemory === 'function') {
      global.Consciousness_decayBackgroundOperativeMemory(0.5);
    }
  }

  // --- Serialization and restore ---
  function serializeState() {
    var arr = global.GoalImagesLife;
    if (!Array.isArray(arr)) return { goals: [], nextId: 1 };
    var list = [];
    for (var i = 0; i < arr.length; i++) {
      var g = arr[i];
      if (!g) continue;
      var chain = [];
      if (Array.isArray(g.episodicRuleChain)) {
        for (var c = 0; c < g.episodicRuleChain.length; c++) {
          var link = cloneEpisodicRule(g.episodicRuleChain[c]);
          if (link) chain.push(link);
        }
      }
      list.push({
        id: g.id,
        perceptionNodeId: g.perceptionNodeId,
        perceptionBranchId: g.perceptionBranchId != null ? g.perceptionBranchId : (g.perceptionNodeId || 0),
        situationId: g.situationId != null ? g.situationId : 0,
        stimulusImageId: g.stimulusImageId,
        actionImageId: g.actionImageId,
        effect: g.effect != null ? g.effect : 0,
        count: g.count != null ? g.count : 0,
        usefulness: g.usefulness != null ? g.usefulness : 0,
        usefulnessCount: g.usefulnessCount != null ? g.usefulnessCount : 0,
        lastUsedAt: g.lastUsedAt || 0,
        goalKind: g.goalKind || '',
        goalLabel: g.goalLabel || '',
        episodicRule: g.episodicRule != null ? cloneEpisodicRule(g.episodicRule) : null,
        episodicRuleChain: chain
      });
    }
    return { goals: list, nextId: getNextId() };
  }

  /** State without lastUsedAt — for signature compare so we do not save every pulse on time-only updates. */
  function serializeStateForSig() {
    var arr = global.GoalImagesLife;
    if (!Array.isArray(arr)) return { goals: [], nextId: 1 };
    var list = [];
    for (var i = 0; i < arr.length; i++) {
      var g = arr[i];
      if (!g) continue;
      var chainSig = [];
      if (Array.isArray(g.episodicRuleChain)) {
        for (var c2 = 0; c2 < g.episodicRuleChain.length; c2++) {
          var lk = cloneEpisodicRule(g.episodicRuleChain[c2]);
          if (lk) chainSig.push(lk);
        }
      }
      list.push({
        id: g.id,
        perceptionNodeId: g.perceptionNodeId,
        perceptionBranchId: g.perceptionBranchId != null ? g.perceptionBranchId : (g.perceptionNodeId || 0),
        situationId: g.situationId != null ? g.situationId : 0,
        stimulusImageId: g.stimulusImageId,
        actionImageId: g.actionImageId,
        effect: g.effect != null ? g.effect : 0,
        count: g.count != null ? g.count : 0,
        usefulness: g.usefulness != null ? g.usefulness : 0,
        usefulnessCount: g.usefulnessCount != null ? g.usefulnessCount : 0,
        goalKind: g.goalKind || '',
        goalLabel: g.goalLabel || '',
        episodicRule: g.episodicRule != null ? cloneEpisodicRule(g.episodicRule) : null,
        episodicRuleChain: chainSig
      });
    }
    return { goals: list, nextId: getNextId() };
  }

  function applyState(state) {
    if (!state || !Array.isArray(state.goals)) {
      global.GoalImagesLife = [];
      rebuildIndex();
      return;
    }
    global.GoalImagesLife = [];
    for (var i = 0; i < state.goals.length; i++) {
      var s = state.goals[i];
      if (!s || s.id == null) continue;
      var pn = s.perceptionNodeId != null ? s.perceptionNodeId : (s.perceptionBranchId != null ? s.perceptionBranchId : 0);
      var restChain = [];
      if (Array.isArray(s.episodicRuleChain)) {
        for (var rc = 0; rc < s.episodicRuleChain.length; rc++) {
          var rcl = cloneEpisodicRule(s.episodicRuleChain[rc]);
          if (rcl) restChain.push(rcl);
        }
      }
      var actId = 0;
      if (typeof s.actionImageId === 'number' && !isNaN(s.actionImageId)) actId = s.actionImageId;
      else if (s.actionImageId != null) {
        var ap = parseInt(s.actionImageId, 10);
        actId = isNaN(ap) ? 0 : ap;
      }
      global.GoalImagesLife.push(normalizeLifeGoalRecord({
        id: s.id,
        perceptionNodeId: pn,
        perceptionBranchId: s.perceptionBranchId != null ? s.perceptionBranchId : pn,
        situationId: s.situationId != null ? s.situationId : 0,
        stimulusImageId: s.stimulusImageId != null ? s.stimulusImageId : 0,
        actionImageId: actId,
        effect: typeof s.effect === 'number' ? s.effect : 0,
        count: (s.count != null && s.count >= 0) ? s.count : 0,
        usefulness: typeof s.usefulness === 'number' ? s.usefulness : 0,
        usefulnessCount: (s.usefulnessCount != null && s.usefulnessCount >= 0) ? s.usefulnessCount : 0,
        lastUsedAt: s.lastUsedAt || 0,
        goalKind: s.goalKind != null ? s.goalKind : '',
        goalLabel: s.goalLabel != null ? s.goalLabel : '',
        episodicRule: s.episodicRule != null ? cloneEpisodicRule(s.episodicRule) : null,
        episodicRuleChain: restChain
      }));
    }
    nextId = (typeof state.nextId === 'number' && state.nextId > 0) ? state.nextId : getNextId();
    rebuildIndex();
    ensureDefaultMeaningGoal();
    ensureDefaultCryGoal();
    lastGoalsSavedSig = JSON.stringify(serializeStateForSig());
    goalsDirty = false;
  }

  // IndexedDB (separate DB, same pattern as automatisms)
  var db = null;
  var DB_NAME = 'BEAST_Goals_DB';
  var DB_VERSION = 1;
  var STORE = 'goals_state';
  var KEY = 'goals_singleton';

  function openDb() {
    if (!global.indexedDB || !global.IndexedDBModule) return Promise.reject(new Error('IndexedDB is not available'));
    if (db) return Promise.resolve(db);
    return global.IndexedDBModule.openDatabase({
      dbName: DB_NAME,
      version: DB_VERSION,
      stores: [{ name: STORE, options: { keyPath: 'id' } }]
    }).then(function (d) {
      db = d;
      return d;
    });
  }

  function saveToIndexedDB(state) {
    if (!global.IndexedDBModule) return;
    state = state || serializeState();
    function put(database) {
      return global.IndexedDBModule.put({
        db: database,
        storeName: STORE,
        value: { id: KEY, state: state, ts: Date.now() }
      }).catch(function () {});
    }
    if (db) put(db);
    else openDb().then(put).catch(function () {});
  }

  function loadFromIndexedDB() {
    if (!global.IndexedDBModule) return;
    openDb()
      .then(function (d) {
        return global.IndexedDBModule.get({ db: d, storeName: STORE, key: KEY });
      })
      .then(function (record) {
        if (record && record.state) {
          applyState(record.state);
          lastGoalsSavedSig = JSON.stringify(serializeStateForSig());
        }
      })
      .catch(function () {});
  }

  if (typeof global.registerIndexedDBSaver === 'function') {
    global.registerIndexedDBSaver(function () {
      if (!goalsDirty) return;
      goalsDirty = false;
      var state = serializeState();
      var sig = JSON.stringify(serializeStateForSig());
      if (sig === lastGoalsSavedSig) return;
      lastGoalsSavedSig = sig;
      saveToIndexedDB(state);
    });
  }

  function clearAllLifeGoals() {
    global.GoalImagesLife = [];
    rebuildIndex();
    nextId = 1;
    goalsDirty = true;
    if (typeof global.TargetRuleStack_clear === 'function') global.TargetRuleStack_clear();
    var info = global.InfoPicture;
    if (info && (info.currentGoalType === 'life' || info.currentGoalType === 'meaning')) {
      info.currentGoalType = null;
      info.currentGoalId = 0;
    }
    if (info) info.usedRule = 0;
    if (typeof global.Info_updateView === 'function') global.Info_updateView();
    ensureDefaultMeaningGoal();
    ensureDefaultCryGoal();
  }

  rebuildIndex();
  ensureDefaultMeaningGoal();
  ensureDefaultCryGoal();
  loadFromIndexedDB();

  global.GoalImagesLife = global.GoalImagesLife;
  global.Goals_determineGoalInSituation = Goals_determineGoalInSituation;
  global.Goals_runEpisodicSearch = Goals_runEpisodicSearch;
  global.Goals_considerNewGoalFromEpisode = Goals_considerNewGoalFromEpisode;
  global.PassiveMode_processUnderstandingModels = PassiveMode_processUnderstandingModels;
  global.PassiveMode_notifyScenariosExhausted = PassiveMode_notifyScenariosExhausted;
  global.Goals_addOrUpdateLifeGoalFromFrame = addOrUpdateLifeGoalFromFrame;
  global.Goals_episodicRuleFromFrame = episodicRuleFromFrame;
  global.Goals_appendLifeGoalEpisodicRuleLink = appendLifeGoalEpisodicRuleLink;
  global.Goals_getGoalById = getGoalById;
  global.Goals_getBestLifeGoalForBranch = getBestLifeGoalForBranch;
  global.Goals_findLifeGoalByPerceptionAndSituation = findLifeGoalByPerceptionAndSituation;
  global.Goals_findBestLifeGoalPositiveUsefulness = findBestLifeGoalPositiveUsefulness;
  global.Goals_mergeUsefulnessSampleForGoalId = mergeUsefulnessSampleForGoalId;
  global.Goals_applyWaitingPeriodEffectToGoalUsefulness = applyWaitingPeriodEffectToGoalUsefulness;
  global.getActiveBaseGoalVitalId = getActiveBaseGoalVitalId;
  global.Goals_setCurrentGoalInInfoPicture = setCurrentGoalInInfoPicture;
  global.Goals_serializeState = serializeState;
  global.Goals_applyState = applyState;
  global.Goals_clearAllLifeGoals = clearAllLifeGoals;
  global.Goals_ensureDefaultMeaningGoal = ensureDefaultMeaningGoal;
  global.Goals_findDefaultMeaningGoal = findDefaultMeaningGoal;
  global.Goals_isDefaultMeaningGoalId = isDefaultMeaningGoalId;
  global.Goals_getDefaultMeaningGoalId = getDefaultMeaningGoalId;
  global.GOAL_KIND_MEANING_DEFAULT = GOAL_KIND_MEANING_DEFAULT;
  global.GOALS_DEFAULT_MEANING_LABEL = GOALS_DEFAULT_MEANING_LABEL;
  global.Goals_ensureDefaultCryGoal = ensureDefaultCryGoal;
  global.Goals_findDefaultCryGoal = findDefaultCryGoal;
  global.Goals_getDefaultCryGoalId = getDefaultCryGoalId;
  global.Goals_isDefaultCryGoalId = isDefaultCryGoalId;
  global.GOAL_KIND_CRY_DEFAULT = GOAL_KIND_CRY_DEFAULT;
  global.GOALS_DEFAULT_CRY_LABEL = GOALS_DEFAULT_CRY_LABEL;
})(typeof window !== 'undefined' ? window : globalThis);