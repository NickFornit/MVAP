# Hippocampus and orientation reflex (_8_Hippocampus)

## Purpose

The module combines **working stimulus memory** (hippocampus) and the **orientation reflex (OR)** — competition among active stimuli and choice of the most salient. OR starts consciousness, episodic memory, and reflex blocking for 2 pulses; EP frame creation and CR formation depend on OR conditions.

## Hippocampus (hippocampus.js)

- **active_stimulsArr_ID** — FinalImageIds that triggered OR.
- **actual_stimul_ID** — most salient stimulus (image id). Set in Hippocampus_holdStimulusFromOR(winnerId) from OR.

## Orientation reflex (orientation_reflex.js)

- **Run conditions:** active stimuli exist, perception tree has terminal node, competition winner found, winner **samplesCount >= OR_well_known** (default 10). Otherwise OR does not create EP frame; in test mode a reject reason is shown.
- UI OR readiness on buttons uses the same `OR_well_known` (remaining activations = `max(0, OR_well_known - samplesCount)`).
- **Salience** = novelty × importance; hysteresis for previous winner (stronger with `ImportantProblem`). During **EP answer wait**, activation is handled as operator answer (close frame, new frame for answer), then **second full OR pass** — again `stimuls_consciousness` and `save_episodic_memory` (see `about_episodic_memory_rules.md`, §4).
- **OR actions** on successful thresholds: reflex block 2 pulses (`setBlockedReflex`), `Hippocampus_holdStimulusFromOR`, **`stimuls_consciousness(orContext)`** (context marks OR winner), **`save_episodic_memory`** — regardless of test mode and existing semantic row.

Full EP rules and CR links: _10_Episodic_memory/about_episodic_memory_rules.md.

## Files

- **hippocampus.js** — active_stimulsArr_ID, actual_stimul_ID, holdStimulusFromOR.
- **orientation_reflex.js** — runOROnStimulusActivation, reject conditions, OR_well_known, EP wait checks, EP and consciousness calls.
