/**
 * Hippocampus: working memory of stimuli that triggered the orienting reflex.
 *
 * - active_stimulsArr_ID — array of held stimulus IDs (FinalImageId) that triggered the OR.
 * - actual_stimul_ID — global reference to the most salient stimulus (image / combination id).
 */
(function (global) {
  'use strict';

  /** Working memory: FinalImageIds of stimuli that triggered the OR. */
  if (!Array.isArray(global.active_stimulsArr_ID)) {
    global.active_stimulsArr_ID = [];
  }

  /** Most salient stimulus (FinalImageId). Set on OR. */
  if (typeof global.actual_stimul_ID !== 'number') {
    global.actual_stimul_ID = 0;
  }

  /**
   * Hold stimulus that triggered OR (push to active_stimulsArr_ID and set actual_stimul_ID).
   * @param {number} finalImageId — FinalImageId of the salient stimulus.
   */
  function holdStimulusFromOR(finalImageId) {
    if (typeof finalImageId !== 'number' || finalImageId <= 0) return;
    if (global.active_stimulsArr_ID.indexOf(finalImageId) === -1) {
      global.active_stimulsArr_ID.push(finalImageId);
    }
    global.actual_stimul_ID = finalImageId;
  }

  global.Hippocampus_holdStimulusFromOR = holdStimulusFromOR;
})(window);
