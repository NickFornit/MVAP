/**
 * Orienting reflex (OR) — competition among active stimuli.
 *
 * OR start condition: ID of the terminal node of the active perception tree branch
 * (perception condition tree, not only baseline + emotion).
 *
 * Algorithm:
 * - Salience = novelty × stimulus significance.
 * - If no semantic significance for these conditions:
 *   significance = (VitalsArr.importance)/20, novelty = 1.
 * - Novelty when significance exists: N = (SI * samplesCount) / 10 (SI = semantic importance).
 * - Novelty multipliers when tree levels missing: no 6th → N*=2, no 5th → N*=3, 4th → *4, etc.
 *
 * OR actions:
 * 1. Hysteresis: lower salience of other stimuli (subtract constant).
 *    Stimuli from a connected EM frame chain (suffix with reaction on each frame) skip hysteresis
 *    and get salience boost — see EpisodicMemory_getChainPriorityStimulusSet, about_episodic_memory_rules.md.
 * 2. Block genetic/conditioned reflex for 2 pulses (decision delay).
 * 3. Hippocampus: hold stimulus in memory (active_stimulsArr_ID, actual_stimul_ID).
 * 4. Awareness: call stimuls_consciousness(actual_stimul_ID).
 * 5. Episodic memory: call save_episodic_memory().
 */
(function (global) {
  'use strict';

  /** OR hysteresis constant: subtracted from salience of other stimuli (tuned in optimization). */
  var OR_HYSTERESIS = 0.5;

  /** Reflex blocked for this many pulses after OR. */
  var OR_BLOCK_PULSES = 2;

  /** “Well known” experience threshold: if samplesCount < OR_well_known, stimulus does not trigger OR or enter EM. Tuned in optimization. */
  var OR_well_known = 10;
  global.OR_well_known = OR_well_known;

  /** Block store: { key: string (finalImageId or stimId), untilPulse: number, actionId?: number } */
  var reflexBlockedUntil = [];

  /**
   * Current perception tree path: [baseID, emotionID, 0, 0, 0, 0].
   * baseID = BadNormWell, emotionID = Emotions_getOrCreateEmotionId(BasicContextsActived).
   */
  function getCurrentTreePath() {
    var baseID = global.BadNormWell || 0;
    var emotionID = 0;
    if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
      emotionID = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
    }
    return [baseID, emotionID, 0, 0, 0, 0];
  }

  /**
   * Get semantic significance object for (well, emotionId, finalImageId).
   * @returns {{ meanImportance: number, samplesCount: number } | null}
   */
  function getSemanticForConditions(finalImageId, well, emotionId) {
    if (!finalImageId || !well || !global.SemanticMemoryIndex) return null;
    var wKey = String(well);
    var eKey = String(emotionId);
    var bucket = global.SemanticMemoryIndex[wKey] && global.SemanticMemoryIndex[wKey][eKey];
    if (!bucket) return null;
    var obj = bucket[String(finalImageId)];
    if (!obj) return null;
    return {
      meanImportance: obj.meanImportance || 0,
      samplesCount: obj.samplesCount || 0
    };
  }

  /**
   * Experience readiness (OR_well_known threshold) for a FinalImageId.
   * Returns remaining “activations” until threshold (max(0, wellKnown - samplesCount)).
   * In Bad state actual OR start is not blocked by threshold (see runOROnStimulusActivation), but for UI
   * remainder uses semantics like Normal/Good.
   *
   * @param {number} finalImageId
   * @returns {{remainingActivations:number, samplesCount:number, wellKnown:number, well:number, emotionId:number}}
   */
  function getOrReadinessForFinalImageId(finalImageId) {
    var well = global.BadNormWell || 0;
    var wellKnown = (typeof global.OR_well_known === 'number' && global.OR_well_known >= 0) ? global.OR_well_known : OR_well_known;

    // If baseline not computed yet (BadNormWell=0) — maturity indicator cannot be computed.
    if (well !== 1 && well !== 2 && well !== 3) {
      return {
        remainingActivations: null,
        samplesCount: null,
        wellKnown: wellKnown,
        well: well,
        emotionId: null
      };
    }

    // In Bad, OR_well_known does not block actual OR start (see runOROnStimulusActivation),
    // but “experience readiness” for UI uses same formula as Normal/Good — else at well===1
    // all stimuli would show remaining=0 and all buttons look OR-ready.

    var emotionId = 0;
    if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
      emotionId = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
    }
    if (!emotionId) {
      return {
        remainingActivations: null,
        samplesCount: null,
        wellKnown: wellKnown,
        well: well,
        emotionId: 0
      };
    }

    var samplesCount = 0;
    if (finalImageId && well && emotionId) {
      var sem = getSemanticForConditions(finalImageId, well, emotionId);
      samplesCount = (sem && typeof sem.samplesCount === 'number') ? sem.samplesCount : 0;
    }

    var remaining = Math.max(0, wellKnown - samplesCount);
    return {
      remainingActivations: remaining,
      samplesCount: samplesCount,
      wellKnown: wellKnown,
      well: well,
      emotionId: emotionId
    };
  }

  /** Mean vital importance for significance when no semantic row (importance/20). */
  function getDefaultSignificanceFromVitals() {
    if (!Array.isArray(global.VitalsArr) || !global.VitalsArr.length) return 0.05;
    var sum = 0;
    for (var i = 0; i < global.VitalsArr.length; i++) {
      sum += (global.VitalsArr[i].importance || 0);
    }
    return (sum / global.VitalsArr.length) / 20;
  }

  /**
   * Novelty multiplier from missing tree node levels (pathArr — 6-element path).
   * No 6th level → *2, no 5th → *3, 4th → *4, 3rd → *5, 2nd → *6.
   */
  function noveltyLevelMultiplier(pathArr) {
    if (!Array.isArray(pathArr) || pathArr.length < 6) return 1;
    var m = 1;
    if (!pathArr[5]) m *= 2; // phraseID
    if (!pathArr[4]) m *= 3; // simbolID
    if (!pathArr[3]) m *= 4; // toneMoodID
    if (!pathArr[2]) m *= 5; // activityID
    if (!pathArr[1]) m *= 6; // emotionID
    return m;
  }

  /**
   * Compute stimulus novelty for these conditions.
   * If no SI: novelty = 1.
   * Else N = (SI * samplesCount) / 10, then N *= multiplier for missing levels.
   */
  function computeNovelty(finalImageId, well, emotionId, pathArr) {
    var sem = getSemanticForConditions(finalImageId, well, emotionId);
    var n;
    if (!sem || sem.samplesCount <= 0) {
      n = 1;
    } else {
      n = (sem.meanImportance * sem.samplesCount) / 10;
      if (n <= 0) n = 0.1;
    }
    n *= noveltyLevelMultiplier(pathArr || getCurrentTreePath());
    return n;
  }

  /**
   * Compute stimulus significance for these conditions.
   * If no SI row: (VitalsArr.importance)/20.
   */
  function computeSignificance(finalImageId, well, emotionId) {
    var sem = getSemanticForConditions(finalImageId, well, emotionId);
    if (!sem || sem.samplesCount <= 0) return getDefaultSignificanceFromVitals();
    return sem.meanImportance;
  }

  /**
   * Salience = novelty × significance.
   */
  function computeActuality(finalImageId, well, emotionId, pathArr) {
    var sig = computeSignificance(finalImageId, well, emotionId);
    var nov = computeNovelty(finalImageId, well, emotionId, pathArr);
    return nov * sig;
  }

  /**
   * Among candidates (finalImageId[]) pick most salient.
   * lastWinnerId — previous winner; others get hysteresis subtracted from salience.
   * Under ImportantProblem hysteresis is stronger (lowers other stimuli in competition).
   * Stimuli from connected EM chain (reaction on each suffix frame) skip hysteresis and
   * get salience boost — edge over stimuli that break the chain.
   * @returns {{ winnerId: number, actuality: number } | null}
   */
  function findMostActualStimulus(candidateFinalImageIds, lastWinnerId) {
    if (!candidateFinalImageIds || !candidateFinalImageIds.length) return null;
    var well = global.BadNormWell || 0;
    var emotionId = 0;
    if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
      emotionId = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
    }
    var pathArr = getCurrentTreePath();
    var importantProblem = !!(global.InfoPicture && global.InfoPicture.ImportantProblem);
    var hysteresis = importantProblem ? OR_HYSTERESIS * 2 : OR_HYSTERESIS;
    var chainSet = typeof global.EpisodicMemory_getChainPriorityStimulusSet === 'function'
      ? global.EpisodicMemory_getChainPriorityStimulusSet() : null;

    var bestId = null;
    var bestAct = -Infinity;
    for (var i = 0; i < candidateFinalImageIds.length; i++) {
      var fid = candidateFinalImageIds[i];
      if (fid == null || fid <= 0) continue;
      var inChain = !!(chainSet && chainSet[String(fid)]);
      var act = computeActuality(fid, well, emotionId, pathArr);
      if (inChain) {
        act = act * 2 + 1;
      } else if (lastWinnerId && lastWinnerId !== fid) {
        act -= hysteresis;
      }
      if (act > bestAct) {
        bestAct = act;
        bestId = fid;
      }
    }
    return bestId != null ? { winnerId: bestId, actuality: bestAct } : null;
  }

  /** Last competition winner (for hysteresis). */
  var lastORWinnerId = 0;

  /**
   * Block reflex for this image/stimulus for OR_BLOCK_PULSES pulses.
   */
  function setBlockedReflex(finalImageIdOrStimId, actionId) {
    var pulse = typeof global.Cur_puls_val === 'number' ? global.Cur_puls_val : 0;
    reflexBlockedUntil.push({
      key: String(finalImageIdOrStimId),
      actionId: actionId,
      untilPulse: pulse + OR_BLOCK_PULSES
    });
  }

  /**
   * Whether reflex is blocked for this image/stimulus and action (OR delays 2 pulses).
   */
  function isReflexBlockedByOR(finalImageIdOrStimId, actionId) {
    var pulse = typeof global.Cur_puls_val === 'number' ? global.Cur_puls_val : 0;
    for (var i = reflexBlockedUntil.length - 1; i >= 0; i--) {
      var b = reflexBlockedUntil[i];
      if (pulse >= b.untilPulse) {
        reflexBlockedUntil.splice(i, 1);
        continue;
      }
      if (b.key === String(finalImageIdOrStimId) && (actionId == null || b.actionId === actionId)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Stimulus detail by FinalImageId. stimulIds in FinalImages are global ids (type*1000+localId);
   * StimulusGlobalId_getName avoids name collisions across stimulus types.
   */
  /**
   * Active stimuli “Food” / “Water” (global ids 1001, 1002): bypass OR_well_known threshold
   * so OR, conscious channel, and genetic “Eats”/“Drinks” still run with weak semantics.
   */
  function activeIdsIncludeFoodOrWaterRelief(activeIds) {
    if (!activeIds || !activeIds.length) return false;
    for (var i = 0; i < activeIds.length; i++) {
      var g = activeIds[i];
      if (g === 1001 || g === 1002) return true;
      if (typeof global.StimulusGlobalId_fromGlobal === 'function') {
        var p = global.StimulusGlobalId_fromGlobal(g);
        if (p && p.type === 1 && (p.localId === 1 || p.localId === 2)) return true;
      }
    }
    return false;
  }

  function getStimulusDetailForAlert(finalImageId) {
    if (!finalImageId) return '';
    var stimulIds = null;
    if (Array.isArray(global.FinalImages)) {
      for (var i = 0; i < global.FinalImages.length; i++) {
        if (global.FinalImages[i] && global.FinalImages[i].id === finalImageId) {
          stimulIds = global.FinalImages[i].stimulIds;
          break;
        }
      }
    }
    if (!stimulIds || !stimulIds.length) return 'ID=' + finalImageId;
    var names = [];
    var getName = typeof global.StimulusGlobalId_getName === 'function' ? global.StimulusGlobalId_getName : null;
    for (var g = 0; g < stimulIds.length; g++) {
      var sid = stimulIds[g];
      var n = getName ? getName(sid) : '';
      if (n) names.push(n); else names.push('Id ' + sid);
    }
    return names.length ? names.join(', ') : 'ID=' + finalImageId;
  }

  /**
   * Run competition and OR on stimulus activation (e.g. click).
   * Call after active stimuli and FinalImage are updated.
   * Candidates: FinalImageId of full active set + one FinalImageId per active stimulus.
   */
  function runOROnStimulusActivation() {
    if (typeof global.FinalImages_getOrCreateFinalImageId !== 'function' ||
        typeof global.PerceptionTree_getOrCreateTerminalNode !== 'function') {
      if (global.EpisodicMemory_testMode && typeof global.show_alert === 'function') {
        global.show_alert('<b>Why EM process did not start:</b> perception tree or image functions unavailable. Orienting reflex not invoked. EM frame not created. Progress bar not started.', 0);
      }
      return false;
    }

    // Global stimulus ids (type*1000+localId) avoid name collisions across arrays (see stimulus_global_id.js).
    var activeIds = typeof global.StimulusGlobalId_getActiveGlobalIds === 'function'
      ? global.StimulusGlobalId_getActiveGlobalIds()
      : [];

    // Deactivating all stimuli is normal; EM frame already started on activation is not cancelled.
    if (!activeIds.length) {
      // No active stimuli — reset stimulus detector on info picture.
      if (typeof global.Info_updateFromStimulus === 'function') {
        global.Info_updateFromStimulus(0, 'external');
      }
      if (typeof global.InfoDet_updateConsoleStimulus === 'function') {
        global.InfoDet_updateConsoleStimulus(0);
      }
      return false;
    }

    var fullId = global.FinalImages_getOrCreateFinalImageId(activeIds);
    var pathArr = getCurrentTreePath();
    // Terminal node must match processGeneticReflexes (getActiveTerminalNodeId) or branchId won’t match when clearing delayed reflex.
    var terminalNodeId = typeof global.PerceptionTree_getActiveTerminalNodeId === 'function'
      ? global.PerceptionTree_getActiveTerminalNodeId()
      : global.PerceptionTree_getOrCreateTerminalNode(pathArr);
    if (!terminalNodeId) {
      // EM formation must not block semantic accounting — register exposure even on early exit.
      var wellEarly = global.BadNormWell || 0;
      var emotionIdEarly = 0;
      if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
        emotionIdEarly = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
      }
      if (wellEarly && emotionIdEarly && fullId && typeof global.registerSemanticSample === 'function' && typeof global.getDiffImportance === 'function') {
        var zEarly = global.getDiffImportance();
        if (typeof zEarly === 'number' && !isNaN(zEarly)) global.registerSemanticSample(fullId, emotionIdEarly, zEarly);
      }
      if (global.EpisodicMemory_testMode && typeof global.show_alert === 'function') {
        var det = getStimulusDetailForAlert(fullId);
        global.show_alert('<b>Stimulus:</b> ' + (det || 'ID=' + fullId) + '.<br><b>Why EM process did not start:</b> perception tree branch not found or not created. Orienting reflex not invoked. EM frame not created. Waiting-period progress bar not started.', 0);
      }
      return true;
    }

    // Update info picture: current branch and stimulus.
    if (typeof global.Info_updateFromPerceptionTree === 'function') {
      global.Info_updateFromPerceptionTree();
    }
    if (typeof global.Info_updateFromStimulus === 'function') {
      global.Info_updateFromStimulus(fullId, 'external');
    }
    if (typeof global.Info_thinkingFlash === 'function') {
      global.Info_thinkingFlash();
    }

    var candidates = [];
    if (fullId) candidates.push(fullId);
    for (var j = 0; j < activeIds.length; j++) {
      var oneGlobalId = activeIds[j];
      var oneId = global.FinalImages_getOrCreateFinalImageId([oneGlobalId]);
      if (oneId && candidates.indexOf(oneId) === -1) candidates.push(oneId);
    }

    var result = findMostActualStimulus(candidates, lastORWinnerId);
    if (!result) {
      var wellNoRes = global.BadNormWell || 0;
      var emotionIdNoRes = 0;
      if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
        emotionIdNoRes = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
      }
      if (wellNoRes && emotionIdNoRes && fullId && typeof global.registerSemanticSample === 'function' && typeof global.getDiffImportance === 'function') {
        var zNoRes = global.getDiffImportance();
        if (typeof zNoRes === 'number' && !isNaN(zNoRes)) global.registerSemanticSample(fullId, emotionIdNoRes, zNoRes);
      }
      if (global.EpisodicMemory_testMode && typeof global.show_alert === 'function') {
        var det2 = getStimulusDetailForAlert(fullId);
        global.show_alert('<b>Stimulus:</b> ' + (det2 || 'ID=' + fullId) + '.<br><b>Why EM process did not start:</b> no most salient stimulus among candidates. Orienting reflex not invoked. EM frame not created. Waiting-period progress bar not started.', 0);
      }
      return false;
    }

    var winnerId = result.winnerId;
    if (activeIds.length === 1 && fullId) {
      winnerId = fullId;
    }

    var well = global.BadNormWell || 0;
    var emotionId = 0;
    if (typeof global.Emotions_getOrCreateEmotionId === 'function' && Array.isArray(global.BasicContextsActived)) {
      emotionId = global.Emotions_getOrCreateEmotionId(global.BasicContextsActived) || 0;
    }
    var semWinner = getSemanticForConditions(winnerId, well, emotionId);
    var samplesCount = (semWinner && typeof semWinner.samplesCount === 'number') ? semWinner.samplesCount : 0;
    var wellKnown = (typeof global.OR_well_known === 'number' && global.OR_well_known >= 0) ? global.OR_well_known : OR_well_known;

    // Register stimulus exposure on each activation, else samplesCount only grows on reflex fire
    // (e.g. “Singing” without reflex would never increment).
    if (well && emotionId && typeof global.registerSemanticSample === 'function' && typeof global.getDiffImportance === 'function') {
      var z = global.getDiffImportance();
      if (typeof z === 'number' && !isNaN(z)) {
        global.registerSemanticSample(winnerId, emotionId, z);
      }
    }
    // Refresh count after registration (could be 0 before first registerSemanticSample).
    semWinner = getSemanticForConditions(winnerId, well, emotionId);
    samplesCount = (semWinner && typeof semWinner.samplesCount === 'number') ? semWinner.samplesCount : 0;

    // Second OR pass: after closing frame on response stimulus — full orienting reflex and new conscious cycle (no shortened wait branch).
    var resumeFullOr = !!global.OrientationReflex_resumeFullOrAfterWaitingResponse;
    if (resumeFullOr) {
      global.OrientationReflex_resumeFullOrAfterWaitingResponse = false;
      if (typeof global.Consciousness_getMainCycle === 'function' && typeof global.Consciousness_cycleAppendLog === 'function') {
        var orMain = global.Consciousness_getMainCycle();
        if (orMain && orMain.isMainCycle) {
          global.Consciousness_cycleAppendLog(orMain, 'OR: second full pass after operator answer during EM waiting period.', typeof global.cpuls === 'number' ? global.cpuls : 0);
        }
      }
    }

    // First check waiting period: response stimulus does not need familiarity threshold (OR_well_known).
    if (!resumeFullOr && typeof global.EpisodicMemory_isInWaitingPeriod === 'function' && global.EpisodicMemory_isInWaitingPeriod()) {
      if (typeof global.EpisodicMemory_closeLastFrameWithResponse === 'function') {
        global.EpisodicMemory_closeLastFrameWithResponse(winnerId);
      }
      // Operator answer received — “ignoring” mode cleared and answer detector updated.
      if (typeof global.InfoDet_updateOperatorIgnoring === 'function') {
        global.InfoDet_updateOperatorIgnoring(false);
      }
      if (typeof global.InfoDet_updateOperatorAnswer === 'function') {
        global.InfoDet_updateOperatorAnswer(true);
      }
      global.EpisodicMemory_skipConditionalReflexFormation = true;
      global.actual_stimul_ID = winnerId;
      var branchIdResponse = (typeof global.PerceptionTree_getActiveTerminalNodeId === 'function')
        ? global.PerceptionTree_getActiveTerminalNodeId() : 0;
      // EM chain: open new frame on response stimulus, then unconditional second OR pass —
      // full path (hippocampus, orContext, stimuls_consciousness, save_episodic), new consciousness cycle.
      if (typeof global.save_episodic_memory === 'function' && branchIdResponse) {
        global.save_episodic_memory(branchIdResponse, winnerId);
      }
      global.OrientationReflex_resumeFullOrAfterWaitingResponse = true;
      if (typeof global.Consciousness_getMainCycle === 'function' && typeof global.Consciousness_cycleAppendLog === 'function') {
        var orM2 = global.Consciousness_getMainCycle();
        if (orM2 && orM2.isMainCycle) {
          global.Consciousness_cycleAppendLog(orM2, 'OR: answer during wait — EM frame opened, repeat full OR scheduled.', typeof global.cpuls === 'number' ? global.cpuls : 0);
        }
      }
      return runOROnStimulusActivation();
    }

    // Familiarity threshold only for starting new OR/EM process (not response stimulus in waiting period).
    // In Bad (well === 1) skip threshold: always run OR and conscious channel, else sharp worsening
    // (e.g. “Punish” button) would not start a new cycle due to low samplesCount for (Bad, emotion, stimulus).
    // Second pass after wait answer (resumeFullOr) also bypasses threshold — need full OR and new conscious cycle.
    var skipWellKnownInBadState = (well === 1);
    var skipWellKnownFoodWater = activeIdsIncludeFoodOrWaterRelief(activeIds);
    if (!resumeFullOr && !skipWellKnownInBadState && !skipWellKnownFoodWater && samplesCount < wellKnown) {
      if (global.EpisodicMemory_testMode && typeof global.show_alert === 'function') {
        var detWeak = (activeIds.length === 1 && typeof global.StimulusGlobalId_getName === 'function')
          ? (global.StimulusGlobalId_getName(activeIds[0]) || getStimulusDetailForAlert(winnerId))
          : getStimulusDetailForAlert(winnerId);
        global.show_alert('<b>Stimulus:</b> ' + (detWeak || 'ID=' + winnerId) + '.<br><b>Why EM process did not start:</b> semantic experience too weak (samplesCount=' + samplesCount + ' < ' + wellKnown + '). Orienting reflex not invoked. EM frame not created. Waiting-period progress bar not started.', 0);
      }
      return false;
    }

    lastORWinnerId = winnerId;
    global.actual_stimul_ID = winnerId;

    var hasSignificance = semWinner != null;

    if (typeof global.Hippocampus_holdStimulusFromOR === 'function') {
      global.Hippocampus_holdStimulusFromOR(winnerId);
    }

    setBlockedReflex(winnerId, undefined);
    if (typeof global.addBlockedReflexToQueue === 'function') {
      global.addBlockedReflexToQueue(terminalNodeId);
    }

    var activityID = (typeof global.FinalImages_getOrCreateFinalImageId === 'function' && activeIds && activeIds.length)
      ? (global.FinalImages_getOrCreateFinalImageId(activeIds) || 0) : 0;
    var pathArr2 = [well, emotionId, activityID, 0, 0, 0];
    var novelty = computeNovelty(winnerId, well, emotionId, pathArr2);
    var significance = computeSignificance(winnerId, well, emotionId);
    var orContext = {
      actual_stimul_ID: winnerId,
      branchId: terminalNodeId,
      novelty: novelty,
      significance: significance,
      samplesCount: samplesCount,
      pathArr: pathArr2,
      well: well,
      emotionId: emotionId,
      activityID: activityID,
      isResponseStimulus: false,
      /** Winner already chosen by OR competition — conscious channel must not cancel start with “thought silence” threshold. */
      orientationReflexWinner: true
    };
    if (typeof global.stimuls_consciousness === 'function') {
      global.stimuls_consciousness(orContext);
    }
    // EM frame and progress bar always when OR fires (if frame build started).
    // Test mode only affects step messages, not progress bar presence.
    if (typeof global.save_episodic_memory === 'function') {
      global.save_episodic_memory(terminalNodeId, winnerId);
      if (global.EpisodicMemory_testMode && typeof global.show_alert === 'function') {
        var detStart = getStimulusDetailForAlert(winnerId);
        global.show_alert('<b>Stimulus:</b> ' + (detStart || 'ID=' + winnerId) + '.<br><b>Result:</b> EM frame formation started. Waiting for answer or reaction. Waiting-period progress bar started.', 0);
      }
    }
    if (typeof global.PerceptionTree_updateActiveBranchView === 'function') {
      global.PerceptionTree_updateActiveBranchView();
    }
    return true;
  }

  global.OrientationReflex_runOnStimulusActivation = runOROnStimulusActivation;
  global.OrientationReflex_isReflexBlockedByOR = isReflexBlockedByOR;
  global.OrientationReflex_setBlockedReflex = setBlockedReflex;
  global.OrientationReflex_findMostActualStimulus = findMostActualStimulus;
  global.OrientationReflex_OR_HYSTERESIS = OR_HYSTERESIS;
  global.OrientationReflex_getOrReadinessForFinalImageId = getOrReadinessForFinalImageId;

  /**
   * Test button click counter: each call passes higher significance
   * so a new click always interrupts current cycle (threshold: currentThinkingImportance + 2).
   */
  var runTestNegativeInterruptCounter = 0;

  /**
   * Test interrupt of consciousness cycle. Creates cycle with small significance 5;
   * each further click raises significance (10, 15, 20…) so each click causes a new interrupt
   * (current main goes to background, new cycle created).
   * Not a stimulus — hard consciousness call to test dispatcher and background stack.
   */
  function runTestNegativeInterrupt() {
    runTestNegativeInterruptCounter += 1;
    var significance = 5 + (runTestNegativeInterruptCounter - 1) * 5;
    var branchId = (typeof global.PerceptionTree_getActiveTerminalNodeId === 'function')
      ? global.PerceptionTree_getActiveTerminalNodeId()
      : 0;
    var ctx = {
      actual_stimul_ID: 0,
      branchId: branchId,
      well: 1,              // Bad
      emotionId: 0,
      activityID: 0,
      significance: significance
    };
    if (typeof global.stimuls_consciousness === 'function') {
      global.stimuls_consciousness(ctx);
    }
  }

  global.runTestNegativeInterrupt = runTestNegativeInterrupt;
})(window);
