# Perception condition tree (_7_perception_tree)

## Purpose

The module implements the **perception condition tree** — a six-level hierarchy for the current “branch.” Nodes are used by the orientation reflex, episodic memory (perceptionNodeId in frames), and future richer reflex/automatism logic.

## Levels

1. **BaseID** — baseline (1=Bad, 2=Norm, 3=Well).
2. **EmotionID** — emotion (combination of active basic contexts).
3. **ActivityID** — image id from FinalImages (active stimuli), not button id.
4. **ToneMoodID** — tone/mood (unused here; verbal input and verbal trees are out of scope).
5. **SimbolID** — first symbol of first phrase (unused).
6. **PhraseID** — recognized phrase id (unused).

The active branch uses levels 1–3 (BaseID, EmotionID, ActivityID). Levels 4–6 remain in the structure for theory compatibility and may stay 0 or serve other non-verbal uses later.

Full path of six ids enables fast node lookup (pathIndex); nodeId recovers full path.

## Persistence and UI

- Compact format: one string per node — `ID|ParentNode|BaseID|EmotionID|ActivityID|ToneMoodID|SimbolID|PhraseID`. IndexedDB on pulse when changed; file on Save/Load.
- UI shows **active branch** (yellow block): BaseID → EmotionID → ActivityID, current stimulus, last 10 EP frames, EP wait progress, copy and EP test buttons.

## Files

- **perception_tree.js** — nodes, pathIndex, getOrCreateTerminalNode, active branch view, stimulus/action names for EP, tree save/load.

Tree updates on pulse; terminal node for path (baseID, emotionID, activityID, 0, 0, 0) is passed to OR and save_episodic_memory.
