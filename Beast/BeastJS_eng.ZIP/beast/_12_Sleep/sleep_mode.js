/**
 * Sleep mode — single source of truth for UI and basic context.
 *
 * Behavior:
 * - On: “Sleep” button (basic_contexts_ui) or auto when ConsciousnessFinCyclesTotal > 100 (see tryAutoAfterFinCycles).
 * - While sleepActive: prepare.getActiveBasicContexts forces only SleepMode_CONTEXT_ID (suppresses Norm/critique on vitals).
 * - Stimuli: almost all blocked; only pairs in allowedKeys (Punishment, Howl, Siren, Growl, Fire) — see refreshStimulusButtonVisuals.
 * - Off: toggle, SleepMode_exit(), or first click on an allowed stimulus (stimuls_ui calls exit without flag).
 * - Normal dream completion: sleep_dream_process calls SleepMode_exit(true) → after wake, background FO cycles removed (Consciousness_deleteAllBackgroundCycles).
 *
 * Dreams: dreams.js → sleep_dream_process.js (queue of empty EP frames, passive cycle, frame realization).
 */
(function (global) {
  'use strict';

  var SLEEP_CONTEXT_ID = 15;
  var FIN_CYCLE_AUTO_THRESHOLD = 100;

  var ROW_IDS = ['stimulsRow', 'stimulsRowPositiv', 'stimulsRowNegative', 'stimulsRowNeutral'];

  /** Allowed in sleep: motivation “Punishment”; negative: Howl, Siren, Growl, Fire. */
  var allowedKeys = {
    'stimulsRow|8': true,
    'stimulsRowNegative|8': true,
    'stimulsRowNegative|10': true,
    'stimulsRowNegative|13': true,
    'stimulsRowNegative|20': true
  };

  function rowKey(rowId, stimId) {
    return String(rowId) + '|' + String(stimId);
  }

  function isStimulusAllowedInSleep(rowId, localStimId) {
    return !!allowedKeys[rowKey(rowId, localStimId)];
  }

  var sleepActive = false;
  /** true if last sleep entry was from fin-cycle counter (UI hint). */
  var sleepFromAuto = false;

  function isActive() {
    return sleepActive;
  }

  /** sleep-mode class on html/body — page background (align with vitals_ui and SleepMode_PAGE_BACKGROUND). */
  function applySleepPageBackground() {
    var doc = global.document;
    if (!doc || !doc.body) return;
    if (sleepActive) {
      doc.documentElement.classList.add('sleep-mode');
      doc.body.classList.add('sleep-mode');
    } else {
      doc.documentElement.classList.remove('sleep-mode');
      doc.body.classList.remove('sleep-mode');
    }
  }

  function setSleepButtonVisual() {
    var btn = global.document.getElementById('sleepModeToggleBtn');
    if (!btn) return;
    if (sleepActive) {
      btn.style.backgroundColor = '#c8d8f0';
      btn.style.borderColor = '#6a7aac';
      btn.title = sleepFromAuto
        ? 'Sleep mode (auto after ' + FIN_CYCLE_AUTO_THRESHOLD + '+ fin cycles). Click to exit.'
        : 'Sleep mode on. Click to exit.';
    } else {
      btn.style.backgroundColor = '#f5f5f5';
      btn.style.borderColor = '#888';
      btn.title = 'Enable sleep mode (Sleep context only, limited stimuli)';
    }
  }

  /** Enter sleep: flags, views, stimuli, then dream chain (SleepDreams_onSleepEntered). */
  function enter(isAuto) {
    sleepActive = true;
    sleepFromAuto = !!isAuto;
    applySleepPageBackground();
    setSleepButtonVisual();
    if (typeof global.update_vitals_view === 'function') {
      global.update_vitals_view();
    }
    if (typeof global.update_basic_contexts_view === 'function') {
      global.update_basic_contexts_view();
    }
    if (typeof global.SleepMode_refreshStimulusButtonVisuals === 'function') {
      global.SleepMode_refreshStimulusButtonVisuals();
    }
    if (typeof global.SleepDreams_onSleepEntered === 'function') {
      global.SleepDreams_onSleepEntered(!!isAuto);
    }
  }

  /**
   * @param {boolean} [normalDreamCompletion] — only if sleep_dream_process finished reconstruction limit:
   *   then Consciousness_deleteAllBackgroundCycles (wake after “normal” sleep). Otherwise plain exit (button, stimulus).
   */
  function exit(normalDreamCompletion) {
    sleepActive = false;
    sleepFromAuto = false;
    applySleepPageBackground();
    setSleepButtonVisual();
    if (typeof global.update_vitals_view === 'function') {
      global.update_vitals_view();
    }
    if (typeof global.update_basic_contexts_view === 'function') {
      global.update_basic_contexts_view();
    }
    if (typeof global.SleepMode_refreshStimulusButtonVisuals === 'function') {
      global.SleepMode_refreshStimulusButtonVisuals();
    }
    if (typeof global.SleepDreams_onSleepExited === 'function') {
      global.SleepDreams_onSleepExited();
    }
    // Background cycles only when dreams complete, not on manual wake.
    if (normalDreamCompletion && typeof global.Consciousness_deleteAllBackgroundCycles === 'function') {
      global.Consciousness_deleteAllBackgroundCycles();
    }
  }

  /** Manual toggle from Sleep button; exit without normalDreamCompletion — do not touch background cycles. */
  function toggle() {
    if (sleepActive) {
      exit();
    } else {
      enter(false);
    }
  }

  /** Auto-enter from fin-cycle counter only (does not duplicate enter if already asleep). */
  function enterAuto() {
    if (sleepActive) return;
    enter(true);
  }

  /**
   * “Fin” cycle counter: main cycle marked expired (stagnation) or finished with status finished.
   */
  function tryAutoAfterFinCycles() {
    var n = global.ConsciousnessFinCyclesTotal || 0;
    if (n > FIN_CYCLE_AUTO_THRESHOLD) {
      enterAuto();
    }
  }

  function shouldBlockStimulusInteraction(rowId, localStimId) {
    if (!sleepActive) return false;
    return !isStimulusAllowedInSleep(rowId, localStimId);
  }

  /**
   * When sleep active: disallowed buttons semi-transparent and non-clickable; allowed — light outline (delta border).
   * Called each pulse from puls.js and on sleep enter/exit.
   */
  function refreshStimulusButtonVisuals() {
    var doc = global.document;
    if (!doc) return;

    var i;
    var j;
    for (i = 0; i < ROW_IDS.length; i++) {
      var rid = ROW_IDS[i];
      var row = doc.getElementById(rid);
      if (!row) continue;
      var buttons = row.querySelectorAll('button');
      for (j = 0; j < buttons.length; j++) {
        var btn = buttons[j];
        btn.classList.remove('stimul-btn-sleep-locked');
        btn.classList.remove('stimul-btn-sleep-allowed');
        btn.style.outline = '';
        btn.style.opacity = '';
        btn.style.pointerEvents = '';
        btn.style.cursor = '';
      }
    }

    var lbls = doc.querySelectorAll('button[data-stim-row-clear]');
    for (i = 0; i < lbls.length; i++) {
      var cb = lbls[i];
      cb.classList.remove('stimul-btn-sleep-locked');
      cb.style.opacity = '';
      cb.style.pointerEvents = '';
      cb.style.cursor = '';
    }

    if (!sleepActive) return;

    for (i = 0; i < ROW_IDS.length; i++) {
      var rowId = ROW_IDS[i];
      var r = doc.getElementById(rowId);
      if (!r) continue;
      var btns = r.querySelectorAll('button');
      for (j = 0; j < btns.length; j++) {
        var b = btns[j];
        var sid = b.dataset.stimId;
        if (!sid) {
          b.classList.add('stimul-btn-sleep-locked');
          b.style.opacity = '0.42';
          b.style.pointerEvents = 'none';
          b.style.cursor = 'not-allowed';
          continue;
        }
        var idNum = parseInt(sid, 10);
        if (isStimulusAllowedInSleep(rowId, idNum)) {
          b.classList.add('stimul-btn-sleep-allowed');
          b.style.outline = '1px solid rgba(130, 150, 210, 0.55)';
          b.style.outlineOffset = '1px';
        } else {
          b.classList.add('stimul-btn-sleep-locked');
          b.style.opacity = '0.42';
          b.style.pointerEvents = 'none';
          b.style.cursor = 'not-allowed';
        }
      }
    }

    for (i = 0; i < lbls.length; i++) {
      var cbx = lbls[i];
      cbx.classList.add('stimul-btn-sleep-locked');
      cbx.style.opacity = '0.42';
      cbx.style.pointerEvents = 'none';
      cbx.style.cursor = 'not-allowed';
    }
  }

  /** Page background in sleep mode (see vitals_ui — inline .beast-root background overrode CSS). */
  global.SleepMode_PAGE_BACKGROUND = '#e8e8e8';

  global.SleepMode_CONTEXT_ID = SLEEP_CONTEXT_ID;
  global.SleepMode_isActive = isActive;
  global.SleepMode_exit = exit;
  global.SleepMode_toggle = toggle;
  global.SleepMode_enterAuto = enterAuto;
  global.SleepMode_tryAutoAfterFinCycles = tryAutoAfterFinCycles;
  global.SleepMode_shouldBlockStimulusInteraction = shouldBlockStimulusInteraction;
  global.SleepMode_refreshStimulusButtonVisuals = refreshStimulusButtonVisuals;
  global.SleepMode_setSleepButtonVisual = setSleepButtonVisual;

  if (typeof global.ConsciousnessFinCyclesTotal !== 'number') {
    global.ConsciousnessFinCyclesTotal = 0;
  }
})(window);
