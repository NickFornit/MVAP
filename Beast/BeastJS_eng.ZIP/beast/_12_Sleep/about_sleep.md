# Sleep mode and dreams (`_12_Sleep`)

The module **does not replace** the consciousness dispatcher or `info_fantasizming`: it sets **UI and basic-context behavior**, orchestrates **iteration over empty episodic frames**, and **realizes** a frame after passive fantasy.

Details in code: comments in `sleep_mode.js`, `sleep_dream_process.js`, `dreams.js`.

---

## Files

| File | Role |
|------|------|
| `sleep_mode.js` | Sleep active flag, Sleep button, auto-sleep by fin-cycle counter, stimulus limits, `SleepMode_exit(normalDreamCompletion)`. |
| `dreams.js` | Bridge: enter/exit/pulse hooks, global `SleepDreams_paleActivityBeast`. |
| `sleep_dream_process.js` | Empty EP frame queue, `idle` / `fantasy` phases, sleep main cycle (`thinkingMode: passive`), pulse/frame limits, `SleepMode_exit(true)`. |

Integration:

- `prepare.js` — when sleep active, `getActiveBasicContexts` forces only **`SleepMode_CONTEXT_ID`** (15), regardless of vitals.
- `stimuls_ui.js` — allowed stimuli first call `SleepMode_exit()` (no arg), then normal handling.
- `puls.js` — **`SleepDreams_onPulse`** runs **before** `dispetchConsciousnessThinking` so the same pulse steps the sleep main cycle (`info_fantasizming`).
- `episodic_memory.js` — `EpisodicMemory_isEmptyFrameForSleep`, `EpisodicMemory_collectEmptyFrameIndicesNewestFirst`.
- `consciousness_dispatcher.js` — `Consciousness_deleteAllBackgroundCycles` only after **`SleepMode_exit(true)`** (normal dream completion).

---

## Entering sleep

1. **Manual** — Sleep button in basic-context row (`basic_contexts_ui.js`, before round B), `SleepMode_toggle` → `enter(false)`.
2. **Auto** — when **`ConsciousnessFinCyclesTotal > 100`** (`sleep_mode.js`: `SleepMode_tryAutoAfterFinCycles` from dispatcher `notifyFinCycleCompleted`). Sleep can occur even with critical vitals because contexts are overridden.

---

## Leaving sleep

| Method | `SleepMode_exit` | Background consciousness cycles |
|--------|------------------|--------------------------------|
| Sleep button, allowed stimulus | no argument | **not** removed |
| Dream reconstructed-frame limit (20) | `exit(true)` | **`Consciousness_deleteAllBackgroundCycles`** |

---

## Stimuli in sleep mode

All stimulus buttons blocked except agreed **row + local id** pairs (Punishment, Howl, Siren, Growl, Fire — see `allowedKeys` in `sleep_mode.js`). Allowed buttons get light outline; others faded and non-clickable. Row clear buttons blocked.

---

## Dreams (algorithm)

1. **Empty EP frame** — has `stimulusImageId` and `actionImageId`, no response stimulus and no numeric `effect` (`EpisodicMemory_isEmptyFrameForSleep`).
2. Index queue **newest to oldest**; session-processed indices excluded (`processedSet`).
3. Per frame: previous main cycle pushed to interrupt stack; new **main** cycle with `thinkingMode === 'passive'`, context marked `sleepDream`. Fantasy steps — same **`info_fantasizming`** as normal passive (see `about_passive_fantasizming.md`).
4. After **N pulses** (`MAX_PULSES_PER_FANTASY`) — **realization**: from `fantazmingPlot.chain` pick continuation with max **|effect|**; if no source in `Episodes` — fallback `getFramesByResponseStimulus` + `pickBestFrameByAbsEffect`; then `AbstractImages_cloneFromEpisodeFrame`, `EpisodicMemory_markDirty`.
5. Reconstruction counter; at limit — **`SleepMode_exit(true)`**.

**Passive semantics** (`PassiveMode_processUnderstandingModels`) on pulse runs for main passive cycle in sleep as in normal passive.

---

## Visuals

- **`sleep-mode`** class on `html`/`body`, page background aligned with `vitals_ui` and `SleepMode_PAGE_BACKGROUND`.
- During sleep fantasy phase, **`SleepDreams_paleActivityBeast`** grays out “Beast activity” (`genetic_reflexes_engine.js`, `mental_automatism.js`).

---

## Script order

`sleep_mode.js` and `dreams.js` — near basic contexts; **`sleep_dream_process.js`** — **after** `episodic_memory.js` and **`fantasizming.js`** (see `index.html` comment).

---

## See also

- `beast/_9_Conscience/about_passive_fantasizming.md` — passive mode and `info_fantasizming`.
- `beast/about_global_variables.md` — Sleep section.
- `manuals/Mad_programmer_manual.md` — developer overview.
