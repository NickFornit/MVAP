/**
 * Bridge sleep_mode ↔ sleep_dream_process: sleep lifecycle hooks and global flag for pale “Beast activity”.
 * Wiring: sleep_mode enter/exit/onPulse; index.html loads sleep_dream_process.js before puls calls.
 */
(function (global) {
  'use strict';

  /** true during sleep fantasy phase — genetic_reflexes_engine / mental_automatism lighten automatism output. */
  if (typeof global.SleepDreams_paleActivityBeast !== 'boolean') {
    global.SleepDreams_paleActivityBeast = false;
  }

  function onSleepEntered(fromAuto) {
    if (typeof global.SleepDreamProcess_onSleepEntered === 'function') {
      global.SleepDreamProcess_onSleepEntered();
    }
    if (typeof global.console !== 'undefined' && global.console.log) {
      global.console.log('SleepDreams: sleep', fromAuto ? '(auto)' : '(manual)');
    }
  }

  function onSleepExited() {
    if (typeof global.SleepDreamProcess_onSleepExited === 'function') {
      global.SleepDreamProcess_onSleepExited();
    }
    global.SleepDreams_paleActivityBeast = false;
    if (typeof global.console !== 'undefined' && global.console.log) {
      global.console.log('SleepDreams: wake');
    }
  }

  function onPulse(pulsCount) {
    if (typeof global.SleepDreamProcess_onPulse === 'function') {
      global.SleepDreamProcess_onPulse(pulsCount);
    }
  }

  global.SleepDreams_onSleepEntered = onSleepEntered;
  global.SleepDreams_onSleepExited = onSleepExited;
  global.SleepDreams_onPulse = onPulse;
})(window);
