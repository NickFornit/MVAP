# Beast global variables reference

Variables and objects declared in code as `window.*` or `global.*` (in the browser `window` is usually `global`). Grouped by role and module.

---

## Pulse and time

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **Cur_puls_val** | number | Pulse counter. Incremented in sep_of_puls(); stored in localStorage. | puls.js, saving_ui.js |
| **PrevDiffForEpisode** | number | `getDiffImportance()` at pulse start (before stimulus activation). For EP frame `effect`. | puls.js |
| **update_beast_pulse_view** | function | Updates pulse display in UI. | puls.js |

---

## Vitals and organism state (_1_Genetic_vitals, _2_Genetic_basic_styles)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **VitalsArr** | Array | Vitals: { Id, value, importance, shift, name, title }. value 0..100. | vitals.js |
| **VitalsArrDefaults** | Array | Copy of default vitals for reset. | vitals.js |
| **BadVitalsValue** | Object | How far vitals deviate from norm (id → value). | vitals.js |
| **BadNormWell** | number | Baseline state: 1=Bad, 2=Norm, 3=Well. | vitals.js, BasicContexts.js, prepare.js |
| **IntergalConditionImportance** | number | Integral importance of organism state. | vitals.js, BasicContexts.js, prepare.js |
| **IntergalConditionImportanceOld** | number | Previous integral importance. | vitals.js, BasicContexts.js |
| **DiffZnacher** | number | Importance differentiator. | vitals.js, BasicContexts.js, prepare.js |
| **isShockState** | boolean | Shock mode. | vitals.js, vitals_ui.js, vitals_prepare.js |
| **DeathSequenceStarted** | boolean | Whether “death” sequence started. | vitals_ui.js, vitals_prepare.js |
| **IsSpeeping** | boolean | Sleep mode. | vitals.js |
| **isGameMode** | boolean | Play mode (vitalID 11). | vitals.js, stimuls_ui.js |
| **isAuthoritarianEducation** | boolean | Teach mode (vitalID 12). | vitals.js, stimuls_ui.js |
| **WellHoldRemainingPulses** | number | Pulses left holding Well. | prepare.js |
| **BadHoldRemainingPulses** | number | Pulses left holding Bad. | prepare.js |
| **NormHoldRemainingPulses** | number | Pulses left holding Norm (explicit hold, SetNormForHolding / info_setBadNormWellForHolding(2)). | prepare.js |
| **ContextHoldRemainingPulses** | number | Pulses left holding a context. | prepare.js |
| **WellBadEffectManual** | number | Manual Well/Bad influence on diff (default 5). | prepare.js |
| **saveVitalsToStorage** | function | Save vitals (localStorage/IndexedDB). | vitals_prepare.js |
| **performSensorOperations** | function | “Sensor” ops on vitals. | vitals_prepare.js |
| **update_vitals_view** | function | Update vitals UI. | vitals_ui.js |
| **resetVitalsToDefaults** | function | Reset vitals to defaults. | vitals_ui.js |
| **startDeathSequence** | function | Start death sequence. | vitals_ui.js |

---

## Basic contexts (_2_Genetic_basic_styles)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **BasicContexts** | Array | Basic contexts (Ventilation, Drinking, Fear, Aggression, Calm, etc.). | BasicContexts.js |
| **VitalsContextsActivingArr** | Object | Map “vital out of norm” → array of context IDs to activate. | BasicContexts.js |
| **BasicContextsActived** | Array | IDs of currently active basic contexts. | BasicContexts.js |
| **getActiveBasicContexts** | function | Get/recompute active contexts. | basic_contexts_ui.js / prepare |
| **update_basic_contexts_view** | function | Update context UI. | basic_contexts_ui.js |
| **ActivateBasicContextsForHolding** | function | Force basic contexts for hold duration (as many pulses as `state_retention_period` in prepare.js). | prepare.js |
| **SetWellForHolding** / **SetBadForHolding** / **SetNormForHolding** | function | Hold Well (3) / Bad (1) / Norm (2); mutually clear each other’s counters. | prepare.js |

---

## Stimuli (_3_perception)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **StimulMotivarion** | Array | Motivating stimuli (Food, Water, Reward, Pleasant, Play…). | stimuls.js |
| **ActiveMotivationStimuls** | Array | Active motivating stimulus IDs. | stimuls.js, stimuls_ui.js |
| **StimulPositiv** | Array | Positive stimuli. | stimuls.js |
| **StimulNegative** | Array | Negative stimuli. | stimuls.js |
| **StimulNeutral** | Array | Neutral stimuli. | stimuls.js |
| **ActivePositivStimuls** | Array | Active positive IDs. | stimuls_ui.js (init) |
| **ActiveNegativeStimuls** | Array | Active negative IDs. | stimuls_ui.js (init) |
| **ActiveNeutralStimuls** | Array | Active neutral IDs. | stimuls_ui.js (init) |
| **OrientationReflex_runOnStimulusActivation** | function | Run OR when stimulus set changes (called from UI after click). | orientation_reflex.js |

---

## Actions (_4_actions)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **BasicActions** | Array | Basic actions (Cries, Eats, Smiles…). | effectors.js |
| **BasicVerbal** | Array | Basic “sounds” (vowels, syllables…). | effectors.js |
| **BasicMirrorActions** | Array | Operator mirror actions for EP: { Id, mirrorParentId "n_m", name }. | effectors.js |

---

## Genetic reflexes (_5_Genetic__reflexes)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **StimulMotivarion_EffectsToBContexts** | Object | Motivating stimuli → basic contexts. | genetic_reflexes.js |
| **StimulPositiv_EffectsToBContexts** | Object | Positive stimuli → contexts. | genetic_reflexes.js |
| **StimulNegative_EffectsToBContexts** | Object | Negative stimuli → contexts. | genetic_reflexes.js |
| **StimulMotivarion_GeneticReflexes** | Object | Stimulus (id) → array of actionId. | genetic_reflexes.js |
| **StimulPositiv_GeneticReflexes** | Object | Same for positive. | genetic_reflexes.js |
| **StimulNegative_GeneticReflexes** | Object | Same for negative. | genetic_reflexes.js |
| **ActionProlongator** | Array | Prolonged actions (eating, drinking, etc.): vitalID, shift. | genetic_reflexes.js |
| **processGeneticReflexes** | function | Reflex processing each pulse. | genetic_reflexes_engine.js |
| **runGeneticActionFromSynonymReflex** | function | Run action from conditional reflex. | genetic_reflexes_engine.js |
| **setBeastActivityText** | function | Set “Beast activity” block text. | genetic_reflexes_engine.js |

---

## Conditional reflexes (_5_2_synonyms_reflexes)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **SynonymReflexes** | Array | Conditional (synonym) reflexes. | synonyms_reflexes.js |
| **NextSynonymReflexId** | number | ID counter for new reflexes. | synonyms_reflexes.js |
| **synonyms_onGeneticActionFired** | function | Called when genetic reflex fires (form/strengthen conditional). | synonyms_reflexes.js |
| **synonyms_tryRunReflexes** | function | Try conditional reflexes for current stimuli and context. | synonyms_reflexes.js |
| **serializeConditionalReflexesState** / **applyConditionalReflexesState** | function | Serialize/restore CR state. | synonyms_reflexes.js |
| **clearAllConditionalReflexes** | function | Clear all conditional reflexes. | synonyms_reflexes.js |
| **get_cur_context_for_synonyms** | function | Current context for conditional reflexes. | synonyms_reflexes.js |

---

## Semantic memory and images (_6_semantic_memory)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **FinalImages** | Array | Perception images: { id, stimulIds }. | FinalImage.js |
| **KnownFinalImageIds** | Array | Known image IDs (for semantics). | semantic_memory.js |
| **FinalImages_findFinalImageId** | function | Find id by stimulIds array. | FinalImage.js |
| **FinalImages_getOrCreateFinalImageId** | function | Get or create image id for stimulIds. | FinalImage.js |
| **Emotions** | Array | Emotions (context combinations). | Emotion.js |
| **KnownEmotionIds** | Array | Known emotion IDs. | semantic_memory.js |
| **Emotions_findEmotionId** / **Emotions_getOrCreateEmotionId** | function | Find/create emotion id by contexts. | Emotion.js |
| **SemanticMemory** | Array | Semantic importance records. | semantic_memory.js |
| **SemanticMemoryIndex** | Object | Index [well][emotionId][finalImageId] → { meanImportance, samplesCount }. | semantic_memory.js |
| **registerSemanticSample** | function | Register experience (z, conditions, finalImageId). | semantic_memory.js |
| **getSemanticObjectFast** | function | Fast index lookup (well, emotionId, finalImageId) → object or null. | semantic_memory.js |
| **getSemanticFramesForFinalImageId** | function | All frames for finalImageId via index. | semantic_memory.js |
| **getDiffImportance** | function | Integral state importance (semantics and EP). | vitals_prepare / prepare.js |
| **LastDiffImportanceRaw** | number \| null | Raw diff before `normalizeValue` in last `getDiffImportance()`; for “magnifier” in `registerSemanticSample`. | prepare.js |
| **serializeSemanticState** / **applySemanticState** | function | Serialize/restore semantics. | semantic_memory.js |
| **ImageUnderstandingModelArr** | Object | Image understanding models. | Understanding_model.js |
| **getImageUnderstandingModel** / **buildImageUnderstandingModel** | function | Get/build understanding model. | Understanding_model.js |

---

## Perception tree (_7_perception_tree)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **PerceptionTree_getOrCreateTerminalNode** | function | Get/create terminal node for path [baseID, emotionID, activityID, 0,0,0]. | perception_tree.js |
| **PerceptionTree_updateActiveBranchView** | function | Update “Active tree branch” block and EP frames in UI. | perception_tree.js |
| **PerceptionTree_getStimulusNamesForFinalImageId** | function | Stimulus names for FinalImageId. | perception_tree.js |
| **PerceptionTree_getActionNamesForActionImage** | function | Action names for action image id. | perception_tree.js |
| **PerceptionTree_serializeState** / **PerceptionTree_applyState** | function | Save/load tree. | perception_tree.js |
| **PerceptionTree_*** | (other) | addNode, findActiveBranch, getPathByNodeId, serializeCompact, etc. | perception_tree.js |

---

## Hippocampus and OR (_8_Hippocampus)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **active_stimulsArr_ID** | Array | FinalImageIds that triggered OR. | hippocampus.js |
| **actual_stimul_ID** | number | Most salient stimulus (image id). Set on OR. | hippocampus.js, orientation_reflex.js |
| **Hippocampus_holdStimulusFromOR** | function | Hold stimulus in memory after OR. | hippocampus.js |
| **OR_well_known** | number | samplesCount threshold for OR/EP (default 10). | orientation_reflex.js |
| **OrientationReflex_runOnStimulusActivation** | function | Run competition and OR on stimulus activation. | orientation_reflex.js |
| **OrientationReflex_isReflexBlockedByOR** | function | Whether reflex blocked by OR for 2 pulses. | orientation_reflex.js |
| **OrientationReflex_setBlockedReflex** | function | Block reflex by key. | orientation_reflex.js |

---

## Conscience (_9_Conscience)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **ConsciousnessCycles** | Object | Consciousness cycle registry: id → cycleInfo. Fields include … **createdThemeId**, **createdSituationId** — info-picture theme/situation at cycle creation; **expired**, **events[]**, `noInfoChangeStreak`; **fantasizmArr** (EP rule snapshots for background cycle), **fantasizmPassiveFillStarted**, etc. | consciousness_dispatcher.js |
| **ConsciousnessProcessNextId** | number | Counter for new cycle id. | consciousness_dispatcher.js |
| **ConsciousnessCurrentProcessId** | number | Current main (conscious) cycle id. UI: “Main cycle ID: nn”. | consciousness_dispatcher.js, conscious_attention_channel.js |
| **ConsciousnessBackgroundStack** | Array | Interrupt queue (up to 10): on interrupt, only current main id is pushed (LIFO). Cycle stays in registry as background. On main finish promoteFromBackgroundCycle() pops id and promotes; if finished, next id or weight pick. | conscious_attention_channel.js, consciousness_dispatcher.js |
| **Consciousness_createCycle** | function | Create cycle and register in ConsciousnessCycles. | consciousness_dispatcher.js |
| **Consciousness_setMainCycle** | function | Set cycle id as main (others isMainCycle = false). | consciousness_dispatcher.js |
| **Consciousness_getMainCycle** | function | Current main cycle (status === 'running'). | consciousness_dispatcher.js |
| **Consciousness_cancelProcess** | function | Cancel cycle (status = 'cancelled'). | consciousness_dispatcher.js |
| **Consciousness_runElementary** | function | Elementary consciousness pass (levels 1 and 2) for cycle context. On create and on stack promote. | conscious_attention_channel.js |
| **Consciousness_runOneStep** | function | One thinking step for dispatcher. If `cycle.thinkingMode === 'passive'` — `info_fantasizming` and return (no levels 3–4); else levels 3–4 via `conscience_level_3_runFromChannel` / `conscience_level_4_runFromChannel`. | conscious_attention_channel.js |
| **Consciousness_getMainCycleThinkingMode** | function | `'target'` \| `'passive'` — **main** cycle thinking mode (not a field on info picture). | consciousness_dispatcher.js |
| **Consciousness_getInfoPictureSignature** | function | Info-picture signature string for anti-stagnation of passive fantasy **main** cycle (dispatcher and `runOneStep`). | consciousness_dispatcher.js |
| **dispetchConsciousnessThinking** | function | Dispatcher: main step + background (every 5 pulses); on main finish or expired — decay background weight×0.5; promote from stack. | consciousness_dispatcher.js, puls.js |
| **Consciousness_decayBackgroundOperativeMemory** | function | Multiply all running background cycle weights by 0.5. On problem solved (main finished), main expired, or manual from passive. | consciousness_dispatcher.js |
| **PassiveMode_notifyScenariosExhausted** | function | Passive scenarios exhausted — trigger background decay. | goals.js |
| **stimuls_consciousness** | function | Consciousness entry. Interrupt threshold: effective stimulus importance ≥ 150% of main `thinkingImportance`; theme/situation mismatch halves effective importance. New cycle weight = stimulus importance. | conscious_attention_channel.js |
| **automatismRanForBranchIds** | Object | branchId → true if automatism ran for branch. Set in stimuls_consciousness; in processGeneticReflexes genetic reflex skipped for that branch. Cleared on branch change. | conscious_attention_channel.js, genetic_reflexes_engine.js |
| **unsolved_problem** | number \| null | Unsolved level-1 problem marker: FinalImageId of actual stimulus with no acceptable automatic answer (neither EP nor default automatism). Set in stimuls_consciousness; may clear on successful automatism for same stimulus. | conscious_attention_channel.js |
| **conscience_level_2** | function | Level 2 consciousness. From Consciousness_runElementary when unsolved_problem for actual stimulus. Extended context (actualId, branchId, well, emotionId, activityID, sourceContext). | conscience_level_2.js |
| **info_automatismWithEpisodeFeedbackAndExpireCycle** | function | Start automatism and AID, EP wait, expired+non-main cycle. Levels 1–3. Operator answer: `closeLastFrame` → `conscience_level_2`. | infofunctions.js |
| **info_insight** | function | Insight: goal “what does this mean for me?” (`meaning`), target mode; background → main (`Consciousness_setMainCycle`). From `registerInsight` (gestalt.js), \|effect\| ≥ `FANTASMI_INSITE_COMPARE` from `info_fantasizming`. | infofunctions.js |
| **info_new_abstract_semantic** | function | `(cycle, opts?)` — move `fantasizmArr` into `semanticStructure` clones with `ruleKind` fantasy (`AbstractImages_upsertSemanticRuleFromFantasyFrame`), clear plot on cycle; for sleep. Does not touch teacher slots. | infofunctions.js, abstract_images.js |
| **info_fantasizming** | function | One passive fantasy step: chain EP frames with `responseStimulusImageId === currentStimulusId`, best by \|effect\|; plot in `fantasmPlotRules` / `fantasizmArr`; optional insight without `runActionImage`. | fantasizming.js |
| **FANTASMI_INSITE_COMPARE** | number | \|effect\| threshold for fantasy insight (default 5). | fantasizming.js |
| **info_bestEpisodicRule** | function | `(perceptionNodeId, situationId, options)` → `{ frame, exactRule }`; options: `filterByStimulus`, `stimulusImageId`, `allowStimulusFallback` (level 2 survival / level 3). | infofunctions.js |
| **info_bestEpisodicRuleForStimulus** | function | Wrapper: `filterByStimulus: true`. | infofunctions.js |
| **info_teacherEpisodicRuleForAction** | function | Teacher EP frame: `(perceptionNodeId, situationId, actionImageId)` → `{ frame, exactRule }`; closed frame with same AID and nonzero `responseStimulusImageId`, no effect ranking. | infofunctions.js |
| **AbstractImages_findRuleFrameMatchingContext** | function | `semanticStructure` frame on perception clone for exact branch, `situationId`, `actualStimulusImageId` (level 3 shortcut). | abstract_images.js |
| **AbstractImages_applyEpisodeEffectToSemanticContextAbstractions** | function | Operator answer: average `meanImportance` of perception/action clones by `effect` if matching `semanticStructure` frame. | abstract_images.js |
| **AbstractImages_boostSemanticRulesForAction** | function | Level 2, “meaning” goal: average `meanImportance` of abstractions where `semanticStructure.frames` has rule with given `actionImageId`. | abstract_images.js |
| **info_activateBasicContextForHolding** | function | `(basicContextId)` — hold one basic context like UI (`ActivateBasicContextsForHolding([id])`). | infofunctions.js |
| **info_setBadNormWellForHolding** | function | `(1\|2\|3)` — hold Bad / Norm / Well (`SetBadForHolding` / `SetNormForHolding` / `SetWellForHolding`). | infofunctions.js |
| **activateStimulusForBasicMirrorActionId** | function | Enable stimulus from `BasicMirrorActions[].Id` (`mirrorParentId` → row type and local id). | stimuls_ui.js |
| **info_activateBasicMirrorAction** | function | Wrapper over `activateStimulusForBasicMirrorActionId`. | infofunctions.js |
| **conscience_level_3** | function | One level-3 event: `{ sourceCycle, reason? }`. Pipeline mental → semanticStructure → EP → teacher; EP wait gate; frame/semantics gates; log via `Consciousness_cycleAppendLog`. From `conscience_level_3_runFromChannel`. | conscience_level_3.js |
| **conscience_level_3_runFromChannel** | function | Level-3 tick from `Consciousness_runOneStep`: deferred level-2 plan, “cry”, `isDissatisfaction`; nested `runLevel3` skips full pass if EP wait for automatism already. | conscience_level_3.js |
| **conscience_level_4** | function | One level-4 event (extensions; gestalt via `Gestalt_*`). | conscience_level_4.js |
| **conscience_level_4_runFromChannel** | function | Level-4 tick from channel: `Gestalt_onConsciousnessTick` (resonance, context). | conscience_level_4.js |
| **GestaltArr** | Array | Gestalt records (open tasks by goal image). | gestalt.js |
| **GestaltResonanceBuffer** | Array | FIFO of closed EP frame signatures for cross-cycle analogy. | gestalt.js |
| **GestaltContextForLevel3** | Object \| null | Open gestalt context for level 3 after `Gestalt_prepareContextForCycle`. | gestalt.js |
| **Gestalt_prepareContextForCycle** | function | Called at start of `conscience_level_3_runFromChannel`. | gestalt.js |
| **Gestalt_onConsciousnessTick** | function | Level-4 tick: resonance, context update. | gestalt.js |
| **Gestalt_onEpisodeFeedbackClosed** | function | Called from `EpisodicMemory_closeLastFrame` after effect computed. | gestalt.js |
| **Gestalt_bumpFromMeaningForecast** | function | Level 2, “meaning” goal: raise open gestalt status when goal/automatism matches forecast AID. | gestalt.js |
| **GESTALT_STATUS** | Object | Status constants 0–4. | gestalt.js |
| **Info_showGestaltsList** | function | Dialog with gestalt id list; id click → `Info_showGestaltDetail`. | informing.js |
| **Info_showGestaltDetail** | function | Detail for one `GestaltArr` entry (goal, branch, situation, motor automatisms). | informing.js |
| **InfoPicture.fantasmPlotRules** | Array | Fantasy plot: EP frame snapshots; on target→passive (`Info_fillFantasmPlotOnPassiveMain`) and each `info_fantasizming` step. | informing.js |
| **InfoPicture.thinkingSource** | string | `'external'` \| `'imagination'` \| `'fantasy'` — operator-visible thought source (stimulus / imagination / passive fantasy). | informing.js, fantasizming.js |
| **Info_showFantasmPlotDetail** / **Info_showDetail('fantasmPlot')** | function | Fantasy plot detail. | informing.js |
| **Info_fillFantasmPlotOnPassiveMain** / **Info_fillFantasmPlotOnPassiveBackground** | function | Fill plot on passive transition (stub: last `Episodes` frames). Background plot grows via `info_fantasizming`, not separate background-fill call. | informing.js |
| **addBlockedReflexToQueue** | function | Enqueue OR-blocked genetic reflex to delayedReflexes (from OR after setBlockedReflex). Reflex tied to branchId. | genetic_reflexes_engine.js |
| **removeDelayedReflexesForBranch** | function | Remove all delayed reflex entries for branchId. From stimuls_consciousness when automatism starts — no action comparison. | genetic_reflexes_engine.js |
| **runActionImage** | function | Run action image (AID) by id: actionIds and/or odSequence. On automatism fire. | genetic_reflexes_engine.js |

---

## Action images (_10_actions_image)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **ActionImages** | Array | Action images: { id, finalImageId, actionIds, odSequence }. | actions_image.js |
| **ActionImages_registerReaction** | function | Register reaction (finalImageId, actionId) → AID id. | actions_image.js |
| **ActionImages_getOrCreateActionImageId** | function | Get or create AID id for finalImageId. | actions_image.js |
| **ActionImages_getActionImage** | function | Get AID object by id. | actions_image.js |
| **ActionImages_serializeState** / **ActionImages_applyState** | function | Serialize/restore. | actions_image.js |

---

## Episodic memory (_10_Episodic_memory)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **Episodes** | Array | Episodic memory frames. | episodic_memory.js |
| **EpisodicMemory_waitingStartedAt** | number \| null | Wait period start time this session (timestamp) or null. Progress bar visibility and isInWaitingPeriod(); not restored from IndexedDB. | episodic_memory.js |
| **EpisodicMemory_pulsesWaiting** | number | Current wait pulse count (updated in EpisodicMemory_onPulse). | episodic_memory.js |
| **EpisodicMemory_barShowCompletePulsesLeft** | number | Pulses left to show 100% bar after closing frame with answer. | episodic_memory.js |
| **EpisodicMemory_testMode** | boolean | Test mode (step messages). | episodic_memory.js |
| **EpisodicMemory_skipConditionalReflexFormation** | boolean | Set true in OR when closing frame with response stimulus; in startAction blocks CR formation; cleared in puls.js after processGeneticReflexes. | orientation_reflex.js, genetic_reflexes_engine.js, puls.js |
| **save_episodic_memory** | function | Create/close frame (from OR). | episodic_memory.js |
| **EpisodicMemory_setLastFrameActionFromActionId** | function | Write response action into last frame by actionId. | episodic_memory.js |
| **EpisodicMemory_isInWaitingPeriod** | function | Whether answer wait is active. | episodic_memory.js |
| **EpisodicMemory_closeLastFrameWithResponse** | function | Close last frame with response stimulus. | episodic_memory.js |
| **EpisodicMemory_onPulse** | function | From puls.js each pulse; counts wait pulses and timeout close. | episodic_memory.js |
| **EpisodicMemory_response_waiting_period** | number | Wait duration in pulses (not wall clock). | episodic_memory.js |
| **EpisodicMemory_serializeState** / **EpisodicMemory_applyState** | function | Serialize/restore EP. | episodic_memory.js |
| **EpisodicMemory_clearAll** | function | Clear all EP. | episodic_memory.js |
| **EpisodicMemory_pickBestPositiveFrameForStimulus** | function | Best frame with effect > 0 and given `stimulusImageId` (level 3). | episodic_memory.js |
| **EpisodicMemory_getFramesByResponseStimulus** | function | Frames where `responseStimulusImageId` matches (teacher answer to stimulus). | episodic_memory.js |
| **EpisodicMemory_pickBestFrameByAbsEffect** | function | Best frame by max \|effect\| among candidates with nonzero `actionImageId`. | episodic_memory.js |

---

## Automatisms (_11_Automatizms)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **Automatizms** | Array | Automatisms (id, branchId, usefulness, actionsImageId, count, isDefault). | automatizms.js |
| **Automatizms_getAutomatizmsByBranchId** | function | All automatisms for branch id. | automatizms.js |
| **Automatizms_getDefaultAutomatizmForBranch** | function | Default automatism for branch (isDefault=true). | automatizms.js |
| **Automatizms_createAutomatizm** | function | Create automatism (no duplicate branchId+actionsImageId); returns id or 0. | automatizms.js |
| **Automatizms_setDefaultAutomatizm** | function | Set automatism as default for branch (others same branch isDefault=false). | automatizms.js |
| **Automatizms_addUsefulnessSample** | function | Update usefulness and count from effect. | automatizms.js |
| **Automatizms_serializeState** / **Automatizms_applyState** | function | Serialize/restore for file and IndexedDB. | automatizms.js |
| **GoalImagesLife** | Array | Life-experience goal images: { id, perceptionNodeId, stimulusImageId, actionImageId, effect, count, lastUsedAt }. Built on level 2 from EP. | goals.js |
| **Goals_determineGoalInSituation** | function | Goal pick (level 2 first step): base → life experience by branch → if stimulus importance >3 and no branch goal, default “meaning” (`meaning`). Sets currentGoalType/currentGoalId/currentGoalVitalId. | goals.js |
| **Goals_ensureDefaultMeaningGoal** / **Goals_isDefaultMeaningGoalId** / **Goals_getDefaultMeaningGoalId** | function | Default “what does this mean for me?” goal (perceptionNodeId=0, situationId=0, actionImageId=-1); id checks. | goals.js |
| **Goals_getBestLifeGoalForBranch** | function | Best life goal image for branch (exact match and parents), minCount. | goals.js |
| **Goals_considerNewGoalFromEpisode** | function | Consider EP frame: if effect > 0 — add/update GoalImagesLife. | goals.js |
| **getActiveBaseGoalVitalId** | function | Base homeostatic goal: vital id to return to norm (only when BadNormWell === 1). | goals.js |
| **Goals_serializeState** / **Goals_applyState** | function | Serialize/restore goal images. | goals.js |
| **PerceptionTree_getActiveTerminalNodeId** | function | Current active terminal node from vitals and active stimuli. For automatisms and branchId into stimuls_consciousness. | perception_tree.js |

---

## Sleep mode (_12_Sleep)

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **SleepMode_isActive** | function | Whether sleep mode active (UI + contexts + dreams). | sleep_mode.js |
| **SleepMode_CONTEXT_ID** | number | Basic context id for Sleep (15). | sleep_mode.js |
| **SleepMode_exit** | function | Exit sleep; `exit(true)` — normal dream end → delete background consciousness cycles. | sleep_mode.js |
| **SleepMode_toggle** / **SleepMode_enterAuto** / **SleepMode_tryAutoAfterFinCycles** | function | Manual toggle, auto entry, hook after fin cycle (>100). | sleep_mode.js |
| **SleepMode_shouldBlockStimulusInteraction** | function | Whether to block stimulus click in sleep. | sleep_mode.js |
| **SleepMode_refreshStimulusButtonVisuals** | function | Highlight/block stimulus buttons (from pulse). | sleep_mode.js |
| **SleepMode_PAGE_BACKGROUND** | string | Expected page background in sleep (aligned with vitals_ui). | sleep_mode.js |
| **SleepDreams_onSleepEntered** / **SleepDreams_onSleepExited** / **SleepDreams_onPulse** | function | Bridge to dream orchestrator. | dreams.js |
| **SleepDreams_paleActivityBeast** | boolean | Pale “Beast activity” text during sleep fantasy phase. | dreams.js, sleep_dream_process.js |
| **SleepDreamProcess_onSleepEntered** etc. | function | Dream process API (empty-frame queue, limits). | sleep_dream_process.js |
| **ConsciousnessFinCyclesTotal** | number | “Fin” consciousness cycle counter; >100 may trigger auto-sleep. | consciousness_dispatcher.js (increment), sleep_mode.js |
| **Consciousness_deleteAllBackgroundCycles** | function | Delete all running background cycles; only from `SleepMode_exit(true)`. | consciousness_dispatcher.js |
| **EpisodicMemory_isEmptyFrameForSleep** / **EpisodicMemory_collectEmptyFrameIndicesNewestFirst** | function | Empty-frame criterion and iteration order for dreams. | episodic_memory.js |

More: **`beast/_12_Sleep/about_sleep.md`**.

---

## UI and saving

| Variable | Type | Description | Where set |
|----------|------|-------------|-----------|
| **show_alert** / **close_alert** | function | Custom alert show/close. | sys/alerts/alerts.js |
| **show_confirm** / **show_prompt** | function | Confirm and prompt. | sys/alerts/alerts.js |
| **showSaveIndicator** / **hideSaveIndicator** | function | Save indicator (blue dot). | index.html (inline) |
| **registerIndexedDBSaver** | function | Register per-pulse save. Dirty + signature (lastSavedSig) so IndexedDB writes only on real change (EP — new/removed frame, tree — new node, semantics/CR/AID — array changes). Module list in comment in indexeddb.js. | sys/IndexedDB/indexeddb.js |
| **runIndexedDBSavesForPulse** | function | Run all registered saves once per pulse (sep_of_puls). | sys/IndexedDB/indexeddb.js |
| **IndexedDBModule** | Object | openDatabase, get, put, remove wrapper. | sys/IndexedDB/indexeddb.js |
| **BEAST** | Object | Shared project structures (e.g. persistent module registry). | date/saving_ui.js |
| **BEAST.persistentModules** | Array | Persistent modules: { key, serialize, apply }. New store for file = one entry here. | date/saving_ui.js |
| **handle_save_memory_click** / **load_all_memory** | function | Save/load memory file. | date/saving_ui.js |
| **was_emergency_shutdown** | boolean | Emergency shutdown before page close. | saving_before_closing.js |
| **init_saving_before_closing** / **saving_before_closing** | function | Init and save on close. | saving_before_closing.js |
| **updateStimulusButtonsReadinessView** | function | Update OR readiness borders for all buttons (no hover). From `puls.js` only on 2nd pulse after start. | _3_perception/stimuls_ui.js |
| **updateStimulusButtonsReadinessViewForFinalImageId** | function | Point update for buttons tied to `finalImageId`. From `semantic_memory.js` after new semantic sample. | _3_perception/stimuls_ui.js, _6_semantic_memory/semantic_memory.js |

---

When adding globals or functions, extend this file with module and a short purpose.
