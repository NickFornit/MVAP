/* Image understanding models (FinalImage).
 *
 * For a given finalImageId we need a temporary array of all semantic “frames”
 * (SemanticObjectImportance) in every condition (WellNormaBad, EmotionId) where this image appeared.
 *
 * From that sample we build an understanding model:
 * ImageUnderstandingModelArr[finalImageId] — array of records, each summarizing one condition pair.
 */

(function (global) {
  'use strict';

  // Global array of image understanding models.
  // Index: ImageUnderstandingModelArr[finalImageId] = model or undefined.
  if (!global.ImageUnderstandingModelArr) {
    global.ImageUnderstandingModelArr = {};
  }

  var MULTIPLIER = (typeof global.StimulusGlobalId_MULTIPLIER === 'number') ? global.StimulusGlobalId_MULTIPLIER : 1000;

  /**
   * For an image with global stimulIds (e.g. [2010]) returns ids of other FinalImage entries
   * whose stimulIds use the old format (e.g. [10]). Used to merge frames after switching to global ids.
   */
  function getLegacyEquivalentFinalImageIds(finalImageId) {
    var ids = [];
    if (!Array.isArray(global.FinalImages)) return ids;
    var current = null;
    for (var i = 0; i < global.FinalImages.length; i++) {
      if (global.FinalImages[i] && global.FinalImages[i].id === finalImageId) {
        current = global.FinalImages[i];
        break;
      }
    }
    if (!current || !Array.isArray(current.stimulIds) || !current.stimulIds.length) return ids;
    var legacy = [];
    for (var j = 0; j < current.stimulIds.length; j++) {
      var s = current.stimulIds[j];
      var v = parseInt(s, 10);
      if (isNaN(v) || v <= 0) continue;
      legacy.push(v >= MULTIPLIER ? v % MULTIPLIER : v);
    }
    legacy.sort(function (a, b) { return a - b; });
    for (var k = 0; k < global.FinalImages.length; k++) {
      var im = global.FinalImages[k];
      if (!im || im.id === finalImageId || !Array.isArray(im.stimulIds)) continue;
      var other = im.stimulIds.slice(0).sort(function (a, b) { return a - b; });
      if (other.length !== legacy.length) continue;
      var eq = true;
      for (var n = 0; n < legacy.length; n++) {
        if (other[n] !== legacy[n]) { eq = false; break; }
      }
      if (eq) ids.push(im.id);
    }
    return ids;
  }

  /**
   * Collect all semantic frames for this finalImageId across SemanticMemory.
   * Includes frames stored under “legacy” images (old local stimulIds) so data is not lost
   * after migrating to global stimulus ids.
   *
   * @param {number} finalImageId
   * @returns {Array<Object>} SemanticObjectImportance rows for this image and legacy equivalents.
   */
  function getSemanticFramesForFinalImage(finalImageId) {
    var result = [];
    var getFrames = global.getSemanticFramesForFinalImageId;
    if (typeof getFrames !== 'function') return result;
    var idsToInclude = [finalImageId].concat(getLegacyEquivalentFinalImageIds(finalImageId));
    for (var i = 0; i < idsToInclude.length; i++) {
      var frames = getFrames(idsToInclude[i]);
      if (frames && frames.length) {
        for (var j = 0; j < frames.length; j++) result.push(frames[j]);
      }
    }
    return result;
  }

  /**
   * Build (or refresh) the understanding model for finalImageId.
   *
   * Model is an array of summary records for every (wellNormaBad, emotionId) pair found:
   * [
   *   {
   *     wellNormaBad: 1|2|3,
   *     emotionId: number,
   *     meanImportance: number,
   *     samplesCount: number,
   *     lastImportance: number
   *   },
   *   ...
   * ]
   *
   * @param {number} finalImageId
   * @returns {Array<Object>} understanding model for this finalImageId.
   */
  function buildImageUnderstandingModel(finalImageId) {
    var frames = getSemanticFramesForFinalImage(finalImageId);
    var model = [];
    for (var i = 0; i < frames.length; i++) {
      var f = frames[i];
      model.push({
        wellNormaBad: f.wellNormaBad,
        emotionId: f.emotionId,
        meanImportance: f.meanImportance,
        samplesCount: f.samplesCount,
        lastImportance: f.lastImportance
      });
    }
    global.ImageUnderstandingModelArr[finalImageId] = model;
    return model;
  }

  /**
   * Return cached understanding model without recomputing.
   * If missing, builds from current SemanticMemory.
   *
   * @param {number} finalImageId
   * @returns {Array<Object>} understanding model.
   */
  function getImageUnderstandingModel(finalImageId) {
    var model = global.ImageUnderstandingModelArr[finalImageId];
    if (!model) {
      model = buildImageUnderstandingModel(finalImageId);
    }
    return model;
  }

  // Export to global
  global.getSemanticFramesForFinalImage = getSemanticFramesForFinalImage;
  global.buildImageUnderstandingModel = buildImageUnderstandingModel;
  global.getImageUnderstandingModel = getImageUnderstandingModel;

})(window);
