# Semantic memory (_6_semantic_memory)

## Purpose

The module implements **semantic memory** — linking a stimulus image (FinalImageId) to its **importance** under given conditions (baseline + emotion). Importance feeds the orientation reflex (novelty, OR_well_known threshold), understanding models, and decisions.

## When it writes

- Before reflexes run, a “zero” is fixed (`getDiffImportance`).
- After reflexes (via pulse), `getDiffImportance` again; the resulting z is semantic importance of the image in current conditions.
- Records are unique per triple: **wellNormaBad** (1/2/3), **emotionId**, **finalImageId**. Each triple stores meanImportance, samplesCount, lastImportance; new experience updates the average.

**Importance magnifier** (`registerSemanticSample`): when semantics are already “quiet” (|meanImportance| ≤ 0.5) and **all vitals in norm** (no Kbad > 0), averaging mixes in not raw `getDiffImportance()` but `normalizeValue` of **raw** diff × 5 clamped to ±3 (`LastDiffImportanceRaw` in `prepare.js`). Weak signals stand out against near-zero memory; magnifier turns off under vital stress.

## Main components

- **SemanticMemoryIndex** — index (well, emotionId) → objects by finalImageId (meanImportance, samplesCount).
- **FinalImage.js** — final perception images (FinalImages): (id, stimulIds). getOrCreateFinalImageId(stimulIds) returns or creates id for stimulus id set.
- **Emotion.js** — emotion as id of active basic-context combination (getOrCreateEmotionId).
- **Understanding_model.js** — understanding models from semantics.

## Files

- **semantic_memory.js** — SemanticObjectImportance class, indexing, `registerSemanticSample`, save/load. On **restore** from snapshot, `meanImportance`, `lastImportance`, `samplesCount` are copied explicitly (with type normalization); restore path avoids extra `addSample(meanImportance)` so counts are not skewed or samplesCount left low on duplicate keys or string values from storage.
- **FinalImage.js**, **Emotion.js**, **Understanding_model.js** — images, emotions, semantics usage.

Semantic memory persists in IndexedDB and file; it drives OR conditions and EP frame formation (threshold samplesCount >= OR_well_known).

Additionally: after a new semantic sample (`registerSemanticSample`), `semantic_memory.js` may call point UI update for OR readiness on stimulus buttons (avoid full border recompute every pulse). After async semantics load from IndexedDB, indicators refresh, including `setTimeout(0)` on next tick to reduce desync with contexts right after start.
