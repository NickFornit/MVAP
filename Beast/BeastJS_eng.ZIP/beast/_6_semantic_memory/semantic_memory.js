/* Semantic memory — foundation of understanding models.
Links stimulus id (image) to its significance under those conditions, producing abstraction.
Each semantic update needs a snapshot of current conditions (context):
baseline WellNormBad id (1 / 2 / 3) and the combination of active basic context ids (EmotionId).
Significance comes from current state z = getDiffImportance()
relative to state before contact with the object.

Significance "loupe" (registerSemanticSample): if for triple (well, emotion, finalImage) the accumulated
meanImportance magnitude is ≤ 0.5 and no vital is out of norm (Kbad = 0),
the stored value is not z but normalizeValue(clamp(raw × 5, ±3)), where raw is the unrounded diff from
getDiffImportance (LastDiffImportanceRaw in prepare.js) — boosting weak signal under "quiet" semantics
and calm body (no distortion under vital stress).

On object interaction:
1) Before internal reflexes run, getDiffImportance() — baseline "zero".
2) After reflexes (after 1 pulse when effect is settled) getDiffImportance() again.
   The resulting z is "semantic significance" of this object (FinalImageId) under current conditions
   (WellNormBad + EmotionId).
3) For (WellNormBad, EmotionId, FinalImageId) create/update SemanticObjectImportance in SemanticMemory.
*/

/* Semantic significance of an object on interaction (including passive).
Record identity:
- wellNormaBad (1, 2, 3) — baseline Bad / Normal / Good at interaction;
- emotionId — combination of basic contexts (Emotion);
- finalImageId — combination of active stimuli (FinalImage).

Each new experience with the same (wellNormaBad, emotionId, finalImageId) updates meanImportance
from current z and samplesCount.

NOTE: if an action does not change a vital (already at 0 or 100) there is no effect from the action.
e.g. "Reward" only has effect if Stress has room to decrease.
*/

(function (global) {
  'use strict';

  // One semantic memory row
  function SemanticObjectImportance(wellNormaBad, emotionId, finalImageId, initialImportance) {
    this.wellNormaBad = wellNormaBad;      // 1 / 2 / 3
    this.emotionId = emotionId;            // Emotion id
    this.finalImageId = finalImageId;      // FinalImage id

    this.meanImportance = initialImportance || 0; // mean z
    this.samplesCount = 0;                        // observation count
    this.lastImportance = 0;                      // last z

    if (typeof initialImportance === 'number') {
      this.meanImportance = initialImportance;
      this.lastImportance = initialImportance;
      this.samplesCount = 1;
    }
  }

  SemanticObjectImportance.prototype.addSample = function (z) {
    if (typeof z !== 'number' || isNaN(z)) {
      return;
    }
    var n = this.samplesCount;
    if (n <= 0) {
      this.meanImportance = z;
      this.samplesCount = 1;
      this.lastImportance = z;
      return;
    }
    // Running mean: new = (old*n + z) / (n+1)
    this.meanImportance = (this.meanImportance * n + z) / (n + 1);
    this.samplesCount = n + 1;
    this.lastImportance = z;
  };

  if (!Array.isArray(global.SemanticMemory)) {
    global.SemanticMemory = [];
  }

  // Known FinalImageId / EmotionId arrays for save/restore
  if (!Array.isArray(global.KnownFinalImageIds)) {
    global.KnownFinalImageIds = [];
  }
  if (!Array.isArray(global.KnownEmotionIds)) {
    global.KnownEmotionIds = [];
  }

  // Index for O(1) lookup by (wellNormaBad, emotionId, finalImageId)
  // SemanticMemoryIndex[wellNormaBad][emotionId][finalImageId] = SemanticObjectImportance
  if (!global.SemanticMemoryIndex) {
    global.SemanticMemoryIndex = {};
  }

  function getIndexBucket(wellNormaBad, emotionId) {
    var wKey = String(wellNormaBad);
    var eKey = String(emotionId);
    if (!global.SemanticMemoryIndex[wKey]) {
      global.SemanticMemoryIndex[wKey] = {};
    }
    if (!global.SemanticMemoryIndex[wKey][eKey]) {
      global.SemanticMemoryIndex[wKey][eKey] = {};
    }
    return global.SemanticMemoryIndex[wKey][eKey];
  }

  /**
   * Fast lookup by index O(1).
   * @param {number} well — baseline (1/2/3)
   * @param {number} emotionId
   * @param {number} finalImageId
   * @returns {SemanticObjectImportance|null}
   */
  function getSemanticObjectFast(well, emotionId, finalImageId) {
    if (!well || !emotionId || !finalImageId || !global.SemanticMemoryIndex) return null;
    var bucket = global.SemanticMemoryIndex[String(well)];
    if (!bucket) return null;
    bucket = bucket[String(emotionId)];
    if (!bucket) return null;
    return bucket[String(finalImageId)] || null;
  }

  /**
   * All semantic frames for one finalImageId (index walk, no linear SemanticMemory scan).
   * @param {number} finalImageId
   * @returns {Object[]} SemanticObjectImportance rows
   */
  /** true if any vital has Kbad > 0 (as in prepare.calculateBadVitalsValues). */
  function semanticMemory_anyVitalOutOfNorm() {
    var bad = global.BadVitalsValue;
    var arr = global.VitalsArr;
    if (!bad || !arr || !arr.length) return false;
    for (var vi = 0; vi < arr.length; vi++) {
      var vid = arr[vi].Id;
      var kb = bad[vid];
      if (kb == null) kb = bad[String(vid)];
      if (typeof kb === 'number' && kb > 0) return true;
    }
    return false;
  }

  function getSemanticFramesForFinalImageId(finalImageId) {
    var result = [];
    if (!global.SemanticMemoryIndex || finalImageId == null) return result;
    var fKey = String(finalImageId);
    var wKeys = Object.keys(global.SemanticMemoryIndex);
    for (var w = 0; w < wKeys.length; w++) {
      var byEmotion = global.SemanticMemoryIndex[wKeys[w]];
      if (!byEmotion) continue;
      var eKeys = Object.keys(byEmotion);
      for (var e = 0; e < eKeys.length; e++) {
        var obj = byEmotion[eKeys[e]] && byEmotion[eKeys[e]][fKey];
        if (obj) result.push(obj);
      }
    }
    return result;
  }

  function getOrCreateSemanticObject(wellNormaBad, emotionId, finalImageId, initialImportance) {
    if (!wellNormaBad || !emotionId || !finalImageId) {
      return null;
    }
    var bucket = getIndexBucket(wellNormaBad, emotionId);
    var fKey = String(finalImageId);
    var obj = bucket[fKey];
    if (!obj) {
      obj = new SemanticObjectImportance(wellNormaBad, emotionId, finalImageId, initialImportance);
      bucket[fKey] = obj;
      global.SemanticMemory.push(obj);

      if (global.KnownFinalImageIds.indexOf(finalImageId) === -1) {
        global.KnownFinalImageIds.push(finalImageId);
      }
      if (global.KnownEmotionIds.indexOf(emotionId) === -1) {
        global.KnownEmotionIds.push(emotionId);
      }
    } else if (typeof initialImportance === 'number') {
      obj.addSample(initialImportance);
    }
    return obj;
  }

  /**
   * Register one semantic experience.
   * Call AFTER second getDiffImportance() when z is available.
   *
   * Loupe: if |meanImportance| ≤ 0.5 for this triple and vitals in norm,
   * sample uses normalizeValue(clamp(LastDiffImportanceRaw × 5, ±3)) instead of z — see file header.
   * Requires getDiffImportance() just before (fills LastDiffImportanceRaw).
   *
   * @param {number} finalImageId
   * @param {number} emotionId
   * @param {number} z — object significance from getDiffImportance() (replaced when loupe applies)
   */
  function registerSemanticSample(finalImageId, emotionId, z) {
    if (typeof z !== 'number' || isNaN(z)) {
      return;
    }
    var well = global.BadNormWell || 0; // 1 / 2 / 3
    if (!well) {
      return;
    }

    var LOUPE_PRIOR_MEAN_ABS = 0.5;
    var LOUPE_RAW_SCALE = 5;
    var LOUPE_RAW_CLAMP = 3;

    var priorObj = getSemanticObjectFast(well, emotionId, finalImageId);
    var priorMean = priorObj && typeof priorObj.meanImportance === 'number' && !isNaN(priorObj.meanImportance)
      ? priorObj.meanImportance
      : 0;
    var zApplied = z;
    if (Math.abs(priorMean) <= LOUPE_PRIOR_MEAN_ABS && !semanticMemory_anyVitalOutOfNorm()) {
      var raw = global.LastDiffImportanceRaw;
      if (typeof raw === 'number' && !isNaN(raw)) {
        var mag = raw * LOUPE_RAW_SCALE;
        if (mag > LOUPE_RAW_CLAMP) mag = LOUPE_RAW_CLAMP;
        if (mag < -LOUPE_RAW_CLAMP) mag = -LOUPE_RAW_CLAMP;
        if (typeof global.normalizeValue === 'function') {
          zApplied = global.normalizeValue(mag);
        } else {
          zApplied = mag;
        }
      }
    }

    // One call = one sample: getOrCreateSemanticObject already calls addSample when object exists.
    var obj = getOrCreateSemanticObject(well, emotionId, finalImageId, zApplied);
    if (!obj) return;

    // OR readiness indicator for buttons tied to this finalImageId
    if (typeof global.updateStimulusButtonsReadinessViewForFinalImageId === 'function') {
      global.updateStimulusButtonsReadinessViewForFinalImageId(finalImageId);
    }
    var state = serializeSemanticState();
    var sig;
    try {
      sig = JSON.stringify(state);
    } catch (e) {
      sig = '';
    }
    if (sig && sig === lastSemanticSavedSig) return;
    lastSemanticSavedSig = sig;
    saveSemanticStateToIndexedDB(state);
  }

  // ---- Serialize / deserialize for IndexedDB and files ----

  function serializeSemanticState() {
    var plain = [];
    for (var i = 0; i < global.SemanticMemory.length; i++) {
      var it = global.SemanticMemory[i];
      plain.push({
        wellNormaBad: it.wellNormaBad,
        emotionId: it.emotionId,
        finalImageId: it.finalImageId,
        meanImportance: it.meanImportance,
        samplesCount: it.samplesCount,
        lastImportance: it.lastImportance
      });
    }
    return {
      semanticMemory: plain,
      knownFinalImageIds: global.KnownFinalImageIds.slice(0),
      knownEmotionIds: global.KnownEmotionIds.slice(0),
      finalImages: Array.isArray(global.FinalImages) ? global.FinalImages.slice(0) : [],
      emotions: Array.isArray(global.Emotions) ? global.Emotions.slice(0) : []
    };
  }

  function clearSemanticStructures() {
    global.SemanticMemory = [];
    global.SemanticMemoryIndex = {};
    global.KnownFinalImageIds = [];
    global.KnownEmotionIds = [];
  }

  /**
   * Clear all semantic memory (UI "Sx" button).
   */
  function clearAllSemanticMemory() {
    clearSemanticStructures();
    var state = serializeSemanticState();
    lastSemanticSavedSig = JSON.stringify(state);
    saveSemanticStateToIndexedDB(state);
  }

  /**
   * Restore object fields from plain record without addSample logic.
   */
  function restoreSemanticObjectFromPlain(p) {
    if (!p) return;
    var w = parseInt(p.wellNormaBad, 10);
    var e = parseInt(p.emotionId, 10);
    var f = parseInt(p.finalImageId, 10);
    if (!w || !e || !f) return;
    var obj = getOrCreateSemanticObject(w, e, f, undefined);
    if (!obj) return;
    if (p.meanImportance != null && typeof p.meanImportance === 'number' && !isNaN(p.meanImportance)) {
      obj.meanImportance = p.meanImportance;
    } else if (p.meanImportance != null && !isNaN(Number(p.meanImportance))) {
      obj.meanImportance = Number(p.meanImportance);
    }
    if (p.lastImportance != null && typeof p.lastImportance === 'number' && !isNaN(p.lastImportance)) {
      obj.lastImportance = p.lastImportance;
    } else if (p.lastImportance != null && !isNaN(Number(p.lastImportance))) {
      obj.lastImportance = Number(p.lastImportance);
    }
    var sc = parseInt(p.samplesCount, 10);
    if (!isNaN(sc) && sc >= 0) {
      obj.samplesCount = sc;
    } else if (typeof p.samplesCount === 'number' && !isNaN(p.samplesCount) && p.samplesCount >= 0) {
      obj.samplesCount = p.samplesCount;
    } else {
      if (!obj.samplesCount && obj.meanImportance) {
        obj.samplesCount = 1;
      }
    }
  }

  function applySemanticState(state) {
    clearSemanticStructures();
    if (!state) {
      return;
    }
    if (Array.isArray(state.knownFinalImageIds)) {
      global.KnownFinalImageIds = state.knownFinalImageIds.slice(0);
    }
    if (Array.isArray(state.knownEmotionIds)) {
      global.KnownEmotionIds = state.knownEmotionIds.slice(0);
    }
    if (Array.isArray(state.finalImages)) {
      global.FinalImages = state.finalImages.slice(0);
    }
    if (Array.isArray(state.emotions)) {
      global.Emotions = state.emotions.slice(0);
    }

    if (Array.isArray(state.semanticMemory)) {
      for (var i = 0; i < state.semanticMemory.length; i++) {
        restoreSemanticObjectFromPlain(state.semanticMemory[i]);
      }
    }
  }

  // ---- IndexedDB ----

  var semanticDb = null;
  // Version 4: preferences store (last folder for Save/Load).
  var SEMANTIC_DB_NAME = 'BEAST_DB';
  var SEMANTIC_DB_VERSION = 4;
  var SEMANTIC_STORE = 'semantic_state';
  var SEMANTIC_KEY = 'semantic_state_singleton';
  var MEMORY_SNAPSHOT_STORE = 'memory_snapshot';
  var MEMORY_SNAPSHOT_KEY = 'memory_singleton';
  var PREFERENCES_STORE = 'preferences';
  var LAST_MEMORY_DIR_KEY = 'lastMemoryDirectory';
  var lastSemanticSavedSig = '';

  function openSemanticDb() {
    if (!global.indexedDB || !global.IndexedDBModule) {
      return Promise.reject(new Error('IndexedDB unavailable or module not loaded.'));
    }
    return global.IndexedDBModule.openDatabase({
      dbName: SEMANTIC_DB_NAME,
      version: SEMANTIC_DB_VERSION,
      stores: [
        { name: SEMANTIC_STORE, options: { keyPath: 'id' } },
        { name: MEMORY_SNAPSHOT_STORE, options: { keyPath: 'id' } },
        { name: PREFERENCES_STORE, options: { keyPath: 'id' } }
      ]
    }).then(function (db) {
      semanticDb = db;
      return db;
    });
  }

  function loadSemanticStateFromIndexedDB() {
    if (!global.IndexedDBModule) {
      return;
    }
    openSemanticDb()
      .then(function (db) {
        return global.IndexedDBModule.get({
          db: db,
          storeName: SEMANTIC_STORE,
          key: SEMANTIC_KEY
        });
      })
      .then(function (record) {
        if (record && record.state) {
          applySemanticState(record.state);
          lastSemanticSavedSig = JSON.stringify(serializeSemanticState());

          if (typeof global.updateStimulusButtonsReadinessView === 'function') {
            global.updateStimulusButtonsReadinessView();
            global.setTimeout(function () {
              if (typeof global.updateStimulusButtonsReadinessView === 'function') {
                global.updateStimulusButtonsReadinessView();
              }
            }, 0);
          }
        }
      })
      .catch(function () {});
  }

  function saveSemanticStateToIndexedDB(state) {
    if (!global.IndexedDBModule) {
      return;
    }
    state = state || serializeSemanticState();
    function doPut(db) {
      global.IndexedDBModule.put({
        db: db,
        storeName: SEMANTIC_STORE,
        value: {
          id: SEMANTIC_KEY,
          state: state,
          ts: Date.now()
        }
      }).catch(function () {});
    }
    if (semanticDb) {
      doPut(semanticDb);
      return;
    }
    openSemanticDb().then(function (db) {
      semanticDb = db;
      doPut(db);
    }).catch(function () {});
  }

  /**
   * Save last picked folder for Save/Load memory dialogs (Chrome FileSystemHandle).
   */
  function saveLastMemoryDirectory(dirHandle) {
    if (!dirHandle || !global.IndexedDBModule) return Promise.resolve();
    function doPut(db) {
      return global.IndexedDBModule.put({
        db: db,
        storeName: PREFERENCES_STORE,
        value: { id: LAST_MEMORY_DIR_KEY, handle: dirHandle }
      });
    }
    if (semanticDb) return doPut(semanticDb);
    return openSemanticDb().then(doPut).catch(function () {});
  }

  /**
   * Load last directory for startIn in file picker.
   */
  function loadLastMemoryDirectory() {
    if (!global.IndexedDBModule) return Promise.resolve(undefined);
    function doGet(db) {
      return global.IndexedDBModule.get({
        db: db,
        storeName: PREFERENCES_STORE,
        key: LAST_MEMORY_DIR_KEY
      }).then(function (record) {
        return record && record.handle ? record.handle : undefined;
      });
    }
    if (semanticDb) return doGet(semanticDb);
    return openSemanticDb().then(doGet).catch(function () { return undefined; });
  }

  loadSemanticStateFromIndexedDB();

  global.SemanticObjectImportance = SemanticObjectImportance;
  global.getOrCreateSemanticObject = getOrCreateSemanticObject;
  global.registerSemanticSample = registerSemanticSample;
  global.serializeSemanticState = serializeSemanticState;
  global.applySemanticState = applySemanticState;
  global.saveLastMemoryDirectory = saveLastMemoryDirectory;
  global.loadLastMemoryDirectory = loadLastMemoryDirectory;
  global.clearAllSemanticMemory = clearAllSemanticMemory;
  global.getSemanticObjectFast = getSemanticObjectFast;
  global.getSemanticFramesForFinalImageId = getSemanticFramesForFinalImageId;

  function bindResetSemanticButton() {
    try {
      var btn = global.document && global.document.getElementById('btnResetSemanticMemory');
      if (btn && typeof btn.addEventListener === 'function') {
        btn.addEventListener('click', function () {
          var msg = 'Reset all semantic memory?';
          if (typeof global.show_confirm === 'function') {
            global.show_confirm(msg, function (result) {
              if (result) clearAllSemanticMemory();
            });
          } else if (global.confirm(msg)) {
            clearAllSemanticMemory();
          }
        });
      }
    } catch (e) {}
  }
  if (global.document && global.document.readyState === 'loading') {
    global.document.addEventListener('DOMContentLoaded', bindResetSemanticButton);
  } else {
    bindResetSemanticButton();
  }

})(window);
