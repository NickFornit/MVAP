/* Genetically predetermined action programs.
Split into motor and “internal” — baseline state or basic context changes.

Primary external actions: cry, start eating, drinking, make whatever sounds possible.
Primary internal actions are genetic; later (episodic memory) mirrored control appears — not cry but do something.
Simple adult reactions (faces, gestures, basic motor acts) start to be mirrored by children around age 3.

Children often shift mood quickly from bad to normal or good via external stimuli or internal self-regulation — typical of child psychology.
Hugs and contact with a parent can quickly improve a fussy child’s mood.

Infants show muscle avoidance of unpleasant and approach to pleasant stimuli from the first weeks (innate reflexes).

The long Russian developmental notes below are summarized: motor and emotional patterns develop from reflexive withdrawal/
approach through crawling away, covering ears, selective social responses, then walking away and refusal — building on the same
reflex arcs that genetic reflex tables in this project approximate.

Curiosity can follow brief fear when novelty is safe; feeding vs protective switching appears when food is unpleasant;
satiation can flip curiosity to avoidance (fatigue, sleep).
*/

/* Basic genetic actions
Genetic reflexes attach to these; conditional reflexes may form.
*/
window.BasicActions = [
  { Id: 1, name: "Cries" },
  { Id: 2, name: "Laughs" },
  { Id: 3, name: "Eats" },
  { Id: 4, name: "Drinks" },
  { Id: 5, name: "Grasps" },
  { Id: 6, name: "Runs to" },
  { Id: 7, name: "Runs away" },
  { Id: 8, name: "Startles" },
  { Id: 9, name: "Hits" },
  { Id: 10, name: "Shouts" },
  { Id: 11, name: "Scratches self" },
  { Id: 12, name: "Plays" },
  { Id: 13, name: "Vomits" },
  { Id: 14, name: "Gasps" },
  { Id: 15, name: "Hides" },
  { Id: 16, name: "Breaks" },
  { Id: 17, name: "Sleeps" },
  { Id: 18, name: "Throws" },
  { Id: 19, name: "Falls" },
  { Id: 20, name: "Surprised" },
  { Id: 21, name: "Ill" },
  { Id: 22, name: "Shivers cold" },
  { Id: 23, name: "Sweats" },
  { Id: 24, name: "Coughs" },
  { Id: 25, name: "Silent" },
  { Id: 26, name: "Bites self" },
  { Id: 27, name: "Smiles" },
  { Id: 28, name: "Angry" },
  { Id: 29, name: "Toilet" },
  { Id: 30, name: "Trembles" },
  ];

/* Basic “physiological” sounds
Random samples and combinations; conditional reflexes may form.
*/
window.BasicVerbal = [
  { Id: 1, name: "ah" },
  { Id: 2, name: "oh" },
  { Id: 3, name: "oo" },
  { Id: 4, name: "yh" },
  { Id: 5, name: "a-oh" },
  { Id: 6, name: "a-yh" },
  { Id: 7, name: "guh" },
  { Id: 8, name: "goo" },
  { Id: 9, name: "aaaa" },
  { Id: 10, name: "eeee" },
  { Id: 11, name: "kh" },
  { Id: 12, name: "guh-ee" },
  { Id: 13, name: "goo-oo" },
  { Id: 14, name: "boo" },
  { Id: 15, name: "mgu" },
  { Id: 16, name: "guh-ah" },
  { Id: 17, name: "ba-ba-ba" },
  { Id: 18, name: "ma-ma-ma" },
  { Id: 19, name: "pa-pa-pa" },
  { Id: 20, name: "da-da-da" }
];

/* Operator mirror actions for EM frames (authoritarian learning).
 * Each entry — “operator applied stimulus”; Id used in action image schema.
 * mirrorParentId: "n_m" — n stimulus kind (1=Motivation, 2=Positiv, 3=Negative, 4=Neutral), m — Id in stimuls.js.
 * Excluded: Food(1_1), Water(1_2), Play(1_19), Teach(1_20) — duplicate basic actions.
 */
window.BasicMirrorActions = [
  { Id: 1, mirrorParentId: "1_3", name: "Warmth" },
  { Id: 2, mirrorParentId: "1_4", name: "Cold" },
  { Id: 3, mirrorParentId: "1_5", name: "Air" },
  { Id: 4, mirrorParentId: "1_6", name: "Healing" },
  { Id: 5, mirrorParentId: "1_7", name: "Reward" },
  { Id: 6, mirrorParentId: "1_8", name: "Punish" },
  { Id: 7, mirrorParentId: "1_9", name: "Pleasant" },
  { Id: 8, mirrorParentId: "1_10", name: "Unpleasant" },
  { Id: 9, mirrorParentId: "1_11", name: "Calm" },
  { Id: 10, mirrorParentId: "1_12", name: "Clear" },
  { Id: 11, mirrorParentId: "1_13", name: "Unclear" },
  { Id: 12, mirrorParentId: "1_14", name: "Forgive" },
  { Id: 13, mirrorParentId: "1_15", name: "Laugh" },
  { Id: 14, mirrorParentId: "1_16", name: "Joy" },
  { Id: 15, mirrorParentId: "1_17", name: "Crush" },
  { Id: 16, mirrorParentId: "1_18", name: "Ignore" },
  { Id: 17, mirrorParentId: "2_1", name: "Smile" },
  { Id: 18, mirrorParentId: "2_2", name: "Child" },
  { Id: 19, mirrorParentId: "2_3", name: "Puppy" },
  { Id: 20, mirrorParentId: "2_4", name: "Flower" },
  { Id: 21, mirrorParentId: "2_5", name: "Sun" },
  { Id: 22, mirrorParentId: "2_6", name: "Butterfly" },
  { Id: 23, mirrorParentId: "2_7", name: "Berry" },
  { Id: 24, mirrorParentId: "2_8", name: "Bell" },
  { Id: 25, mirrorParentId: "2_9", name: "Laughter" },
  { Id: 26, mirrorParentId: "2_10", name: "Singing" },
  { Id: 27, mirrorParentId: "2_11", name: "Melody" },
  { Id: 28, mirrorParentId: "2_12", name: "Rustle" },
  { Id: 29, mirrorParentId: "2_13", name: "Purring" },
  { Id: 30, mirrorParentId: "2_14", name: "Sweetness" },
  { Id: 31, mirrorParentId: "2_15", name: "Aroma" },
  { Id: 32, mirrorParentId: "2_16", name: "Warmth" },
  { Id: 33, mirrorParentId: "2_17", name: "Breeze" },
  { Id: 34, mirrorParentId: "2_18", name: "Coolness" },
  { Id: 35, mirrorParentId: "2_19", name: "Touch" },
  { Id: 36, mirrorParentId: "2_20", name: "Caress" },
  { Id: 37, mirrorParentId: "3_1", name: "Spite" },
  { Id: 38, mirrorParentId: "3_2", name: "Blood" },
  { Id: 39, mirrorParentId: "3_3", name: "Ruin" },
  { Id: 40, mirrorParentId: "3_4", name: "Spider" },
  { Id: 41, mirrorParentId: "3_5", name: "Snake" },
  { Id: 42, mirrorParentId: "3_6", name: "Mushroom" },
  { Id: 43, mirrorParentId: "3_7", name: "Rot" },
  { Id: 44, mirrorParentId: "3_8", name: "Howl" },
  { Id: 45, mirrorParentId: "3_9", name: "Moan" },
  { Id: 46, mirrorParentId: "3_10", name: "Siren" },
  { Id: 47, mirrorParentId: "3_11", name: "Squeak" },
  { Id: 48, mirrorParentId: "3_12", name: "Creak" },
  { Id: 49, mirrorParentId: "3_13", name: "Growl" },
  { Id: 50, mirrorParentId: "3_14", name: "Shards" },
  { Id: 51, mirrorParentId: "3_15", name: "Lightning" },
  { Id: 52, mirrorParentId: "3_16", name: "Dagger" },
  { Id: 53, mirrorParentId: "3_17", name: "Bitterness" },
  { Id: 54, mirrorParentId: "3_18", name: "Sourness" },
  { Id: 55, mirrorParentId: "3_19", name: "Stench" },
  { Id: 56, mirrorParentId: "3_20", name: "Fire" },
  { Id: 57, mirrorParentId: "4_1", name: "Brown" },
  { Id: 58, mirrorParentId: "4_2", name: "Red" },
  { Id: 59, mirrorParentId: "4_3", name: "Yellow" },
  { Id: 60, mirrorParentId: "4_4", name: "Green" },
  { Id: 61, mirrorParentId: "4_5", name: "Cyan" },
  { Id: 62, mirrorParentId: "4_6", name: "Blue" },
  { Id: 63, mirrorParentId: "4_7", name: "Violet" },
  { Id: 64, mirrorParentId: "4_8", name: "Black" },
  { Id: 65, mirrorParentId: "4_9", name: "White" },
  { Id: 66, mirrorParentId: "4_10", name: "Circle" },
  { Id: 67, mirrorParentId: "4_11", name: "Square" },
  { Id: 68, mirrorParentId: "4_12", name: "Arc" },
  { Id: 69, mirrorParentId: "4_13", name: "Dot" },
  { Id: 70, mirrorParentId: "4_14", name: "Zigzag" },
  { Id: 71, mirrorParentId: "4_15", name: "Line" },
  { Id: 72, mirrorParentId: "4_16", name: "Star" },
  { Id: 73, mirrorParentId: "4_17", name: "Cross" },
  { Id: 74, mirrorParentId: "4_18", name: "Triangle" },
  { Id: 75, mirrorParentId: "4_19", name: "Noise" },
  { Id: 76, mirrorParentId: "4_20", name: "Whistle" },
  { Id: 77, mirrorParentId: "4_21", name: "Hum" },
  { Id: 78, mirrorParentId: "4_22", name: "Ring" },
  { Id: 79, mirrorParentId: "4_23", name: "Vibration" },
  { Id: 80, mirrorParentId: "4_24", name: "Book" },
  { Id: 81, mirrorParentId: "4_25", name: "Table" },
  { Id: 82, mirrorParentId: "4_26", name: "Chair" },
  { Id: 83, mirrorParentId: "4_27", name: "Bed" },
  { Id: 84, mirrorParentId: "4_28", name: "Light bulb" },
  { Id: 85, mirrorParentId: "4_29", name: "Plant" },
  { Id: 86, mirrorParentId: "4_30", name: "Animal" },
  { Id: 87, mirrorParentId: "4_31", name: "Human" },
  { Id: 88, mirrorParentId: "1_19", name: "Wants to play" },
  { Id: 89, mirrorParentId: "1_20", name: "Wants to learn" },
];
