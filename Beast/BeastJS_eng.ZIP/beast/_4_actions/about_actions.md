# Actions and effectors (_4_actions)

## Purpose

The module defines **genetically preset action programs** for Beast: motor and “internal” (baseline and contexts). Actions are reflex outputs; action images (AIDs) and episodic memory build on them.

## Main data

- **BasicActions** — basic actions (Cries, Laughs, Eats, Drinks, Grabs, Flees, Smiles, Gets angry, etc.). Each has `Id` and `name`. Genetic and conditional reflexes attach here.

- **BasicVerbal** — basic “physiological” sounds (vowels, syllables, babble). Used for action Id == 100 (verbal reflex).

- **BasicMirrorActions** — operator mirror actions for EP frames (authoritarian teaching). Each: `Id` (for action image), `mirrorParentId` as `"n_m"` (n = stimulus row type 1..4, m = id in stimuls.js), `name`. Excludes duplicates of base actions (Food, Water, Play, Teach).

## Files

- **effectors.js** — BasicActions, BasicVerbal, static BasicMirrorActions.

Actions are chosen from genetic reflex maps (_5_Genetic__reflexes) and conditional reflexes (_5_2_synonyms_reflexes); execution via `startAction` / `runGeneticActionFromSynonymReflex` in genetic_reflexes_engine.js, with registration in action images and episodic memory.
