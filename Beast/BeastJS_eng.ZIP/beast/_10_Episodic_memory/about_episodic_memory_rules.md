# Rules and conditions for episodic memory (EP) frames

## 1. General episodic memory layout

EP is a frame array in **strict historical order**. Order is not shuffled; only in-place edits and deletes that preserve order.

**Rule (episode frame):**  
Stimulus (FinalImage) → response action (action image, AID) → effect (Effect) → operator response stimulus (if any).

**Frame fields:**
- `perceptionNodeId` — terminal perception-tree branch id (conditions);
- `stimulusImageId` — stimulus image id (FinalImage) that triggered the reaction;
- `actionImageId` — response action image id (AID);
- `effect` — `getDiffImportance()` after minus before (before stimulus activation);
- `responseStimulusImageId` — operator response stimulus image id (if during wait).

Response action + response stimulus form a “teacher” rule: how the operator answers Beast’s action.

**Answer wait** — `response_waiting_period` in **pulses** (default 15). Timeout close in `EpisodicMemory_onPulse` (from puls.js). During wait, expect response stimulus or effect recording. Frames with unset `effect` may be left for optimization (e.g. sleep).

---

## 2. When EP frame formation starts

EP frames **only start from the orientation reflex (OR)**. A frame is created when:

1. **OR ran** — “winner” among active stimuli (most salient image).
2. **OR conditions** hold (active stimuli, tree branch, winner, winner `samplesCount >= OR_well_known`; see §4).
3. Either **wait is active** — activation is handled as **response stimulus** (no `OR_well_known` check), then **second full OR** with new EP frame and consciousness (see §4). Or no wait — normal knownness threshold.

`save_episodic_memory(perceptionNodeId, stimulusImageId)` is called from OR after reflex block and hippocampus. **Frame and wait bar are created on every such OR pass** (not only when significance is absent or in test mode).

---

## 3. Frame lifecycle

1. **Create (OR pass):**
   - Close previous open frame if any: before `closeLastFrame`, `episodicFrameFillRuleZerosForIncompleteClose(prev)` writes **0** into empty AID/response fields; then `closeLastFrame` uses **current** `stimulusImageId` (new OR winner) as previous frame’s response, computes `effect` in [-10, +10].
   - Append “empty” frame: `perceptionNodeId`, `stimulusImageId`, `diffBefore` (from `PrevDiffForEpisode` / `getDiffImportance`), `actionImageId = null`, `effect = null`, `responseStimulusImageId = null`.
   - Set `EpisodicMemory_waitingStartedAt` and wait pulse counter; timeout in `EpisodicMemory_onPulse` (pulses, not wall clock). Bar only if wait active this session (`waitingStartedAt != null` or 100% tail after close with answer).

2. **Fill with response action:**  
   When Beast reacts (genetic or conditional), `actionImageId` is written via `EpisodicMemory_setLastFrameActionFromActionId(actionId)`. Uses `stimulusImageId` already in frame (works with delayed reaction or cleared stimuli).

3. **Close frame:**
   - **Response stimulus during wait:** OR **first** checks `EpisodicMemory_isInWaitingPeriod()`. If true, stimulus is operator answer — `closeLastFrame` with response image (`EpisodicMemory_closeLastFrameWithResponse`). `OR_well_known` **not** checked. Then **new** open frame (`save_episodic_memory`) for answer image, flag `OrientationReflex_resumeFullOrAfterWaitingResponse`, OR **re-invoked** same activation: second pass full (hippocampus, `stimuls_consciousness` with OR winner context, `save_episodic_memory`) so new consciousness cycle and EP frame start without “thought silence” blocking the OR winner.
   - **Wait expires without response:** in `EpisodicMemory_onPulse` at `response_waiting_period` pulses, frame **closes** (`closeLastFrame`), not removed. If no reaction (`actionImageId` still `null`), zeros in rule fields (AID and response → 0), ignore/no-answer indicators, full close pipeline including **abstractions** (`AbstractImages_cloneFromEpisodeFrame`). If reaction existed, close with recorded `actionImageId`, no zero on AID.
   - **Closed** frame `effect` is **always** a number in **[-10, +10]** (clamped `getDiffImportance` delta or 0 without `diffBefore`).

While frame is open without `effect`, “foreign” stimulus in main path is treated as operator answer; after close and new frame for answer, **full** OR follows (see above), not close-only without consciousness.

**Shared effect (EP ↔ automatisms):** on close, same computed `effect` (after clamp [-10,+10]) is stored in EP and passed to default branch automatism via `Automatizms_addUsefulnessSample(staff.id, last.effect)`. Single evaluation — no duplicate or divergent EP vs automatism scores.

**Abstractions:** see §9 below and `about_episodic_memory.md` (“Link to abstract images”).

---

## 4. Orientation reflex (OR) and EP conditions

OR runs on stimulus activation (e.g. click). **Check order in OR:**

1. **No active stimuli** — empty array (deactivation). OR exits **without message**; existing EP frame and wait are not canceled.
2. No perception branch / no winner — exit with message in test mode.
3. Register exposure in semantic memory (once per activation).
4. **“Second full pass” after answer:** if `OrientationReflex_resumeFullOrAfterWaitingResponse`, clear flag; `OR_well_known` **not** checked; full path as in step 7 (OR context to `stimuls_consciousness` with winner flag — see `about_conscience.md`).
5. **Else — wait check:** if `EpisodicMemory_isInWaitingPeriod()`, handle response branch (close frame, open next, schedule step 4, recursive `runOROnStimulusActivation`). `OR_well_known` **not** applied to response stimulus.
6. **Then** knownness: if winner `samplesCount < OR_well_known` (default 10) — reject new frame, test message (in Bad state threshold may be waived; see `orientation_reflex.js`).
7. Else — reflex block, hippocampus, `stimuls_consciousness(orContext)`, `save_episodic_memory(terminalNodeId, winnerId)`. Frame and bar **always** on this OR pass.

**Wait:** `isInWaitingPeriod()` true only if `EpisodicMemory_waitingStartedAt != null`, last frame without effect, pulse count below limit. Open frame loaded from IndexedDB after reload is not active wait (`waitingStartedAt` not restored) so first click creates new frame with bar from 0%.

---

## 5. EP formation test mode

Toggle with **t** in “Active perception tree branch.” Flag: `global.EpisodicMemory_testMode`.

**In test mode:**

- **Deactivation** (no active stimuli) — **no** message (normal).
- **Reject** new frame (when wait not active) — reasons shown:
  - missing perception-tree functions or images;
  - branch not found/created;
  - no most salient stimulus among candidates;
  - weak semantic experience (`samplesCount < OR_well_known`) — **does not apply** to response stimulus during wait.
- **Frame start** — “EP frame formation started. Stimulus: (detail). Waiting for answer or reaction. Wait bar started.”
- **Response action fixed** — “Stimulus image activated: (detail). Reaction: (detail). Answer wait started.”
- **Response stimulus during wait** — “Stimulus during wait: (detail). Episode frame completed and saved.”
- **Wait timeout without reaction** — frame **closes with zeros**; test message explains episode recorded and perception abstraction strengthened per effect (wording in `episodic_memory.js`).

Progress bar follows session wait rules regardless of test mode; test mode adds step messages only.

---

## 6. Conditional reflexes vs orientation reflex

**Rule:** if a stimulus **drew the orientation reflex**, **no conditional reflex formation** runs for it.

**Mechanism:**

1. OR **blocks** genetic (or conditional) reflex for 2 pulses (`OR_BLOCK_PULSES`). Reflex does not run immediately; event goes to `delayedReflexes`.
2. On enqueue and when delayed reflex runs, event carries **`noConditionalReflex: true`**.
3. Delayed reflex in `startAction` with `noConditionalReflex: true` **skips** `synonyms_onGeneticActionFired` — conditional reflex subsystem does not form/strengthen CR for that stimulus.

Thus stimuli that triggered OR (reflex was delayed) do not participate in CR formation; CR forms only for stimuli whose reflex fired without OR block.

---

## 7. Linked EP frame chains: priority over “interrupting” stimuli

**Motivation.** Several EP frames in a row can form a chain (e.g. action → operator answer → next stimulus). Stimuli in that chain should not lose competition to unrelated active stimuli without recorded reaction or ongoing answer scenario — or the chain keeps breaking.

**Definition (suffix chain).** From the end of `Episodes`, walk backward counting consecutive frames where **each** has nonzero `actionImageId` (reaction bound). If suffix length **≥** `EpisodicMemory_chainPriorityMinFrames` (default **2**), all `stimulusImageId` and nonzero `responseStimulusImageId` in those frames are **chain-priority** stimuli.

**Implementation.**

- `EpisodicMemory_getChainPriorityStimulusSet()` — id set or `null` if no chain.
- `EpisodicMemory_isStimulusEpisodicChainPriority(finalImageId)` — single-stimulus check.

**OR** (`findMostActualStimulus`): for chain-priority candidates **no** hysteresis subtraction vs previous winner; salience **boosted** (linear scale + offset) so chain-continuing stimulus wins when otherwise tied.

**Consciousness, main cycle** (`stimuls_consciousness`): dampening for competing stimulus (“thought silence”) and `INTERRUPT_THRESHOLD_ATTENTION_RATIO` apply **only while a main cycle exists and is not `expired`**. If no main or it finished, those limits do not apply.

Additionally:

- **Chain-priority** stimulus: no theme/situation mismatch multiplier, no `ImportantProblem` penalty, interrupt threshold coefficient **1.0**;
- Stimulus passed from OR as **competition winner** (`orientationReflexWinner` in context) is **not** cut by “thought silence” vs current main — else OR would pick salient stimulus but consciousness would not start.

A single isolated frame with reaction does **not** qualify; need **at least two** consecutive suffix frames.

---

## 8. Key constants and flags

| Parameter | Description | Default |
|-----------|-------------|---------|
| `response_waiting_period` | Answer wait length (**pulses**) | 15 |
| `OR_well_known` | Semantic sample threshold to **start** new OR/EP process (not for response stimulus) | 10 |
| `EpisodicMemory_testMode` | Step messages for EP formation | false |
| `OR_BLOCK_PULSES` | Pulses to block reflex after OR | 2 |
| `EpisodicMemory_chainPriorityMinFrames` | Min suffix length of frames with `actionImageId` for chain priority in OR/consciousness | 2 |

**Progress bar:** visible only if `EpisodicMemory_waitingStartedAt != null` or `EpisodicMemory_barShowCompletePulsesLeft > 0` (active session wait or 100% tail after close with answer). After page reload, hidden until stimulus activation starts OR again.

**isInWaitingPeriod():** true only if `EpisodicMemory_waitingStartedAt != null` (wait started this session). Loaded open frame does not yield true so first post-reload click creates new frame with bar from 0%.

Implementation files: `_10_Episodic_memory/episodic_memory.js`, `_8_Hippocampus/orientation_reflex.js`, `_7_perception_tree/perception_tree.js`, `_5_Genetic__reflexes/genetic_reflexes_engine.js`.

---

## 9. Effect, rule-field zeros, abstractions (summary)

| Moment | Behavior |
|--------|----------|
| Frame close | `effect` ∈ [-10, +10], always number; see `clampEpisodeFrameEffect` |
| Missing AID or answer at close | `episodicFrameFillRuleZerosForIncompleteClose` → **0** in empty slots (closed frame slots not `null`) |
| Timeout, no reaction | No `ep.pop`: zeros + `closeLastFrame(null)` + abstractions / mental rules |
| New OR with previous frame open | Zeros on previous if needed + `closeLastFrame(new stimulus)` |
| Compact save | `"0"` in action/response parses as **0**, not `null` (`parseIntOrNull`) |
| `abstract_images.js` | Always from `closeLastFrame`; action clone only if `actionImageId` nonzero; **0** means no action clone |

Implementation: `episodic_memory.js` (`closeLastFrame`, `EpisodicMemory_onPulse`, `episodicFrameFillRuleZerosForIncompleteClose`), `abstract_images.js`, `mental_automatism.js` (`MentalRules_registerFromEpisodeFrame`).
