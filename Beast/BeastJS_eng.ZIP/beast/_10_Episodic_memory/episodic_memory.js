/**
 * Episodic memory (EP).
 *
 * EP — array with strict historical order of episode frames.
 * Order is not shuffled; edits and deletes are allowed without reordering.
 *
 * Rule (episode frame): stimulus (FinalImage) → response action (actions_image) → effect (Effect).
 * Effect = getDiffImportance() before stimulus activation minus getDiffImportance() at first stimulus
 * after actions complete. Wait period is in pulses (RESPONSE_WAITING_PULSES), not a wall-clock timer.
 *
 * Frame fields: perceptionNodeId, stimulusImageId, situationId, actionImageId, effect, responseStimulusImageId.
 * AnswerID + responseStimulusImageId — teacher rule: how to respond to the action.
 * Open frame: effect === null. After close (closeLastFrame) effect is always a number in [-10, +10].
 * Wait expiry without reaction: frame is not removed — zeros fill missing action image / response stimulus, frame closes, abstractions / mental rules run like any close.
 * Frames with unfilled effect in a saved snapshot are left for sleep-time optimization.
 *
 * CONTINUITY OF EFFECT SCORING (EP ↔ automatisms):
 * The same effect is computed in EP (closeLastFrame: effect = clamp(diffAfter - diffBefore) in [-10,+10]) and passed
 * to the branch default automatism via addUsefulnessSample(automatizmId, last.effect). Effect scoring
 * is single-source: not duplicated, not divergent. Automatism usefulness averages the same values
 * as EP frames (reflex or automatism fired → frame closed → one effect → one automatism sample).
 */
(function (global) {
  'use strict';

  /** Wait period length in pulses (EpisodicMemory_onPulse from puls.js). */
  var response_waiting_period = 15;
  var pulsesWaiting = 0;
  /** Show progress bar at 100% for N more pulses after closing frame with response. */
  var barShowCompletePulsesLeft = 0;

  global.EpisodicMemory_waitingStartedAt = null;
  global.EpisodicMemory_testMode = false;
  global.EpisodicMemory_pulsesWaiting = 0;
  /** Consciousness automatism ID whose effect is averaged when current open frame closes (cleared after write). */
  global.EpisodicMemory_pendingFeedbackAutomatizmId = 0;
  /** Comprehension cycle id where automatism was started (EP frame wait period). */
  global.EpisodicMemory_waitingAutomatismCycleId = 0;
  /** Effect of frame just closed (for L2 on operator response). */
  global.EpisodicMemory_lastClosedFrameEffect = null;

  if (!Array.isArray(global.Episodes)) {
    global.Episodes = [];
  }

  /**
   * Closed EP frame effect scale: always a finite number in [-10, +10].
   * Same meaning as semantic importance scale; diff outliers are clamped.
   */
  var EPISODE_EFFECT_MIN = -10;
  var EPISODE_EFFECT_MAX = 10;

  function clampEpisodeFrameEffect(n) {
    if (typeof n !== 'number' || isNaN(n)) return 0;
    if (n < EPISODE_EFFECT_MIN) return EPISODE_EFFECT_MIN;
    if (n > EPISODE_EFFECT_MAX) return EPISODE_EFFECT_MAX;
    return n;
  }

  /**
   * Whether answer wait is active (open frame started this session, pulse counter below limit).
   * If last frame was loaded from IndexedDB with effect === null, waitingStartedAt stays null — not treated as active wait,
   * so first click after reload creates a new frame with progress from 0%, not closing old with 100% display.
   */
  function isInWaitingPeriod() {
    if (global.EpisodicMemory_waitingStartedAt == null) return false;
    var ep = global.Episodes;
    if (!ep.length) return false;
    var last = ep[ep.length - 1];
    if (last.effect !== null && last.effect !== undefined) return false;
    return pulsesWaiting < response_waiting_period;
  }

  /**
   * Close last frame: compute effect and optionally record response stimulus.
   * CONTINUITY: same effect is written to EP frame and passed to branch default automatism
   * (addUsefulnessSample) — single effect score for EP and automatism.
   *
   * Abstractions (`abstract_images.js`): AbstractImages_cloneFromEpisodeFrame(last) runs at end;
   * by then effect is numeric in [-10,+10], and rule gaps are pre-filled with zeros if needed
   * — see episodicFrameFillRuleZerosForIncompleteClose.
   *
   * @param {number|null} responseStimulusImageId — response stimulus image ID (or null)
   */
  function closeLastFrame(responseStimulusImageId) {
    var ep = global.Episodes;
    if (!ep.length) return;
    var last = ep[ep.length - 1];
    if (last.effect !== null && last.effect !== undefined) return;
    var waitCycleId = typeof global.EpisodicMemory_waitingAutomatismCycleId === 'number'
      ? global.EpisodicMemory_waitingAutomatismCycleId : 0;
    // Closed frame effect is never non-numeric: with valid diffBefore — clamp(Δdiff), else 0 (neutral).
    if (typeof global.getDiffImportance === 'function') {
      var diffAfter = global.getDiffImportance();
      var before = last.diffBefore;
      if (typeof before === 'number' && !isNaN(before)) {
        last.effect = clampEpisodeFrameEffect(diffAfter - before);
      } else {
        last.effect = 0;
      }
    } else {
      last.effect = 0;
    }
    global.EpisodicMemory_lastClosedFrameEffect = last.effect;
    if (responseStimulusImageId != null && waitCycleId && typeof global.Consciousness_getCycle === 'function') {
      var oc = global.Consciousness_getCycle(waitCycleId);
      if (oc && oc.awaitingAutomatismEpisodeFeedback) {
        oc.automatismOperatorAnswerReceived = true;
        oc.lastAutomatismEpisodeEffect = last.effect;
        if (typeof global.Info_setField === 'function') {
          global.Info_setField('isOperatorAnswerReceived', 1);
        } else if (global.InfoPicture) {
          global.InfoPicture.isOperatorAnswerReceived = 1;
        }
        if (typeof global.Consciousness_cycleAppendLog === 'function') {
          var pcEp = typeof global.cpuls === 'number' ? global.cpuls : 0;
          var effStr = String(last.effect);
          global.Consciousness_cycleAppendLog(oc, 'EP: frame closed by operator response, automatismOperatorAnswerReceived=1, effect=' + effStr + '.', pcEp, { force: true });
        }
        // Cycle may already be expired / not main (info_automatismWithEpisodeFeedbackAndExpireCycle) — runOneStep may not call L2.
        if (typeof global.conscience_level_2 === 'function') {
          var cxOr = oc.context || {};
          global.conscience_level_2({
            sourceCycle: oc,
            actualId: cxOr.actual_stimul_ID,
            branchId: cxOr.branchId,
            well: cxOr.well,
            emotionId: cxOr.emotionId,
            activityID: cxOr.activityID,
            _operatorAnswerCycleOnly: true
          });
        }
      }
    }
    if (responseStimulusImageId != null) {
      last.responseStimulusImageId = responseStimulusImageId;
      if (global.EpisodicMemory_testMode && typeof global.show_alert === 'function') {
        var respDetail = typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function'
          ? global.PerceptionTree_getStimulusNamesForFinalImageId(responseStimulusImageId)
          : ('ID ' + responseStimulusImageId);
        global.show_alert('Stimulus during wait period: ' + respDetail + '<br>Episode frame completed and saved.', 0);
      }
    }
    // Effect scoring continuity: last.effect → automatism started in consciousness (feedbackAutomatizmId on frame), else branch default.
    if (last.perceptionNodeId != null && typeof global.Automatizms_addUsefulnessSample === 'function') {
      var feedbackAutoId = (typeof last.feedbackAutomatizmId === 'number' && last.feedbackAutomatizmId > 0)
        ? last.feedbackAutomatizmId : 0;
      if (!feedbackAutoId && typeof global.EpisodicMemory_pendingFeedbackAutomatizmId === 'number' &&
          global.EpisodicMemory_pendingFeedbackAutomatizmId > 0) {
        feedbackAutoId = global.EpisodicMemory_pendingFeedbackAutomatizmId;
      }
      if (feedbackAutoId) {
        global.Automatizms_addUsefulnessSample(feedbackAutoId, last.effect);
      } else if (typeof global.Automatizms_getDefaultAutomatizmForBranch === 'function') {
        var staff = global.Automatizms_getDefaultAutomatizmForBranch(last.perceptionNodeId);
        if (staff && staff.id) {
          global.Automatizms_addUsefulnessSample(staff.id, last.effect);
        }
      }
      if (typeof global.PerceptionTree_updateActiveBranchView === 'function') {
        global.PerceptionTree_updateActiveBranchView();
      }
    }
    /**
     * Gestalt (L4): resonance buffer and record updates for closed frame.
     * Called before clearing EpisodicMemory_pendingFeedbackAutomatizmId / waitingAutomatismCycleId
     * to pass waiting automatism id.
     *
     * Scenarios:
     *   — Operator response during wait: waitCycleId > 0, effect numeric, lastFrame has branch/situation/action image.
     *   — Close without response stimulus (responseStimulusImageId == null): effect still numeric; gestalt
     *     gets signal for possible reinterpretation (weak/negative effect).
     *   — Close on new OR stimulus without automatism wait: waitCycleId === 0 — resonance push only
     *     on positive effect (cross-cycle analogy for other goals).
     */
    if (typeof global.Gestalt_onEpisodeFeedbackClosed === 'function') {
      try {
        var feedbackAutoIdForGestalt = 0;
        if (typeof last.feedbackAutomatizmId === 'number' && last.feedbackAutomatizmId > 0) {
          feedbackAutoIdForGestalt = last.feedbackAutomatizmId;
        } else if (typeof global.EpisodicMemory_pendingFeedbackAutomatizmId === 'number' &&
            global.EpisodicMemory_pendingFeedbackAutomatizmId > 0) {
          feedbackAutoIdForGestalt = global.EpisodicMemory_pendingFeedbackAutomatizmId;
        }
        global.Gestalt_onEpisodeFeedbackClosed({
          waitCycleId: waitCycleId,
          lastFrame: last,
          automatismId: feedbackAutoIdForGestalt,
          effect: last.effect
        });
      } catch (eGestalt) {}
    }
    global.EpisodicMemory_pendingFeedbackAutomatizmId = 0;
    global.EpisodicMemory_waitingAutomatismCycleId = 0;
    if (last.feedbackAutomatizmId !== undefined) delete last.feedbackAutomatizmId;
    if (waitCycleId && typeof global.Consciousness_getCycle === 'function') {
      var cWF = global.Consciousness_getCycle(waitCycleId);
      if (cWF) cWF.waitingFeedbackAutomatizmId = 0;
    }
    if (typeof global.InfoDet_updateActiveWaiting === 'function') {
      global.InfoDet_updateActiveWaiting(false);
    }

    if (waitCycleId && typeof global.Consciousness_getCycle === 'function') {
      var cEnd = global.Consciousness_getCycle(waitCycleId);
      // Without response stimulus goal image usefulness (cycle.goalImageId) unchanged — L2 pipeline not invoked.
      if (cEnd && cEnd.awaitingAutomatismEpisodeFeedback && !cEnd.automatismOperatorAnswerReceived) {
        cEnd.awaitingAutomatismEpisodeFeedback = false;
        cEnd.expired = true;
        cEnd.isMainCycle = false;
        if (typeof global.Consciousness_cycleAppendLog === 'function') {
          var pc = typeof global.cpuls === 'number' ? global.cpuls : 0;
          global.Consciousness_cycleAppendLog(cEnd, 'Wait period closed without response stimulus — cycle expired.', pc, { force: true });
        }
        if (typeof global.Info_updateView === 'function') global.Info_updateView();
      }
    }

    // Abstractions (beast/_9_Conscience/abstract_images.js): on each frame close —
    // strengthen/create perception record for (perceptionNodeId, stimulusImageId);
    // action clone — only if actionImageId non-zero (0 after gap fill = no action-image clone).
    var abstractClone = null;
    if (typeof global.AbstractImages_cloneFromEpisodeFrame === 'function') {
      try {
        abstractClone = global.AbstractImages_cloneFromEpisodeFrame(last);
      } catch (e) {
        if (typeof global.console !== 'undefined' && global.console.warn) {
          global.console.warn('AbstractImages_cloneFromEpisodeFrame', e);
        }
      }
    }
    // mental_automatism.js: average mental rule by abstractPerceptionId | abstractActionId and effect.
    if (abstractClone && typeof global.MentalRules_registerFromEpisodeFrame === 'function') {
      try {
        global.MentalRules_registerFromEpisodeFrame(last, abstractClone);
      } catch (e) {}
    }
    if (typeof global.AbstractImages_flushIndexedDB === 'function') {
      try {
        global.AbstractImages_flushIndexedDB();
      } catch (e) {}
    }
    last.diffBefore = undefined;
    pulsesWaiting = 0;
    global.EpisodicMemory_pulsesWaiting = 0;
    global.EpisodicMemory_waitingStartedAt = null;
    barShowCompletePulsesLeft = 2;
    global.EpisodicMemory_barShowCompletePulsesLeft = 2;
    epDirty = true;
  }

  /**
   * Save episode (called from OR on new most salient stimulus).
   * If needed, previous frame is closed first (effect + response stimulus).
   * Then an “empty” frame is appended; timeout close runs on pulses (EpisodicMemory_onPulse).
   *
   * @param {number} perceptionNodeId — terminal perception branch id
   * @param {number} stimulusImageId — stimulus image id (FinalImage)
   */
  function save_episodic_memory(perceptionNodeId, stimulusImageId) {
    var ep = global.Episodes;
    var now = Date.now();
    barShowCompletePulsesLeft = 0;
    global.EpisodicMemory_barShowCompletePulsesLeft = 0;

    if (ep.length > 0) {
      var prev = ep[ep.length - 1];
      if (prev.effect === null || prev.effect === undefined) {
        // New OR winner closes previous open frame: response stimulus = stimulusImageId.
        // If previous frame lacks action image or response — rule fields zeroed, then closeLastFrame.
        episodicFrameFillRuleZerosForIncompleteClose(prev);
        closeLastFrame(stimulusImageId);
      }
    }

    var diffBefore = (typeof global.PrevDiffForEpisode === 'number' && !isNaN(global.PrevDiffForEpisode))
      ? global.PrevDiffForEpisode
      : (typeof global.getDiffImportance === 'function' ? global.getDiffImportance() : null);
    var situationId = 0;
    if (typeof global.Info_initIfNeeded === 'function') {
      try {
        var info = global.Info_initIfNeeded();
        if (info && typeof info.situationId === 'number') {
          situationId = info.situationId || 0;
        }
      } catch (e) {}
    }
    ep.push({
      perceptionNodeId: perceptionNodeId || 0,
      stimulusImageId: stimulusImageId || 0,
      situationId: situationId,
      actionImageId: null,
      diffBefore: diffBefore,
      effect: null,
      responseStimulusImageId: null,
      createdAt: now
    });
    epDirty = true;
    pulsesWaiting = 0;
    global.EpisodicMemory_pulsesWaiting = 0;
    global.EpisodicMemory_waitingStartedAt = now;
    barShowCompletePulsesLeft = 0;
    global.EpisodicMemory_barShowCompletePulsesLeft = 0;
  }

  /**
   * Called from puls.js each pulse. Counts wait pulses and at limit closes frame without answer.
   * No wall timers — tied to pulse; frozen tab does not catch up.
   *
   * Two outcomes after response_waiting_period:
   * — no reaction (empty actionImageId): zeros for action image and response stimulus, closeLastFrame (frame kept, perception abstraction);
   * — reaction recorded, no operator answer: closeLastFrame(null) without removing frame.
   */
  function EpisodicMemory_onPulse() {
    if (barShowCompletePulsesLeft > 0) {
      barShowCompletePulsesLeft--;
      global.EpisodicMemory_barShowCompletePulsesLeft = barShowCompletePulsesLeft;
      if (barShowCompletePulsesLeft === 0) {
        global.EpisodicMemory_waitingStartedAt = null;
      }
      return;
    }
    var ep = global.Episodes;
    if (!ep.length) return;
    var last = ep[ep.length - 1];
    if (last.effect !== null && last.effect !== undefined) return;
    pulsesWaiting++;
    global.EpisodicMemory_pulsesWaiting = pulsesWaiting;
    if (pulsesWaiting < response_waiting_period) return;
    pulsesWaiting = 0;
    global.EpisodicMemory_pulsesWaiting = 0;
    global.EpisodicMemory_waitingStartedAt = null;
    // Timeout without motor reaction: previously frame removed (ep.pop); now close with zero action image/response and full EP+abstraction pipeline.
    if (last.actionImageId === null || last.actionImageId === undefined) {
      if (global.EpisodicMemory_testMode && typeof global.show_alert === 'function' && last.stimulusImageId) {
        var stimDetail2 = typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function'
          ? global.PerceptionTree_getStimulusNamesForFinalImageId(last.stimulusImageId)
          : ('ID ' + last.stimulusImageId);
        global.show_alert('No reaction to stimulus (' + stimDetail2 + ').<br>EP frame closes: zeros for missing action image and response stimulus; perception abstraction strengthened by effect.', 0);
      }
      if (typeof global.InfoDet_updateOperatorIgnoring === 'function') {
        global.InfoDet_updateOperatorIgnoring(true);
      }
      if (typeof global.InfoDet_updateOperatorAnswer === 'function') {
        global.InfoDet_updateOperatorAnswer(false);
      }
      episodicFrameFillRuleZerosForIncompleteClose(last);
      closeLastFrame(null);
      if (typeof global.Consciousness_getMainCycle === 'function') {
        var mcNoAct = global.Consciousness_getMainCycle();
        if (mcNoAct) mcNoAct.waitingFeedbackAutomatizmId = 0;
      }
    } else {
      // Reaction was recorded; response stimulus missing — frame closes with known actionImageId.
      // Wait period ended after reaction without response stimulus —
      // operator ignored the action.
      if (typeof global.InfoDet_updateOperatorIgnoring === 'function') {
        global.InfoDet_updateOperatorIgnoring(true);
      }
      // Operator answer not received within allotted period.
      if (typeof global.InfoDet_updateOperatorAnswer === 'function') {
        global.InfoDet_updateOperatorAnswer(false);
      }
      closeLastFrame(null);
    }
  }

  /**
   * Fill last frame with action image id (AnswerID).
   * @param {number} actionImageId — action image id
   */
  function setLastFrameActionImageId(actionImageId) {
    var ep = global.Episodes;
    if (!ep.length || actionImageId == null) return;
    var last = ep[ep.length - 1];
    if (last.actionImageId !== null) return;
    last.actionImageId = actionImageId;
    epDirty = true;
  }

  /**
   * Record response action in last frame from actionId.
   * Uses stimulusImageId already in frame (not current stimuli)
   * so frame fills on delayed reflex or when stimuli already cleared.
   * Called from startAction after reaction fires.
   *
   * @param {number} actionId — action id (BasicActions)
   */
  function setLastFrameActionFromActionId(actionId) {
    if (!actionId) return;
    var ep = global.Episodes;
    if (!ep.length) return;
    var last = ep[ep.length - 1];
    if (last.actionImageId !== null) return;
    var stimulusImageId = last.stimulusImageId;
    if (!stimulusImageId || typeof global.ActionImages_registerReaction !== 'function') return;
    var odId = 0;
    try {
      odId = global.ActionImages_registerReaction(stimulusImageId, actionId);
    } catch (e) {}
    if (odId) {
      last.actionImageId = odId;
      if (typeof global.EpisodicMemory_pendingFeedbackAutomatizmId === 'number' &&
          global.EpisodicMemory_pendingFeedbackAutomatizmId > 0) {
        last.feedbackAutomatizmId = global.EpisodicMemory_pendingFeedbackAutomatizmId;
        global.EpisodicMemory_pendingFeedbackAutomatizmId = 0;
      }
      epDirty = true;
      // Create automatism from action image; effect written on frame close (scoring continuity).
      var pnId = last.perceptionNodeId;
      if (pnId && typeof global.Automatizms_createAutomatizm === 'function') {
        var aId = global.Automatizms_createAutomatizm(pnId, odId);
        if (aId) {
          var list = (typeof global.Automatizms_getAutomatizmsByBranchId === 'function')
            ? global.Automatizms_getAutomatizmsByBranchId(pnId) : [];
          if (list && list.length === 1 && typeof global.Automatizms_setDefaultAutomatizm === 'function') {
            global.Automatizms_setDefaultAutomatizm(aId);
          }
          if (typeof global.PerceptionTree_updateActiveBranchView === 'function') {
            global.PerceptionTree_updateActiveBranchView();
          }
        }
      }
      if (global.EpisodicMemory_testMode && typeof global.show_alert === 'function') {
        var stimDetail = typeof global.PerceptionTree_getStimulusNamesForFinalImageId === 'function'
          ? global.PerceptionTree_getStimulusNamesForFinalImageId(stimulusImageId)
          : ('ID ' + stimulusImageId);
        var actDetail = typeof global.PerceptionTree_getActionNamesForActionImage === 'function'
          ? global.PerceptionTree_getActionNamesForActionImage(odId)
          : ('ID ' + odId);
        global.show_alert('Stimulus image activated: ' + stimDetail + '<br>Reaction that fired: ' + actDetail + '<br>Answer wait period started.', 0);
      }
    }
  }

  var epDirty = false;
  var lastEpSavedSig = '';

  /**
   * Compact frame serialization: perceptionNode|stimulus|situation|action|effect|response.
   * Empty segment on parse → null. Explicit "0" for action/response stored as number 0
   * (missing action image or response in rule); see parseIntOrNull — do not use (x||null) or 0 is lost.
   */
  var EP_SEP = '|';

  /**
   * Before closeLastFrame: replace missing parts of teacher rule with 0 so frame stays a valid record.
   * Open frame keeps null in unfilled fields; 0 after close means “component absent” (timeout, broken scenario).
   */
  function episodicFrameFillRuleZerosForIncompleteClose(frame) {
    if (!frame || frame.effect !== null && frame.effect !== undefined) return;
    if (frame.actionImageId === null || frame.actionImageId === undefined) {
      frame.actionImageId = 0;
    }
    if (frame.responseStimulusImageId === null || frame.responseStimulusImageId === undefined) {
      frame.responseStimulusImageId = 0;
    }
  }

  function serializeState() {
    var lines = [];
    if (Array.isArray(global.Episodes)) {
      for (var i = 0; i < global.Episodes.length; i++) {
        var f = global.Episodes[i];
        if (!f) continue;
        var a = f.perceptionNodeId != null ? String(f.perceptionNodeId) : '';
        var b = f.stimulusImageId != null ? String(f.stimulusImageId) : '';
        var c = f.situationId != null ? String(f.situationId) : '';
        var d = f.actionImageId != null ? String(f.actionImageId) : '';
        var e = (f.effect !== null && f.effect !== undefined) ? String(f.effect) : '';
        var r = f.responseStimulusImageId != null ? String(f.responseStimulusImageId) : '';
        lines.push(a + EP_SEP + b + EP_SEP + c + EP_SEP + d + EP_SEP + e + EP_SEP + r);
      }
    }
    return {
      compact: lines.join('\n'),
      response_waiting_period: response_waiting_period
    };
  }

  function parseCompactLine(line) {
    var parts = line.split(EP_SEP);
    // Legacy lines may lack situationId (5 fields).
    // New format: perceptionNodeId|stimulusImageId|situationId|actionImageId|effect|responseStimulusImageId
    var p = parts[0];
    var s = parts[1];
    var sit = parts.length > 5 ? parts[2] : ''; // old format: situationId treated as 0
    var a = parts.length > 5 ? parts[3] : (parts[2] || '');
    var ef = parts.length > 5 ? parts[4] : (parts[3] || '');
    var r = parts.length > 5 ? parts[5] : (parts[4] || '');
    var eff = ef === '' ? null : parseFloat(ef);
    if (eff !== null && isNaN(eff)) eff = null;
    /** Empty string → null; else integer (including 0). Needed for frames with zero action/response after timeout. */
    function parseIntOrNull(str) {
      if (str === '') return null;
      var x = parseInt(str, 10);
      return isNaN(x) ? null : x;
    }
    return {
      perceptionNodeId: p === '' ? 0 : parseInt(p, 10) || 0,
      stimulusImageId: s === '' ? 0 : parseInt(s, 10) || 0,
      situationId: sit === '' ? 0 : (parseInt(sit, 10) || 0),
      actionImageId: parseIntOrNull(a),
      effect: eff,
      responseStimulusImageId: parseIntOrNull(r),
      createdAt: 0
    };
  }

  function applyState(state) {
    if (!state) return;
    var list = [];
    if (typeof state.compact === 'string' && state.compact.length >= 0) {
      var lineArr = state.compact.split('\n');
      for (var i = 0; i < lineArr.length; i++) {
        var line = lineArr[i].trim();
        if (!line) continue;
        list.push(parseCompactLine(line));
      }
    } else if (Array.isArray(state.episodes)) {
      for (var j = 0; j < state.episodes.length; j++) {
        var o = state.episodes[j];
        if (!o) continue;
        list.push({
          perceptionNodeId: o.perceptionNodeId != null ? o.perceptionNodeId : 0,
          stimulusImageId: o.stimulusImageId != null ? o.stimulusImageId : 0,
          situationId: o.situationId != null ? o.situationId : 0,
          actionImageId: o.actionImageId != null ? o.actionImageId : null,
          effect: o.effect != null ? o.effect : null,
          responseStimulusImageId: o.responseStimulusImageId != null ? o.responseStimulusImageId : null,
          createdAt: 0
        });
      }
    }
    global.Episodes = list;
    if (typeof state.response_waiting_period === 'number' && state.response_waiting_period > 0) {
      response_waiting_period = state.response_waiting_period;
    }
  }

  var epDb = null;
  var EP_DB_NAME = 'BEAST_Episodes_DB';
  var EP_DB_VERSION = 1;
  var EP_STORE = 'episodes_state';
  var EP_KEY = 'episodes_singleton';

  function openEpDb() {
    if (!global.indexedDB || !global.IndexedDBModule) {
      return Promise.reject(new Error('IndexedDB is not supported or the module is not loaded.'));
    }
    if (epDb) return Promise.resolve(epDb);
    return global.IndexedDBModule.openDatabase({
      dbName: EP_DB_NAME,
      version: EP_DB_VERSION,
      stores: [{ name: EP_STORE, options: { keyPath: 'id' } }]
    }).then(function (db) {
      epDb = db;
      return db;
    });
  }

  function saveEpStateToIndexedDB(state) {
    if (!global.IndexedDBModule) return;
    state = state || serializeState();
    function doPut(db) {
      return global.IndexedDBModule.put({
        db: db,
        storeName: EP_STORE,
        value: { id: EP_KEY, state: state, ts: Date.now() }
      }).catch(function () {});
    }
    if (epDb) {
      doPut(epDb);
      return;
    }
    openEpDb().then(doPut).catch(function () {});
  }

  function loadEpStateFromIndexedDB() {
    if (!global.IndexedDBModule) return;
    openEpDb()
      .then(function (db) {
        return global.IndexedDBModule.get({
          db: db,
          storeName: EP_STORE,
          key: EP_KEY
        });
      })
      .then(function (record) {
        if (record && record.state) {
          applyState(record.state);
          lastEpSavedSig = JSON.stringify(serializeState());
        }
      })
      .catch(function () {});
  }

  if (typeof global.registerIndexedDBSaver === 'function') {
    global.registerIndexedDBSaver(function () {
      if (!epDirty) return;
      epDirty = false;
      var state = serializeState();
      var sig = JSON.stringify(state);
      if (sig === lastEpSavedSig) return;
      lastEpSavedSig = sig;
      saveEpStateToIndexedDB(state);
    });
  }

  function clearAllEpisodicMemory() {
    global.Episodes = [];
    global.EpisodicMemory_pendingFeedbackAutomatizmId = 0;
    global.EpisodicMemory_waitingAutomatismCycleId = 0;
    global.EpisodicMemory_lastClosedFrameEffect = null;
    global.EpisodicMemory_waitingStartedAt = null;
    pulsesWaiting = 0;
    global.EpisodicMemory_pulsesWaiting = 0;
    barShowCompletePulsesLeft = 0;
    global.EpisodicMemory_barShowCompletePulsesLeft = 0;
    epDirty = true;
    lastEpSavedSig = '';
    saveEpStateToIndexedDB(serializeState());
  }

  loadEpStateFromIndexedDB();

  if (global.document) {
    function bindClearButton() {
      var btn = global.document.getElementById('btnClearEpisodicMemory');
      if (!btn || btn._epBound) return;
      btn._epBound = true;
      btn.addEventListener('click', function () {
        if (typeof global.show_confirm !== 'function') {
          if (global.confirm('Delete all episodic memory?')) clearAllEpisodicMemory();
          return;
        }
        global.show_confirm('Delete all episodic memory?', function (result) {
          if (result === 'OK') clearAllEpisodicMemory();
        });
      });
    }
    function bindTestModeButton() {
      var btn = global.document.getElementById('btnEpTestMode');
      if (!btn || btn._epTestBound) return;
      btn._epTestBound = true;
      btn.addEventListener('click', function () {
        global.EpisodicMemory_testMode = !global.EpisodicMemory_testMode;
        if (global.EpisodicMemory_testMode) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });
    }
    function bindButtons() {
      bindClearButton();
      bindTestModeButton();
    }
    if (global.document.readyState === 'loading') {
      global.document.addEventListener('DOMContentLoaded', bindButtons);
    } else {
      bindButtons();
    }
  }

  global.save_episodic_memory = save_episodic_memory;
  /**
   * All episodic memory frames (rules) for perception branch and situation branch.
   * @param {number} perceptionNodeId - perception tree branch id (required, >0)
   * @param {number} situationId - situation image id (0 = ignore situation)
   * @returns {Object[]} new array of frames (shallow copy)
   */
  function EpisodicMemory_getFramesByPerceptionAndSituation(perceptionNodeId, situationId) {
    perceptionNodeId = parseInt(perceptionNodeId, 10) || 0;
    situationId = parseInt(situationId, 10) || 0;
    if (!perceptionNodeId || !Array.isArray(global.Episodes)) return [];
    var out = [];
    for (var i = 0; i < global.Episodes.length; i++) {
      var f = global.Episodes[i];
      if (!f) continue;
      if ((f.perceptionNodeId || 0) !== perceptionNodeId) continue;
      if (situationId && (f.situationId || 0) !== situationId) continue;
      // shallow copy — do not mutate original
      out.push({
        perceptionNodeId: f.perceptionNodeId || 0,
        stimulusImageId: f.stimulusImageId || 0,
        situationId: f.situationId || 0,
        actionImageId: f.actionImageId != null ? f.actionImageId : null,
        effect: f.effect != null ? f.effect : null,
        responseStimulusImageId: f.responseStimulusImageId != null ? f.responseStimulusImageId : null,
        createdAt: f.createdAt || 0
      });
    }
    return out;
  }

  /**
   * All episodic memory frames (rules) for stimulus id (FinalImageId).
   * @param {number} stimulusImageId - stimulus image id (FinalImage)
   * @returns {Object[]} new array of frames (shallow copy)
   */
  function EpisodicMemory_getFramesByStimulus(stimulusImageId) {
    stimulusImageId = parseInt(stimulusImageId, 10) || 0;
    if (!stimulusImageId || !Array.isArray(global.Episodes)) return [];
    var out = [];
    for (var i = 0; i < global.Episodes.length; i++) {
      var f = global.Episodes[i];
      if (!f) continue;
      if ((f.stimulusImageId || 0) !== stimulusImageId) continue;
      out.push({
        perceptionNodeId: f.perceptionNodeId || 0,
        stimulusImageId: f.stimulusImageId || 0,
        situationId: f.situationId || 0,
        actionImageId: f.actionImageId != null ? f.actionImageId : null,
        effect: f.effect != null ? f.effect : null,
        responseStimulusImageId: f.responseStimulusImageId != null ? f.responseStimulusImageId : null,
        createdAt: f.createdAt || 0
      });
    }
    return out;
  }

  /**
   * All EP frames where operator response stimulus matches given FinalImageId.
   *
   * Semantics of responseStimulusImageId: “after Beast reaction, operator answered with image of this id”.
   * Passive fantasy (info_fantasizming) picks frames where this id matches current chain focus
   * to build associative continuation from past teacher episodes.
   *
   * @param {number} responseStimulusImageId — usually FinalImageId of answer stimulus; in fantasy chain at step N+1
   *   often actionImageId from step N is passed (next search anchor — see fantasizming.js).
   * @returns {Object[]} field copies + _episodeIndex (index in global.Episodes)
   */
  function EpisodicMemory_getFramesByResponseStimulus(responseStimulusImageId) {
    responseStimulusImageId = parseInt(responseStimulusImageId, 10) || 0;
    if (!responseStimulusImageId || !Array.isArray(global.Episodes)) return [];
    var out = [];
    for (var i = 0; i < global.Episodes.length; i++) {
      var f = global.Episodes[i];
      if (!f) continue;
      var rs = f.responseStimulusImageId != null ? parseInt(f.responseStimulusImageId, 10) : 0;
      if (rs !== responseStimulusImageId) continue;
      out.push({
        _episodeIndex: i,
        perceptionNodeId: f.perceptionNodeId || 0,
        stimulusImageId: f.stimulusImageId || 0,
        situationId: f.situationId || 0,
        actionImageId: f.actionImageId != null ? f.actionImageId : null,
        effect: f.effect != null ? f.effect : null,
        responseStimulusImageId: f.responseStimulusImageId != null ? f.responseStimulusImageId : null
      });
    }
    return out;
  }

  /**
   * Frame with max |effect| among inputs (teacher/episodic rule with non-zero action image).
   *
   * Skips frames without numeric effect or without actionImageId. Used where strong
   * emotional coloring matters regardless of sign (including passive fantasy).
   *
   * @param {Object[]} frames — usually EpisodicMemory_getFramesByResponseStimulus result
   * @returns {Object|null}
   */
  function EpisodicMemory_pickBestFrameByAbsEffect(frames) {
    if (!Array.isArray(frames) || !frames.length) return null;
    var best = null;
    var bestAbs = -1;
    for (var i = 0; i < frames.length; i++) {
      var f = frames[i];
      if (!f || typeof f.effect !== 'number' || isNaN(f.effect)) continue;
      var aid = f.actionImageId != null ? parseInt(f.actionImageId, 10) : 0;
      if (!aid) continue;
      var ab = Math.abs(f.effect);
      if (best === null || ab > bestAbs) {
        bestAbs = ab;
        best = f;
      }
    }
    return best;
  }

  /**
   * From frame array pick one with maximum positive effect and non-zero actionImageId.
   */
  function EpisodicMemory_pickBestPositiveFrame(frames) {
    if (!Array.isArray(frames) || !frames.length) return null;
    var best = null;
    var bestEff = 0;
    for (var i = 0; i < frames.length; i++) {
      var f = frames[i];
      if (!f || typeof f.effect !== 'number' || f.effect <= 0 || f.actionImageId == null || !f.actionImageId) continue;
      if (best === null || f.effect > bestEff) {
        bestEff = f.effect;
        best = f;
      }
    }
    return best;
  }

  /**
   * Like pickBestPositiveFrame but only frames with given stimulus (current FinalImageId of comprehension).
   */
  function EpisodicMemory_pickBestPositiveFrameForStimulus(frames, stimulusImageId) {
    stimulusImageId = parseInt(stimulusImageId, 10) || 0;
    if (!stimulusImageId || !Array.isArray(frames) || !frames.length) return null;
    var best = null;
    var bestEff = 0;
    for (var i = 0; i < frames.length; i++) {
      var f = frames[i];
      if (!f || (f.stimulusImageId || 0) !== stimulusImageId) continue;
      if (typeof f.effect !== 'number' || f.effect <= 0 || f.actionImageId == null || !f.actionImageId) continue;
      if (best === null || f.effect > bestEff) {
        bestEff = f.effect;
        best = f;
      }
    }
    return best;
  }

  /**
   * Find in Episodes tape a chain of frames matching goal image stack (order in Episodes array).
   * goalIdsBottomToTop — Target_rule_stack entries: [bottom … top], as sequence of moves/rules
   * (chess analogy: move → partner reply → next move depends on chain of prior EP frames).
   * Frames between steps may be skipped: find first matching rule, then after it the next, etc.
   * @param {number[]} goalIdsBottomToTop
   * @returns {Object[]|null} original frames from Episodes (same objects as in memory array)
   */
  function EpisodicMemory_findChainForGoalStack(goalIdsBottomToTop) {
    if (!Array.isArray(goalIdsBottomToTop) || !goalIdsBottomToTop.length) return null;
    if (!Array.isArray(global.Episodes) || !global.Episodes.length) return null;

    function signatureForGoalId(gid) {
      var id = parseInt(gid, 10) || 0;
      if (!id || typeof global.Goals_getGoalById !== 'function') return null;
      var g = global.Goals_getGoalById(id);
      if (!g) return null;
      var r = g.episodicRule;
      if (r && typeof r === 'object') {
        return {
          perceptionNodeId: r.perceptionNodeId || g.perceptionNodeId || 0,
          situationId: r.situationId != null ? r.situationId : (g.situationId || 0),
          stimulusImageId: r.stimulusImageId || g.stimulusImageId || 0,
          actionImageId: r.actionImageId != null ? r.actionImageId : g.actionImageId
        };
      }
      return {
        perceptionNodeId: g.perceptionNodeId || 0,
        situationId: g.situationId != null ? g.situationId : 0,
        stimulusImageId: g.stimulusImageId || 0,
        actionImageId: g.actionImageId != null ? g.actionImageId : 0
      };
    }

    function matches(f, sig) {
      if (!f || !sig) return false;
      if ((f.perceptionNodeId || 0) !== (sig.perceptionNodeId || 0)) return false;
      if ((sig.situationId || 0) !== 0 && (f.situationId || 0) !== (sig.situationId || 0)) return false;
      if ((sig.stimulusImageId || 0) !== 0 && (f.stimulusImageId || 0) !== (sig.stimulusImageId || 0)) return false;
      if ((sig.actionImageId || 0) !== 0 && (f.actionImageId || 0) !== (sig.actionImageId || 0)) return false;
      if (typeof f.effect !== 'number' || f.effect <= 0) return false;
      return true;
    }

    var sigs = [];
    for (var s = 0; s < goalIdsBottomToTop.length; s++) {
      var sg = signatureForGoalId(goalIdsBottomToTop[s]);
      if (!sg) return null;
      sigs.push(sg);
    }

    var ep = global.Episodes;
    var bestChain = null;
    var bestSum = -Infinity;

    for (var start = 0; start < ep.length; start++) {
      var idx = start;
      var matched = [];
      for (var j = 0; j < sigs.length; j++) {
        var found = false;
        while (idx < ep.length) {
          var fr = ep[idx];
          idx += 1;
          if (matches(fr, sigs[j])) {
            matched.push(fr);
            found = true;
            break;
          }
        }
        if (!found) {
          matched = null;
          break;
        }
      }
      if (matched && matched.length === sigs.length) {
        var sum = 0;
        for (var m = 0; m < matched.length; m++) sum += matched[m].effect || 0;
        if (sum > bestSum) {
          bestSum = sum;
          bestChain = matched.slice();
        }
      }
    }

    return bestChain;
  }

  /** Minimum consecutive frames with reaction (actionImageId) in Episodes suffix for chain priority. */
  var EPISODIC_CHAIN_PRIORITY_MIN_FRAMES = 2;
  global.EpisodicMemory_chainPriorityMinFrames = EPISODIC_CHAIN_PRIORITY_MIN_FRAMES;

  /**
   * Set of FinalImageId stimuli in EP “tail” chain: consecutive from array end,
   * each with recorded reaction (actionImageId). Uses stimulusImageId and responseStimulusImageId of frames.
   * Single-frame chain does not count — need ≥ EpisodicMemory_chainPriorityMinFrames (default 2).
   * @returns {Object|null} map { "id": true } or null if no chain
   */
  function EpisodicMemory_getChainPriorityStimulusSet() {
    var ep = global.Episodes;
    var minN = typeof global.EpisodicMemory_chainPriorityMinFrames === 'number' && global.EpisodicMemory_chainPriorityMinFrames >= 2
      ? global.EpisodicMemory_chainPriorityMinFrames
      : EPISODIC_CHAIN_PRIORITY_MIN_FRAMES;
    if (!Array.isArray(ep) || ep.length < minN) return null;
    var run = 0;
    var i = ep.length - 1;
    while (i >= 0) {
      var f = ep[i];
      if (!f || f.actionImageId == null || !f.actionImageId) break;
      run++;
      i--;
    }
    if (run < minN) return null;
    var set = Object.create(null);
    for (var j = ep.length - run; j < ep.length; j++) {
      var fr = ep[j];
      if (!fr) continue;
      if (fr.stimulusImageId) set[String(fr.stimulusImageId)] = true;
      if (fr.responseStimulusImageId) set[String(fr.responseStimulusImageId)] = true;
    }
    return set;
  }

  /**
   * Stimulus (FinalImageId) belongs to active EP reaction-frame chain — for OR/consciousness priority.
   */
  function EpisodicMemory_isStimulusEpisodicChainPriority(stimulusFinalImageId) {
    var id = parseInt(stimulusFinalImageId, 10) || 0;
    if (!id) return false;
    var s = EpisodicMemory_getChainPriorityStimulusSet();
    return !!(s && s[String(id)]);
  }

  global.EpisodicMemory_setLastFrameActionImageId = setLastFrameActionImageId;
  global.EpisodicMemory_setLastFrameActionFromActionId = setLastFrameActionFromActionId;
  global.EpisodicMemory_clearAll = clearAllEpisodicMemory;
  global.EpisodicMemory_serializeState = serializeState;
  global.EpisodicMemory_applyState = applyState;
  global.EpisodicMemory_response_waiting_period = response_waiting_period;
  global.EpisodicMemory_isInWaitingPeriod = isInWaitingPeriod;
  global.EpisodicMemory_closeLastFrameWithResponse = closeLastFrame;
  global.EpisodicMemory_onPulse = EpisodicMemory_onPulse;
  global.EpisodicMemory_barShowCompletePulsesLeft = 0;
  global.EpisodicMemory_getFramesByPerceptionAndSituation = EpisodicMemory_getFramesByPerceptionAndSituation;
  global.EpisodicMemory_getFramesByStimulus = EpisodicMemory_getFramesByStimulus;
  global.EpisodicMemory_getFramesByResponseStimulus = EpisodicMemory_getFramesByResponseStimulus;
  global.EpisodicMemory_pickBestFrameByAbsEffect = EpisodicMemory_pickBestFrameByAbsEffect;
  global.EpisodicMemory_pickBestPositiveFrame = EpisodicMemory_pickBestPositiveFrame;
  global.EpisodicMemory_pickBestPositiveFrameForStimulus = EpisodicMemory_pickBestPositiveFrameForStimulus;
  global.EpisodicMemory_findChainForGoalStack = EpisodicMemory_findChainForGoalStack;
  global.EpisodicMemory_getChainPriorityStimulusSet = EpisodicMemory_getChainPriorityStimulusSet;
  global.EpisodicMemory_isStimulusEpisodicChainPriority = EpisodicMemory_isStimulusEpisodicChainPriority;

  /**
   * “Empty” frame for sleep refinement (sleep_dream_process): stimulus and action image present, no response stimulus, no numeric effect.
   */
  function EpisodicMemory_isEmptyFrameForSleep(f) {
    if (!f) return false;
    var stim = f.stimulusImageId || 0;
    var act = f.actionImageId != null ? parseInt(f.actionImageId, 10) : 0;
    if (stim <= 0 || act <= 0) return false;
    var rs = f.responseStimulusImageId != null ? parseInt(f.responseStimulusImageId, 10) : 0;
    if (rs > 0) return false;
    if (f.effect !== null && f.effect !== undefined) return false;
    return true;
  }

  /**
   * Indices of empty frames in Episodes newest-first — dream iteration order.
   */
  function EpisodicMemory_collectEmptyFrameIndicesNewestFirst() {
    var ep = global.Episodes;
    if (!Array.isArray(ep) || !ep.length) return [];
    var out = [];
    for (var i = ep.length - 1; i >= 0; i--) {
      if (EpisodicMemory_isEmptyFrameForSleep(ep[i])) out.push(i);
    }
    return out;
  }

  global.EpisodicMemory_isEmptyFrameForSleep = EpisodicMemory_isEmptyFrameForSleep;
  global.EpisodicMemory_collectEmptyFrameIndicesNewestFirst = EpisodicMemory_collectEmptyFrameIndicesNewestFirst;

  function EpisodicMemory_markDirty() {
    epDirty = true;
  }
  global.EpisodicMemory_markDirty = EpisodicMemory_markDirty;

})(window);
