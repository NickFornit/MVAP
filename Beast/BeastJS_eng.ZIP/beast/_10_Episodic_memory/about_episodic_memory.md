# Episodic memory (_10_Episodic_memory)

## Purpose

The module implements **episodic memory (EP)** — an array of frames in strict historical order. Each frame is a rule: stimulus (FinalImage) → response action (action image, AID) → effect (difference of getDiffImportance before and after) → operator response stimulus (if any during wait). Frames are created only through the orientation reflex when semantic experience and wait-period conditions are met.

## Core concepts

- **Episode frame:** perceptionNodeId, stimulusImageId, actionImageId, effect, responseStimulusImageId. Response action + response stimulus form a “teacher” rule.
- **Answer wait period** — `response_waiting_period` pulses (default 15). Timeout close runs in EpisodicMemory_onPulse (from puls.js), no setTimeout; tab hang stays aligned with pulse.
- **Test mode** (`EpisodicMemory_testMode`) — step messages for OR checks, frame start, response stimulus, reject; does not control progress bar visibility.

## Behavior notes

- **Frame creation and progress bar:** on each **full** OR pass (after `OR_well_known`, or second pass after answer during wait — see rules), `save_episodic_memory` runs — frame is created and wait bar starts, not only in test mode.
- **Progress bar only when wait active this session:** bar container shows only if `EpisodicMemory_waitingStartedAt != null` or `EpisodicMemory_barShowCompletePulsesLeft > 0`. After reload these are not restored from IndexedDB, so bar is hidden until a stimulus activation starts OR again.
- **Wait only in current session:** `isInWaitingPeriod()` is true only when `EpisodicMemory_waitingStartedAt != null`. An open frame loaded from IndexedDB (`effect === null`) is **not** “active wait” — first click after reload creates a new frame with bar from 0%, not closing the old with 100%.
- **Stimulus deactivation:** clearing all stimuli exits OR without message. Existing EP frame and wait are not canceled; stimulus is already stored in the frame.
- **Operator response stimulus:** activation during wait closes the frame (`closeLastFrame` / `EpisodicMemory_closeLastFrameWithResponse`), opens the next frame, and runs **full OR again**: new consciousness cycle and another `save_episodic_memory`. `OR_well_known` is **not** checked for this answer step.

## Shared effect evaluation (EP ↔ automatisms)

**Single effect value:** same computation in EP and passed to automatism.

- In **closeLastFrame**, effect once: `effect = getDiffImportance() (after) − diffBefore` stored in EP (`last.effect`).
- Same `last.effect` goes to branch default automatism via **Automatizms_addUsefulnessSample(staff.id, last.effect)**.
- No duplicate or divergent evaluation — one effect value for EP frame and usefulness update (averaged by count). This keeps EP and automatism scoring aligned.

- **Gestalt (level 4):** after writing `effect` to the frame, before clearing automatism-wait globals, **`Gestalt_onEpisodeFeedbackClosed`** (`gestalt.js`): **resonance buffer** gets a close signature; if waiting cycle has **`goalImageId`**, matching gestalt updates (status, insights). Does not recompute effect — uses computed `effect`. Details — **`beast/_9_Conscience/about_gestalt.md`**.

## Closed frame effect and incomplete rules (zeros)

- After `closeLastFrame`, frame `effect` is **always a number** in **[-10, +10]** (`clampEpisodeFrameEffect` in `episodic_memory.js`): either from `getDiffImportance()` delta vs saved `diffBefore`, or **0** if base missing (neutral score).
- If at close there is still no **action image (AID)** and/or **response stimulus**, `episodicFrameFillRuleZerosForIncompleteClose` writes **0** into those fields (open frame held `null`). Frame stays in `Episodes` history, not removed.
- **Wait timeout without reaction** (`EpisodicMemory_onPulse`): frame **stays** in array — zeros set, `closeLastFrame(null)` (like with reaction but no operator answer).
- On **new OR stimulus** with previous frame open, previous closed with `episodicFrameFillRuleZerosForIncompleteClose(prev)` and `closeLastFrame(stimulusImageId)` for new winner — answer for “old” frame comes from new stimulus.
- In **compact** file/IndexedDB serialization, explicit **"0"** in action/response fields parses as numeric **0** (`parseIntOrNull`), distinct from empty (`null`).

## Clone persistence (IndexedDB + backup)

`abstract_images.js` state in IndexedDB (`BEAST_AbstractImages_DB`, `openDatabase`, one cached connection — like action images). Write: per pulse **right after** `closeLastFrame` (`AbstractImages_flushIndexedDB`) and on `beforeunload` if `absDirty`. On `put` error, snapshot to **localStorage** (`BEAST_AbstractImages_LS`); if IndexedDB empty on load, restore from backup. Full file snapshot key **`AbstractImagesState`**.

## “abstr” indicator in info picture

Counter shows **clone count** from `AbstractPerceptionImages` + `AbstractActionImages` (created on **closing** EP frames). Extra suffix `+N` — `Abstractions` array (`mental_automatism.js`). Click opens summary for all three sets.

## Link to abstract images (`abstract_images.js`)

- On **every** `closeLastFrame`, `AbstractImages_cloneFromEpisodeFrame(last)` creates or strengthens (average `meanImportance`, `count`) a **perception** abstraction for `(perceptionNodeId, stimulusImageId)`.
- **Action** abstraction updates only if `actionImageId` is nonzero; **0** after zero-fill means no AID — no action clone.
- **`semanticStructure`** per abstraction is `{ frames: [...] }`: per **(perception branch node, `situationId`)** stores best episodic rule snapshot (`ruleKind: episodic`, pick by larger `effect`) or teacher (`ruleKind: teacher`, `responseStimulusImageId` on AID; trust not via `effect`). Updates in `AbstractImages_cloneFromEpisodeFrame` via `AbstractImages_upsertSemanticRuleFromEpisodeFrame`; level-3 teacher fallback also `AbstractImages_activateTeacherRuleOnAbstractions` (clones for current FinalImage and rule AID). **Level 3:** `AbstractImages_findRuleFrameMatchingContext` for shortcut / mental automatism; motor on that frame only if frame “positive” per `conscience_level_3_semanticStructureFrameAllowsMotor` (teacher or episodic with `effect > 0`). Else semantics+EP and teacher path. While cycle waits for EP after automatism, full level 3 does not re-run (see `about_conscience.md`).
- **Operator answer after automatism (`conscience_level_2_operatorAnswerPipeline`):** on numeric `effect` and matching `semanticStructure` frame (branch, situation, stimulus), **`AbstractImages_applyEpisodeEffectToSemanticContextAbstractions`** averages `meanImportance` on perception/action clones (positive strengthens, negative weakens). On **positive** `effect`, **`MentalAutomatizms_tryCreateFromSemanticStructureRule`** — mental automatism; both also when **`goalImageId === 0`** (level 3).
- `MentalRules_registerFromEpisodeFrame` (`mental_automatism.js`): uses `abstractActionId || abstractPerceptionId`, so mental rule can still strengthen on perception-only abstraction without AID.

## EP chain stimulus priority (OR and consciousness)

Consecutive **suffix** of `Episodes` where **each** has a recorded **reaction** (`actionImageId`) forms a **connected chain**. If suffix length ≥ `EpisodicMemory_chainPriorityMinFrames`, all their `stimulusImageId` and `responseStimulusImageId` get **priority**:

- in **OR**, **no** competition hysteresis subtraction; salience **boosted** (`findMostActualStimulus` in `orientation_reflex.js`);
- on **main consciousness** start (`stimuls_consciousness`), **no** dampening multipliers (theme/situation mismatch, ImportantProblem) and interrupt threshold uses “equal salience” (ratio 1) so the chain is not cut by unrelated stimuli without reaction/answer. For other stimuli, “thought silence” applies **only while main cycle is not `expired`**; OR winner is flagged in context and not cut by that threshold (see **about_episodic_memory_rules.md** and **about_conscience.md**).

More — **about_episodic_memory_rules.md** (chains and interruption).

## Related modules

- Frame creation from **OR** (_8_Hippocampus) via save_episodic_memory.
- actionImageId fill from **genetic_reflexes_engine** (`EpisodicMemory_setLastFrameActionFromActionId`) on reaction.
- Last frames, bar, buttons in **_7_perception_tree** (`updateActiveBranchView`); bar visibility per session wait rules.
- **EP → automatisms:** (1) On reflex (including delayed) `setLastFrameActionFromActionId` creates automatism for action image on branch with zero usefulness; first automatism for branch becomes default. (2) On frame close (response during wait or timeout), computed effect updates default automatism usefulness via addUsefulnessSample (average); see **shared effect** above. If default automatism ran then response came — same default gets another usefulness sample (averaged).

## Detailed rules

Full frame rules, test mode, OR and CR links — **about_episodic_memory_rules.md** (**§9** — effect, rule zeros, abstractions).

## Files

- **episodic_memory.js** — Episodes array, save_episodic_memory, closeLastFrame, isInWaitingPeriod, setLastFrameActionFromActionId, persistence (IndexedDB, compact file), reset and test UI.
