# Beast demos (`/demos`)

Standalone **`.htm` tutorials**: mock fragments of the control panel + scripted steps (`createDemoRunner`) + **`sys/arrows.js`** for animated arrows.

- **No** `beast/*.js`, **no** IndexedDB.
- After large changes to **`index.html`** layout or shared CSS, skim each file in `modules/` (~5 min) and adjust copied classes/markup if the real panel moved.

Entry: **`demo.html`** (list of demos).

### Controls (injected by `demo-runner.js`)

- **Next** — manual step-by-step frame switching.
- **Start**: first shows the screen hint (`0 / N`); **▶** starts autoplay from the **first frame** without using “Next”; “Next” manually also starts from the first frame.
- **Round icon** — toggle **autoplay**; default pauses are **~2x shorter** than before (`autoTimeFactor: 0.5`).
- **Speed slider** — left side makes the frame longer, right side shorter. Base: `options.baseReadMs` (26s); per-frame step: `readTimeMs`; acceleration: `options.autoTimeFactor` (0.5 = twice as fast).
