/**
 * createDemoRunner(steps, options) — plaque, “Next”, icon-based autoplay, speed controller.
 * DOM: #demoPlaque, #demoPlaqueTitle, #demoPlaqueBody, #demoNextBtn, #demoProgress
 * Optional: #demoAutoToggle, #demoSpeedRange, #demoSpeedHint — otherwise the block is created in bindDom().
 *
 * steps[]: { title, html, readTimeMs (pause for a frame in autoplay mode), manualOnly, durationMs (legacy),
 *            onEnter(ctx), onLeave(ctx) }
 * ctx(): scrollIntoView(el, opts?) — scroll the page to an element (for long mock layouts with arrows).
 *
 * options:
 *   baseReadMs — base pause for reading/understanding a frame (default 26000)
 *   minStepMs / maxStepMs — bounds after speed calculation (8000 / 90000)
 *   autoTimeFactor — duration multiplier for autoplay mode (default 0.5 = 2x faster than base)
 *   onComplete
 *
 * Modes:
 *   Autoplay OFF — like before: only “Next” (and legacy timer if durationMs>0 and !manualOnly)
 *   Autoplay ON — after each frame automatic transition via effectiveDuration; “Next” skips the frame.
 *
 * Speed: slider 0–100 → tempo multiplier ~0.42…2.1 relative to base (slower left = longer frame).
 * Start: idx=-1, plaque hint; first frame starts via ▶ or “Next”.
 */
(function (global) {
  'use strict';

  function createDemoRunner(steps, options) {
    options = options || {};
    var defaultDur = options.defaultDurationMs != null ? options.defaultDurationMs : 14000;
    var baseReadMs = options.baseReadMs != null ? options.baseReadMs : 26000;
    var minStepMs = options.minStepMs != null ? options.minStepMs : 4000;
    var maxStepMs = options.maxStepMs != null ? options.maxStepMs : 90000;
    /** Overall autoplay acceleration: 0.5 ≈ 2x faster than the old base */
    var autoTimeFactor = options.autoTimeFactor != null ? options.autoTimeFactor : 0.5;

    var idx = -1;
    var timerId = null;
    var isAuto = false;

    var plaque = null;
    var titleEl = null;
    var bodyEl = null;
    var nextBtn = null;
    var progressEl = null;
    var autoBtn = null;
    var speedRange = null;
    var speedHint = null;

    function $(id) {
      return document.getElementById(id);
    }

    function getPaceFromSlider() {
      if (!speedRange) return 1;
      var v = parseInt(speedRange.value, 10);
      if (isNaN(v)) v = 32;
      // 0 = very slow (long pause), 100 = fast (short pause)
      return 0.42 + 1.68 * (v / 100);
    }

    function getEffectiveDuration(step) {
      var base = step.readTimeMs != null ? step.readTimeMs : baseReadMs;
      var pace = getPaceFromSlider();
      var ms = Math.round((base / pace) * autoTimeFactor);
      if (ms < minStepMs) ms = minStepMs;
      if (ms > maxStepMs) ms = maxStepMs;
      return ms;
    }

    function updateSpeedLabel() {
      if (!speedHint || !speedRange) return;
      var v = parseInt(speedRange.value, 10);
      if (isNaN(v)) v = 32;
      if (v < 20) speedHint.textContent = 'very slow';
      else if (v < 40) speedHint.textContent = 'slow';
      else if (v < 60) speedHint.textContent = 'normal';
      else if (v < 80) speedHint.textContent = 'faster';
      else speedHint.textContent = 'fast';
    }

    function setAutoUi() {
      if (!autoBtn) return;
      autoBtn.setAttribute('aria-pressed', isAuto ? 'true' : 'false');
      autoBtn.title = isAuto ? 'Pause autoplay' : 'Enable autoplay';
      var play = autoBtn.querySelector('.demo-auto-icon-play');
      var pause = autoBtn.querySelector('.demo-auto-icon-pause');
      if (play && pause) {
        play.style.display = isAuto ? 'none' : 'inline';
        pause.style.display = isAuto ? 'inline' : 'none';
      }
    }

    function ensureAutoControls(actionsRow) {
      if (!actionsRow || $('demoAutoWrap')) return;
      var wrap = document.createElement('div');
      wrap.id = 'demoAutoWrap';
      wrap.className = 'demo-auto-wrap';
      wrap.innerHTML =
        '<button type="button" class="demo-auto-toggle" id="demoAutoToggle" aria-pressed="false" title="Autoplay">' +
        '<svg class="demo-auto-icon-play" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">' +
        '<path fill="currentColor" d="M8 5v14l11-7z"/></svg>' +
        '<svg class="demo-auto-icon-pause" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" style="display:none">' +
        '<path fill="currentColor" d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>' +
        '</button>' +
        '<div class="demo-speed-block">' +
        '<div class="demo-speed-caption"><label class="demo-speed-label" for="demoSpeedRange">Speed</label> ' +
        '<span id="demoSpeedHint" class="demo-speed-hint"></span></div>' +
        '<input type="range" id="demoSpeedRange" min="0" max="100" value="32" ' +
        'title="Left — longer frames; right — shorter">' +
        '</div>';

      var prog = $('demoProgress');
      actionsRow.insertBefore(wrap, prog ? prog.nextSibling : actionsRow.firstChild);

      autoBtn = $('demoAutoToggle');
      speedRange = $('demoSpeedRange');
      speedHint = $('demoSpeedHint');

      if (autoBtn) {
        autoBtn.onclick = function () {
          if (!isAuto) {
            isAuto = true;
            setAutoUi();
            updateSpeedLabel();
            clearTimer();
            if (idx < 0) {
              goNext(true);
              return;
            }
            scheduleIfAutoDeferred();
            return;
          }
          isAuto = false;
          setAutoUi();
          updateSpeedLabel();
          clearTimer();
        };
      }
      if (speedRange) {
        speedRange.oninput = function () {
          updateSpeedLabel();
          if (isAuto && idx >= 0 && idx < steps.length) {
            clearTimer();
            scheduleIfAutoDeferred();
          }
        };
      }
      setAutoUi();
      updateSpeedLabel();
    }

    function bindDom() {
      plaque = $('demoPlaque');
      titleEl = $('demoPlaqueTitle');
      bodyEl = $('demoPlaqueBody');
      nextBtn = $('demoNextBtn');
      progressEl = $('demoProgress');
      var actionsRow = document.querySelector('.demo-plaque-actions');
      ensureAutoControls(actionsRow);
      autoBtn = $('demoAutoToggle');
      speedRange = $('demoSpeedRange');
      speedHint = $('demoSpeedHint');

      if (nextBtn) {
        nextBtn.onclick = function () {
          goNext(true);
        };
      }
    }

    function clearTimer() {
      if (timerId) {
        clearTimeout(timerId);
        timerId = null;
      }
    }

    function scheduleIfAuto() {
      if (!isAuto || idx < 0 || idx >= steps.length) return;
      var step = steps[idx];
      var ms = getEffectiveDuration(step);
      timerId = global.setTimeout(function () {
        timerId = null;
        goNext(false);
      }, ms);
    }

    /** After onEnter and arrow rendering — the next-frame timer */
    function scheduleIfAutoDeferred() {
      if (!isAuto || idx < 0 || idx >= steps.length) return;
      global.setTimeout(function () {
        scheduleIfAuto();
      }, 0);
    }

    function setProgress() {
      if (!progressEl || !steps.length) return;
      progressEl.textContent = idx + 1 + ' / ' + steps.length;
    }

    function ctx() {
      return {
        stepIndex: idx,
        step: steps[idx],
        goNext: function () {
          goNext(true);
        },
        clearArrows: function () {
          if (global.DemoArrows) global.DemoArrows.clear();
        },
        showArrows: function (fn) {
          if (typeof fn === 'function') fn();
        },
        isAuto: function () {
          return isAuto;
        },
        scrollIntoView: function (el, opts) {
          if (!el || typeof el.scrollIntoView !== 'function') return;
          global.requestAnimationFrame(function () {
            try {
              el.scrollIntoView(opts || { block: 'center', behavior: 'smooth' });
            } catch (e) {
              try {
                el.scrollIntoView(true);
              } catch (e2) {}
            }
          });
        }
      };
    }

    /**
     * @param {boolean} userAction — true: user clicked “Next”; false: autoplay timer fired
     */
    function goNext(userAction) {
      clearTimer();
      if (idx >= 0 && idx < steps.length && steps[idx] && typeof steps[idx].onLeave === 'function') {
        try {
          steps[idx].onLeave(ctx());
        } catch (e) {
          if (global.console && global.console.error) global.console.error(e);
        }
      }
      idx++;
      if (idx >= steps.length) {
        isAuto = false;
        setAutoUi();
        if (titleEl) titleEl.textContent = 'Done';
        if (bodyEl) {
          bodyEl.innerHTML =
            '<p>Demo finished. You can return to <a href="../demo.html">the demo list</a>.</p>';
        }
        if (nextBtn) nextBtn.style.display = 'none';
        var aw = $('demoAutoWrap');
        if (aw) aw.style.display = 'none';
        setProgress();
        if (typeof options.onComplete === 'function') options.onComplete();
        return;
      }

      var step = steps[idx];
      if (titleEl) titleEl.textContent = step.title || '';
      if (bodyEl) bodyEl.innerHTML = step.html || '';
      if (nextBtn) {
        nextBtn.style.display = 'inline-block';
        nextBtn.textContent = 'Next';
      }
      setProgress();

      if (typeof step.onEnter === 'function') {
        try {
          step.onEnter(ctx());
        } catch (e2) {
          if (global.console && global.console.error) global.console.error(e2);
        }
      }

      if (isAuto) {
        scheduleIfAutoDeferred();
        return;
      }

      var dur = step.durationMs != null ? step.durationMs : defaultDur;
      var manualOnly = step.manualOnly === true || step.durationMs === 0;
      if (dur > 0 && !manualOnly) {
        timerId = global.setTimeout(function () {
          goNext(false);
        }, dur);
      }
    }

    function start() {
      bindDom();
      idx = -1;
      isAuto = false;
      if (autoBtn) {
        autoBtn.style.display = '';
        setAutoUi();
      }
      var aw = $('demoAutoWrap');
      if (aw) aw.style.display = '';
      if (nextBtn) nextBtn.style.display = 'inline-block';
      if (global.DemoArrows) global.DemoArrows.init();
      if (titleEl) titleEl.textContent = 'Demo';
      if (bodyEl) {
        bodyEl.innerHTML =
          '<p class="demo-start-hint">Press <strong>▶</strong> to autoplay starting from the first frame, or “Next” for a manual step.</p>';
      }
      setProgressStart();
    }

    function setProgressStart() {
      if (!progressEl || !steps.length) return;
      progressEl.textContent = '0 / ' + steps.length;
    }

    return { start: start, goNext: function () { goNext(true); }, setAuto: function (v) { isAuto = !!v; setAutoUi(); } };
  }

  global.createDemoRunner = createDemoRunner;
})(window);
