# Beast control panel — operator guide

This document describes the “Beast creature, comms panel” UI in `index.html`: screen areas, state indication, messages, and all stimulus controls. Behavior is tied to code in `beast/` (see also `manuals/Mad_programmer_manual.md`).

---

## Introduction: what Beast is and how it “lives”

**Beast** is a browser model of a creature with discrete **pulse** time (≈1 s): each pulse updates vitals, basic behavior contexts, the perception tree, the consciousness cycle dispatcher, episodic and semantic memory, reflexes, and automatisms.

- **Life** is measured by the pulse counter `Cur_puls_val` (stored in `localStorage` and may be included in the memory file).
- **Development** is accumulated experience: semantic samples per stimulus, perception-tree branches, episodes, abstractions, motor and mental automatisms, goals, gestalts; as experience grows, readiness for the **orientation reflex (OR)**, consciousness levels 2–4, and scenarios (play, teach, sleep, dreams) change.

The panel is the **operator’s channel to the model**: you set stimuli and modes, read vitals, contexts, the info picture and cycle logs, and save/load memory.

---

## 1. Purpose and capabilities

**Purpose**

- Set the **external situation** via motivating, positive, negative, and neutral stimuli (including “Play” / “Teach” modes).
- Observe **somatic state** (vitals), **emotional-contextual** state (basic contexts, Bad / Norm / Well), **cognitive context** (perception tree, info picture, Beast activity).
- Control **holding** of baseline state (B / W), measure **diff** importance, enable **sleep** with limited stimuli.
- Work with **memory**: save/load JSON to disk (pulse, vitals, semantics, tree, episodes, reflexes, etc. — registry `BEAST.persistentModules` in `beast/date/saving_ui.js`).
- For debugging and training: reset conditional reflexes and semantics (**Uh**, **Sx**), test consciousness interruption (**Test**), episodic-memory test mode (**t**), view stimulus understanding model (**i** on button).

**Capabilities are limited by sleep design**: in sleep mode only pre-allowed stimuli are clickable (see sleep section).

---

## 2. How state and other indicators are shown

### 2.1. Top row

| Element | Meaning |
|--------|--------|
| **Green circle + number** | Life pulse: blinking circle (`pulseCounter`) = pulse count. |
| **Blue dot by “Save”** (`saveIndicator`) | IndexedDB and/or disk write in progress; brief display (≥ ~300 ms). |
| **Save / Load** | Export/import memory to a chosen folder (File System Access API). |

### 2.2. Vitals (life parameters)

- Row of **0–100%** indicators: color from light green (0) toward red (100).
- Labels: short **name** and full **title** in tooltip.
- **Click a vital** — dialog to set **value** and **shift** (drift per pulse).
- **×** on the header — reset vitals to defaults (with confirmation).

Vital names (Id 1–10): Wounds, Suffocation, Thirst, Heat, Cold, Hunger, Stress, Rut, Communication, Interest (see `beast/_1_Genetic_vitals/vitals.js`).

### 2.3. Basic behavior contexts

- Header: **“Basic behavior contexts”** + **Bad / Norm / Well** + **“improved/worsened by …”** from `DiffZnacher`.
- **Indicators** — rectangles with context name: inactive gray; active light green with glow.
- **Block border**: Bad — pink; Well — green; **context holding** (yellow background) — pulse counter top-center and yellow header/row.
- **Buttons** (header right): **Sleep**, **B** (hold Bad), **W** (hold Well), **diff** — see §4 and §6.
- **Counter** above B/W: remaining pulses of Bad or Well hold.

### 2.4. Answer-wait bar

Thin blue bar (`epWaitingProgressFill` in `epWaitingProgressWrap`) — progress of **operator answer wait** after an episodic frame (`response_waiting_period`). Tooltip on wrapper in `title`.

### 2.5. Active perception-tree branch

- Branch text (`perceptionTreeActiveBranchText`), button **t** — episodic-memory formation test mode (highlights active state).
- Episodes line (`perceptionTreeEpisodesLine`), button **✕** — clear all episodic memory (shown per UI logic).
- **`epTotalCountLabel`** — total episode count (if filled by code).
- **📋** — copy block contents to clipboard.

### 2.6. Beast activity

Gray block with current activity text (multiline). Right: **📋** (copy), **Uh** (clear all conditional reflexes), **Sx** (clear all semantic memory). Border aligned with Bad/Well on the context row.

### 2.7. Information picture (extended row)

Under **“Information picture”**:

- **Blue bulb** (`infoThinkingIndicator`) — brief (~0.5 s) on consciousness events (`Info_thinkingFlash`).
- **Main cycle ID** — current main consciousness cycle id.
- **Pure background processes** — count of background cycles.
- **interrupt queue** — LIFO length of interrupted main cycles.
- Clickable counters: **bg:** — background cycle list; **auto:** / **m-auto:** / **abstr:** / **goals:** / **situations:** — detail dialogs; first four have **×** to clear motor/mental automatisms, abstractions, life-experience goals, situation images.
- **gest:** — gestalts; **fant:** — fantasy plot (detail on click).

### 2.8. Info-picture cell grid

Labeled cells; **yellow background** (`info-cell-active`) — significant/active value. **Click** opens detail (`Info_showDetail(...)`): mode, theme, situation, fantasy plot, problem, step, stimulus, Base, emotion, activity, plus **detectors** (critical vital, important problem, rule reaction, shock, sharp deterioration, play, teach, negative automatism effects, “bad”, console stimulus, search, teacher, operator ignore, dissatisfaction, misunderstanding, doubt, defense, fear, aggression, important object, mood, novelty, semantics, hard problem, action effects, answer wait, no-effect series, automatism usefulness, found automatism, etc.).

See `InfoPicture` in `beast/_9_Conscience/informing.js`.

---

## 3. How messages are shown

### 3.1. Static (in the page)

- Text in **“Beast activity”**, updated by consciousness and helpers.
- Labels, counters, **title** on buttons and cells (browser tooltips).
- **Information picture** and cells — steady reflection of `InfoPicture` after `Info_updateView()`.

### 3.2. Modal dialogs

Module `beast/sys/alerts/alerts.js`:

| Function | Purpose |
|---------|------------|
| `show_alert(message, timeShow, options)` | HTML message; `timeShow > 0` — auto close after N ms; `timeShow === 0` — “Close” button. |
| `show_confirm(message, callback)` | Yes / No → `callback('OK' \| 'NO')`. |
| `show_prompt(message, callback)` | Text input → `callback(value)`. |
| `close_alert()` | Close active dialog. |

Special **`dialogType: 'cyclelog'`** — **main cycle log** window (last `debugLog` lines), updates as written; user close marks log suppressed for that cycle. Does not stack over arbitrary other modals.

More alert examples:

- Click **Bad/Norm/Well** in context header — `DiffZnacher`, integral importance.
- **diff** — old/new values and normalized difference.
- **i** on stimulus — **understanding model** (semantics): summary or frame on **z** click.

---

## 4. All stimulus buttons and rows

Behavior from code (`stimuls.js`, `stimuls_ui.js`, `genetic_reflexes.js`, `genetic_reflexes_engine.js`, `sleep_mode.js`).

### 4.1. General row rules

- Each row: header and **×** on header — clear **all** active stimuli **of that row**.
- **Double-click any stimulus button** (any row) — **clear all stimuli in all four rows** (`clearAllStimuli`), except in sleep (blocked).
- **Active** button: stronger fill and colored glow (`box-shadow`).
- **OR readiness**: **2px** border and tooltip “Participates in orientation reflex” if for linked `FinalImage` remaining activations to threshold = 0; else show remaining count (or “unknown” on early pulses).
- On **OR/consciousness start** on button — brief **flash** glow top/bottom for one pulse.
- **Sleep mode**: disallowed buttons faded and non-clickable; allowed ones outlined. Allowed pairs: motivation **Punishment** (Id 8); negative **Howl** (8), **Siren** (10), **Growl** (13), **Fire** (20). First click on allowed stimulus **exits sleep**, then processes normally.

### 4.2. Global stimulus ids

To avoid collisions across arrays, memory uses **global ids**: `type * 1000 + localId`, type: 1 motivation, 2 positive, 3 negative, 4 neutral (`stimulus_global_id.js`).

### 4.3. Motivating stimuli (`stimulsRow`)

**bg** in data: **1** pink base, **2** white/neutral, **3** light green. Each row entry has **vitalID** and **shift** (long exposure via reflex engine — see `genetic_reflexes_engine.js`).

| Id | Name | vitalID | shift (table) | Note |
|----|------|---------|-----------------|------|
| 1 | Food | 6 | 0 | On activate: stress −20, SetWellForHolding; branch automatism cache reset with Food/Water. |
| 2 | Water | 3 | 0 | Same as Food. |
| 3 | Warmth | 4 | −1 | |
| 4 | Cold | 5 | −1 | |
| 5 | Air | 2 | −2 | |
| 6 | Treatment | 1 | −0.5 | |
| 7 | Reward | 7 | 0 | Strong stress drop + hold Well. |
| 8 | Punishment | 7 | 0 | Stress rise + hold Bad. |
| 9 | Pleasant | 7 | 0 | Stress −30; effect table may list vitalID 17 (if vital missing, delta may not apply). |
| 10 | Unpleasant | 7 | 0 | Stress +30. |
| 11 | Calm | 7 | 0 | |
| 12 | Clear | 7 | 0 | |
| 13 | Unclear | 7 | 0 | |
| 14 | Forgive | 7 | 0 | |
| 15 | Laughter | 7 | 0 | |
| 16 | Joy | 7 | 0 | |
| 17 | Crush | 8 | 2 | |
| 18 | Ignore | 7 | 0 | |
| 19 | Play | 11 | 0 | Not via `ActiveMotivationStimuls`: toggles **isGameMode**, excludes **Teach**; on — effect 103. |
| 20 | Teach | 12 | 0 | **isAuthoritarianEducation**, excludes **Play**; effect 104. |

On **activation** of a motivating stimulus (except Play/Teach toggle), **one-shot** effects from `StimulMotivarion_EffectsToBContexts` run (vital deltas 1–10, codes 101–104: hold Well/Bad, play/teach mode).

### 4.4. Positive stimuli (`stimulsRowPositiv`)

Background light green; active — stronger green glow. On activate, **contexts** from `StimulPositiv_EffectsToBContexts` (1–20 = basic context ids for hold period; 101–104 as motivation).

| Id | Name |
|----|------|
| 1 | Smile |
| 2 | Child |
| 3 | Puppy |
| 4 | Flower |
| 5 | Sun |
| 6 | Butterfly |
| 7 | Berry |
| 8 | Bell |
| 9 | Laughter |
| 10 | Singing |
| 11 | Melody |
| 12 | Rustle |
| 13 | Purr |
| 14 | Sweetness |
| 15 | Scent |
| 16 | Warmth |
| 17 | Breeze |
| 18 | Coolness |
| 19 | Touch |
| 20 | Caress |

### 4.5. Negative stimuli (`stimulsRowNegative`)

Pink background; active — stronger pink glow. Contexts: `StimulNegative_EffectsToBContexts` (incl. 102 = SetBadForHolding for some buttons).

| Id | Name |
|----|------|
| 1 | Malice |
| 2 | Blood |
| 3 | Ruin |
| 4 | Spider |
| 5 | Snake |
| 6 | Mushroom |
| 7 | Rot |
| 8 | Howl |
| 9 | Moan |
| 10 | Siren |
| 11 | Squeak |
| 12 | Creak |
| 13 | Growl |
| 14 | Shards |
| 15 | Lightning |
| 16 | Dagger |
| 17 | Bitterness |
| 18 | Sourness |
| 19 | Stench |
| 20 | Fire |

**“Test”** button (red, after row): `runTestNegativeInterrupt()` — hard test of consciousness interruption with maximal negative significance; disabled in sleep.

### 4.6. Neutral stimuli (`stimulsRowNeutral`)

Gray; on activate **do not** call `StimulPositiv/Negative_EffectsToBContexts` (only accumulate `ActiveNeutralStimuls` for image and OR).

| Id | Name |
|----|------|
| 1–9 | Brown … White (colors) |
| 10–18 | Circle … Triangle (shapes) |
| 19–23 | Noise \| Whistle \| Hum \| Ring \| Vibration |
| 24–31 | Book \| Table \| Chair \| Bed \| Bulb \| Plant \| Animal \| Human |

### 4.7. “i” badge on stimuli

Small **i** in corner: opens **understanding model** (semantic frames, z, episode count); click **z** for frame detail.

### 4.8. Other UI buttons (not stimulus rows)

| Button | Action |
|--------|--------|
| **Sleep** | `SleepMode_toggle`; page gray; only Sleep context (id 15); auto entry possible when “fin” cycles high (`ConsciousnessFinCyclesTotal` > 100). |
| **B** | `SetBadForHolding` — hold Bad; info picture target mode + thought “bulb” flash. |
| **W** | `SetWellForHolding` — hold Well. |
| **diff** | `getDiffImportance()` and show differences in alert. |
| **Save / Load** | See §2.1. |

---

## 5. How development shows in the UI

- **New stimuli** — add rows to `StimulMotivarion` / `StimulPositiv` / `StimulNegative` / `StimulNeutral` and effect tables; UI rebuilds on load (`stimuls_ui.js`).
- **OR readiness** — semantics accumulation updates borders/tooltips; first cycle may show **main cycle log** modal.
- **Info picture** — new detectors in `InfoPicture` → new cells in `index.html` and branches in `Info_updateView` / `Info_showDetail` (`informing.js`).
- **Consciousness levels 2–4**, gestalt, abstractions — new counters (**gest:**, **fant:**, mental automatisms, etc.) and alert behavior on click.
- **Sleep and dreams** — separate branch: Sleep button, limited stimuli, `sleep_dream_process.js` scenarios.

---

## 6. How to grow Beast: sequence and focus

Suggested order for **operator-researcher** (no code):

1. **Pulse and vitals** — Bad/Well scenarios, contexts, `DiffZnacher`.
2. **Stimuli** — motivation and neutral first, then positive/negative; watch OR readiness and model (**i**).
3. **Tree and info picture** — how Base, emotion, activity, step, stimulus relate.
4. **Episodic memory** — **t** for tests, wait bar, close frames with answers; read `about_episodic_memory*.md`.
5. **Sleep** — use deliberately for dream scenarios; remember limited stimuli.
6. **Saves** — save memory to file before experiments; **Sx** and **Uh** are irreversible for the session without load.

For **developers**:

- Respect **script order** in `index.html` (end-of-file comment required).
- New persistent data — one entry in `BEAST.persistentModules`.
- Update `about_*.md` and `PROJECT_STATE_FOR_NEW_CHAT.md` with logic changes.
- Architecture — **`manuals/Mad_programmer_manual.md`**.

---

*This document matches the BEAST codebase; if UI and behavior diverge, the repository implementation wins.*
