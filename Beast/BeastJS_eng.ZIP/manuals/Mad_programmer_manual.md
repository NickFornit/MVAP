# Mad Programmer Manual — Beast

A guide for anyone who is **seriously** digging into the **Beast** code (“Beast creature, comms panel”) and plans to extend it. It is not a substitute for sources or a copy of every module — it is a **thinking map**, principles, and **where the truth lives** (in code and `about_*.md`).

---

## 1. Why this document

- The project is **large**, links are **non-obvious**, script load order **matters**.
- Much state lives in **`window` / globals** — without a mental model you break what “happened to work”.
- **`PROJECT_STATE_FOR_NEW_CHAT.md`** in the root is a **compressed snapshot** for AI and people; **this manual** is broader: philosophy, layers, traps, how to grow features.

If you change architecture, update **`PROJECT_STATE_FOR_NEW_CHAT.md`** and the relevant **`beast/**/about_*.md`** (including **`beast/_12_Sleep/about_sleep.md`** for sleep changes).

---

## 2. What Beast is, conceptually

**Beast** is a browser app modeling **organism ↔ stimuli ↔ orientation reflex (OR) ↔ consciousness processing ↔ episodic memory (EP)**.

Principles:

1. **Time is discrete** — “pulse” (`global.cpuls`, `Cur_puls_val`). Almost everything important ties to the pulse or a UI event between pulses.
2. **Body state** — vitals, deviation from norm, integral importance, baseline **Bad / Norm / Well** (`BadNormWell`).
3. **Contexts** — compact emotional-behavioral tags (basic contexts); from them “emotion” and the tree branch are built.
4. **Stimuli** — typed (motivation, positive, negative, neutral); global ids **do not collide** across arrays (see `StimulusGlobalId_*`).
5. **OR** — stimulus competition by salience, semantic “maturity” threshold (`OR_well_known`), exceptions for some scenarios (see OR code).
6. **Consciousness** — not one call but a **cycle registry** (`ConsciousnessCycles`), dispatcher steps, main vs background cycles, `expired`, cycle log.
7. **Memory** — semantics (importance by condition), episodes (frames with `effect`, stimulus, action, operator answer), abstractions and rules for higher levels.

Implementation is **spread** across `beast/_1_` … `beast/_12_` — the number hints the layer (from “body” toward “consciousness, memory, sleep”).

---

## 3. `beast/` directory map (layers)

| Folder | Role |
|--------|------|
| `_1_Genetic_vitals` | Vitals, scales, shock, death, prep for calculations |
| `_2_Genetic_basic_styles` | Basic contexts, styles, **`prepare.js`**: `BadNormWell`, `GetBadNormWell`, `SetWellForHolding`, holds, `getDiffImportance` |
| `_3_perception` | Stimulus lists, stimulus UI, activation, OR link |
| `_4_actions` | `BasicActions`, effectors, mirror actions |
| `_5_Genetic__reflexes` | Reflex tables, **`genetic_reflexes_engine.js`**: `processGeneticReflexes`, `runActionImage`, `startAction` |
| `_5_2_synonyms_reflexes` | Conditional (synonym) reflexes |
| `_6_semantic_memory` | FinalImage, semantic index, experience registration |
| `_7_perception_tree` | Perception tree; terminal node = “branch” for EP and automatisms |
| `_8_Hippocampus` | Hippocampus, **`orientation_reflex.js`** — OR |
| `_9_Conscience` | Info picture, detectors, **consciousness levels 2–4**, gestalt, abstractions, attention channel |
| `_10_Episodic_memory` | EP frames, answer wait, closing frames, `effect` |
| `_10_actions_image` | Action images (AID), link to goals |
| `_11_Automatizms` | Branch automatisms, AID binding |
| `_12_Sleep` | Sleep mode (Sleep context, stimulus limits, auto-sleep by fin-cycle count), dreams over empty EP frames |

Plus: **`beast/puls.js`** — tick heart; **`beast/docs/`** — project notes and analysis.

---

## 4. Entry point and sacred script order

- Entry: **`index.html`** at repo root.
- At the end of **`body`**, **`index.html`** script order is a **contract**. Reordering leaves some globals `undefined` at init.

Rule: **dependents load below**. Examples:

- `consciousness_dispatcher.js` defines the cycle registry and dispatch.
- `gestalt.js` must be **before** `episodic_memory.js` (hook `Gestalt_onEpisodeFeedbackClosed` in `closeLastFrame`).
- “Level” modules depend on info picture and EP.

**Practice:** before a big refactor, export the `<script src=...>` list from `index.html` and verify the chain by hand.

---

## 5. Pulse: what happens each tick

**`beast/puls.js`** (and related calls):

- increment pulse counter;
- update vitals/contexts (`getActiveBasicContexts`, etc.);
- if sleep active — stimulus visuals and **`SleepDreams_onPulse`** (dream machine **before** consciousness dispatcher so the same tick runs `info_fantasizming` for the sleep main cycle);
- genetic and conditional reflexes;
- **consciousness dispatcher** (`Consciousness_runOneStep`, etc.);
- episodic memory (wait ticks, frame closing).

**Principle:** if logic “belongs in the pulse”, do not duplicate it only in UI — UI and pulse must agree or you get races (e.g. info picture vs reflex).

---

## 6. Global state: discipline

1. **`beast/about_global_variables.md`** — key `window.*` reference. Before adding a global, ask: **must it be on `window`**, or is a module closure enough?
2. **Naming** — mix of Russian comments and English ids exists; new code should **match the file** you edit.
3. **Serialization** — vitals, tree, semantics, EP, goals, AIDs, automatisms go to **IndexedDB** / files. Any new `window` entity should either **join save/load** or be clearly “session-only” (and document that).

---

## 7. Data flow “textbook style”

Simplified (reality branches more):

```
Vitals → BadVitalsValue / contexts → BasicContextsActived
       → BadNormWell, emotion (Emotions_*)
       → perception-tree path → terminal node (branchId)
Stimuli (UI) → global stimulus ids → FinalImage
       → OR (competition, thresholds) → actual_stimul_ID
       → stimuls_consciousness → consciousness cycles / automatisms
       → EP frame, effect, frame close → semantics / abstractions / gestalt
```

**Orientation reflex** (`orientation_reflex.js`) is not decoration — it is the **hub**: consciousness start, reflex block for two pulses, delayed reflex queue, second pass after answer in wait (see `about_episodic_memory_rules.md`).

---

## 8. Info picture and detectors

- **`informing.js`** — `InfoPicture`, view updates.
- **`info_detectors.js`** — computed fields: `criticalVital`, `badState`, play/teach modes, etc. Situations in **`situatioms_tree.js`** assemble from **detector components**.

**Principle:** detectors should be **idempotent given their inputs** (vitals, `BadNormWell`, flags). If you overlay meaning (e.g. food suppresses critical indicator when Well), document **briefly** in code why.

---

## 9. Consciousness levels 2–4 — where to look

| Level | File | Note |
|-------|------|------|
| Dispatcher, registry, log | `consciousness_dispatcher.js` | `Consciousness_cycleAppendLog`, `expired`, `force` |
| Attention channel, consciousness entry | `conscious_attention_channel.js` | interrupts, “thought silence” |
| Level 2 | `conscience_level_2.js` | survival, goals, operator answer, EP link |
| Level 3 | `conscience_level_3.js` | rule pipeline, EP wait, motor gates |
| Level 4 / gestalt | `conscience_level_4.js`, `gestalt.js` | see `about_gestalt.md` |
| Shared helpers | `infofunctions.js` | `info_automatismWithEpisodeFeedbackAndExpireCycle`, EP rule search |

Details and current agreements — **`beast/_9_Conscience/about_conscience.md`**, **`about_adaptivity_levels_2_4.md`**.

---

## 10. Episodic memory and action images

- **`episodic_memory.js`** — frames, wait, `effect`, operator link.
- **`actions_image.js`** — AIDs (`actionIds`, `finalImageId`). Life-experience goals in **`goals.js`** reference AIDs; after IndexedDB load **do not** lose id consistency.

**Principle:** if you add a new “single source of truth”, define it **once** (as with default goal “Cry” and AID with `actionIds: [1]`).

---

## 11. Debugging without going mad

1. **`global.cpuls` / `Cur_puls_val`** — pulse number in logs.
2. **`Consciousness_cycleAppendLog`** — human-readable main cycle log; remember **`expired`** and **`{ force: true }`**.
3. **EP test mode** (`EpisodicMemory_testMode`) — OR alerts (see `orientation_reflex.js`).
4. **“Beast activity”** block — text from genetic/conditional reflexes and automatisms (`setBeastActivityText`).

---

## 12. Typical traps (Madness Checklist)

| Symptom | Likely cause |
|---------|----------------|
| “Nothing happens” on stimulus | OR below `OR_well_known`, no terminal tree node, empty candidates |
| Duplicate objects in `window` | second `window.StimulMotivarion_GeneticReflexes = {...}` overwrote the first |
| Goal “Cry” but different action | **AID desync** after IndexedDB load and goal `actionImageId` |
| Genetic reflex does not fire | `automatismRanForBranchIds`, OR block, delayed reflex queue |
| Empty cycle log at start | `OrientationReflex_anyStimulusReadyForOr` and dispatcher auto-log conditions |

---

## 13. Growing the system safely

### New stimulus

1. Add to `stimuls.js` in the right array.
2. Wire effects in **`genetic_reflexes.js`** (internal and/or motor tables).
3. Ensure **global id** via `StimulusGlobalId_toGlobal`.
4. Adjust UI rules in `stimuls_ui.js` if needed.

### New action

1. `BasicActions` in **`effectors.js`** (if not mirror).
2. AID link via `ActionImages_registerReaction` / `getOrCreateActionImageId`.

### New consciousness branch

1. First decide **where in the pipeline** (level 2 vs 3, before/after EP wait).
2. Do not break the **`awaitingAutomatismEpisodeFeedback`** gate without reading `conscience_level_3.js` and `about_conscience.md`.

### Persistence

1. Find a similar module with `serialize/apply` and IndexedDB.
2. Do not forget **load order** — after restoring AIDs, refresh dependents (example: goals and AIDs).

---

## 14. Sleep mode (`beast/_12_Sleep`)

- **Purpose:** when Beast “sleeps”, only basic context Sleep is active, almost all stimuli blocked (exceptions — Punishment, Howl, Siren, Growl, Fire); **auto-sleep** at `ConsciousnessFinCyclesTotal > 100` (even with critical vitals — contexts overridden in `prepare.js`).
- **Dreams:** iterate **empty** EP frames (stimulus and AID present, no response stimulus and no numeric `effect`), newest → oldest; per frame — main cycle in **`passive`** and same **`info_fantasizming`** / **`PassiveMode_processUnderstandingModels`** as normal passive; then frame realization and reconstruction limit; **`SleepMode_exit(true)`** removes **background** consciousness cycles (`Consciousness_deleteAllBackgroundCycles`). Manual sleep exit does not touch background.
- **Docs:** **`beast/_12_Sleep/about_sleep.md`**; globals — **`beast/about_global_variables.md`**; script order — comment in **`index.html`** (`sleep_dream_process.js` after `fantasizming.js`).

---

## 15. What to read next (order)

1. **`PROJECT_STATE_FOR_NEW_CHAT.md`** — architecture snapshot.
2. **`beast/about_global_variables.md`** — globals dictionary.
3. **`beast/_10_Episodic_memory/about_episodic_memory_rules.md`** — OR, wait, chains.
4. **`beast/_8_Hippocampus/about_hippocampus.md`**
5. **`beast/_9_Conscience/about_conscience.md`**
6. **`beast/_6_semantic_memory/about_semantic_memory.md`**
7. **`beast/_11_Automatizms/about_automatizms.md`**
8. **`beast/_12_Sleep/about_sleep.md`** — if you touch sleep, sleep stimuli, or dreams.
9. Other `about_*.md` as needed.

---

## 16. Ethics of the “mad programmer”

- **Code is truth** — comments and `about_*` can lag; on conflict **trust code** and fix docs.
- **Small steps** — one scenario, one mental test, one “commit in spirit”.
- **Do not multiply globals** without need.
- **Respect the pulse** — if behavior “must happen right after click”, check order: UI → vitals/contexts → OR → pulse.

---

*Manual version: 2026-03-21 (sleep section `_12_Sleep`). Beast is alive; after major architecture changes update this file and `PROJECT_STATE_FOR_NEW_CHAT.md`.*
